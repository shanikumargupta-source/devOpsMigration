package com.vf.cove.document.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("ListOfFile")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ListOfFile")
public class ListOfFile implements Serializable {

	public static ListOfFile toDTO(String json) {
		return ObjectMapperUtil.readValue(ListOfFile.class, json);
	}

	public static ListOfFile unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(ListOfFile.class, json);
	}

	@Schema(example = "IP-VPN")
	public String getBusinessServiceName() {
		if (_businessServiceNameSupplier != null) {
			businessServiceName = _businessServiceNameSupplier.get();

			_businessServiceNameSupplier = null;
		}

		return businessServiceName;
	}

	public void setBusinessServiceName(String businessServiceName) {
		this.businessServiceName = businessServiceName;

		_businessServiceNameSupplier = null;
	}

	@JsonIgnore
	public void setBusinessServiceName(
		UnsafeSupplier<String, Exception> businessServiceNameUnsafeSupplier) {

		_businessServiceNameSupplier = () -> {
			try {
				return businessServiceNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessServiceName;

	@JsonIgnore
	private Supplier<String> _businessServiceNameSupplier;

	@Schema(example = "1b8841dddb41cb00cc1e79ab8c961998")
	public String getBusinessServiceSysID() {
		if (_businessServiceSysIDSupplier != null) {
			businessServiceSysID = _businessServiceSysIDSupplier.get();

			_businessServiceSysIDSupplier = null;
		}

		return businessServiceSysID;
	}

	public void setBusinessServiceSysID(String businessServiceSysID) {
		this.businessServiceSysID = businessServiceSysID;

		_businessServiceSysIDSupplier = null;
	}

	@JsonIgnore
	public void setBusinessServiceSysID(
		UnsafeSupplier<String, Exception> businessServiceSysIDUnsafeSupplier) {

		_businessServiceSysIDSupplier = () -> {
			try {
				return businessServiceSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessServiceSysID;

	@JsonIgnore
	private Supplier<String> _businessServiceSysIDSupplier;

	@Schema(example = "")
	public String getFileDescription() {
		if (_fileDescriptionSupplier != null) {
			fileDescription = _fileDescriptionSupplier.get();

			_fileDescriptionSupplier = null;
		}

		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;

		_fileDescriptionSupplier = null;
	}

	@JsonIgnore
	public void setFileDescription(
		UnsafeSupplier<String, Exception> fileDescriptionUnsafeSupplier) {

		_fileDescriptionSupplier = () -> {
			try {
				return fileDescriptionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileDescription;

	@JsonIgnore
	private Supplier<String> _fileDescriptionSupplier;

	@Schema(example = "rtf")
	public String getFileExtension() {
		if (_fileExtensionSupplier != null) {
			fileExtension = _fileExtensionSupplier.get();

			_fileExtensionSupplier = null;
		}

		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;

		_fileExtensionSupplier = null;
	}

	@JsonIgnore
	public void setFileExtension(
		UnsafeSupplier<String, Exception> fileExtensionUnsafeSupplier) {

		_fileExtensionSupplier = () -> {
			try {
				return fileExtensionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileExtension;

	@JsonIgnore
	private Supplier<String> _fileExtensionSupplier;

	@Schema(example = "2019-03-01T08:22:45")
	public String getFileLastUpdated() {
		if (_fileLastUpdatedSupplier != null) {
			fileLastUpdated = _fileLastUpdatedSupplier.get();

			_fileLastUpdatedSupplier = null;
		}

		return fileLastUpdated;
	}

	public void setFileLastUpdated(String fileLastUpdated) {
		this.fileLastUpdated = fileLastUpdated;

		_fileLastUpdatedSupplier = null;
	}

	@JsonIgnore
	public void setFileLastUpdated(
		UnsafeSupplier<String, Exception> fileLastUpdatedUnsafeSupplier) {

		_fileLastUpdatedSupplier = () -> {
			try {
				return fileLastUpdatedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileLastUpdated;

	@JsonIgnore
	private Supplier<String> _fileLastUpdatedSupplier;

	@Schema(example = "Rani")
	public String getFileName() {
		if (_fileNameSupplier != null) {
			fileName = _fileNameSupplier.get();

			_fileNameSupplier = null;
		}

		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;

		_fileNameSupplier = null;
	}

	@JsonIgnore
	public void setFileName(
		UnsafeSupplier<String, Exception> fileNameUnsafeSupplier) {

		_fileNameSupplier = () -> {
			try {
				return fileNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileName;

	@JsonIgnore
	private Supplier<String> _fileNameSupplier;

	@Schema(example = "198.0")
	public String getFileSize() {
		if (_fileSizeSupplier != null) {
			fileSize = _fileSizeSupplier.get();

			_fileSizeSupplier = null;
		}

		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;

		_fileSizeSupplier = null;
	}

	@JsonIgnore
	public void setFileSize(
		UnsafeSupplier<String, Exception> fileSizeUnsafeSupplier) {

		_fileSizeSupplier = () -> {
			try {
				return fileSizeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileSize;

	@JsonIgnore
	private Supplier<String> _fileSizeSupplier;

	@Schema(example = "")
	public String getFileSizeUnit() {
		if (_fileSizeUnitSupplier != null) {
			fileSizeUnit = _fileSizeUnitSupplier.get();

			_fileSizeUnitSupplier = null;
		}

		return fileSizeUnit;
	}

	public void setFileSizeUnit(String fileSizeUnit) {
		this.fileSizeUnit = fileSizeUnit;

		_fileSizeUnitSupplier = null;
	}

	@JsonIgnore
	public void setFileSizeUnit(
		UnsafeSupplier<String, Exception> fileSizeUnitUnsafeSupplier) {

		_fileSizeUnitSupplier = () -> {
			try {
				return fileSizeUnitUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileSizeUnit;

	@JsonIgnore
	private Supplier<String> _fileSizeUnitSupplier;

	@Schema(example = "456e19ebdbffeb8460fc5259dc9619dc")
	public String getFileSysID() {
		if (_fileSysIDSupplier != null) {
			fileSysID = _fileSysIDSupplier.get();

			_fileSysIDSupplier = null;
		}

		return fileSysID;
	}

	public void setFileSysID(String fileSysID) {
		this.fileSysID = fileSysID;

		_fileSysIDSupplier = null;
	}

	@JsonIgnore
	public void setFileSysID(
		UnsafeSupplier<String, Exception> fileSysIDUnsafeSupplier) {

		_fileSysIDSupplier = () -> {
			try {
				return fileSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileSysID;

	@JsonIgnore
	private Supplier<String> _fileSysIDSupplier;

	@Schema(example = "Service Management")
	public String getFileType() {
		if (_fileTypeSupplier != null) {
			fileType = _fileTypeSupplier.get();

			_fileTypeSupplier = null;
		}

		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;

		_fileTypeSupplier = null;
	}

	@JsonIgnore
	public void setFileType(
		UnsafeSupplier<String, Exception> fileTypeUnsafeSupplier) {

		_fileTypeSupplier = () -> {
			try {
				return fileTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileType;

	@JsonIgnore
	private Supplier<String> _fileTypeSupplier;

	@Schema(example = "")
	public String getFileTypeSysID() {
		if (_fileTypeSysIDSupplier != null) {
			fileTypeSysID = _fileTypeSysIDSupplier.get();

			_fileTypeSysIDSupplier = null;
		}

		return fileTypeSysID;
	}

	public void setFileTypeSysID(String fileTypeSysID) {
		this.fileTypeSysID = fileTypeSysID;

		_fileTypeSysIDSupplier = null;
	}

	@JsonIgnore
	public void setFileTypeSysID(
		UnsafeSupplier<String, Exception> fileTypeSysIDUnsafeSupplier) {

		_fileTypeSysIDSupplier = () -> {
			try {
				return fileTypeSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileTypeSysID;

	@JsonIgnore
	private Supplier<String> _fileTypeSysIDSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ListOfFile)) {
			return false;
		}

		ListOfFile listOfFile = (ListOfFile)object;

		return Objects.equals(toString(), listOfFile.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String businessServiceName = getBusinessServiceName();

		if (businessServiceName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessServiceName\": ");

			sb.append("\"");

			sb.append(_escape(businessServiceName));

			sb.append("\"");
		}

		String businessServiceSysID = getBusinessServiceSysID();

		if (businessServiceSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessServiceSysID\": ");

			sb.append("\"");

			sb.append(_escape(businessServiceSysID));

			sb.append("\"");
		}

		String fileDescription = getFileDescription();

		if (fileDescription != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileDescription\": ");

			sb.append("\"");

			sb.append(_escape(fileDescription));

			sb.append("\"");
		}

		String fileExtension = getFileExtension();

		if (fileExtension != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileExtension\": ");

			sb.append("\"");

			sb.append(_escape(fileExtension));

			sb.append("\"");
		}

		String fileLastUpdated = getFileLastUpdated();

		if (fileLastUpdated != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileLastUpdated\": ");

			sb.append("\"");

			sb.append(_escape(fileLastUpdated));

			sb.append("\"");
		}

		String fileName = getFileName();

		if (fileName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileName\": ");

			sb.append("\"");

			sb.append(_escape(fileName));

			sb.append("\"");
		}

		String fileSize = getFileSize();

		if (fileSize != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileSize\": ");

			sb.append("\"");

			sb.append(_escape(fileSize));

			sb.append("\"");
		}

		String fileSizeUnit = getFileSizeUnit();

		if (fileSizeUnit != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileSizeUnit\": ");

			sb.append("\"");

			sb.append(_escape(fileSizeUnit));

			sb.append("\"");
		}

		String fileSysID = getFileSysID();

		if (fileSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileSysID\": ");

			sb.append("\"");

			sb.append(_escape(fileSysID));

			sb.append("\"");
		}

		String fileType = getFileType();

		if (fileType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileType\": ");

			sb.append("\"");

			sb.append(_escape(fileType));

			sb.append("\"");
		}

		String fileTypeSysID = getFileTypeSysID();

		if (fileTypeSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileTypeSysID\": ");

			sb.append("\"");

			sb.append(_escape(fileTypeSysID));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.document.dto.v1_0.ListOfFile",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}