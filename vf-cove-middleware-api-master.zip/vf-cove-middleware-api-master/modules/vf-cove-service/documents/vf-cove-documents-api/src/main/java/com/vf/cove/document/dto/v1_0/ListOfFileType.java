package com.vf.cove.document.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("ListOfFileType")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ListOfFileType")
public class ListOfFileType implements Serializable {

	public static ListOfFileType toDTO(String json) {
		return ObjectMapperUtil.readValue(ListOfFileType.class, json);
	}

	public static ListOfFileType unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(ListOfFileType.class, json);
	}

	@Schema(example = "Service Management")
	public String getFileType() {
		if (_fileTypeSupplier != null) {
			fileType = _fileTypeSupplier.get();

			_fileTypeSupplier = null;
		}

		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;

		_fileTypeSupplier = null;
	}

	@JsonIgnore
	public void setFileType(
		UnsafeSupplier<String, Exception> fileTypeUnsafeSupplier) {

		_fileTypeSupplier = () -> {
			try {
				return fileTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileType;

	@JsonIgnore
	private Supplier<String> _fileTypeSupplier;

	@Schema(example = "1b8841dddb41cb00cc1e79ab8c961998")
	public String getFileTypeSysID() {
		if (_fileTypeSysIDSupplier != null) {
			fileTypeSysID = _fileTypeSysIDSupplier.get();

			_fileTypeSysIDSupplier = null;
		}

		return fileTypeSysID;
	}

	public void setFileTypeSysID(String fileTypeSysID) {
		this.fileTypeSysID = fileTypeSysID;

		_fileTypeSysIDSupplier = null;
	}

	@JsonIgnore
	public void setFileTypeSysID(
		UnsafeSupplier<String, Exception> fileTypeSysIDUnsafeSupplier) {

		_fileTypeSysIDSupplier = () -> {
			try {
				return fileTypeSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileTypeSysID;

	@JsonIgnore
	private Supplier<String> _fileTypeSysIDSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ListOfFileType)) {
			return false;
		}

		ListOfFileType listOfFileType = (ListOfFileType)object;

		return Objects.equals(toString(), listOfFileType.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String fileType = getFileType();

		if (fileType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileType\": ");

			sb.append("\"");

			sb.append(_escape(fileType));

			sb.append("\"");
		}

		String fileTypeSysID = getFileTypeSysID();

		if (fileTypeSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fileTypeSysID\": ");

			sb.append("\"");

			sb.append(_escape(fileTypeSysID));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.document.dto.v1_0.ListOfFileType",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}