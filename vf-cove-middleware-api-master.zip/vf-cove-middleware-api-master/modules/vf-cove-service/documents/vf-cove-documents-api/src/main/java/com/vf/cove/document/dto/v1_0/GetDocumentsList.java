package com.vf.cove.document.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("GetDocumentsList")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetDocumentsList")
public class GetDocumentsList implements Serializable {

	public static GetDocumentsList toDTO(String json) {
		return ObjectMapperUtil.readValue(GetDocumentsList.class, json);
	}

	public static GetDocumentsList unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(GetDocumentsList.class, json);
	}

	@Schema
	@Valid
	public ListOfBusinessService[] getListOfBusinessServices() {
		if (_listOfBusinessServicesSupplier != null) {
			listOfBusinessServices = _listOfBusinessServicesSupplier.get();

			_listOfBusinessServicesSupplier = null;
		}

		return listOfBusinessServices;
	}

	public void setListOfBusinessServices(
		ListOfBusinessService[] listOfBusinessServices) {

		this.listOfBusinessServices = listOfBusinessServices;

		_listOfBusinessServicesSupplier = null;
	}

	@JsonIgnore
	public void setListOfBusinessServices(
		UnsafeSupplier<ListOfBusinessService[], Exception>
			listOfBusinessServicesUnsafeSupplier) {

		_listOfBusinessServicesSupplier = () -> {
			try {
				return listOfBusinessServicesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ListOfBusinessService[] listOfBusinessServices;

	@JsonIgnore
	private Supplier<ListOfBusinessService[]> _listOfBusinessServicesSupplier;

	@Schema
	@Valid
	public ListOfFileType[] getListOfFileTypes() {
		if (_listOfFileTypesSupplier != null) {
			listOfFileTypes = _listOfFileTypesSupplier.get();

			_listOfFileTypesSupplier = null;
		}

		return listOfFileTypes;
	}

	public void setListOfFileTypes(ListOfFileType[] listOfFileTypes) {
		this.listOfFileTypes = listOfFileTypes;

		_listOfFileTypesSupplier = null;
	}

	@JsonIgnore
	public void setListOfFileTypes(
		UnsafeSupplier<ListOfFileType[], Exception>
			listOfFileTypesUnsafeSupplier) {

		_listOfFileTypesSupplier = () -> {
			try {
				return listOfFileTypesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ListOfFileType[] listOfFileTypes;

	@JsonIgnore
	private Supplier<ListOfFileType[]> _listOfFileTypesSupplier;

	@Schema
	@Valid
	public ListOfFile[] getListOfFiles() {
		if (_listOfFilesSupplier != null) {
			listOfFiles = _listOfFilesSupplier.get();

			_listOfFilesSupplier = null;
		}

		return listOfFiles;
	}

	public void setListOfFiles(ListOfFile[] listOfFiles) {
		this.listOfFiles = listOfFiles;

		_listOfFilesSupplier = null;
	}

	@JsonIgnore
	public void setListOfFiles(
		UnsafeSupplier<ListOfFile[], Exception> listOfFilesUnsafeSupplier) {

		_listOfFilesSupplier = () -> {
			try {
				return listOfFilesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ListOfFile[] listOfFiles;

	@JsonIgnore
	private Supplier<ListOfFile[]> _listOfFilesSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetDocumentsList)) {
			return false;
		}

		GetDocumentsList getDocumentsList = (GetDocumentsList)object;

		return Objects.equals(toString(), getDocumentsList.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		ListOfBusinessService[] listOfBusinessServices =
			getListOfBusinessServices();

		if (listOfBusinessServices != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"listOfBusinessServices\": ");

			sb.append("[");

			for (int i = 0; i < listOfBusinessServices.length; i++) {
				sb.append(String.valueOf(listOfBusinessServices[i]));

				if ((i + 1) < listOfBusinessServices.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		ListOfFileType[] listOfFileTypes = getListOfFileTypes();

		if (listOfFileTypes != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"listOfFileTypes\": ");

			sb.append("[");

			for (int i = 0; i < listOfFileTypes.length; i++) {
				sb.append(String.valueOf(listOfFileTypes[i]));

				if ((i + 1) < listOfFileTypes.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		ListOfFile[] listOfFiles = getListOfFiles();

		if (listOfFiles != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"listOfFiles\": ");

			sb.append("[");

			for (int i = 0; i < listOfFiles.length; i++) {
				sb.append(String.valueOf(listOfFiles[i]));

				if ((i + 1) < listOfFiles.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.document.dto.v1_0.GetDocumentsList",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}