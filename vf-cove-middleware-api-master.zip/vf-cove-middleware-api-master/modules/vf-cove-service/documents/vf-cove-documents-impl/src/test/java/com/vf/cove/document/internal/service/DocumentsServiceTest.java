package com.vf.cove.document.internal.service;

import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.document.dto.v1_0.DocumentsListRequest;
import com.vf.cove.document.dto.v1_0.DocumentsListResponse;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DocumentsServiceTest {
	@Mock
	private CoveResponseParser responseParser;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	@InjectMocks
	DocumentsService documentsService;

	private String successResponse;
	private String failureResponse;
	private static final String MESSAGE_ID = "testMessageId";

	  private CoveResponse esbResponse;
	  private DocumentsListRequest documentsListRequest;

	@BeforeEach
	public void setUp() throws Exception {
		successResponse = TestUtils.inputStreamToString("src/test/resources/DocumentsSuccessResp.json");
		failureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");
		esbResponse = new CoveResponse();
		documentsListRequest = new DocumentsListRequest();

        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setAttribute("contentLength","123");
        ServiceContextThreadLocal.pushServiceContext(serviceContext);

	}

	@Test
	public void documentsListSuccessResponse() throws IOException {
		esbResponse.setData(successResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		DocumentsListResponse coveResponse = documentsService.postGetDocumentsList(documentsListRequest, MESSAGE_ID);
		Assertions.assertThat(coveResponse).isNotNull();
	}

	@Test
	public void documentsListFailureResponse() throws IOException {
		esbResponse.setData(failureResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		DocumentsListResponse coveResponse = documentsService.postGetDocumentsList(documentsListRequest, MESSAGE_ID);
		Assertions.assertThat(coveResponse).isNotNull();
	}
}
