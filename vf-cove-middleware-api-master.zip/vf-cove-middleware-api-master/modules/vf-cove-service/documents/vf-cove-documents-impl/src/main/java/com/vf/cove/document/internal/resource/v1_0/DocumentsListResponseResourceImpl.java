package com.vf.cove.document.internal.resource.v1_0;

import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import com.vf.cove.document.dto.v1_0.DocumentsListRequest;
import com.vf.cove.document.dto.v1_0.DocumentsListResponse;
import com.vf.cove.document.internal.constants.DocumentsConstants;
import com.vf.cove.document.internal.service.DocumentsService;
import com.vf.cove.document.resource.v1_0.DocumentsListResponseResource;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Virtusa
 */
@Component(
        properties = "OSGI-INF/liferay/rest/v1_0/documents-list-response.properties",
        scope = ServiceScope.PROTOTYPE,
        service = DocumentsListResponseResource.class
)
public class DocumentsListResponseResourceImpl extends BaseDocumentsListResponseResourceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentsListResponseResourceImpl.class);

    @Reference(unbind = "-")
    private DocumentsService documentsService;

    @Override
    public DocumentsListResponse postGetDocumentsList(DocumentsListRequest documentsListRequest)
            throws Exception {
        String messageId = RequestUtils.getUUID();
        requiredFieldValidations(documentsListRequest);
        LOGGER.info("Invoking postGetDocumentsList API for messageId {} "+ messageId);
        documentsListRequest.setUserId(contextUser.getEmailAddress());
        documentsListRequest.setCurrentDate(RequestUtils.getUTCDate());
        if (contextUser.getOrganizations().size() > 0) {
            documentsListRequest.setCustomerId(String.valueOf(
                    contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
        }
        documentsListRequest.setOamuserId(contextUser.getEmailAddress());
        documentsListRequest.setMessageId(messageId);

        return documentsService.postGetDocumentsList(documentsListRequest, messageId);
    }

    private void requiredFieldValidations(DocumentsListRequest request) throws Exception {
        LOGGER.debug("Inside postGetDocumentsList - requiredFieldValidations()");
        if(StringUtils.isEmpty(request.getUserId())) {
        	throw new ValidationException(DocumentsConstants.ERROR_CODE_400, DocumentsConstants.MISSING_REQUIRED_ATTRIBUTES);
        }
    }
}
