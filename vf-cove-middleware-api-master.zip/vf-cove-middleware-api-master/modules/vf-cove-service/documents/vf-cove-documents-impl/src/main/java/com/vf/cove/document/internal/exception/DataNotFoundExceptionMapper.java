package com.vf.cove.document.internal.exception;

import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.document.dto.v1_0.ErrorMessage;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Component(properties = "OSGI-INF/liferay/rest/v1_0/exception-mapper.properties", scope = ServiceScope.PROTOTYPE)
@Produces(MediaType.APPLICATION_JSON)
@Provider
public class DataNotFoundExceptionMapper implements ExceptionMapper<DataNotFoundException> {
	private static final Logger LOGGER = LoggerFactory.getLogger(DataNotFoundExceptionMapper.class);

	@Override
	public Response toResponse(DataNotFoundException ex) {
		LOGGER.error("Exception occurred :::::::", ex);

		ErrorMessage error = new ErrorMessage();
		error.setErrorCode(ex.getErrorCode());
		error.setErrorMessage(ex.getMessage());
		if (ex.getErrorCode() == 493) {
			return Response.status(Status.CONFLICT).entity(error).type(MediaType.APPLICATION_JSON).build();
		}
		return Response.status(Status.NO_CONTENT).entity(error).type(MediaType.APPLICATION_JSON).build();
	}

}
