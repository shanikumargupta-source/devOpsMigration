package com.vf.cove.document.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.document.dto.v1_0.*;
import com.vf.cove.document.internal.constants.DocumentsConstants;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Virtusa
 */
@Component(service = DocumentsService.class)
public class DocumentsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentsService.class);

	 @Reference(target="(backend=DXL)")
	    private RestAPIProcessor restAPIProcessor;

	 @Reference(unbind = "-")
		private CoveResponseParser responseParser;

    public DocumentsListResponse postGetDocumentsList(DocumentsListRequest documentsListRequest, String messageId) {
    	LOGGER.info("Documents service");
        DocumentsListResponse documentsListResponse = new DocumentsListResponse();
        try {
            if (ObjectUtils.isNotEmpty(documentsListRequest)) {

            	final String request = documentsListRequest.toString();
                String relativeUrl = DocumentsConstants.DOCUMENTS_LIST;
                RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
        		restAPIRequest.setRelativeUrl(relativeUrl);
                restAPIRequest.setRequest(request);
                restAPIRequest.setTransactionId(messageId);
                String sourceSystem = getSourceSystemHeader();
                if(StringUtils.isNotEmpty(sourceSystem)){
                    restAPIRequest.addHeader(DocumentsConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
                }
                LOGGER.info("Request Headers.. {}", restAPIRequest.getHeaders());
        		CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

                if(StringUtils.isEmpty(dxlResponse.getData())) {
                    throw new ServiceException(DocumentsConstants.ERROR_CODE_500, DocumentsConstants.INTERNAL_SERVER_ERROR);
                }

                JsonNode rootNode = responseParser.getCoveMapper().readTree(dxlResponse.getData());
                JsonNode responseData = rootNode.get(DocumentsConstants.RESPONSE_DATA);

                JsonNode responseStatus = responseData.get(DocumentsConstants.STATUS);
                String status = responseParser.getCoveMapper().readValue(responseStatus.toString(), String.class);
                if (status.equalsIgnoreCase(DocumentsConstants.STATUS_CODE)) {
                    throw new DataNotFoundException(DocumentsConstants.ERROR_CODE_491, DocumentsConstants.NO_DATA_FOUND);
                }

                JsonNode response = responseData.get(DocumentsConstants.RESPONSE);

                ArrayNode filesArrayNode = (ArrayNode) response.get(DocumentsConstants.LIST_OF_FILES);
                List<ListOfFile> listOfFiles = new ArrayList<>();
                filesArrayNode.forEach(node -> {
                    try {
                        listOfFiles
                            .add(responseParser.getCoveMapper().readValue(node.toString(), ListOfFile.class));
                    } catch (IOException e) {
                    	LOGGER.error("Exception {} ", e);
                    }
                });

                ArrayNode bsArrayNode = (ArrayNode) response.get(DocumentsConstants.LIST_OF_BUSINESS_SERVICES);
                List<ListOfBusinessService> listOfBusinessServices = new ArrayList<>();
                bsArrayNode.forEach(node -> {
                    try {
                        listOfBusinessServices
                            .add(responseParser.getCoveMapper().readValue(node.toString(), ListOfBusinessService.class));
                    } catch (IOException e) {
                        LOGGER.error("Exception {}", e);
                    }
                });

                ArrayNode filetypesArrayNode = (ArrayNode) response.get(DocumentsConstants.LIST_OF_FILE_TYPES);
                List<ListOfFileType> fileTypeArrayList = new ArrayList<>();
                filetypesArrayNode.forEach(node -> {
                    try {
                        fileTypeArrayList
                            .add(responseParser.getCoveMapper().readValue(node.toString(), ListOfFileType.class));
                    } catch (IOException e) {
                    	LOGGER.error("Exception {}", e);
                    }
                });

                GetDocumentsList getDocumentsList = new GetDocumentsList();

                getDocumentsList.setListOfFiles(
                    listOfFiles.toArray(new ListOfFile[listOfFiles.size()]));
                getDocumentsList.setListOfBusinessServices(
                    listOfBusinessServices.toArray(new ListOfBusinessService[listOfBusinessServices.size()]));
                getDocumentsList.setListOfFileTypes(
                    fileTypeArrayList.toArray(new ListOfFileType[fileTypeArrayList.size()]));

                documentsListResponse.setGetDocumentsList(getDocumentsList);
            }
        } catch (Exception ex) {
            LOGGER.error("Exception occurred in getDocumentsList {} ", ex);
        }
        return documentsListResponse;
    }

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }

}
