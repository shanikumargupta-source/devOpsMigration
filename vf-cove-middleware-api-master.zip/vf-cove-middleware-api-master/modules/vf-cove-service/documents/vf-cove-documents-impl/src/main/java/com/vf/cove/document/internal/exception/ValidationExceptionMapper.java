package com.vf.cove.document.internal.exception;

import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.document.dto.v1_0.ErrorMessage;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Component(properties = "OSGI-INF/liferay/rest/v1_0/exception-mapper.properties", scope = ServiceScope.PROTOTYPE)
@Produces(MediaType.APPLICATION_JSON)
@Provider
public class ValidationExceptionMapper implements ExceptionMapper<ValidationException> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ValidationExceptionMapper.class);

    @Override
    public Response toResponse(ValidationException ex) {
        LOGGER.error("Exception occurred :::::::", ex);
        ErrorMessage error = new ErrorMessage();
        error.setErrorCode(ex.getErrorCode());
        error.setErrorMessage(ex.getMessage());
        return Response.status(Response.Status.BAD_REQUEST).entity(error).type(MediaType.APPLICATION_JSON).build();
    }
}
