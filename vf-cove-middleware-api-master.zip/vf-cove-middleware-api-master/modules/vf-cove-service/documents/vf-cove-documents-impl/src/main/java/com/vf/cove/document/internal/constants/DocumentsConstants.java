package com.vf.cove.document.internal.constants;

public class DocumentsConstants {

    public static final String DOCUMENTS_LIST = "/cove/documentService/getDocumentList";
    public static final String INTERNAL_SERVER_ERROR = "Internal server error";
    public static final String NO_DATA_FOUND = "No data found";
    public static final String STATUS_CODE = "1";
    public static final String RESPONSE_DATA = "responseData";
    public static final String RESPONSE = "response";
    public static final String LIST_OF_FILES = "listOfFiles";
    public static final String LIST_OF_BUSINESS_SERVICES = "listOfBusinessServices";
    public static final String LIST_OF_FILE_TYPES = "listOfFileTypes";
    public static final String STATUS = "status";
    public static final String MISSING_REQUIRED_ATTRIBUTES = "Missing required attributes as part of the request";
    public static final int ERROR_CODE_500 = 500;
    public static final int ERROR_CODE_400 = 400;
    public static final int ERROR_CODE_491 = 491;

    public static final String SOURCE_SYSTEM_HEADER = "X-Source-System";

}
