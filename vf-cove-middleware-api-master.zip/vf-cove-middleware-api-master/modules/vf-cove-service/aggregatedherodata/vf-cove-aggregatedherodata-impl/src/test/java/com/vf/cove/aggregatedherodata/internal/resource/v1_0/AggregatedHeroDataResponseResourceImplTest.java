package com.vf.cove.aggregatedherodata.internal.resource.v1_0;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.aggregatedherodata.dto.v1_0.AggregatedHeroDataResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class AggregatedHeroDataResponseResourceImplTest {
    private AggregatedHeroDataResponse aggregatedHeroDataResponse;
    private String customerId = "123456";
    private String userId = "test@liferay.com";
    private ObjectMapper mapper = new ObjectMapper();

    @Test
    public void getAggregatedHeroDataTest() throws Exception {

        if(Validator.isNotNull(customerId) && Validator.isNotNull(userId)){
            String mockResponse = "{\"responseData\": {\"heroCount\": {\"inc\": \"168\",\"min\": \"168\",\"prb\": \"49\",\"req\": \"77\",\"preq\": \"77\",\"chg\": \"1\"},\"priority\": {\"inc\": {\"P1\": \"15\",\"P2\": \"4\",\"P3\": \"12\",\"P4\": \"137\"},\"req\": {\"P1\": \"1\",\"P2\": \"1\",\"P3\": \"\",\"P4\": \"75\"},\"chg\": {\"P1\": \"\",\"P2\": \"\",\"P3\": \"\",\"P4\": \"1\"},\"prb\": {\"TotalCount\": \"49\"}}}}";
            aggregatedHeroDataResponse = mapper.readValue(mockResponse, AggregatedHeroDataResponse.class);

            assertNotNull(aggregatedHeroDataResponse);

            assertEquals("168", aggregatedHeroDataResponse.getResponseData().getHeroCount().getInc());
            assertEquals("168", aggregatedHeroDataResponse.getResponseData().getHeroCount().getMin());
            assertEquals("49", aggregatedHeroDataResponse.getResponseData().getHeroCount().getPrb());
            assertEquals("77", aggregatedHeroDataResponse.getResponseData().getHeroCount().getReq());
            assertEquals("77", aggregatedHeroDataResponse.getResponseData().getHeroCount().getPreq());
            assertEquals("1", aggregatedHeroDataResponse.getResponseData().getHeroCount().getChg());

            assertEquals("15", aggregatedHeroDataResponse.getResponseData().getPriority().getInc().getP1());
            assertEquals("4", aggregatedHeroDataResponse.getResponseData().getPriority().getInc().getP2());
            assertEquals("12", aggregatedHeroDataResponse.getResponseData().getPriority().getInc().getP3());
            assertEquals("137", aggregatedHeroDataResponse.getResponseData().getPriority().getInc().getP4());

            assertEquals("1", aggregatedHeroDataResponse.getResponseData().getPriority().getReq().getP1());
            assertEquals("1", aggregatedHeroDataResponse.getResponseData().getPriority().getReq().getP2());
            assertEquals("", aggregatedHeroDataResponse.getResponseData().getPriority().getReq().getP3());
            assertEquals("75", aggregatedHeroDataResponse.getResponseData().getPriority().getReq().getP4());

            assertEquals("", aggregatedHeroDataResponse.getResponseData().getPriority().getChg().getP1());
            assertEquals("", aggregatedHeroDataResponse.getResponseData().getPriority().getChg().getP2());
            assertEquals("", aggregatedHeroDataResponse.getResponseData().getPriority().getChg().getP3());
            assertEquals("1", aggregatedHeroDataResponse.getResponseData().getPriority().getChg().getP4());

            assertEquals("49", aggregatedHeroDataResponse.getResponseData().getPriority().getPrb().getTotalCount());
        }
    }

}
