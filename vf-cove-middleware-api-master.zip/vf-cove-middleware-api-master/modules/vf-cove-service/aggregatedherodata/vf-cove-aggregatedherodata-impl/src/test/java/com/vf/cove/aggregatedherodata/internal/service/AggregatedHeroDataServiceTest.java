package com.vf.cove.aggregatedherodata.internal.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.aggregatedherodata.dto.v1_0.AggregatedHeroDataResponse;
import com.vf.cove.core.restutils.model.CoveResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AggregatedHeroDataServiceTest {
    private AggregatedHeroDataResponse aggregatedHeroDataResponse;
    private ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    public void setUp() throws Exception {
        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setAttribute("contentLength","dummy");
        ServiceContextThreadLocal.pushServiceContext(serviceContext);
    }

    @Test
    void getAggregatedHeroDataResponseTest() throws Exception {
        String mockResponse = "{\"responseData\": {\"heroCount\": {\"inc\": \"168\",\"min\": \"168\",\"prb\": \"49\",\"req\": \"77\",\"preq\": \"77\",\"chg\": \"1\"},\"priority\": {\"inc\": {\"P1\": \"15\",\"P2\": \"4\",\"P3\": \"12\",\"P4\": \"137\"},\"req\": {\"P1\": \"1\",\"P2\": \"1\",\"P3\": \"\",\"P4\": \"75\"},\"chg\": {\"P1\": \"\",\"P2\": \"\",\"P3\": \"\",\"P4\": \"1\"},\"prb\": {\"TotalCount\": \"49\"}}}}";
        aggregatedHeroDataResponse = mapper.readValue(mockResponse, AggregatedHeroDataResponse.class);
        CoveResponse coveResponse = new CoveResponse(mockResponse);
    }

}
