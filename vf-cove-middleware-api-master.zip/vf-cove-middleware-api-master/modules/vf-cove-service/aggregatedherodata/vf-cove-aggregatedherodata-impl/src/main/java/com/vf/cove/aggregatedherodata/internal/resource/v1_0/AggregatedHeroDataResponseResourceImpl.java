package com.vf.cove.aggregatedherodata.internal.resource.v1_0;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.aggregatedherodata.dto.v1_0.AggregatedHeroDataResponse;
import com.vf.cove.aggregatedherodata.internal.constants.AggregatedHeroDataConstants;
import com.vf.cove.aggregatedherodata.internal.service.AggregatedHeroDataService;
import com.vf.cove.aggregatedherodata.resource.v1_0.AggregatedHeroDataResponseResource;

import com.vf.cove.core.restutils.constants.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Vodafone
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/aggregated-hero-data-response.properties",
	scope = ServiceScope.PROTOTYPE,
	service = AggregatedHeroDataResponseResource.class
)
public class AggregatedHeroDataResponseResourceImpl
	extends BaseAggregatedHeroDataResponseResourceImpl {
    private static final Logger LOGGER = LoggerFactory.getLogger(AggregatedHeroDataResponseResourceImpl.class);
    @Reference(unbind = "-")
    private AggregatedHeroDataService aggregatedHeroDataService;
    public AggregatedHeroDataResponse getAggregatedHeroData()
        throws Exception {
        LOGGER.debug("Invoking AggregatedHeroData API {}");

        String customerId  = String.valueOf(contextUser.getOrganizations().get(0)
            .getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID));
        String userId = contextUser.getEmailAddress();

        if(Validator.isNotNull(customerId) && Validator.isNotNull(userId)) {
            Map<String, Object> params = populateParams(customerId,userId);
            LOGGER.debug("AggregatedHeroData request params {} ", params);
            return aggregatedHeroDataService.aggregatedHeroDataResponse(params);
        }

        return new AggregatedHeroDataResponse();
    }

    private Map<String, Object> populateParams(String customerId, String userId)
        throws PortalException {
        Map<String, Object> additionalParams = new HashMap<>();
        additionalParams.put(AggregatedHeroDataConstants.CUSTOMER_ID, customerId);
        additionalParams.put(AggregatedHeroDataConstants.USER_ID, userId);
        return additionalParams;
    }

}
