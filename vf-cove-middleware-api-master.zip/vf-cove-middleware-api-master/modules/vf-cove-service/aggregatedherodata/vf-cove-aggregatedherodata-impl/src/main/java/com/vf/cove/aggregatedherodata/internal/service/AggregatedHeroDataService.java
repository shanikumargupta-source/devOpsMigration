
package com.vf.cove.aggregatedherodata.internal.service;

import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.aggregatedherodata.dto.v1_0.AggregatedHeroDataResponse;
import com.vf.cove.aggregatedherodata.internal.constants.AggregatedHeroDataConstants;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.ftlutils.utils.StreamToStringUtil;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Map;

@Component(service = AggregatedHeroDataService.class)
public class AggregatedHeroDataService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AggregatedHeroDataService.class);

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;
    @Reference(unbind = "-")
	private FtlTemplateService ftlTemplateService;

	@Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	public AggregatedHeroDataResponse aggregatedHeroDataResponse(Map<String, Object> params) throws Exception {
		String dxlRequest = createDXLRequest(params, AggregatedHeroDataConstants.AGGREGATED_HERO_DATA_REQUEST_DEFINITION);
		DXLAPIRequest apiRequest = (DXLAPIRequest) restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);

        apiRequest.setEndPoint(apiRequest.getEndPoint());
		apiRequest.setRelativeUrl(AggregatedHeroDataConstants.AGGREGATED_HERO_DATA_URL);
        apiRequest.setRequest(dxlRequest);
        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            apiRequest.addHeader(AggregatedHeroDataConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
        LOGGER.info("AggregatedHeroData Request Headers.. {}", apiRequest.getHeaders());

        CoveResponse dxlResponse = restAPIProcessor.post(apiRequest);

        AggregatedHeroDataResponse getAggregatedHeroDataResponse = responseParser.getCoveMapper().readValue(dxlResponse.getData(),
                AggregatedHeroDataResponse.class);

		LOGGER.info("AggregatedHeroData Final Response {} ", getAggregatedHeroDataResponse);
		return getAggregatedHeroDataResponse;
	}

    private String createDXLRequest(Map<String, Object> additionalParams, String templateName)
        throws Exception {

        final InputStream resourceAsStream = this.getClass().getResourceAsStream(templateName);
        String template = StreamToStringUtil.getString(resourceAsStream);
        final String dxlRequest = ftlTemplateService
            .renderTemplate(templateName, template, additionalParams);

        LOGGER.info("AggregatedHeroData DXL Request formed {} ", dxlRequest);

        return dxlRequest;
    }
    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("GetSourceSystemHeader for AggregatedHeroData ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }
}
