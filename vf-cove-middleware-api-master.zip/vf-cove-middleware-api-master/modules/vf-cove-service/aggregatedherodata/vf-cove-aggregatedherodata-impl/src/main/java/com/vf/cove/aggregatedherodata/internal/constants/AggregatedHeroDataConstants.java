package com.vf.cove.aggregatedherodata.internal.constants;

public class AggregatedHeroDataConstants {
    private AggregatedHeroDataConstants() {
        throw new IllegalStateException("Utility class");
    }
    public static final String  CUSTOMER_ID ="customerId";
    public static final String USER_ID = "userId";
    public static final String  AGGREGATED_HERO_DATA_REQUEST_DEFINITION = "/AggregatedHeroDataRequest.vm";
    public static final String  AGGREGATED_HERO_DATA_URL ="/vbps/dxl/cove/ticket-data/aggregate-data";
    public static final String SOURCE_SYSTEM_HEADER = "X-Source-System";

}
