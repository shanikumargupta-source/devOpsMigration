package com.vf.cove.aggregatedherodata.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author Vodafone
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false",
		"osgi.jaxrs.application.base=/vf-cove-aggregatedherodata",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=vf-cove-aggregatedherodata"
	},
	service = Application.class
)
@Generated("")
public class CoveAggregatedHeroData extends Application {
}