package com.vf.cove.aggregatedherodata.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Vodafone
 * @generated
 */
@Generated("")
@GraphQLName("Priority")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Priority")
public class Priority implements Serializable {

	public static Priority toDTO(String json) {
		return ObjectMapperUtil.readValue(Priority.class, json);
	}

	public static Priority unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Priority.class, json);
	}

	@Schema
	@Valid
	public Chg getChg() {
		if (_chgSupplier != null) {
			chg = _chgSupplier.get();

			_chgSupplier = null;
		}

		return chg;
	}

	public void setChg(Chg chg) {
		this.chg = chg;

		_chgSupplier = null;
	}

	@JsonIgnore
	public void setChg(UnsafeSupplier<Chg, Exception> chgUnsafeSupplier) {
		_chgSupplier = () -> {
			try {
				return chgUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Chg chg;

	@JsonIgnore
	private Supplier<Chg> _chgSupplier;

	@Schema
	@Valid
	public Inc getInc() {
		if (_incSupplier != null) {
			inc = _incSupplier.get();

			_incSupplier = null;
		}

		return inc;
	}

	public void setInc(Inc inc) {
		this.inc = inc;

		_incSupplier = null;
	}

	@JsonIgnore
	public void setInc(UnsafeSupplier<Inc, Exception> incUnsafeSupplier) {
		_incSupplier = () -> {
			try {
				return incUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Inc inc;

	@JsonIgnore
	private Supplier<Inc> _incSupplier;

	@Schema
	@Valid
	public Min getMin() {
		if (_minSupplier != null) {
			min = _minSupplier.get();

			_minSupplier = null;
		}

		return min;
	}

	public void setMin(Min min) {
		this.min = min;

		_minSupplier = null;
	}

	@JsonIgnore
	public void setMin(UnsafeSupplier<Min, Exception> minUnsafeSupplier) {
		_minSupplier = () -> {
			try {
				return minUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Min min;

	@JsonIgnore
	private Supplier<Min> _minSupplier;

	@Schema
	@Valid
	public Prb getPrb() {
		if (_prbSupplier != null) {
			prb = _prbSupplier.get();

			_prbSupplier = null;
		}

		return prb;
	}

	public void setPrb(Prb prb) {
		this.prb = prb;

		_prbSupplier = null;
	}

	@JsonIgnore
	public void setPrb(UnsafeSupplier<Prb, Exception> prbUnsafeSupplier) {
		_prbSupplier = () -> {
			try {
				return prbUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Prb prb;

	@JsonIgnore
	private Supplier<Prb> _prbSupplier;

	@Schema
	@Valid
	public Preq getPreq() {
		if (_preqSupplier != null) {
			preq = _preqSupplier.get();

			_preqSupplier = null;
		}

		return preq;
	}

	public void setPreq(Preq preq) {
		this.preq = preq;

		_preqSupplier = null;
	}

	@JsonIgnore
	public void setPreq(UnsafeSupplier<Preq, Exception> preqUnsafeSupplier) {
		_preqSupplier = () -> {
			try {
				return preqUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Preq preq;

	@JsonIgnore
	private Supplier<Preq> _preqSupplier;

	@Schema
	@Valid
	public Req getReq() {
		if (_reqSupplier != null) {
			req = _reqSupplier.get();

			_reqSupplier = null;
		}

		return req;
	}

	public void setReq(Req req) {
		this.req = req;

		_reqSupplier = null;
	}

	@JsonIgnore
	public void setReq(UnsafeSupplier<Req, Exception> reqUnsafeSupplier) {
		_reqSupplier = () -> {
			try {
				return reqUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Req req;

	@JsonIgnore
	private Supplier<Req> _reqSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Priority)) {
			return false;
		}

		Priority priority = (Priority)object;

		return Objects.equals(toString(), priority.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		Chg chg = getChg();

		if (chg != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"chg\": ");

			sb.append(String.valueOf(chg));
		}

		Inc inc = getInc();

		if (inc != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"inc\": ");

			sb.append(String.valueOf(inc));
		}

		Min min = getMin();

		if (min != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"min\": ");

			sb.append(String.valueOf(min));
		}

		Prb prb = getPrb();

		if (prb != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"prb\": ");

			sb.append(String.valueOf(prb));
		}

		Preq preq = getPreq();

		if (preq != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"preq\": ");

			sb.append(String.valueOf(preq));
		}

		Req req = getReq();

		if (req != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"req\": ");

			sb.append(String.valueOf(req));
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.aggregatedherodata.dto.v1_0.Priority",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}