package com.vf.cove.aggregatedherodata.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Vodafone
 * @generated
 */
@Generated("")
@GraphQLName("HeroCount")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "HeroCount")
public class HeroCount implements Serializable {

	public static HeroCount toDTO(String json) {
		return ObjectMapperUtil.readValue(HeroCount.class, json);
	}

	public static HeroCount unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(HeroCount.class, json);
	}

	@Schema
	public String getChg() {
		if (_chgSupplier != null) {
			chg = _chgSupplier.get();

			_chgSupplier = null;
		}

		return chg;
	}

	public void setChg(String chg) {
		this.chg = chg;

		_chgSupplier = null;
	}

	@JsonIgnore
	public void setChg(UnsafeSupplier<String, Exception> chgUnsafeSupplier) {
		_chgSupplier = () -> {
			try {
				return chgUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String chg;

	@JsonIgnore
	private Supplier<String> _chgSupplier;

	@Schema
	public String getInc() {
		if (_incSupplier != null) {
			inc = _incSupplier.get();

			_incSupplier = null;
		}

		return inc;
	}

	public void setInc(String inc) {
		this.inc = inc;

		_incSupplier = null;
	}

	@JsonIgnore
	public void setInc(UnsafeSupplier<String, Exception> incUnsafeSupplier) {
		_incSupplier = () -> {
			try {
				return incUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String inc;

	@JsonIgnore
	private Supplier<String> _incSupplier;

	@Schema
	public String getMin() {
		if (_minSupplier != null) {
			min = _minSupplier.get();

			_minSupplier = null;
		}

		return min;
	}

	public void setMin(String min) {
		this.min = min;

		_minSupplier = null;
	}

	@JsonIgnore
	public void setMin(UnsafeSupplier<String, Exception> minUnsafeSupplier) {
		_minSupplier = () -> {
			try {
				return minUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String min;

	@JsonIgnore
	private Supplier<String> _minSupplier;

	@Schema
	public String getPrb() {
		if (_prbSupplier != null) {
			prb = _prbSupplier.get();

			_prbSupplier = null;
		}

		return prb;
	}

	public void setPrb(String prb) {
		this.prb = prb;

		_prbSupplier = null;
	}

	@JsonIgnore
	public void setPrb(UnsafeSupplier<String, Exception> prbUnsafeSupplier) {
		_prbSupplier = () -> {
			try {
				return prbUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String prb;

	@JsonIgnore
	private Supplier<String> _prbSupplier;

	@Schema
	public String getPreq() {
		if (_preqSupplier != null) {
			preq = _preqSupplier.get();

			_preqSupplier = null;
		}

		return preq;
	}

	public void setPreq(String preq) {
		this.preq = preq;

		_preqSupplier = null;
	}

	@JsonIgnore
	public void setPreq(UnsafeSupplier<String, Exception> preqUnsafeSupplier) {
		_preqSupplier = () -> {
			try {
				return preqUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String preq;

	@JsonIgnore
	private Supplier<String> _preqSupplier;

	@Schema
	public String getReq() {
		if (_reqSupplier != null) {
			req = _reqSupplier.get();

			_reqSupplier = null;
		}

		return req;
	}

	public void setReq(String req) {
		this.req = req;

		_reqSupplier = null;
	}

	@JsonIgnore
	public void setReq(UnsafeSupplier<String, Exception> reqUnsafeSupplier) {
		_reqSupplier = () -> {
			try {
				return reqUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String req;

	@JsonIgnore
	private Supplier<String> _reqSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof HeroCount)) {
			return false;
		}

		HeroCount heroCount = (HeroCount)object;

		return Objects.equals(toString(), heroCount.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String chg = getChg();

		if (chg != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"chg\": ");

			sb.append("\"");

			sb.append(_escape(chg));

			sb.append("\"");
		}

		String inc = getInc();

		if (inc != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"inc\": ");

			sb.append("\"");

			sb.append(_escape(inc));

			sb.append("\"");
		}

		String min = getMin();

		if (min != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"min\": ");

			sb.append("\"");

			sb.append(_escape(min));

			sb.append("\"");
		}

		String prb = getPrb();

		if (prb != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"prb\": ");

			sb.append("\"");

			sb.append(_escape(prb));

			sb.append("\"");
		}

		String preq = getPreq();

		if (preq != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"preq\": ");

			sb.append("\"");

			sb.append(_escape(preq));

			sb.append("\"");
		}

		String req = getReq();

		if (req != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"req\": ");

			sb.append("\"");

			sb.append(_escape(req));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.aggregatedherodata.dto.v1_0.HeroCount",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}