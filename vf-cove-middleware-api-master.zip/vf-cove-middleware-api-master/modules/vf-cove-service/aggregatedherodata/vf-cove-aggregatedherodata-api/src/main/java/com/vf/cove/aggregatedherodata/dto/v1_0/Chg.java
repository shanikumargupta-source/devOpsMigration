package com.vf.cove.aggregatedherodata.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Vodafone
 * @generated
 */
@Generated("")
@GraphQLName("Chg")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Chg")
public class Chg implements Serializable {

	public static Chg toDTO(String json) {
		return ObjectMapperUtil.readValue(Chg.class, json);
	}

	public static Chg unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Chg.class, json);
	}

	@Schema
	public String getP1() {
		if (_P1Supplier != null) {
			P1 = _P1Supplier.get();

			_P1Supplier = null;
		}

		return P1;
	}

	public void setP1(String P1) {
		this.P1 = P1;

		_P1Supplier = null;
	}

	@JsonIgnore
	public void setP1(UnsafeSupplier<String, Exception> P1UnsafeSupplier) {
		_P1Supplier = () -> {
			try {
				return P1UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String P1;

	@JsonIgnore
	private Supplier<String> _P1Supplier;

	@Schema
	public String getP2() {
		if (_P2Supplier != null) {
			P2 = _P2Supplier.get();

			_P2Supplier = null;
		}

		return P2;
	}

	public void setP2(String P2) {
		this.P2 = P2;

		_P2Supplier = null;
	}

	@JsonIgnore
	public void setP2(UnsafeSupplier<String, Exception> P2UnsafeSupplier) {
		_P2Supplier = () -> {
			try {
				return P2UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String P2;

	@JsonIgnore
	private Supplier<String> _P2Supplier;

	@Schema
	public String getP3() {
		if (_P3Supplier != null) {
			P3 = _P3Supplier.get();

			_P3Supplier = null;
		}

		return P3;
	}

	public void setP3(String P3) {
		this.P3 = P3;

		_P3Supplier = null;
	}

	@JsonIgnore
	public void setP3(UnsafeSupplier<String, Exception> P3UnsafeSupplier) {
		_P3Supplier = () -> {
			try {
				return P3UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String P3;

	@JsonIgnore
	private Supplier<String> _P3Supplier;

	@Schema
	public String getP4() {
		if (_P4Supplier != null) {
			P4 = _P4Supplier.get();

			_P4Supplier = null;
		}

		return P4;
	}

	public void setP4(String P4) {
		this.P4 = P4;

		_P4Supplier = null;
	}

	@JsonIgnore
	public void setP4(UnsafeSupplier<String, Exception> P4UnsafeSupplier) {
		_P4Supplier = () -> {
			try {
				return P4UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String P4;

	@JsonIgnore
	private Supplier<String> _P4Supplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Chg)) {
			return false;
		}

		Chg chg = (Chg)object;

		return Objects.equals(toString(), chg.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String P1 = getP1();

		if (P1 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"P1\": ");

			sb.append("\"");

			sb.append(_escape(P1));

			sb.append("\"");
		}

		String P2 = getP2();

		if (P2 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"P2\": ");

			sb.append("\"");

			sb.append(_escape(P2));

			sb.append("\"");
		}

		String P3 = getP3();

		if (P3 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"P3\": ");

			sb.append("\"");

			sb.append(_escape(P3));

			sb.append("\"");
		}

		String P4 = getP4();

		if (P4 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"P4\": ");

			sb.append("\"");

			sb.append(_escape(P4));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.aggregatedherodata.dto.v1_0.Chg",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}