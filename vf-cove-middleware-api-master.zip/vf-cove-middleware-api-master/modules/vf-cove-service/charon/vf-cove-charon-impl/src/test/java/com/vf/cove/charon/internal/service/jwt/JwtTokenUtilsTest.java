package com.vf.cove.charon.internal.service.jwt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;
import com.vf.cove.charon.internal.configuration.registry.CharonClientRegistryImpl;
import com.vf.cove.charon.internal.configuration.api.CharonClientProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class JwtTokenUtilsTest {
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Mock
    private CharonClientRegistryImpl clientRegistry;

    @Spy
    @InjectMocks
    private JwtTokenUtils validator;

    @Test
    void testMalformedTokenReturnsNull() {
        String token = "not.a.jwt";
        String email = validator.validateJwtAndExtractEmail(token);
        assertThat(email).isNull();
    }

    @Test
    void testMissingAudienceReturnsNull() throws Exception {
        // build a token with no aud claim
        Map<String, Object> payload = new HashMap<>();
        payload.put("iss", "https://issuer.example.com");
        payload.put("email", "user@example.com");

        String token = buildUnsignedToken(payload);

        String email = validator.validateJwtAndExtractEmail(token);
        assertThat(email).isNull();
    }

    @Test
    void testInvalidSignatureReturnsNull() throws Exception {
        // create signer keypair A and jwks from different keypair B
        KeyPair signer = generateRSAKeyPair();
        KeyPair jwksKey = generateRSAKeyPair();

        String kid = "kid-1";
        String token = buildSignedToken(signer.getPrivate(), kid, "https://issuer.example.com", "aud-1", "user@example.com", "BUSINESSPORTAL_USER");

        // build JWKS using jwksKey (different public key -> signature won't verify)
        JsonNode jwks = jwksFromKey(jwksKey.getPublic(), kid);

        // mock config
        CharonApiConfiguration config = Mockito.mock(CharonApiConfiguration.class);
        // mock provider and registry
        CharonClientProvider provider = Mockito.mock(CharonClientProvider.class);
        Mockito.lenient().when(provider.getConfiguration()).thenReturn(config);
        Mockito.lenient().when(clientRegistry.getClient("aud-1")).thenReturn(provider);

        // stub JWKS fetch to return our jwks
        doReturn(jwks).when(validator).fetchJwks(any(CharonApiConfiguration.class));

        String email = validator.validateJwtAndExtractEmail(token);
        assertThat(email).isNull();
    }

    @Test
    void testValidTokenReturnsEmail() throws Exception {
        KeyPair keyPair = generateRSAKeyPair();
        String kid = "kid-valid";

        String issuer = "https://issuer.example.com";
        String audience = "aud-valid";
        String expectedEmail = "good@example.com";

        String token = buildSignedToken(keyPair.getPrivate(), kid, issuer, audience, expectedEmail, "BUSINESSPORTAL_USER");
        JsonNode jwks = jwksFromKey(keyPair.getPublic(), kid);

        CharonApiConfiguration config = Mockito.mock(CharonApiConfiguration.class);
        // these stubs are relevant for validation; keep them but mark lenient to avoid strict unused-stub failures
        Mockito.lenient().when(config.jwtAudience()).thenReturn(audience);
        Mockito.lenient().when(config.jwtIssuer()).thenReturn(issuer);
        Mockito.lenient().when(config.jwtJwksUrl()).thenReturn("https://example.com/jwks");
        Mockito.lenient().when(config.jwtAllowedRolesList()).thenReturn("BUSINESSPORTAL_USER");

        // mock provider and registry
        CharonClientProvider provider = Mockito.mock(CharonClientProvider.class);
        Mockito.lenient().when(provider.getConfiguration()).thenReturn(config);
        Mockito.lenient().when(clientRegistry.getClient(audience)).thenReturn(provider);

        // stub JWKS fetch to return our jwks
        doReturn(jwks).when(validator).fetchJwks(any(CharonApiConfiguration.class));

        String email = validator.validateJwtAndExtractEmail(token);
        assertThat(email).isEqualTo(expectedEmail);
    }

    // --- helpers ---

    private KeyPair generateRSAKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        return kpg.generateKeyPair();
    }

    private String base64UrlNoPad(byte[] data) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(data);
    }

    private JsonNode jwksFromKey(java.security.PublicKey publicKey, String kid) {
        RSAPublicKey rsa = (RSAPublicKey) publicKey;
        BigInteger modulus = rsa.getModulus();
        BigInteger exponent = rsa.getPublicExponent();
        String n = base64UrlNoPad(modulus.toByteArray());
        String e = base64UrlNoPad(exponent.toByteArray());

        ObjectNode jwks = objectMapper.createObjectNode();
        ArrayNode keys = objectMapper.createArrayNode();
        ObjectNode key = objectMapper.createObjectNode();
        key.put("kid", kid);
        key.put("kty", "RSA");
        key.put("alg", "RS256");
        key.put("n", n);
        key.put("e", e);
        keys.add(key);
        jwks.set("keys", keys);
        return jwks;
    }

    private String buildUnsignedToken(Map<String, Object> payload) throws Exception {
        String headerJson = objectMapper.writeValueAsString(Map.of("alg", "none", "typ", "JWT"));
        String payloadJson = objectMapper.writeValueAsString(payload);
        String header = base64UrlNoPad(headerJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String body = base64UrlNoPad(payloadJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return header + "." + body + ".";
    }

    private String buildSignedToken(PrivateKey privateKey, String kid, String issuer, String audience, String email, String userRole) throws Exception {
        ObjectNode header = objectMapper.createObjectNode();
        header.put("alg", "RS256");
        header.put("kid", kid);

        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("iss", issuer);
        payload.put("aud", audience);
        payload.put("email", email);
        payload.put("userRole", userRole);
        payload.put("exp", Instant.now().getEpochSecond() + 60);

        String headerJson = objectMapper.writeValueAsString(header);
        String payloadJson = objectMapper.writeValueAsString(payload);

        String headerB = base64UrlNoPad(headerJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String payloadB = base64UrlNoPad(payloadJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String signingInput = headerB + "." + payloadB;

        java.security.Signature sig = java.security.Signature.getInstance("SHA256withRSA");
        sig.initSign(privateKey);
        sig.update(signingInput.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        byte[] signature = sig.sign();
        String signatureB = base64UrlNoPad(signature);

        return signingInput + "." + signatureB;
    }
}
