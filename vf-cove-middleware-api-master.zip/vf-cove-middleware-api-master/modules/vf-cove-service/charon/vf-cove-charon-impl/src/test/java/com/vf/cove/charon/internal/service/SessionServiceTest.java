package com.vf.cove.charon.internal.service;

import com.vf.cove.charon.internal.service.jwt.JwtTokenUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SessionServiceTest {

    @InjectMocks
    private SessionService sessionService;

    @Mock
    private JwtTokenUtils jwtTokenUtils;

    // ========== JWT Token Validation Tests ==========

    @Test
    void createSessionReturnsUnauthorizedWhenNoToken() {
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(jwtTokenUtils.extractJWTToken(req)).thenReturn(null);

        WebApplicationException ex = assertThrows(WebApplicationException.class, () -> sessionService.createSession(req));
        assertThat(ex.getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    void createSessionReturnsUnauthorizedWhenInvalidToken() {
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(jwtTokenUtils.extractJWTToken(req)).thenReturn("bad.token.here");
        when(jwtTokenUtils.validateJwtAndExtractEmail("bad.token.here")).thenReturn(null);

        WebApplicationException ex = assertThrows(WebApplicationException.class, () -> sessionService.createSession(req));
        assertThat(ex.getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    void checkSessionReturnsUnauthorizedWhenNoToken() {
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(jwtTokenUtils.extractJWTToken(req)).thenReturn(null);

        WebApplicationException ex = assertThrows(WebApplicationException.class, () -> sessionService.checkSession(req));
        assertThat(ex.getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    void checkSessionReturnsUnauthorizedWhenInvalidToken() {
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(jwtTokenUtils.extractJWTToken(req)).thenReturn("expired.token.here");
        when(jwtTokenUtils.validateJwtAndExtractEmail("expired.token.here")).thenReturn(null);

        WebApplicationException ex = assertThrows(WebApplicationException.class, () -> sessionService.checkSession(req));
        assertThat(ex.getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    void createSessionReturnsUnauthorizedWhenMultipleTokenFormatErrors() {
        HttpServletRequest req = mock(HttpServletRequest.class);
        when(jwtTokenUtils.extractJWTToken(req)).thenReturn("malformed");
        when(jwtTokenUtils.validateJwtAndExtractEmail("malformed")).thenReturn(null);

        WebApplicationException ex = assertThrows(WebApplicationException.class, () -> sessionService.createSession(req));
        assertThat(ex.getResponse().getStatus()).isEqualTo(401);
    }

}
