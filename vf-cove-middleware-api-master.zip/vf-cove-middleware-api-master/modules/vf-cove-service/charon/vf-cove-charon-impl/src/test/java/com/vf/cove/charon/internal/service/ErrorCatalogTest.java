package com.vf.cove.charon.internal.service;

import com.vf.cove.charon.internal.resource.v1_0.dto.ErrorCatalog;
import com.vf.cove.charon.dto.v1_0.ErrorMessage;
import org.junit.jupiter.api.Test;

import javax.ws.rs.core.Response;

import static org.assertj.core.api.Assertions.assertThat;

class ErrorCatalogTest {

    @Test
    void userNotFoundFormatsMessage() {
        try (Response response = ErrorCatalog.USER_NOT_FOUND.toResponse("alice@example.com")) {

            assertThat(response.getStatus()).isEqualTo(401);
            Object entity = response.getEntity();
            assertThat(entity).isInstanceOf(ErrorMessage.class);
            ErrorMessage er = (ErrorMessage) entity;
            assertThat(er.getError()).isEqualTo("User not found");
            assertThat(er.getMessage()).contains("alice@example.com");
            assertThat(er.getStatus()).isEqualTo("unauthorized");
            assertThat(er.getCode()).isEqualTo(401);
        }
    }
}
