package com.vf.cove.charon.internal.resource.v1_0.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.vf.cove.charon.dto.v1_0.UserDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class UserDetailsSerializationTest {

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        // Configure FilterProvider to handle Liferay.Vulcan filter
        // In tests, we use a SimpleFilterProvider that accepts all filters
        FilterProvider filters = new SimpleFilterProvider().setFailOnUnknownId(false);
        objectMapper.setFilterProvider(filters);
    }

    // ========== Serialization Tests ==========

    @Test
    void userDetailsSerializesToJsonWithAllFields() throws Exception {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserId(12345);
        userDetails.setUserEmail("john.doe@example.com");
        userDetails.setUserScreenName("jdoe");
        userDetails.setUserFullName("John Doe");
        userDetails.setActive(true);
        userDetails.setLastLoginTime("Mon Mar 02 16:08:07 GMT 2026");

        String json = objectMapper.writeValueAsString(userDetails);

        assertThat(json)
            .contains("\"userId\":12345")
            .contains("\"userEmail\":\"john.doe@example.com\"")
            .contains("\"userScreenName\":\"jdoe\"")
            .contains("\"userFullName\":\"John Doe\"")
            .contains("\"active\":true")
            .contains("\"lastLoginTime\":\"Mon Mar 02 16:08:07 GMT 2026\"");
    }

    @Test
    void userDetailsSerializesWithoutLastLoginTime() throws Exception {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserId(12345);
        userDetails.setUserEmail("jane.doe@example.com");
        userDetails.setUserScreenName("janed");
        userDetails.setUserFullName("Jane Doe");
        userDetails.setActive(true);

        String json = objectMapper.writeValueAsString(userDetails);

        assertThat(json)
            .contains("\"userId\":12345")
            .contains("\"userEmail\":\"jane.doe@example.com\"");
    }

    @Test
    void userDetailsSerializesWithInactiveUser() throws Exception {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserId(99999);
        userDetails.setUserEmail("inactive@example.com");
        userDetails.setUserScreenName("inactive");
        userDetails.setUserFullName("Inactive User");
        userDetails.setActive(false);
        userDetails.setLastLoginTime("Tue Feb 01 10:00:00 GMT 2026");

        String json = objectMapper.writeValueAsString(userDetails);

        assertThat(json)
            .contains("\"active\":false")
            .contains("\"lastLoginTime\":\"Tue Feb 01 10:00:00 GMT 2026\"");
    }

    // ========== Deserialization Tests ==========

    @Test
    void userDetailsDeserializesFromJson() throws Exception {
        String json = "{\"userId\":12345,\"userEmail\":\"john@example.com\",\"userScreenName\":\"jdoe\"," +
                "\"userFullName\":\"John Doe\",\"active\":true,\"lastLoginTime\":\"Mon Mar 02 16:08:07 GMT 2026\"}";

        UserDetails userDetails = objectMapper.readValue(json, UserDetails.class);

        assertThat(userDetails.getUserId()).isEqualTo(12345);
        assertThat(userDetails.getUserEmail()).isEqualTo("john@example.com");
        assertThat(userDetails.getUserScreenName()).isEqualTo("jdoe");
        assertThat(userDetails.getUserFullName()).isEqualTo("John Doe");
        assertThat(userDetails.getActive()).isTrue();
        assertThat(userDetails.getLastLoginTime()).isEqualTo("Mon Mar 02 16:08:07 GMT 2026");
    }

    // ========== Round-trip Tests ==========

    @Test
    void userDetailsRoundTripSerialization() throws Exception {
        UserDetails original = new UserDetails();
        original.setUserId(54321);
        original.setUserEmail("test@example.com");
        original.setUserScreenName("test");
        original.setUserFullName("Test User");
        original.setActive(true);
        original.setLastLoginTime("Sun Mar 01 12:00:00 GMT 2026");

        String json = objectMapper.writeValueAsString(original);
        UserDetails deserialized = objectMapper.readValue(json, UserDetails.class);

        assertThat(deserialized.getUserId()).isEqualTo(original.getUserId());
        assertThat(deserialized.getUserEmail()).isEqualTo(original.getUserEmail());
        assertThat(deserialized.getUserScreenName()).isEqualTo(original.getUserScreenName());
        assertThat(deserialized.getUserFullName()).isEqualTo(original.getUserFullName());
        assertThat(deserialized.getActive()).isEqualTo(original.getActive());
        assertThat(deserialized.getLastLoginTime()).isEqualTo(original.getLastLoginTime());
    }

    // ========== Field Presence Tests ==========

    @Test
    void userDetailsHasLastLoginTimeField() throws Exception {
        UserDetails userDetails = new UserDetails();
        userDetails.setLastLoginTime("Mon Mar 02 16:08:07 GMT 2026");

        String json = objectMapper.writeValueAsString(userDetails);

        assertThat(json).contains("lastLoginTime");
    }

    @Test
    void userDetailsCanGetLastLoginTime() {
        UserDetails userDetails = new UserDetails();
        String loginTime = "Wed Mar 03 08:30:00 GMT 2026";
        userDetails.setLastLoginTime(loginTime);

        assertThat(userDetails.getLastLoginTime()).isEqualTo(loginTime);
    }

}

