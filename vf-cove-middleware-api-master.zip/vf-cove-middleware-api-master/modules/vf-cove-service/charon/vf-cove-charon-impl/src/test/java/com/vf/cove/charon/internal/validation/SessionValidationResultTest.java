package com.vf.cove.charon.internal.validation;

import com.liferay.portal.kernel.model.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class SessionValidationResultTest {

    @Mock
    private User mockUser;

    @Mock
    private HttpSession mockSession;

    // ========== Success Case Tests ==========

    @Test
    void successCreatesValidResultWithUserAndSession() {
        SessionValidationResult result = SessionValidationResult.success(mockUser, mockSession);

        assertThat(result.isValid()).isTrue();
        assertThat(result.getUser()).isEqualTo(mockUser);
        assertThat(result.getSession()).isEqualTo(mockSession);
        assertThat(result.getErrorResponse()).isNull();
    }

    @Test
    void successWithNullUserAndSessionCreatesValidResult() {
        SessionValidationResult result = SessionValidationResult.success(null, null);

        assertThat(result.isValid()).isTrue();
        assertThat(result.getUser()).isNull();
        assertThat(result.getSession()).isNull();
        assertThat(result.getErrorResponse()).isNull();
    }

    // ========== Failure Case Tests ==========

    @Test
    void failureCreatesInvalidResultWithErrorResponse() {
        Response errorResponse = mock(Response.class);
        SessionValidationResult result = SessionValidationResult.failure(errorResponse);

        assertThat(result.isValid()).isFalse();
        assertThat(result.getErrorResponse()).isEqualTo(errorResponse);
        assertThat(result.getUser()).isNull();
        assertThat(result.getSession()).isNull();
    }

    @Test
    void failureWithNullResponseCreatesInvalidResult() {
        SessionValidationResult result = SessionValidationResult.failure(null);

        assertThat(result.isValid()).isFalse();
        assertThat(result.getErrorResponse()).isNull();
        assertThat(result.getUser()).isNull();
        assertThat(result.getSession()).isNull();
    }

    // ========== Data Consistency Tests ==========

    @Test
    void gettersReturnCorrectValuesAfterSuccess() {
        SessionValidationResult result = SessionValidationResult.success(mockUser, mockSession);

        // Multiple calls should return same values
        assertThat(result.isValid()).isTrue();
        assertThat(result.isValid()).isTrue();
        assertThat(result.getUser()).isEqualTo(mockUser);
        assertThat(result.getSession()).isEqualTo(mockSession);
    }

    @Test
    void gettersReturnCorrectValuesAfterFailure() {
        Response errorResponse = mock(Response.class);
        SessionValidationResult result = SessionValidationResult.failure(errorResponse);

        // Multiple calls should return same values
        assertThat(result.isValid()).isFalse();
        assertThat(result.isValid()).isFalse();
        assertThat(result.getErrorResponse()).isEqualTo(errorResponse);
    }

    @Test
    void successAndFailureCreateDifferentResults() {
        SessionValidationResult success = SessionValidationResult.success(mockUser, mockSession);
        SessionValidationResult failure = SessionValidationResult.failure(mock(Response.class));

        assertThat(success.isValid()).isTrue();
        assertThat(failure.isValid()).isFalse();
    }

}

