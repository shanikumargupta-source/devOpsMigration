package com.vf.cove.charon.internal.resource.v1_0;

import com.vf.cove.charon.dto.v1_0.CheckSessionResponse;
import com.vf.cove.charon.dto.v1_0.CreateSessionResponse;
import com.vf.cove.charon.internal.service.SessionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SessionResourceImplTest {


    @Mock
    private SessionService sessionService;

    // ========== createSession() Tests ==========

    @Test
    void createSessionReturnsResponseFromService() {
        CreateSessionResponse expectedResponse = new CreateSessionResponse();
        expectedResponse.setCode(200);
        expectedResponse.setStatus("authenticated");
        expectedResponse.setMessage("JWT Session created successfully");

        HttpServletRequest request = mock(HttpServletRequest.class);
        when(sessionService.createSession(request)).thenReturn(expectedResponse);

        CreateSessionResponse result = sessionService.createSession(request);

        assertThat(result).isEqualTo(expectedResponse);
        assertThat(result.getCode()).isEqualTo(200);
        assertThat(result.getStatus()).isEqualTo("authenticated");
    }

    // ...existing code...

    // ========== checkSession() Tests ==========

    @Test
    void checkSessionReturnsResponseFromService() {
        CheckSessionResponse expectedResponse = new CheckSessionResponse();
        expectedResponse.setCode(200);
        expectedResponse.setStatus("valid");
        expectedResponse.setMessage("JWT session is valid and matches with liferay session");

        HttpServletRequest request = mock(HttpServletRequest.class);
        when(sessionService.checkSession(request)).thenReturn(expectedResponse);

        CheckSessionResponse result = sessionService.checkSession(request);

        assertThat(result).isEqualTo(expectedResponse);
        assertThat(result.getCode()).isEqualTo(200);
        assertThat(result.getStatus()).isEqualTo("valid");
    }

    // ...existing code...

    // ========== Integration Tests ==========

    @Test
    void resourceProperlyDelegatesRequestToService() {
        CreateSessionResponse response = new CreateSessionResponse();
        response.setCode(200);

        HttpServletRequest request = mock(HttpServletRequest.class);
        when(sessionService.createSession(request)).thenReturn(response);

        CreateSessionResponse result = sessionService.createSession(request);

        assertThat(result).isNotNull();
        assertThat(result.getCode()).isEqualTo(200);
    }

}


