package com.vf.cove.charon.internal.service.jwt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JwtRoleValidatorTest {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Mock
    private CharonApiConfiguration config;

    // ========== Valid Role Tests ==========

    @Test
    void validateReturnsTrueWhenUserRoleMatchesAllowedRoles() throws Exception {
        testValidRole("ROLE_ADMIN", "ROLE_ADMIN|ROLE_USER");
        testValidRole("ROLE_USER", "ROLE_ADMIN|ROLE_USER|ROLE_GUEST");
        testValidRole("ROLE_GUEST", "ROLE_ADMIN|ROLE_USER|ROLE_GUEST");
        testValidRole("ADMIN", "ADMIN|USER");
    }

    private void testValidRole(String userRole, String allowedRoles) throws Exception {
        String payload = "{\"userRole\": \"" + userRole + "\"}";
        JsonNode payloadNode = mapper.readTree(payload);
        when(config.jwtAllowedRolesList()).thenReturn(allowedRoles);

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).as("Role " + userRole + " should match allowed roles").isTrue();
    }

    // ========== Invalid Role Tests ==========

    @Test
    void validateReturnsFalseWhenUserRoleDoesNotMatchAllowedRoles() throws Exception {
        testInvalidRole("ROLE_GUEST", "ROLE_ADMIN|ROLE_USER", "Guest role not in allowed list");
        testInvalidRole("ROLE_SUPERADMIN", "ROLE_ADMIN", "SuperAdmin role not allowed");
        testInvalidRole("ROLE_VIEWER", "ROLE_ADMIN|ROLE_USER", "Viewer role not in list");
        testInvalidRole("INVALID", "ROLE_ADMIN|ROLE_USER|ROLE_GUEST", "Invalid role not in allowed");
        testInvalidRole("USER_TEST", "ADMIN|GUEST", "User test not matching allowed roles");
    }

    private void testInvalidRole(String userRole, String allowedRoles, String testDescription) throws Exception {
        String payload = "{\"userRole\": \"" + userRole + "\"}";
        JsonNode payloadNode = mapper.readTree(payload);
        when(config.jwtAllowedRolesList()).thenReturn(allowedRoles);

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).as(testDescription).isFalse();
    }

    @Test
    void validateReturnsFalseWhenUserRoleClaimIsMissing() throws Exception {
        String payload = "{\"email\": \"user@example.com\"}";
        JsonNode payloadNode = mapper.readTree(payload);

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).isFalse();
    }

    @Test
    void validateReturnsFalseWhenUserRoleClaimIsNull() throws Exception {
        String payload = "{\"userRole\": null}";
        JsonNode payloadNode = mapper.readTree(payload);

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).isFalse();
    }

    // ========== Configuration Tests ==========

    @Test
    void validateReturnsFalseWhenConfigurationIsInvalid() throws Exception {
        // Test: Payload is null
        boolean result = JwtRoleValidator.validate(null, config);
        assertThat(result).as("Null payload should return false").isFalse();

        // Test: Config is null
        String payload = "{\"userRole\": \"ROLE_ADMIN\"}";
        JsonNode payloadNode = mapper.readTree(payload);
        result = JwtRoleValidator.validate(payloadNode, null);
        assertThat(result).as("Null config should return false").isFalse();

        // Test: Allowed roles is empty
        when(config.jwtAllowedRolesList()).thenReturn("");
        result = JwtRoleValidator.validate(payloadNode, config);
        assertThat(result).as("Empty roles should return false").isFalse();

        // Test: Allowed roles is null
        when(config.jwtAllowedRolesList()).thenReturn(null);
        result = JwtRoleValidator.validate(payloadNode, config);
        assertThat(result).as("Null roles should return false").isFalse();
    }

    // ========== Edge Case Tests ==========

    @Test
    void validateHandlesRolesWithWhitespace() throws Exception {
        String payload = "{\"userRole\": \"ROLE_ADMIN\"}";
        JsonNode payloadNode = mapper.readTree(payload);
        when(config.jwtAllowedRolesList()).thenReturn(" ROLE_ADMIN | ROLE_USER | ROLE_GUEST ");

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).isTrue();
    }

    @Test
    void validateReturnsFalseWhenConfigThrowsException() throws Exception {
        String payload = "{\"userRole\": \"ROLE_ADMIN\"}";
        JsonNode payloadNode = mapper.readTree(payload);
        when(config.jwtAllowedRolesList()).thenThrow(new RuntimeException("Config error"));

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).isFalse();
    }

    @Test
    void validateUsesContainsMatchingForRoles() throws Exception {
        String payload = "{\"userRole\": \"USER_ADMIN_ROLE\"}";
        JsonNode payloadNode = mapper.readTree(payload);
        when(config.jwtAllowedRolesList()).thenReturn("ADMIN");

        boolean result = JwtRoleValidator.validate(payloadNode, config);

        assertThat(result).isTrue();
    }

}

