package com.vf.cove.charon.internal.service.jwt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;
import com.vf.cove.charon.internal.configuration.CharonConfigurationResolver;
import com.vf.cove.charon.internal.configuration.registry.CharonClientRegistryImpl;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Base64;
import java.util.Objects;

@Component(service = JwtTokenUtils.class)
public class JwtTokenUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtTokenUtils.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private static final String JWT_CLAIM_EMAIL = "email";
    private static final String JWT_CLAIM_SUB = "sub";
    private static final String JWT_CLAIM_AUD = "aud";
    private static final String JWT_CLAIM_ISS = "iss";
    private static final String JWT_CLAIM_EXP = "exp";
    private static final String JWT_CLAIM_NBF = "nbf";

    @Reference
    private CharonClientRegistryImpl clientRegistry;

    public String validateJwtAndExtractEmail(String jwtToken) {
        try {
            JsonNode payloadNode = parsePayload(jwtToken);
            if (payloadNode == null) {
                LOGGER.warn("JWT token payload could not be parsed");
                return null;
            }

            String audience = getAudience(payloadNode);
            if (audience == null) {
                LOGGER.warn("JWT token missing audience claim");
                return null;
            }

            // Resolve configuration for the given audience via the registry
            CharonApiConfiguration config = resolveConfigForAudience(audience);
            if (config == null) {
                // Log available configured client IDs to help debug missing config
                logMissingConfigurationWarning(audience);
                return null;
            }

            // Validate signature using the selected config
            if (!validateJwtSignature(jwtToken, config)) {
                LOGGER.warn("Invalid JWT signature");
                return null;
            }

            if (!validateStandardClaims(payloadNode, config, audience)) {
                return null;
            }

            String email = extractEmail(payloadNode);

            if (!validateUserRole(payloadNode, config)) {
                return null;
            }

            return email;
        } catch (java.io.IOException ioe) {
            // Parsing/decoding issue - likely malformed token
            LOGGER.warn("Failed to parse JWT payload: {}", ioe.getMessage());
            return null;
        } catch (Exception e) {
            // Any other unexpected error
            LOGGER.error("Error validating JWT token", e);
            return null;
        }
    }

    private JsonNode parsePayload(String jwtToken) throws java.io.IOException {
        String[] tokenParts = jwtToken.split("\\.");
        if (tokenParts.length != 3) {
            LOGGER.warn("Invalid JWT format");
            return null;
        }

        try {
            String payloadJson = new String(Base64.getUrlDecoder().decode(tokenParts[1]));
            return objectMapper.readTree(payloadJson);
        } catch (IllegalArgumentException | com.fasterxml.jackson.core.JsonProcessingException e) {
            throw new java.io.IOException("Failed to parse JWT payload", e);
        }
    }

    private String getAudience(JsonNode payloadNode) {
        if (!payloadNode.has(JWT_CLAIM_AUD)) {
            return null;
        }
        return payloadNode.get(JWT_CLAIM_AUD).asText();
    }

    private boolean validateStandardClaims(JsonNode payloadNode, CharonApiConfiguration config, String audience) {
        // exp
        if (payloadNode.has(JWT_CLAIM_EXP)) {
            long exp = payloadNode.get(JWT_CLAIM_EXP).asLong();
            long currentTime = System.currentTimeMillis() / 1000;
            if (currentTime > exp) {
                LOGGER.warn("JWT token has expired");
                return false;
            }
        }

        // iss
        if (payloadNode.has(JWT_CLAIM_ISS)) {
            String issuer = payloadNode.get(JWT_CLAIM_ISS).asText();
            String expectedIssuer = config.jwtIssuer();

            LOGGER.info("Expected issuer {} ", expectedIssuer);

            if (!expectedIssuer.equals(issuer)) {
                LOGGER.warn("Invalid JWT issuer. Expected: {} Got: {}", expectedIssuer, issuer);
                return false;
            }
        } else {
            LOGGER.warn("JWT token missing issuer claim");
            return false;
        }

        // aud already checked above, but double-check and compare
        String expectedAudience = config.jwtAudience();
        LOGGER.info("Expected audience {} ", expectedAudience);
        if (!expectedAudience.equals(audience)) {
            LOGGER.warn("Invalid JWT audience. Expected: {} Got: {}", expectedAudience, audience);
            return false;
        }

        // nbf
        if (payloadNode.has(JWT_CLAIM_NBF)) {
            long nbf = payloadNode.get(JWT_CLAIM_NBF).asLong();
            long currentTime = System.currentTimeMillis() / 1000;
            if (currentTime < nbf) {
                LOGGER.warn("JWT token not yet valid (nbf claim)");
                return false;
            }
        }

        return true;
    }

    private String extractEmail(JsonNode payloadNode) {
        String email = null;
        if (payloadNode.has(JWT_CLAIM_EMAIL) && !payloadNode.get(JWT_CLAIM_EMAIL).isNull()) {
            email = payloadNode.get(JWT_CLAIM_EMAIL).asText();
        }
        if (Validator.isNull(email) && payloadNode.has(JWT_CLAIM_SUB) && !payloadNode.get(JWT_CLAIM_SUB).isNull()) {
            email = payloadNode.get(JWT_CLAIM_SUB).asText();
        }
        return email;
    }

    private boolean validateUserRole(JsonNode payloadNode, CharonApiConfiguration config) {
        return JwtRoleValidator.validate(payloadNode, config);
    }

    public boolean validateJwtSignature(String jwtToken, CharonApiConfiguration config) {
        try {
            String kid = extractKid(jwtToken);
            if (Validator.isNull(kid)) {
                LOGGER.warn("JWT header does not contain kid");
                return false;
            }

            JsonNode matchingKey = getValidMatchingKey(config, kid);
            if (matchingKey == null) {
                LOGGER.warn("No matching key found for kid: {}", kid);
                return false;
            }

            if (!isSupportedKey(matchingKey)) {
                LOGGER.warn("Unsupported key type or algorithm");
                return false;
            }

            String signedData = getSignedData(jwtToken);
            byte[] signatureBytes = getSignatureBytes(jwtToken);
            if (signedData == null || signatureBytes == null) {
                LOGGER.warn("Invalid JWT format for signature verification");
                return false;
            }

            boolean verified = verifySignatureWithKey(matchingKey, signedData, signatureBytes);
            if (!verified) {
                LOGGER.warn("JWT signature verification failed");
            }
            return verified;
        } catch (Exception e) {
            LOGGER.error("Error validating JWT signature", e);
            return false;
        }
    }

    private JsonNode getValidMatchingKey(CharonApiConfiguration config, String kid) {
        JsonNode jwks = fetchJwks(config);
        if (jwks == null) {
            LOGGER.error("Failed to fetch JWKS");
            return null;
        }
        JsonNode keys = jwks.get("keys");
        if (keys == null || !keys.isArray()) {
            LOGGER.error("Invalid JWKS format");
            return null;
        }
        return findKeyForKid(keys, kid);
    }

    private boolean isSupportedKey(JsonNode key) {
        if (key == null) {
            return false;
        }
        JsonNode ktyNode = key.get("kty");
        JsonNode algNode = key.get("alg");
        if (ktyNode == null || algNode == null) {
            return false;
        }
        return "RSA".equals(ktyNode.asText()) && "RS256".equals(algNode.asText());
    }

    private String getSignedData(String jwtToken) {
        String[] tokenParts = jwtToken.split("\\.");
        if (tokenParts.length != 3) {
            return null;
        }
        return tokenParts[0] + "." + tokenParts[1];
    }

    private byte[] getSignatureBytes(String jwtToken) {
        String[] tokenParts = jwtToken.split("\\.");
        if (tokenParts.length != 3) {
            return null;
        }
        try {
            return Base64.getUrlDecoder().decode(tokenParts[2]);
        } catch (IllegalArgumentException iae) {
            LOGGER.warn("Failed to decode JWT signature", iae);
            return null;
        }
    }

    private JsonNode findKeyForKid(JsonNode keys, String kid) {
        for (JsonNode key : keys) {
            if (key.has("kid") && !key.get("kid").isNull()) {
                String keyKid = key.get("kid").asText();
                if (Objects.equals(kid, keyKid)) {
                    return key;
                }
            }
        }
        return null;
    }

    private String extractKid(String jwtToken) throws java.io.IOException {
        String[] tokenParts = jwtToken.split("\\.");
        if (tokenParts.length != 3) {
            throw new java.io.IOException("Invalid JWT format");
        }
        try {
            String headerJson = new String(Base64.getUrlDecoder().decode(tokenParts[0]));
            JsonNode headerNode = objectMapper.readTree(headerJson);
            if (headerNode.has("kid")) {
                return headerNode.get("kid").asText();
            }
            return null;
        } catch (IllegalArgumentException | com.fasterxml.jackson.core.JsonProcessingException e) {
            throw new java.io.IOException("Failed to parse JWT header", e);
        }
    }

    public JsonNode fetchJwks(CharonApiConfiguration config) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Fetching JWKS : {}", config.jwtJwksUrl());
        }

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(config.jwtJwksUrl()))
                    .timeout(Duration.ofSeconds(10))
                    .GET()
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                return objectMapper.readTree(response.body());
            } else {
                LOGGER.error("Failed to fetch JWKS, status code: {}", response.statusCode());
                return null;
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            LOGGER.error("JWKS fetch interrupted", ie);
            return null;
        } catch (Exception e) {
            LOGGER.error("Error fetching JWKS", e);
            return null;
        }
    }

    private boolean verifySignatureWithKey(JsonNode key, String signedData, byte[] signatureBytes) {
        try {
            String n = key.get("n").asText();
            String e = key.get("e").asText();
            byte[] modulusBytes = Base64.getUrlDecoder().decode(n);
            byte[] exponentBytes = Base64.getUrlDecoder().decode(e);
            java.math.BigInteger modulus = new java.math.BigInteger(1, modulusBytes);
            java.math.BigInteger exponent = new java.math.BigInteger(1, exponentBytes);
            java.security.spec.RSAPublicKeySpec spec = new java.security.spec.RSAPublicKeySpec(modulus, exponent);
            java.security.KeyFactory kf = java.security.KeyFactory.getInstance("RSA");
            java.security.PublicKey publicKey = kf.generatePublic(spec);
            java.security.Signature sig = java.security.Signature.getInstance("SHA256withRSA");
            sig.initVerify(publicKey);
            sig.update(signedData.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            return sig.verify(signatureBytes);
        } catch (Exception ex) {
            LOGGER.error("Error during JWT signature verification", ex);
            return false;
        }
    }
    public String extractJWTToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }

        String ciamHeader = request.getHeader("X-CIAM-JWT");
        if (ciamHeader == null) {
            ciamHeader = request.getHeader("x-ciam-jwt");
        }

        if (ciamHeader != null && !ciamHeader.trim().isEmpty()) {
            return ciamHeader.trim();
        }

        String jwtParam = request.getParameter("jwt_token");
        return jwtParam != null ? jwtParam.trim() : null;
    }

    public String getAudienceFromSession(HttpServletRequest request) {
        String audience = request.getParameter("audience");
        return audience != null ? audience.trim() : null;
    }

    // Helper to resolve config for an audience
    public CharonApiConfiguration resolveConfigForAudience(String audience) {
        return CharonConfigurationResolver.resolveConfigForAudience(audience, clientRegistry);
    }

    /**
     * Logs a warning when configuration is not found for the given audience.
     * Attempts to include available configured client IDs in the warning message.
     *
     * @param audience the requested audience that was not found
     */
    private void logMissingConfigurationWarning(String audience) {
        try {
            java.util.Set<String> configured = clientRegistry.getConfiguredClientIds();
            LOGGER.warn("No configuration found for audience: {}. Available configured audiences: {}", audience, configured);
        } catch (Exception ex) {
            LOGGER.warn("No configuration found for audience: {} and failed to read available configs: {}", audience, ex.getMessage());
        }
    }

}
