package com.vf.cove.charon.internal.validation;

import com.liferay.portal.kernel.model.User;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

public class SessionValidationResult {
    private final boolean valid;
    private final User user;
    private final HttpSession session;
    private final Response errorResponse;

    private SessionValidationResult(boolean valid, User user, HttpSession session, Response errorResponse) {
        this.valid = valid;
        this.user = user;
        this.session = session;
        this.errorResponse = errorResponse;
    }

    public static SessionValidationResult success(User user, HttpSession session) {
        return new SessionValidationResult(true, user, session, null);
    }

    public static SessionValidationResult failure(Response errorResponse) {
        return new SessionValidationResult(false, null, null, errorResponse);
    }

    public boolean isValid() {
        return valid;
    }

    public User getUser() {
        return user;
    }

    public HttpSession getSession() {
        return session;
    }

    public Response getErrorResponse() {
        return errorResponse;
    }
}