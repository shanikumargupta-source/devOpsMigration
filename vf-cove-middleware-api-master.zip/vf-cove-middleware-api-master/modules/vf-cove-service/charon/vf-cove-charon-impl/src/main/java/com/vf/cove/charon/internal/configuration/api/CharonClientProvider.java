package com.vf.cove.charon.internal.configuration.api;


import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;

/**
 * Represents a single configured Charon client (one per factory .config).
 */
public interface CharonClientProvider {
    /**
     * The key used to register this provider in the registry. We use the JWT audience
     * as the lookup key in the registry.
     */
    String getClientKey();

    /**
     * Return the typed configuration for this client (API view).
     */
    CharonApiConfiguration getConfiguration();
}
