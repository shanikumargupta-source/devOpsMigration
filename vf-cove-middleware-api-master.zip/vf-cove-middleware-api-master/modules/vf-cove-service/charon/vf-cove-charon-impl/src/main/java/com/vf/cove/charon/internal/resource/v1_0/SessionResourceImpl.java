package com.vf.cove.charon.internal.resource.v1_0;

import com.vf.cove.charon.internal.service.SessionService;
import com.vf.cove.charon.resource.v1_0.SessionResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

import com.vf.cove.charon.dto.v1_0.CreateSessionResponse;
import com.vf.cove.charon.dto.v1_0.CheckSessionResponse;

@Component(
    properties = "OSGI-INF/liferay/rest/v1_0/session.properties",
    scope = ServiceScope.PROTOTYPE, service = SessionResource.class
)
public class SessionResourceImpl extends BaseSessionResourceImpl {

    @Reference(unbind = "-")
    private SessionService sessionService;

    @Context
    private HttpServletRequest request;

    @Context
    private HttpServletResponse response;

    @Override
    public CreateSessionResponse createSession() throws Exception {
        return sessionService.createSession(request);
    }

    @Override
    public CheckSessionResponse checkSession() throws Exception {
        return sessionService.checkSession(request);
    }

}