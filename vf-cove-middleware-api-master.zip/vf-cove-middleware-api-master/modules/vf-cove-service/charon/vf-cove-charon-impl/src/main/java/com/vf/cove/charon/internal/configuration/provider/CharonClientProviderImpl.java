package com.vf.cove.charon.internal.configuration.provider;

import com.vf.cove.charon.internal.configuration.api.CharonClientProvider;
import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component(
    configurationPid = "com.vf.cove.charon.internal.configuration.CharonApiConfiguration",
    configurationPolicy = ConfigurationPolicy.REQUIRE,
    immediate = true,
    service = CharonClientProvider.class
)
public class CharonClientProviderImpl implements CharonClientProvider {
    private static final Logger LOGGER = LoggerFactory.getLogger(CharonClientProviderImpl.class);
    private static final Pattern ENV_VAR_PATTERN = Pattern.compile("^env:([^:]+)(?::(.+))?$");

    private final AtomicReference<CharonApiConfiguration> configuration = new AtomicReference<>();

    @Activate
    @Modified
    protected void activate(Map<String, Object> properties) {
        LOGGER.info("=== CharonClientProviderImpl Activation START ===");
        LOGGER.info("Raw properties received: {}", properties);

        // Resolve environment variables in properties
        Map<String, Object> resolvedProperties = resolveEnvironmentVariables(properties);

        LOGGER.info("Resolved properties: {}", resolvedProperties);

        configuration.set(ConfigurableUtil.createConfigurable(CharonApiConfiguration.class, resolvedProperties));

        CharonApiConfiguration cfg = configuration.get();
        if (cfg != null) {
            LOGGER.info("=== Charon Client Configuration ===");
            LOGGER.info("JWT JWKS URL: {}", cfg.jwtJwksUrl());
            LOGGER.info("JWT Issuer: {}", cfg.jwtIssuer());
            LOGGER.info("JWT Audience: {}", cfg.jwtAudience());
            LOGGER.info("JWT Allowed Roles: {}", cfg.jwtAllowedRolesList());
            LOGGER.info("Liferay Session Timer: {}", cfg.liferaySessionTimer());
            LOGGER.info("=== Configuration Applied Successfully ===");
        } else {
            LOGGER.error("Configuration is NULL after activation!");
        }
    }

    /**
     * Resolves environment variable placeholders in configuration properties.
     * Supports syntax: env:VARIABLE_NAME or env:VARIABLE_NAME:default_value
     */
    private Map<String, Object> resolveEnvironmentVariables(Map<String, Object> properties) {
        Map<String, Object> resolved = new HashMap<>(properties);

        for (Map.Entry<String, Object> entry : properties.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            if (value instanceof String) {
                String stringValue = (String) value;
                String resolvedValue = resolveEnvVar(stringValue);

                if (!stringValue.equals(resolvedValue)) {
                    LOGGER.info("Resolved env var in '{}': '{}' -> '{}'", key, stringValue, resolvedValue);
                    resolved.put(key, resolvedValue);
                }
            }
        }

        return resolved;
    }

    /**
     * Resolves environment variable placeholders in a string.
     *
     * Supports formats:
     * - env:VAR_NAME - resolves to env var value, null if not found
     * - env:VAR_NAME:default_value - resolves to env var, falls back to default
     *
     * Examples:
     * - "env:MY_VAR" -> value of MY_VAR or null
     * - "env:MY_VAR:fallback_value" -> value of MY_VAR or "fallback_value"
     */
    private String resolveEnvVar(String value) {
        if (value == null || value.isEmpty()) {
            return value;
        }

        // Only process if it starts with "env:" (not preceded by other characters)
        if (!value.startsWith("env:")) {
            return value;
        }

        Matcher matcher = ENV_VAR_PATTERN.matcher(value);

        if (!matcher.find()) {
            return value;
        }

        String envVarName = matcher.group(1);
        String defaultValue = matcher.group(2);

        String envVarValue = System.getenv(envVarName);

        if (envVarValue != null) {
            LOGGER.info("Found environment variable: {} = {}", envVarName, envVarValue);
            return envVarValue;
        }

        if (defaultValue != null) {
            LOGGER.info("Environment variable NOT FOUND: {} (using default: {})", envVarName, defaultValue);
            return defaultValue;
        }

        LOGGER.warn("Environment variable NOT FOUND: {} (no default specified, setting to null)", envVarName);
        return null;
    }

    @Override
    public String getClientKey() {
        CharonApiConfiguration cfg = configuration.get();
        return cfg != null ? cfg.jwtAudience() : null;
    }

    @Override
    public CharonApiConfiguration getConfiguration() {
        return configuration.get();
    }
}