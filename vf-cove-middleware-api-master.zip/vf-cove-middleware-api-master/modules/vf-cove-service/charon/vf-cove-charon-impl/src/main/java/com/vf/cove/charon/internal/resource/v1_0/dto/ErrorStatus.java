package com.vf.cove.charon.internal.resource.v1_0.dto;

/**
 * Shared status constants used in error responses.
 */
public final class ErrorStatus {
    public static final String ERROR = "error";
    public static final String UNAUTHORIZED = "unauthorized";

    private ErrorStatus() {
        // no instances
    }
}
