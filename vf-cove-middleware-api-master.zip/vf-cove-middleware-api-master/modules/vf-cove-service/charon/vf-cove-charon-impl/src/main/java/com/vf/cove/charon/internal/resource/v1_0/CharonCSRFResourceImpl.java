package com.vf.cove.charon.internal.resource.v1_0;

import com.liferay.portal.kernel.security.auth.AuthTokenUtil;
import com.vf.cove.charon.resource.v1_0.CharonCSRFResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

/**
 * @author VBITDC
 */
@Component(
    properties = "OSGI-INF/liferay/rest/v1_0/charon-csrf.properties",
    scope = ServiceScope.PROTOTYPE, service = CharonCSRFResource.class
)
public class CharonCSRFResourceImpl extends BaseCharonCSRFResourceImpl {

    @Context
    private HttpServletRequest _request;

    @Override
    @GET
    @Path("/csrf")
    @Produces({"application/json", "application/xml"})
    public String getCsrfToken() {
        // Liferay’s built‑in util returns exactly the p_auth string
        return AuthTokenUtil.getToken(_request);
    }

}
