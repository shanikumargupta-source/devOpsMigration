package com.vf.cove.charon.internal.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.Layout;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.security.auth.AuthTokenUtil;
import com.liferay.portal.kernel.security.auth.PrincipalThreadLocal;
import com.liferay.portal.kernel.security.permission.PermissionChecker;
import com.liferay.portal.kernel.security.permission.PermissionCheckerFactoryUtil;
import com.liferay.portal.kernel.security.permission.PermissionThreadLocal;
import com.liferay.portal.kernel.service.CompanyLocalServiceUtil;
import com.liferay.portal.kernel.service.GroupLocalServiceUtil;
import com.liferay.portal.kernel.service.LayoutLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;
import com.vf.cove.charon.internal.resource.v1_0.dto.ErrorCatalog;
import com.vf.cove.charon.internal.validation.SessionValidationResult;
import com.vf.cove.charon.dto.v1_0.*;
import com.vf.cove.charon.internal.service.jwt.JwtTokenUtils;
import org.jspecify.annotations.NonNull;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component(service = SessionService.class, scope = ServiceScope.SINGLETON, immediate = true)
public class SessionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SessionService.class);
    private static final int DEFAULT_SESSION_TIMEOUT_MINUTES = 30;

    @Reference(unbind = "-")
    private JwtTokenUtils jwtTokenUtils;

    public CreateSessionResponse createSession(HttpServletRequest request) {
        try {
            String jwtToken = jwtTokenUtils.extractJWTToken(request);
            if (jwtToken == null) {
                throw new WebApplicationException(ErrorCatalog.JWT_REQUIRED.toResponse());
            }

            String userEmail = jwtTokenUtils.validateJwtAndExtractEmail(jwtToken);
            if (userEmail == null) {
                throw new WebApplicationException(ErrorCatalog.INVALID_JWT.toResponse());
            }

            User user = getUserByEmail(userEmail);
            if (user == null || !user.isActive()) {
                throw new WebApplicationException(ErrorCatalog.USER_NOT_FOUND.toResponse(userEmail));
            }

            if (!setLiferayAuthenticatedSessionSafe(user, request)) {
                throw new WebApplicationException(ErrorCatalog.SESSION_CREATION_FAILED.toResponse());
            }

            String csrfToken = generateCsrfToken(request, user);
            if (csrfToken == null) {
                LOGGER.error("Failed to generate CSRF token");
            }

            HttpSession session = request.getSession(false);
            if (!isSessionValid(session, user, userEmail)) {
                String msg = session == null ? "Session is null" : "User in session does not match token user";
                throw new WebApplicationException(ErrorCatalog.SESSION_INVALID.toResponse(msg));
            }

            return buildSuccessResponse(user, session, csrfToken, request);
        } catch (WebApplicationException wae) {
            LOGGER.debug("Application error during session creation: {}", wae.getMessage());
            throw wae;
        } catch (Exception e) {
            // Unexpected error - log with full stack trace for debugging and wrap in WebApplicationException
            LOGGER.error("Unexpected error during session creation: {}", e.getMessage(), e);
            throw new WebApplicationException(ErrorCatalog.INTERNAL_SERVER_ERROR.toResponse("Unexpected error: " + e.getMessage()));
        }
    }

    public CheckSessionResponse checkSession(HttpServletRequest request) {
        try {
            String jwtToken = jwtTokenUtils.extractJWTToken(request);
            if (jwtToken == null) {
                throw new WebApplicationException(ErrorCatalog.JWT_REQUIRED.toResponse());
            }

            String userEmail = jwtTokenUtils.validateJwtAndExtractEmail(jwtToken);
            if (userEmail == null) {
                throw new WebApplicationException(ErrorCatalog.INVALID_JWT.toResponse());
            }

            User user = getUserByEmail(userEmail);
            if (user == null || !user.isActive()) {
                throw new WebApplicationException(ErrorCatalog.USER_NOT_FOUND.toResponse(userEmail));
            }

            SessionValidationResult sessionValidation = validateSession(request, userEmail);
            if (!sessionValidation.isValid()) {
                Response errResp = sessionValidation.getErrorResponse();
                throw new WebApplicationException(errResp);
            }
            HttpSession session = sessionValidation.getSession();
            User sessionUser = sessionValidation.getUser();
            String sessionUserEmail = sessionUser.getEmailAddress();
            Long sessionUserId = sessionUser.getUserId();

            LOGGER.info("Fetched session user: email={}, id={}, screenName={}, fullName={}",
                    sessionUserEmail, sessionUserId, sessionUser.getScreenName(), sessionUser.getFullName());

            CheckSessionResponse resp = new CheckSessionResponse();
            resp.setMessage("JWT session is valid and matches with liferay session");
            resp.setStatus("valid");
            resp.setCode(200);

            UserDetails userDetails = new UserDetails();
            userDetails.setUserId(sessionUserId.intValue());
            userDetails.setUserEmail(sessionUserEmail);
            userDetails.setUserScreenName(sessionUser.getScreenName());
            userDetails.setUserFullName(sessionUser.getFullName());
            userDetails.setActive(sessionUser.isActive());
            userDetails.setLastLoginTime(getLoginTimeForResponse(request, sessionUserId));
            userDetails.setOrganizations(mapOrganizationToArray(sessionUser.getOrganizations()));
            userDetails.setGroups(mapGroupSafeToArray(sessionUser));
            resp.setUserDetails(userDetails);

            SessionDetails sessionDetails = new SessionDetails();
            sessionDetails.setSessionId(session.getId());
            sessionDetails.setSessionExists(true);
            sessionDetails.setMaxInactiveInterval(session.getMaxInactiveInterval());
            sessionDetails.setTimeoutMinutes(session.getMaxInactiveInterval() / 60);
            sessionDetails.setCreationTime(new Date(session.getCreationTime()).toString());
            sessionDetails.setLastAccessedTime(new Date(session.getLastAccessedTime()).toString());
            sessionDetails.setExpiresAt(new Date(System.currentTimeMillis() + (session.getMaxInactiveInterval() * 1000L)).toString());
            resp.setSessionDetails(sessionDetails);

            JwtValidationDetails jwtDetails = new JwtValidationDetails();
            jwtDetails.setTokenProvided(true);
            jwtDetails.setTokenValid(true);
            jwtDetails.setUserEmail(userEmail);
            jwtDetails.setSignatureVerified(true);
            jwtDetails.setUserMatchesSession(true);
            resp.setJwtDetails(jwtDetails);

            LOGGER.info("=== JWT Session Check Success ===");
            LOGGER.info("User: {} (ID: {})", sessionUserEmail, sessionUserId);
            LOGGER.info("Session: {}", session.getId());
            LOGGER.info("JWT and session users match");

            return resp;
        } catch (WebApplicationException wae) {
            LOGGER.debug("Application error during session check: {}", wae.getMessage());
            throw wae;
        } catch (Exception e) {
            // Unexpected error - log with full stack trace for debugging and wrap in WebApplicationException
            LOGGER.error("Unexpected error during session check: {}", e.getMessage(), e);
            throw new WebApplicationException(ErrorCatalog.INTERNAL_SERVER_ERROR.toResponse("Unexpected error: " + e.getMessage()));
        }
    }

    private SessionValidationResult validateSession(HttpServletRequest request, String jwtUserEmail) {
        try {
            HttpSession session = request.getSession(false);
            if (session == null) {
                return SessionValidationResult.failure(ErrorCatalog.NO_AUTHENTICATED_USER.toResponse());
            }

            User sessionUser = PortalUtil.getUser(request);
            if (sessionUser == null) {
                return SessionValidationResult.failure(ErrorCatalog.NO_AUTHENTICATED_USER.toResponse());
            }

            String sessionUserEmail = sessionUser.getEmailAddress();
            if (!jwtUserEmail.equalsIgnoreCase(sessionUserEmail)) {
                return SessionValidationResult.failure(ErrorCatalog.JWT_EMAIL_MISMATCH.toResponse());
            }

            return SessionValidationResult.success(sessionUser, session);
        } catch (PortalException e) {
            LOGGER.error("Error validating session", e);
            return SessionValidationResult.failure(ErrorCatalog.ERROR_VALIDATING_SESSION.toResponse());
        }
    }

    private void setLiferayAuthenticatedSession(User user, HttpServletRequest request) throws PortalException {
        LOGGER.info("Setting Liferay authenticated session for user: {}", user.getEmailAddress());

        PrincipalThreadLocal.setName(user.getUserId());

        PermissionChecker permissionChecker = PermissionCheckerFactoryUtil.create(user);
        PermissionThreadLocal.setPermissionChecker(permissionChecker);

        HttpSession session = request.getSession(true);
        configureSessionTimeout(session, request);

        Company company = CompanyLocalServiceUtil.getCompany(user.getCompanyId());

        session.setAttribute(WebKeys.USER_ID, user.getUserId());
        session.setAttribute(WebKeys.USER, user);
        session.setAttribute(WebKeys.COMPANY_ID, user.getCompanyId());
        session.setAttribute(WebKeys.COMPANY, company);

        request.setAttribute(WebKeys.USER_ID, user.getUserId());
        request.setAttribute(WebKeys.USER, user);
        request.setAttribute(WebKeys.COMPANY_ID, user.getCompanyId());
        request.setAttribute(WebKeys.COMPANY, company);

        ThemeDisplay themeDisplay = createCompleteThemeDisplay(user, company, request);
        session.setAttribute(WebKeys.THEME_DISPLAY, themeDisplay);
        request.setAttribute(WebKeys.THEME_DISPLAY, themeDisplay);

        session.setAttribute("LIFERAY_SHARED_USER_ID", user.getUserId());
        session.setAttribute("j_username", user.getLogin());
        session.setAttribute("REMOTE_USER", user.getLogin());

        session.setAttribute("LIFERAY_SESSION_DIRTY", Boolean.TRUE);

        session.setAttribute("PORTAL_SESSION_AUTHENTICATED", Boolean.TRUE);
        session.setAttribute("USER_LOGIN_TIME", System.currentTimeMillis());

        LOGGER.info("Liferay authenticated session set successfully for user: {}", user.getUserId());
    }

    private ThemeDisplay createCompleteThemeDisplay(User user, Company company, HttpServletRequest request) throws PortalException {
        ThemeDisplay themeDisplay = new ThemeDisplay();

        themeDisplay.setCompany(company);
        themeDisplay.setUser(user);
        themeDisplay.setSignedIn(true);
        themeDisplay.setRealUser(user);

        String portalURL = PortalUtil.getPortalURL(request);
        themeDisplay.setPortalURL(portalURL);
        themeDisplay.setServerName(request.getServerName());
        themeDisplay.setServerPort(request.getServerPort());
        themeDisplay.setSecure(request.isSecure());

        String protocol = request.isSecure() ? "https" : "http";
        themeDisplay.setPortalURL(protocol + "://" + request.getServerName() +
                (request.getServerPort() != 80 && request.getServerPort() != 443 ?
                        ":" + request.getServerPort() : ""));

        try {
            com.liferay.portal.kernel.model.Group guestGroup = GroupLocalServiceUtil.getGroup(company.getCompanyId(), com.liferay.portal.kernel.model.GroupConstants.GUEST);
            themeDisplay.setScopeGroupId(guestGroup.getGroupId());
            themeDisplay.setSiteGroupId(guestGroup.getGroupId());

            List<Layout> layouts = LayoutLocalServiceUtil.getLayouts(guestGroup.getGroupId(), false);
            if (!layouts.isEmpty()) {
                Layout defaultLayout = layouts.get(0);
                themeDisplay.setLayout(defaultLayout);
                themeDisplay.setPlid(defaultLayout.getPlid());
                themeDisplay.setLayoutSet(defaultLayout.getLayoutSet());

                themeDisplay.setTilesTitle(defaultLayout.getTitle(user.getLocale()));
            }
        } catch (PortalException e) {
            LOGGER.warn("Could not set complete layout context: {}", e.getMessage(), e);
            com.liferay.portal.kernel.model.Group guestGroup = GroupLocalServiceUtil.getGroup(company.getCompanyId(), com.liferay.portal.kernel.model.GroupConstants.GUEST);
            themeDisplay.setScopeGroupId(guestGroup.getGroupId());
        }

        PermissionChecker permissionChecker = PermissionCheckerFactoryUtil.create(user);
        themeDisplay.setPermissionChecker(permissionChecker);

        themeDisplay.setLocale(user.getLocale());
        themeDisplay.setTimeZone(user.getTimeZone());
        themeDisplay.setLanguageId(user.getLanguageId());

        themeDisplay.setWidget(false);
        themeDisplay.setStateExclusive(false);
        themeDisplay.setStateMaximized(false);
        themeDisplay.setStatePopUp(false);

        return themeDisplay;
    }

    private User getUserByEmail(String userEmail) {
        try {
            long companyId = PortalUtil.getDefaultCompanyId();
            return UserLocalServiceUtil.getUserByEmailAddress(companyId, userEmail);
        } catch (Exception e) {
            LOGGER.error("User lookup failed for: {}", userEmail, e);
            return null;
        }
    }

    private String getLastLoginTime(Long userId) {
        try {
            User user = UserLocalServiceUtil.getUser(userId);
            if (user != null && user.getLastLoginDate() != null) {
                return formatDateWithTimezone(user.getLastLoginDate());
            }
            return null;
        } catch (Exception e) {
            LOGGER.debug("Unable to retrieve last login time for user {}: {}", userId, e.getMessage());
            return null;
        }
    }

    private String getPreviousLoginTime(HttpServletRequest request) {
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                Date previousLoginDate = (Date) session.getAttribute("PREVIOUS_LOGIN_DATE");
                if (previousLoginDate != null) {
                    return formatDateWithTimezone(previousLoginDate);
                }
            }
            return null;
        } catch (Exception e) {
            LOGGER.debug("Unable to retrieve previous login time from session: {}", e.getMessage());
            return null;
        }
    }

    private String formatDateWithTimezone(Date date) {
        try {
            // Format as ISO 8601 with UTC timezone: 2026-01-16T10:14:46Z
            Instant instant = date.toInstant();
            return DateTimeFormatter.ISO_INSTANT.format(instant);
        } catch (Exception e) {
            LOGGER.warn("Error formatting date, falling back to toString(): {}", e.getMessage());
            // Fallback to default toString() which includes timezone
            return date.toString();
        }
    }

    private String getLoginTimeForResponse(HttpServletRequest request, Long userId) {
        // First try to get the previous login date from the session (set by JWT Pre-Auth Filter)
        String previousLogin = getPreviousLoginTime(request);
        if (previousLogin != null) {
            LOGGER.info("Using previous login time from session: {}", previousLogin);
            return previousLogin;
        }

        // Fall back to current lastLoginDate
        return getLastLoginTime(userId);
    }

    private boolean isSessionValid(HttpSession session, User user, String expectedEmail) {
        return session != null &&
                user != null &&
                user.isActive() &&
                user.getEmailAddress().equalsIgnoreCase(expectedEmail);
    }

    private boolean setLiferayAuthenticatedSessionSafe(User user, HttpServletRequest request) {
        try {
            setLiferayAuthenticatedSession(user, request);
            LOGGER.info("Created authenticated session for user: {}", user.getEmailAddress());
            return true;
        } catch (Exception e) {
            LOGGER.error("Failed to create session for user: {}", user.getEmailAddress(), e);
            return false;
        }
    }

    private String generateCsrfToken(HttpServletRequest request, User user) {
        try {
            String csrfToken = AuthTokenUtil.getToken(request);
            LOGGER.info("Generated CSRF token for user: {}", user.getEmailAddress());
            return csrfToken;
        } catch (Exception e) {
            LOGGER.error("Failed to generate CSRF token", e);
            return null;
        }
    }

    private void configureSessionTimeout(HttpSession session, HttpServletRequest request) {
        int sessionTimeout = DEFAULT_SESSION_TIMEOUT_MINUTES;

        try {
            String audience = jwtTokenUtils.getAudienceFromSession(request);
            if (audience != null) {
                CharonApiConfiguration config = jwtTokenUtils.resolveConfigForAudience(audience);
                if (config != null && config.liferaySessionTimer() != null) {
                    int configuredTimeout = Integer.parseInt(config.liferaySessionTimer());
                    sessionTimeout = configuredTimeout > 0 ? configuredTimeout : DEFAULT_SESSION_TIMEOUT_MINUTES;
                    LOGGER.info("Configured session timeout from config for audience {}: {} minutes", audience, sessionTimeout);
                }
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to resolve session timeout from config, using default: {} minutes", DEFAULT_SESSION_TIMEOUT_MINUTES, e);
        }

        session.setMaxInactiveInterval(sessionTimeout * 60);
        LOGGER.info("Session max inactive interval set to: {} minutes", sessionTimeout);
    }

    private List<Organization> mapOrganization(List<com.liferay.portal.kernel.model.Organization> organizations) {
        List<Organization> orgList = new ArrayList<>();
        if (organizations != null) {
            for (com.liferay.portal.kernel.model.Organization org : organizations) {
                Organization orgDetails = new Organization();
                orgDetails.setOrganizationId((int) org.getOrganizationId());
                orgDetails.setName(org.getName());
                orgDetails.setParentName(org.getParentOrganizationName());
                orgDetails.setParentOrgId((int) org.getParentOrganizationId());
                orgList.add(orgDetails);
            }
        }
        return orgList;
    }

    private Organization[] mapOrganizationToArray(List<com.liferay.portal.kernel.model.Organization> organizations) {
        List<Organization> list = mapOrganization(organizations);
        return list.toArray(new Organization[0]);
    }

    private List<Group> mapGroupSafe(User user) {
        try {
            return mapGroup(user.getGroups());
        } catch (Exception e) {
            LOGGER.warn("Failed to retrieve user groups for user {}: {}", user.getUserId(), e.getMessage());
            return new ArrayList<>();
        }
    }

    private Group[] mapGroupSafeToArray(User user) {
        List<Group> list = mapGroupSafe(user);
        return list.toArray(new Group[0]);
    }

    private List<Group> mapGroup(List<com.liferay.portal.kernel.model.Group> userGroup) {
        List<Group> groupList = new ArrayList<>();
        if (userGroup != null) {
            for (com.liferay.portal.kernel.model.Group group : userGroup) {
                if (group.isSite() && !group.isUser() && !group.isCompany()) {
                    Group groupDetails = getGroupDetails(group);
                    groupList.add(groupDetails);
                }
            }
        }
        return groupList;
    }

    private static @NonNull Group getGroupDetails(com.liferay.portal.kernel.model.Group group) {
        Group groupDetails = new Group();
        groupDetails.setGroupId((int) group.getGroupId());
        groupDetails.setName(extractPlainTextName(group.getName()));
        groupDetails.setFriendlyURL(group.getFriendlyURL());
        groupDetails.setDescription(group.getDescription());
        groupDetails.setType(String.valueOf(group.getType()));
        groupDetails.setActive(group.isActive());
        groupDetails.setSite(group.isSite());
        return groupDetails;
    }

    private CreateSessionResponse buildSuccessResponse(User user, HttpSession session, String csrfToken, HttpServletRequest request) {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserId((int) user.getUserId());
        userDetails.setUserEmail(user.getEmailAddress());
        userDetails.setUserScreenName(user.getScreenName());
        userDetails.setUserFullName(user.getFullName());
        userDetails.setActive(user.isActive());
        userDetails.setLastLoginTime(getLoginTimeForResponse(request, user.getUserId()));
        // mapOrganization should not throw; if it does, fall back to empty list
        try {
            userDetails.setOrganizations(mapOrganizationToArray(user.getOrganizations()));
        } catch (Exception e) {
            LOGGER.warn("Failed to map organizations for user {}: {}", user.getUserId(), e.getMessage());
            userDetails.setOrganizations(new Organization[0]);
        }
        userDetails.setGroups(mapGroupSafeToArray(user));

        SessionDetails sessionDetails = new SessionDetails();
        sessionDetails.setSessionId(session != null ? session.getId() : "none");
        sessionDetails.setCsrfToken(csrfToken != null ? csrfToken : "failed_to_generate");
        sessionDetails.setMaxInactiveInterval(session != null ? session.getMaxInactiveInterval() : 0);
        sessionDetails.setTimeoutMinutes(session != null ? session.getMaxInactiveInterval() / 60 : 0);
        sessionDetails.setExpiresAt(session != null ? new Date(System.currentTimeMillis() + (session.getMaxInactiveInterval() * 1000L)).toString() : "none");
        sessionDetails.setCreationTime(session != null ? new Date(session.getCreationTime()).toString() : "none");

        CreateSessionResponse response = new CreateSessionResponse();
        response.setMessage("JWT Session created successfully");
        response.setStatus("authenticated");
        response.setCode(200);
        response.setUserDetails(userDetails);
        response.setSessionDetails(sessionDetails);
        return response;
    }


    /**
     * Extracts plain text name from Liferay's XML-formatted name strings using XPath.
     * Liferay stores multilingual names as XML, e.g.:
     * <?xml version='1.0' encoding='UTF-8'?><root ...><Name language-id="en_US">portal</Name></root>
     *
     * This method uses XPath to extract the text content of the Name element.
     * If the input is not XML-formatted, it returns the input as-is.
     *
     * @param xmlFormattedName the XML-formatted name from Liferay
     * @return plain text name or empty string if extraction fails
     */
    private static String extractPlainTextName(String xmlFormattedName) {
        if (xmlFormattedName == null || xmlFormattedName.trim().isEmpty()) {
            return "";
        }

        // If it doesn't contain XML, return as-is
        if (!xmlFormattedName.contains("<?xml")) {
            return xmlFormattedName;
        }

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Disable external entity processing for security
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);

            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(xmlFormattedName)));

            XPath xpath = XPathFactory.newInstance().newXPath();
            NodeList nodes = (NodeList) xpath.evaluate("//Name/text()", doc, XPathConstants.NODESET);

            if (nodes.getLength() > 0) {
                String plainText = nodes.item(0).getNodeValue().trim();
                return plainText.isEmpty() ? xmlFormattedName : plainText;
            }

            return xmlFormattedName;
        } catch (Exception e) {
            LOGGER.warn("Failed to parse XML-formatted name, returning original: {}", e.getMessage());
            return xmlFormattedName;
        }
    }
}
