package com.vf.cove.charon.internal.configuration;

import aQute.bnd.annotation.metatype.Meta;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

@ExtendedObjectClassDefinition(category = "vodafone")
@Meta.OCD(id = "com.vf.cove.charon.internal.configuration.CharonApiConfiguration", factory = true, localization = "content/Language", name = "Charon configuration (per client)")
public interface CharonApiConfiguration {

    String PID = "com.vf.cove.charon.internal.configuration.CharonApiConfiguration";

    @Meta.AD(deflt = "https://ciamsso.sit1.ciam.vodafone.com/oauth2/jwks", required = true, description = "JWKS url for this client")
    String jwtJwksUrl();

    @Meta.AD(deflt = "https://ciamsso.sit1.ciam.vodafone.com/oauth2/token", required = true, description = "JWT Token Issuer for this client")
    String jwtIssuer();

    @Meta.AD(deflt = "aajfiZpy6jonTAERfGvJNylhsnEa", required = true, description = "JWT token audience (client_id for CIAM) for this client")
    String jwtAudience();

    @Meta.AD(deflt = "BUSINESSPORTAL_USER", required = true, description = "Required roles for JWT Authorization pipe char '|' separated, for this client")
    String jwtAllowedRolesList();

    @Meta.AD(deflt = "30", required = false, description = "Session time in Liferay for this client")
    String liferaySessionTimer();
}
