package com.vf.cove.charon.internal.configuration.registry;

import com.vf.cove.charon.internal.configuration.api.CharonClientProvider;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Component(immediate = true, service = CharonClientRegistryImpl.class)
public class CharonClientRegistryImpl {
    private final ConcurrentMap<String, CharonClientProvider> providers = new ConcurrentHashMap<>();

    @Reference(
        cardinality = ReferenceCardinality.MULTIPLE,
        policy = ReferencePolicy.DYNAMIC,
        service = CharonClientProvider.class,
        bind = "bindProvider",
        unbind = "unbindProvider"
    )
    protected void bindProvider(CharonClientProvider provider) {
        String key = provider.getClientKey();
        if (key != null && !key.isEmpty()) {
            providers.put(key, provider);
        }
    }

    protected void unbindProvider(CharonClientProvider provider) {
        String key = provider.getClientKey();
        if (key != null && !key.isEmpty()) {
            providers.remove(key);
        }
    }

    public CharonClientProvider getClient(String clientKey) {
        return providers.get(clientKey);
    }

    /**
     * Return an unmodifiable set of currently configured client keys (audiences).
     */
    public java.util.Set<String> getConfiguredClientIds() {
        return java.util.Collections.unmodifiableSet(providers.keySet());
    }

}
