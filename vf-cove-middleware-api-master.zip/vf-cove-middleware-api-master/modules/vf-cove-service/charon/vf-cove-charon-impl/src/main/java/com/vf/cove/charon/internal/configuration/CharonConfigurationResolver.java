package com.vf.cove.charon.internal.configuration;

import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.charon.internal.configuration.api.CharonClientProvider;
import com.vf.cove.charon.internal.configuration.registry.CharonClientRegistryImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class to resolve CharonApiConfiguration dynamically based on audience/client ID.
 * This allows components to get the correct configuration without hard-coded dependencies.
 */
public class CharonConfigurationResolver {
    private static final Logger LOGGER = LoggerFactory.getLogger(CharonConfigurationResolver.class);

    private CharonConfigurationResolver() {
        // Utility class - prevent instantiation
    }

    /**
     * Resolve configuration for a given audience/client ID via the registry.
     *
     * @param audience The JWT audience or client ID
     * @param clientRegistry The registry to lookup the client provider
     * @return CharonApiConfiguration if found, null otherwise
     */
    public static CharonApiConfiguration resolveConfigForAudience(String audience, CharonClientRegistryImpl clientRegistry) {
        if (Validator.isNull(audience) || clientRegistry == null) {
            return null;
        }

        try {
            CharonClientProvider provider = clientRegistry.getClient(audience);
            if (provider == null) {
                LOGGER.debug("No provider registered for audience: {}", audience);
                return null;
            }

            CharonApiConfiguration cfg = provider.getConfiguration();
            if (cfg == null) {
                LOGGER.debug("Provider for audience {} returned null configuration", audience);
                return null;
            }

            return cfg;
        } catch (Exception e) {
            // Log the exception with stacktrace at debug level — registry failures shouldn't break validation flow
            LOGGER.debug("Registry lookup failed for audience: {}", audience, e);
            return null;
        }
    }
}

