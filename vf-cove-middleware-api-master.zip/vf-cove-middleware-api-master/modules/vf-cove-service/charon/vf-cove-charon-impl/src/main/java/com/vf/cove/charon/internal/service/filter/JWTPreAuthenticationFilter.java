package com.vf.cove.charon.internal.service.filter;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.auth.PrincipalThreadLocal;

import com.liferay.portal.kernel.security.permission.PermissionChecker;
import com.liferay.portal.kernel.security.permission.PermissionCheckerFactoryUtil;
import com.liferay.portal.kernel.security.permission.PermissionThreadLocal;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.service.CompanyLocalServiceUtil;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

import com.vf.cove.charon.internal.service.jwt.JwtTokenUtils;

/**
 * JWT Pre-Authentication Filter that runs BEFORE Service Access Policy
 * This filter processes JWT tokens and creates authenticated sessions
 * so that Service Access Policy sees an authenticated user.
 */
@Component(
    immediate = true,
    property = {
        "servlet-context-name=",
        "servlet-filter-name=JWT Pre-Authentication Filter",
        "url-pattern=/o/vf-cove-charon/1.0/create-session",
        "dispatcher=REQUEST",
        "before-filter=Service Access Policy Filter"
    },
    service = Filter.class
)
public class JWTPreAuthenticationFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(JWTPreAuthenticationFilter.class);
    @Reference(unbind = "-")
    private JwtTokenUtils jwtTokenUtils;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("=== JWT Pre-Authentication Filter INITIALIZED v1 ===");
        log.info("Filter Name: {}", filterConfig != null ? filterConfig.getFilterName() : "null");
        log.info("This filter is configured for URLs:");
        log.info("  - /o/vf-cove-charon/1.0/create-session");
        log.info("Filter should trigger BEFORE Service Access Policy Filter");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String requestURI = httpRequest.getRequestURI();
        String method = httpRequest.getMethod();

        log.info("=== JWT Pre-Authentication Filter TRIGGERED ===");
        log.info("Request URI: {}", requestURI);
        log.info("HTTP Method: {}", method);
        log.info("Authorization Header: {}", httpRequest.getHeader("Authorization") != null ? "Present" : "Missing");

        try {
            // Check if user is already authenticated
            if (PortalUtil.getUserId(httpRequest) > 0) {
                log.info("User already authenticated, skipping JWT processing");
                chain.doFilter(request, response);
                return;
            }

            // Look for JWT token
            String jwtToken = extractJWTToken(httpRequest);

            if (Validator.isNotNull(jwtToken)) {
                log.info("Found JWT token, attempting pre-authentication for: {}", httpRequest.getRequestURI());

                // Validate and extract user info from JWT
                String userEmail = jwtTokenUtils.validateJwtAndExtractEmail(jwtToken);

                if (Validator.isNotNull(userEmail)) {
                    // Find and authenticate user
                    User user = findUserByEmail(httpRequest, userEmail);

                    if (user != null && user.isActive()) {
                        // Create authenticated session BEFORE Service Access Policy and capture previous login date
                        Date previousLoginDate = createAuthenticatedSession(httpRequest, user);

                        // Store previous login date in session for SessionService to retrieve
                        HttpSession session = httpRequest.getSession(false);
                        if (session != null && previousLoginDate != null) {
                            session.setAttribute("PREVIOUS_LOGIN_DATE", previousLoginDate);
                            log.info("Stored previous login date in session: {}", previousLoginDate);
                        }

                        log.info("Pre-authentication successful for user: {}", user.getEmailAddress());
                    } else {
                        log.warn("User not found or inactive: {}", userEmail);
                    }
                } else {
                    log.warn("Invalid JWT token provided");
                }
            }

        } catch (PortalException pe) {
            log.error("Portal exception during JWT pre-authentication: {}", pe.getMessage(), pe);
            // Continue without authentication - let the request proceed for proper error handling
        } catch (RuntimeException rte) {
            log.error("Runtime exception during JWT pre-authentication: {}", rte.getMessage(), rte);
            // Continue without authentication - let the request proceed for proper error handling
        } catch (Exception e) {
            log.error("Unexpected error in JWT pre-authentication filter: {}", e.getMessage(), e);
            // Continue without authentication - let the request proceed for proper error handling
        }

        // Continue with the request
        chain.doFilter(request, response);
    }

    private String extractJWTToken(HttpServletRequest request) {
        // Check Authorization header
        String authHeader = request.getHeader("Authorization");
        if (Validator.isNotNull(authHeader) && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }

        // Check custom CIAM headers (case insensitive)
        String ciamHeader = request.getHeader("X-CIAM-JWT");
        if (Validator.isNull(ciamHeader)) {
            ciamHeader = request.getHeader("x-ciam-jwt");
        }

        if (Validator.isNotNull(ciamHeader)) {
            // Handle both with and without "Bearer " prefix
            if (ciamHeader.startsWith("Bearer ")) {
                return ciamHeader.substring(7);
            } else {
                return ciamHeader;
            }
        }

        // Check query parameter
        return request.getParameter("jwt_token");
    }

    private User findUserByEmail(HttpServletRequest request, String email) {
        if (Validator.isNotNull(email)) {
            email = email.toLowerCase(java.util.Locale.ROOT);
        }
        try {
            long companyId = PortalUtil.getCompanyId(request);
            log.info("Looking for user with email: {} in company: {}", email, companyId);

            User user = UserLocalServiceUtil.getUserByEmailAddress(companyId, email);
            log.info("Found user: {} (ID: {}, Active: {})", user.getEmailAddress(), user.getUserId(), user.isActive());
            return user;
        } catch (PortalException pe) {
            log.warn("User not found for email: {} - Portal error: {}", email, pe.getMessage());
            // IMPORTANT: Do NOT fall back to default user - this causes the wrong user to be authenticated
            // Instead, return null and let the authentication fail properly
            log.info("Not using fallback user - authentication should fail for non-existent users");
            return null;
        }
    }

    private Date createAuthenticatedSession(HttpServletRequest request, User user) throws PortalException {
        HttpSession session = request.getSession(true);
        Company company = CompanyLocalServiceUtil.getCompany(user.getCompanyId());

        // Capture previous login date BEFORE updating
        Date previousLoginDate = user.getLastLoginDate();


        // Update user's last login date with current session creation time
        Date now = new Date();
        user.setLastLoginDate(now);
        UserLocalServiceUtil.updateUser(user);
        log.info("Updated last login date for user: {} to {}. Previous login: {}",
            user.getEmailAddress(), now, previousLoginDate != null ? previousLoginDate : "Never logged in before");

        // Set core Liferay session attributes
        session.setAttribute(WebKeys.USER_ID, user.getUserId());
        session.setAttribute(WebKeys.USER, user);
        session.setAttribute(WebKeys.COMPANY_ID, user.getCompanyId());
        session.setAttribute(WebKeys.COMPANY, company);

        // Set request attributes for immediate recognition
        request.setAttribute(WebKeys.USER_ID, user.getUserId());
        request.setAttribute(WebKeys.USER, user);
        request.setAttribute(WebKeys.COMPANY_ID, user.getCompanyId());
        request.setAttribute(WebKeys.COMPANY, company);

        // Set ThreadLocal context (critical for Service Access Policy)
        PrincipalThreadLocal.setName(user.getUserId());
        PermissionChecker permissionChecker = PermissionCheckerFactoryUtil.create(user);
        PermissionThreadLocal.setPermissionChecker(permissionChecker);

        // Set authentication markers
        session.setAttribute("LIFERAY_SHARED_USER_ID", user.getUserId());
        session.setAttribute("j_username", user.getLogin());
        session.setAttribute("REMOTE_USER", user.getLogin());
        session.setAttribute("JWT_AUTHENTICATED", Boolean.TRUE);

        log.info("Created authenticated session for user: {} (ID: {})", user.getEmailAddress(), user.getUserId());

        // Return previous login date so it can be used in the response
        return previousLoginDate;
    }

    @Override
    public void destroy() {
        log.info("JWT Pre-Authentication Filter destroyed");
    }
}
