package com.vf.cove.charon.internal.service.jwt;

import com.fasterxml.jackson.databind.JsonNode;
import com.vf.cove.charon.internal.configuration.CharonApiConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Small helper to validate user role claim against configured allowed roles.
 * Kept as a separate class to reduce cognitive complexity in JwtTokenValidator.
 */
public final class JwtRoleValidator {
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtRoleValidator.class);
    private static final String JWT_CLAIM_USER_ROLE = "userRole";

    private JwtRoleValidator() {
        // utility
    }

    public static boolean validate(JsonNode payloadNode, CharonApiConfiguration config) {
        if (payloadNode == null) {
            return false;
        }

        if (!payloadNode.has(JWT_CLAIM_USER_ROLE) || payloadNode.get(JWT_CLAIM_USER_ROLE).isNull()) {
            LOGGER.warn("JWT token missing userRole claim");
            return false;
        }

        String userRole = payloadNode.get(JWT_CLAIM_USER_ROLE).asText();

        List<String> allowedRoles = parseAllowedRoles(config);
        if (allowedRoles == null || allowedRoles.isEmpty()) {
            return false; // parseAllowedRoles logged
        }

        boolean matches = allowedRoles.stream().anyMatch(userRole::contains);
        if (!matches) {
            LOGGER.warn("JWT token missing required DLM role(s). userRole: {} expected: {}", userRole, allowedRoles);
            return false;
        }

        LOGGER.info("Role validation successful : {} as expected roles : {}", userRole, allowedRoles);
        return true;
    }

    private static List<String> parseAllowedRoles(CharonApiConfiguration config) {
        if (config == null) {
            LOGGER.warn("No Charon configuration provided for role validation");
            return List.of();
        }

        String allowedRolesRaw;
        try {
            allowedRolesRaw = config.jwtAllowedRolesList();
        } catch (Exception ex) {
            LOGGER.warn("Failed to read allowed roles from config", ex);
            return List.of();
        }

        if (allowedRolesRaw == null || allowedRolesRaw.trim().isEmpty()) {
            LOGGER.warn("No allowed roles configured for JWT validation");
            return List.of();
        }

        return Arrays.stream(allowedRolesRaw.split("\\|"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }
}

