package com.vf.cove.charon.internal.resource.v1_0.dto;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import java.util.Locale;

// Use the API-generated ErrorResponse DTO so responses match the REST API types
import com.vf.cove.charon.dto.v1_0.ErrorMessage;

/**
 * Centralized error catalog for building ErrorResponse objects and JAX-RS Responses.
 */
public enum ErrorCatalog {
    JWT_REQUIRED("JWT token required", "Authentication required. Please provide a valid JWT token.", ErrorStatus.UNAUTHORIZED, 401),
    INVALID_JWT("Invalid JWT token", "JWT token validation failed. Token may be expired, malformed, incorrect role or have invalid signature.", ErrorStatus.UNAUTHORIZED, 401),
    USER_NOT_FOUND("User not found", "User with email '%s' not found or inactive in Liferay.", ErrorStatus.UNAUTHORIZED, 401),
    SESSION_CREATION_FAILED("Session creation failed", "Failed to create authenticated session.", ErrorStatus.ERROR, 500),
    SESSION_INVALID("Session creation failed", "%s", ErrorStatus.ERROR, 500),
    INTERNAL_SERVER_ERROR("Internal server error", "An error occurred: %s", ErrorStatus.ERROR, 500),
    NO_AUTHENTICATED_USER("No authenticated user", "No authenticated user", ErrorStatus.UNAUTHORIZED, 401),
    JWT_EMAIL_MISMATCH("JWT token email does not match session user", "JWT token email does not match session user", ErrorStatus.ERROR, 400),
    ERROR_VALIDATING_SESSION("Error validating session", "Error validating session", ErrorStatus.ERROR, 500),
    SESSION_INVALIDATION_FAILED("Session invalidation failed", "Failed to properly invalidate session: %s", ErrorStatus.ERROR, 500);

    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorCatalog.class);

    private final String error;
    private final String messageTemplate;
    private final String status;
    private final int code;

    ErrorCatalog(String error, String messageTemplate, String status, int code) {
        this.error = error;
        this.messageTemplate = messageTemplate;
        this.status = status;
        this.code = code;
    }

    public Response toResponse(Object... args) {
        String message = formatMessage(args);

        ErrorMessage errorResponse = new ErrorMessage();
        errorResponse.setError(this.error);
        errorResponse.setMessage(message);
        errorResponse.setStatus(this.status);
        errorResponse.setCode(this.code);

        if (this.code >= 500) {
            LOGGER.error("{} - {}", this.error, message);
        } else {
            LOGGER.warn("{} - {}", this.error, message);
        }

        return Response.status(this.code).entity(errorResponse).build();
    }

    private String formatMessage(Object... args) {
        if (args == null || args.length == 0) {
            // If template contains a %s but no args provided, just return template
            return this.messageTemplate;
        }

        try {
            return String.format(Locale.ENGLISH, this.messageTemplate, args);
        } catch (Exception e) {
            LOGGER.warn("Failed to format error message template '{}' with args: {}", this.messageTemplate, java.util.Arrays.toString(args), e);
            return this.messageTemplate;
        }
    }
}
