package com.vf.cove.charon.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author VBITDC
 * @generated
 */
@Generated("")
@GraphQLName("SessionDetails")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "SessionDetails")
public class SessionDetails implements Serializable {

	public static SessionDetails toDTO(String json) {
		return ObjectMapperUtil.readValue(SessionDetails.class, json);
	}

	public static SessionDetails unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(SessionDetails.class, json);
	}

	@Schema(example = "2026-02-19T12:00:00Z")
	public String getCreationTime() {
		if (_creationTimeSupplier != null) {
			creationTime = _creationTimeSupplier.get();

			_creationTimeSupplier = null;
		}

		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;

		_creationTimeSupplier = null;
	}

	@JsonIgnore
	public void setCreationTime(
		UnsafeSupplier<String, Exception> creationTimeUnsafeSupplier) {

		_creationTimeSupplier = () -> {
			try {
				return creationTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String creationTime;

	@JsonIgnore
	private Supplier<String> _creationTimeSupplier;

	@Schema(example = "xTyeKl")
	public String getCsrfToken() {
		if (_csrfTokenSupplier != null) {
			csrfToken = _csrfTokenSupplier.get();

			_csrfTokenSupplier = null;
		}

		return csrfToken;
	}

	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;

		_csrfTokenSupplier = null;
	}

	@JsonIgnore
	public void setCsrfToken(
		UnsafeSupplier<String, Exception> csrfTokenUnsafeSupplier) {

		_csrfTokenSupplier = () -> {
			try {
				return csrfTokenUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String csrfToken;

	@JsonIgnore
	private Supplier<String> _csrfTokenSupplier;

	@Schema(example = "2026-02-19T12:30:00Z")
	public String getExpiresAt() {
		if (_expiresAtSupplier != null) {
			expiresAt = _expiresAtSupplier.get();

			_expiresAtSupplier = null;
		}

		return expiresAt;
	}

	public void setExpiresAt(String expiresAt) {
		this.expiresAt = expiresAt;

		_expiresAtSupplier = null;
	}

	@JsonIgnore
	public void setExpiresAt(
		UnsafeSupplier<String, Exception> expiresAtUnsafeSupplier) {

		_expiresAtSupplier = () -> {
			try {
				return expiresAtUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String expiresAt;

	@JsonIgnore
	private Supplier<String> _expiresAtSupplier;

	@Schema(example = "2026-02-19T12:05:00Z")
	public String getLastAccessedTime() {
		if (_lastAccessedTimeSupplier != null) {
			lastAccessedTime = _lastAccessedTimeSupplier.get();

			_lastAccessedTimeSupplier = null;
		}

		return lastAccessedTime;
	}

	public void setLastAccessedTime(String lastAccessedTime) {
		this.lastAccessedTime = lastAccessedTime;

		_lastAccessedTimeSupplier = null;
	}

	@JsonIgnore
	public void setLastAccessedTime(
		UnsafeSupplier<String, Exception> lastAccessedTimeUnsafeSupplier) {

		_lastAccessedTimeSupplier = () -> {
			try {
				return lastAccessedTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lastAccessedTime;

	@JsonIgnore
	private Supplier<String> _lastAccessedTimeSupplier;

	@Schema(example = "1800")
	public Integer getMaxInactiveInterval() {
		if (_maxInactiveIntervalSupplier != null) {
			maxInactiveInterval = _maxInactiveIntervalSupplier.get();

			_maxInactiveIntervalSupplier = null;
		}

		return maxInactiveInterval;
	}

	public void setMaxInactiveInterval(Integer maxInactiveInterval) {
		this.maxInactiveInterval = maxInactiveInterval;

		_maxInactiveIntervalSupplier = null;
	}

	@JsonIgnore
	public void setMaxInactiveInterval(
		UnsafeSupplier<Integer, Exception> maxInactiveIntervalUnsafeSupplier) {

		_maxInactiveIntervalSupplier = () -> {
			try {
				return maxInactiveIntervalUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer maxInactiveInterval;

	@JsonIgnore
	private Supplier<Integer> _maxInactiveIntervalSupplier;

	@Schema(example = "true")
	public Boolean getSessionExists() {
		if (_sessionExistsSupplier != null) {
			sessionExists = _sessionExistsSupplier.get();

			_sessionExistsSupplier = null;
		}

		return sessionExists;
	}

	public void setSessionExists(Boolean sessionExists) {
		this.sessionExists = sessionExists;

		_sessionExistsSupplier = null;
	}

	@JsonIgnore
	public void setSessionExists(
		UnsafeSupplier<Boolean, Exception> sessionExistsUnsafeSupplier) {

		_sessionExistsSupplier = () -> {
			try {
				return sessionExistsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean sessionExists;

	@JsonIgnore
	private Supplier<Boolean> _sessionExistsSupplier;

	@Schema(example = "abcdef123456")
	public String getSessionId() {
		if (_sessionIdSupplier != null) {
			sessionId = _sessionIdSupplier.get();

			_sessionIdSupplier = null;
		}

		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;

		_sessionIdSupplier = null;
	}

	@JsonIgnore
	public void setSessionId(
		UnsafeSupplier<String, Exception> sessionIdUnsafeSupplier) {

		_sessionIdSupplier = () -> {
			try {
				return sessionIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String sessionId;

	@JsonIgnore
	private Supplier<String> _sessionIdSupplier;

	@Schema(example = "30")
	public Integer getTimeoutMinutes() {
		if (_timeoutMinutesSupplier != null) {
			timeoutMinutes = _timeoutMinutesSupplier.get();

			_timeoutMinutesSupplier = null;
		}

		return timeoutMinutes;
	}

	public void setTimeoutMinutes(Integer timeoutMinutes) {
		this.timeoutMinutes = timeoutMinutes;

		_timeoutMinutesSupplier = null;
	}

	@JsonIgnore
	public void setTimeoutMinutes(
		UnsafeSupplier<Integer, Exception> timeoutMinutesUnsafeSupplier) {

		_timeoutMinutesSupplier = () -> {
			try {
				return timeoutMinutesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer timeoutMinutes;

	@JsonIgnore
	private Supplier<Integer> _timeoutMinutesSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof SessionDetails)) {
			return false;
		}

		SessionDetails sessionDetails = (SessionDetails)object;

		return Objects.equals(toString(), sessionDetails.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String creationTime = getCreationTime();

		if (creationTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"creationTime\": ");

			sb.append("\"");

			sb.append(_escape(creationTime));

			sb.append("\"");
		}

		String csrfToken = getCsrfToken();

		if (csrfToken != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"csrfToken\": ");

			sb.append("\"");

			sb.append(_escape(csrfToken));

			sb.append("\"");
		}

		String expiresAt = getExpiresAt();

		if (expiresAt != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"expiresAt\": ");

			sb.append("\"");

			sb.append(_escape(expiresAt));

			sb.append("\"");
		}

		String lastAccessedTime = getLastAccessedTime();

		if (lastAccessedTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lastAccessedTime\": ");

			sb.append("\"");

			sb.append(_escape(lastAccessedTime));

			sb.append("\"");
		}

		Integer maxInactiveInterval = getMaxInactiveInterval();

		if (maxInactiveInterval != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"maxInactiveInterval\": ");

			sb.append(maxInactiveInterval);
		}

		Boolean sessionExists = getSessionExists();

		if (sessionExists != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sessionExists\": ");

			sb.append(sessionExists);
		}

		String sessionId = getSessionId();

		if (sessionId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sessionId\": ");

			sb.append("\"");

			sb.append(_escape(sessionId));

			sb.append("\"");
		}

		Integer timeoutMinutes = getTimeoutMinutes();

		if (timeoutMinutes != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"timeoutMinutes\": ");

			sb.append(timeoutMinutes);
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.charon.dto.v1_0.SessionDetails",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}