package com.vf.cove.charon.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author VBITDC
 * @generated
 */
@Generated("")
@GraphQLName("JwtValidationDetails")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "JwtValidationDetails")
public class JwtValidationDetails implements Serializable {

	public static JwtValidationDetails toDTO(String json) {
		return ObjectMapperUtil.readValue(JwtValidationDetails.class, json);
	}

	public static JwtValidationDetails unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			JwtValidationDetails.class, json);
	}

	@Schema(example = "true")
	public Boolean getSignatureVerified() {
		if (_signatureVerifiedSupplier != null) {
			signatureVerified = _signatureVerifiedSupplier.get();

			_signatureVerifiedSupplier = null;
		}

		return signatureVerified;
	}

	public void setSignatureVerified(Boolean signatureVerified) {
		this.signatureVerified = signatureVerified;

		_signatureVerifiedSupplier = null;
	}

	@JsonIgnore
	public void setSignatureVerified(
		UnsafeSupplier<Boolean, Exception> signatureVerifiedUnsafeSupplier) {

		_signatureVerifiedSupplier = () -> {
			try {
				return signatureVerifiedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean signatureVerified;

	@JsonIgnore
	private Supplier<Boolean> _signatureVerifiedSupplier;

	@Schema(example = "true")
	public Boolean getTokenProvided() {
		if (_tokenProvidedSupplier != null) {
			tokenProvided = _tokenProvidedSupplier.get();

			_tokenProvidedSupplier = null;
		}

		return tokenProvided;
	}

	public void setTokenProvided(Boolean tokenProvided) {
		this.tokenProvided = tokenProvided;

		_tokenProvidedSupplier = null;
	}

	@JsonIgnore
	public void setTokenProvided(
		UnsafeSupplier<Boolean, Exception> tokenProvidedUnsafeSupplier) {

		_tokenProvidedSupplier = () -> {
			try {
				return tokenProvidedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean tokenProvided;

	@JsonIgnore
	private Supplier<Boolean> _tokenProvidedSupplier;

	@Schema(example = "true")
	public Boolean getTokenValid() {
		if (_tokenValidSupplier != null) {
			tokenValid = _tokenValidSupplier.get();

			_tokenValidSupplier = null;
		}

		return tokenValid;
	}

	public void setTokenValid(Boolean tokenValid) {
		this.tokenValid = tokenValid;

		_tokenValidSupplier = null;
	}

	@JsonIgnore
	public void setTokenValid(
		UnsafeSupplier<Boolean, Exception> tokenValidUnsafeSupplier) {

		_tokenValidSupplier = () -> {
			try {
				return tokenValidUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean tokenValid;

	@JsonIgnore
	private Supplier<Boolean> _tokenValidSupplier;

	@Schema(example = "user@example.com")
	public String getUserEmail() {
		if (_userEmailSupplier != null) {
			userEmail = _userEmailSupplier.get();

			_userEmailSupplier = null;
		}

		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;

		_userEmailSupplier = null;
	}

	@JsonIgnore
	public void setUserEmail(
		UnsafeSupplier<String, Exception> userEmailUnsafeSupplier) {

		_userEmailSupplier = () -> {
			try {
				return userEmailUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userEmail;

	@JsonIgnore
	private Supplier<String> _userEmailSupplier;

	@Schema(example = "true")
	public Boolean getUserMatchesSession() {
		if (_userMatchesSessionSupplier != null) {
			userMatchesSession = _userMatchesSessionSupplier.get();

			_userMatchesSessionSupplier = null;
		}

		return userMatchesSession;
	}

	public void setUserMatchesSession(Boolean userMatchesSession) {
		this.userMatchesSession = userMatchesSession;

		_userMatchesSessionSupplier = null;
	}

	@JsonIgnore
	public void setUserMatchesSession(
		UnsafeSupplier<Boolean, Exception> userMatchesSessionUnsafeSupplier) {

		_userMatchesSessionSupplier = () -> {
			try {
				return userMatchesSessionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean userMatchesSession;

	@JsonIgnore
	private Supplier<Boolean> _userMatchesSessionSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof JwtValidationDetails)) {
			return false;
		}

		JwtValidationDetails jwtValidationDetails =
			(JwtValidationDetails)object;

		return Objects.equals(toString(), jwtValidationDetails.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		Boolean signatureVerified = getSignatureVerified();

		if (signatureVerified != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"signatureVerified\": ");

			sb.append(signatureVerified);
		}

		Boolean tokenProvided = getTokenProvided();

		if (tokenProvided != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tokenProvided\": ");

			sb.append(tokenProvided);
		}

		Boolean tokenValid = getTokenValid();

		if (tokenValid != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tokenValid\": ");

			sb.append(tokenValid);
		}

		String userEmail = getUserEmail();

		if (userEmail != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userEmail\": ");

			sb.append("\"");

			sb.append(_escape(userEmail));

			sb.append("\"");
		}

		Boolean userMatchesSession = getUserMatchesSession();

		if (userMatchesSession != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userMatchesSession\": ");

			sb.append(userMatchesSession);
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.charon.dto.v1_0.JwtValidationDetails",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}