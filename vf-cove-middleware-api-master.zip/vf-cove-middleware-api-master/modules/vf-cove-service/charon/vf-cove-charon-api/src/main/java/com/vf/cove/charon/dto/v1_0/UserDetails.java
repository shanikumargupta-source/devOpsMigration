package com.vf.cove.charon.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author VBITDC
 * @generated
 */
@Generated("")
@GraphQLName("UserDetails")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "UserDetails")
public class UserDetails implements Serializable {

	public static UserDetails toDTO(String json) {
		return ObjectMapperUtil.readValue(UserDetails.class, json);
	}

	public static UserDetails unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(UserDetails.class, json);
	}

	@Schema(example = "true")
	public Boolean getActive() {
		if (_activeSupplier != null) {
			active = _activeSupplier.get();

			_activeSupplier = null;
		}

		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;

		_activeSupplier = null;
	}

	@JsonIgnore
	public void setActive(
		UnsafeSupplier<Boolean, Exception> activeUnsafeSupplier) {

		_activeSupplier = () -> {
			try {
				return activeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean active;

	@JsonIgnore
	private Supplier<Boolean> _activeSupplier;

	@Schema
	@Valid
	public Group[] getGroups() {
		if (_groupsSupplier != null) {
			groups = _groupsSupplier.get();

			_groupsSupplier = null;
		}

		return groups;
	}

	public void setGroups(Group[] groups) {
		this.groups = groups;

		_groupsSupplier = null;
	}

	@JsonIgnore
	public void setGroups(
		UnsafeSupplier<Group[], Exception> groupsUnsafeSupplier) {

		_groupsSupplier = () -> {
			try {
				return groupsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Group[] groups;

	@JsonIgnore
	private Supplier<Group[]> _groupsSupplier;

	@Schema(example = "Mon Mar 02 16:08:07 GMT 2026")
	public String getLastLoginTime() {
		if (_lastLoginTimeSupplier != null) {
			lastLoginTime = _lastLoginTimeSupplier.get();

			_lastLoginTimeSupplier = null;
		}

		return lastLoginTime;
	}

	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;

		_lastLoginTimeSupplier = null;
	}

	@JsonIgnore
	public void setLastLoginTime(
		UnsafeSupplier<String, Exception> lastLoginTimeUnsafeSupplier) {

		_lastLoginTimeSupplier = () -> {
			try {
				return lastLoginTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lastLoginTime;

	@JsonIgnore
	private Supplier<String> _lastLoginTimeSupplier;

	@Schema
	@Valid
	public Organization[] getOrganizations() {
		if (_organizationsSupplier != null) {
			organizations = _organizationsSupplier.get();

			_organizationsSupplier = null;
		}

		return organizations;
	}

	public void setOrganizations(Organization[] organizations) {
		this.organizations = organizations;

		_organizationsSupplier = null;
	}

	@JsonIgnore
	public void setOrganizations(
		UnsafeSupplier<Organization[], Exception> organizationsUnsafeSupplier) {

		_organizationsSupplier = () -> {
			try {
				return organizationsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Organization[] organizations;

	@JsonIgnore
	private Supplier<Organization[]> _organizationsSupplier;

	@Schema(example = "user@example.com")
	public String getUserEmail() {
		if (_userEmailSupplier != null) {
			userEmail = _userEmailSupplier.get();

			_userEmailSupplier = null;
		}

		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;

		_userEmailSupplier = null;
	}

	@JsonIgnore
	public void setUserEmail(
		UnsafeSupplier<String, Exception> userEmailUnsafeSupplier) {

		_userEmailSupplier = () -> {
			try {
				return userEmailUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userEmail;

	@JsonIgnore
	private Supplier<String> _userEmailSupplier;

	@Schema(example = "John Doe")
	public String getUserFullName() {
		if (_userFullNameSupplier != null) {
			userFullName = _userFullNameSupplier.get();

			_userFullNameSupplier = null;
		}

		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;

		_userFullNameSupplier = null;
	}

	@JsonIgnore
	public void setUserFullName(
		UnsafeSupplier<String, Exception> userFullNameUnsafeSupplier) {

		_userFullNameSupplier = () -> {
			try {
				return userFullNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userFullName;

	@JsonIgnore
	private Supplier<String> _userFullNameSupplier;

	@Schema(example = "12345")
	public Integer getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<Integer, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer userId;

	@JsonIgnore
	private Supplier<Integer> _userIdSupplier;

	@Schema(example = "jdoe")
	public String getUserScreenName() {
		if (_userScreenNameSupplier != null) {
			userScreenName = _userScreenNameSupplier.get();

			_userScreenNameSupplier = null;
		}

		return userScreenName;
	}

	public void setUserScreenName(String userScreenName) {
		this.userScreenName = userScreenName;

		_userScreenNameSupplier = null;
	}

	@JsonIgnore
	public void setUserScreenName(
		UnsafeSupplier<String, Exception> userScreenNameUnsafeSupplier) {

		_userScreenNameSupplier = () -> {
			try {
				return userScreenNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userScreenName;

	@JsonIgnore
	private Supplier<String> _userScreenNameSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof UserDetails)) {
			return false;
		}

		UserDetails userDetails = (UserDetails)object;

		return Objects.equals(toString(), userDetails.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		Boolean active = getActive();

		if (active != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"active\": ");

			sb.append(active);
		}

		Group[] groups = getGroups();

		if (groups != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"groups\": ");

			sb.append("[");

			for (int i = 0; i < groups.length; i++) {
				sb.append(String.valueOf(groups[i]));

				if ((i + 1) < groups.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String lastLoginTime = getLastLoginTime();

		if (lastLoginTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lastLoginTime\": ");

			sb.append("\"");

			sb.append(_escape(lastLoginTime));

			sb.append("\"");
		}

		Organization[] organizations = getOrganizations();

		if (organizations != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"organizations\": ");

			sb.append("[");

			for (int i = 0; i < organizations.length; i++) {
				sb.append(String.valueOf(organizations[i]));

				if ((i + 1) < organizations.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String userEmail = getUserEmail();

		if (userEmail != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userEmail\": ");

			sb.append("\"");

			sb.append(_escape(userEmail));

			sb.append("\"");
		}

		String userFullName = getUserFullName();

		if (userFullName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userFullName\": ");

			sb.append("\"");

			sb.append(_escape(userFullName));

			sb.append("\"");
		}

		Integer userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append(userId);
		}

		String userScreenName = getUserScreenName();

		if (userScreenName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userScreenName\": ");

			sb.append("\"");

			sb.append(_escape(userScreenName));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.charon.dto.v1_0.UserDetails",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}