package com.vf.cove.changerequest.api.dto.v1_0_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author SwatiKeshari
 * @generated
 */
@Generated("")
@GraphQLName("Change")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Change")
public class Change implements Serializable {

	public static Change toDTO(String json) {
		return ObjectMapperUtil.readValue(Change.class, json);
	}

	public static Change unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Change.class, json);
	}

	@Schema(example = "test")
	public String getCIRef() {
		if (_CIRefSupplier != null) {
			CIRef = _CIRefSupplier.get();

			_CIRefSupplier = null;
		}

		return CIRef;
	}

	public void setCIRef(String CIRef) {
		this.CIRef = CIRef;

		_CIRefSupplier = null;
	}

	@JsonIgnore
	public void setCIRef(
		UnsafeSupplier<String, Exception> CIRefUnsafeSupplier) {

		_CIRefSupplier = () -> {
			try {
				return CIRefUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String CIRef;

	@JsonIgnore
	private Supplier<String> _CIRefSupplier;

	@Schema(example = "test")
	public String getActualEndDate() {
		if (_actualEndDateSupplier != null) {
			actualEndDate = _actualEndDateSupplier.get();

			_actualEndDateSupplier = null;
		}

		return actualEndDate;
	}

	public void setActualEndDate(String actualEndDate) {
		this.actualEndDate = actualEndDate;

		_actualEndDateSupplier = null;
	}

	@JsonIgnore
	public void setActualEndDate(
		UnsafeSupplier<String, Exception> actualEndDateUnsafeSupplier) {

		_actualEndDateSupplier = () -> {
			try {
				return actualEndDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String actualEndDate;

	@JsonIgnore
	private Supplier<String> _actualEndDateSupplier;

	@Schema(example = "test")
	public String getActualStartDate() {
		if (_actualStartDateSupplier != null) {
			actualStartDate = _actualStartDateSupplier.get();

			_actualStartDateSupplier = null;
		}

		return actualStartDate;
	}

	public void setActualStartDate(String actualStartDate) {
		this.actualStartDate = actualStartDate;

		_actualStartDateSupplier = null;
	}

	@JsonIgnore
	public void setActualStartDate(
		UnsafeSupplier<String, Exception> actualStartDateUnsafeSupplier) {

		_actualStartDateSupplier = () -> {
			try {
				return actualStartDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String actualStartDate;

	@JsonIgnore
	private Supplier<String> _actualStartDateSupplier;

	@Schema
	public String getAddress() {
		if (_addressSupplier != null) {
			address = _addressSupplier.get();

			_addressSupplier = null;
		}

		return address;
	}

	public void setAddress(String address) {
		this.address = address;

		_addressSupplier = null;
	}

	@JsonIgnore
	public void setAddress(
		UnsafeSupplier<String, Exception> addressUnsafeSupplier) {

		_addressSupplier = () -> {
			try {
				return addressUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String address;

	@JsonIgnore
	private Supplier<String> _addressSupplier;

	@Schema
	public String getApprovalFlag() {
		if (_approvalFlagSupplier != null) {
			approvalFlag = _approvalFlagSupplier.get();

			_approvalFlagSupplier = null;
		}

		return approvalFlag;
	}

	public void setApprovalFlag(String approvalFlag) {
		this.approvalFlag = approvalFlag;

		_approvalFlagSupplier = null;
	}

	@JsonIgnore
	public void setApprovalFlag(
		UnsafeSupplier<String, Exception> approvalFlagUnsafeSupplier) {

		_approvalFlagSupplier = () -> {
			try {
				return approvalFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String approvalFlag;

	@JsonIgnore
	private Supplier<String> _approvalFlagSupplier;

	@Schema(example = "test")
	public String getAssignmentGroup() {
		if (_assignmentGroupSupplier != null) {
			assignmentGroup = _assignmentGroupSupplier.get();

			_assignmentGroupSupplier = null;
		}

		return assignmentGroup;
	}

	public void setAssignmentGroup(String assignmentGroup) {
		this.assignmentGroup = assignmentGroup;

		_assignmentGroupSupplier = null;
	}

	@JsonIgnore
	public void setAssignmentGroup(
		UnsafeSupplier<String, Exception> assignmentGroupUnsafeSupplier) {

		_assignmentGroupSupplier = () -> {
			try {
				return assignmentGroupUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String assignmentGroup;

	@JsonIgnore
	private Supplier<String> _assignmentGroupSupplier;

	@Schema
	@Valid
	public Attachments getAttachments() {
		if (_attachmentsSupplier != null) {
			attachments = _attachmentsSupplier.get();

			_attachmentsSupplier = null;
		}

		return attachments;
	}

	public void setAttachments(Attachments attachments) {
		this.attachments = attachments;

		_attachmentsSupplier = null;
	}

	@JsonIgnore
	public void setAttachments(
		UnsafeSupplier<Attachments, Exception> attachmentsUnsafeSupplier) {

		_attachmentsSupplier = () -> {
			try {
				return attachmentsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Attachments attachments;

	@JsonIgnore
	private Supplier<Attachments> _attachmentsSupplier;

	@Schema(example = "test")
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema(example = "test")
	public String getBusinessServiceSysID() {
		if (_businessServiceSysIDSupplier != null) {
			businessServiceSysID = _businessServiceSysIDSupplier.get();

			_businessServiceSysIDSupplier = null;
		}

		return businessServiceSysID;
	}

	public void setBusinessServiceSysID(String businessServiceSysID) {
		this.businessServiceSysID = businessServiceSysID;

		_businessServiceSysIDSupplier = null;
	}

	@JsonIgnore
	public void setBusinessServiceSysID(
		UnsafeSupplier<String, Exception> businessServiceSysIDUnsafeSupplier) {

		_businessServiceSysIDSupplier = () -> {
			try {
				return businessServiceSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessServiceSysID;

	@JsonIgnore
	private Supplier<String> _businessServiceSysIDSupplier;

	@Schema(example = "test")
	public String getCategory() {
		if (_categorySupplier != null) {
			category = _categorySupplier.get();

			_categorySupplier = null;
		}

		return category;
	}

	public void setCategory(String category) {
		this.category = category;

		_categorySupplier = null;
	}

	@JsonIgnore
	public void setCategory(
		UnsafeSupplier<String, Exception> categoryUnsafeSupplier) {

		_categorySupplier = () -> {
			try {
				return categoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String category;

	@JsonIgnore
	private Supplier<String> _categorySupplier;

	@Schema(example = "test")
	public String getChangeReference() {
		if (_changeReferenceSupplier != null) {
			changeReference = _changeReferenceSupplier.get();

			_changeReferenceSupplier = null;
		}

		return changeReference;
	}

	public void setChangeReference(String changeReference) {
		this.changeReference = changeReference;

		_changeReferenceSupplier = null;
	}

	@JsonIgnore
	public void setChangeReference(
		UnsafeSupplier<String, Exception> changeReferenceUnsafeSupplier) {

		_changeReferenceSupplier = () -> {
			try {
				return changeReferenceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String changeReference;

	@JsonIgnore
	private Supplier<String> _changeReferenceSupplier;

	@Schema(example = "test")
	public String getChangeType() {
		if (_changeTypeSupplier != null) {
			changeType = _changeTypeSupplier.get();

			_changeTypeSupplier = null;
		}

		return changeType;
	}

	public void setChangeType(String changeType) {
		this.changeType = changeType;

		_changeTypeSupplier = null;
	}

	@JsonIgnore
	public void setChangeType(
		UnsafeSupplier<String, Exception> changeTypeUnsafeSupplier) {

		_changeTypeSupplier = () -> {
			try {
				return changeTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String changeType;

	@JsonIgnore
	private Supplier<String> _changeTypeSupplier;

	@Schema(example = "test")
	public String getCountry() {
		if (_countrySupplier != null) {
			country = _countrySupplier.get();

			_countrySupplier = null;
		}

		return country;
	}

	public void setCountry(String country) {
		this.country = country;

		_countrySupplier = null;
	}

	@JsonIgnore
	public void setCountry(
		UnsafeSupplier<String, Exception> countryUnsafeSupplier) {

		_countrySupplier = () -> {
			try {
				return countryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String country;

	@JsonIgnore
	private Supplier<String> _countrySupplier;

	@Schema(example = "test")
	public String getCustomerImpact() {
		if (_customerImpactSupplier != null) {
			customerImpact = _customerImpactSupplier.get();

			_customerImpactSupplier = null;
		}

		return customerImpact;
	}

	public void setCustomerImpact(String customerImpact) {
		this.customerImpact = customerImpact;

		_customerImpactSupplier = null;
	}

	@JsonIgnore
	public void setCustomerImpact(
		UnsafeSupplier<String, Exception> customerImpactUnsafeSupplier) {

		_customerImpactSupplier = () -> {
			try {
				return customerImpactUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerImpact;

	@JsonIgnore
	private Supplier<String> _customerImpactSupplier;

	@Schema(example = "test")
	public String getCustomerRef() {
		if (_customerRefSupplier != null) {
			customerRef = _customerRefSupplier.get();

			_customerRefSupplier = null;
		}

		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;

		_customerRefSupplier = null;
	}

	@JsonIgnore
	public void setCustomerRef(
		UnsafeSupplier<String, Exception> customerRefUnsafeSupplier) {

		_customerRefSupplier = () -> {
			try {
				return customerRefUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerRef;

	@JsonIgnore
	private Supplier<String> _customerRefSupplier;

	@Schema(example = "test")
	public String getDateRaised() {
		if (_dateRaisedSupplier != null) {
			dateRaised = _dateRaisedSupplier.get();

			_dateRaisedSupplier = null;
		}

		return dateRaised;
	}

	public void setDateRaised(String dateRaised) {
		this.dateRaised = dateRaised;

		_dateRaisedSupplier = null;
	}

	@JsonIgnore
	public void setDateRaised(
		UnsafeSupplier<String, Exception> dateRaisedUnsafeSupplier) {

		_dateRaisedSupplier = () -> {
			try {
				return dateRaisedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dateRaised;

	@JsonIgnore
	private Supplier<String> _dateRaisedSupplier;

	@Schema
	public String getDescription() {
		if (_descriptionSupplier != null) {
			description = _descriptionSupplier.get();

			_descriptionSupplier = null;
		}

		return description;
	}

	public void setDescription(String description) {
		this.description = description;

		_descriptionSupplier = null;
	}

	@JsonIgnore
	public void setDescription(
		UnsafeSupplier<String, Exception> descriptionUnsafeSupplier) {

		_descriptionSupplier = () -> {
			try {
				return descriptionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String description;

	@JsonIgnore
	private Supplier<String> _descriptionSupplier;

	@Schema
	public String getDetailRisk() {
		if (_detailRiskSupplier != null) {
			detailRisk = _detailRiskSupplier.get();

			_detailRiskSupplier = null;
		}

		return detailRisk;
	}

	public void setDetailRisk(String detailRisk) {
		this.detailRisk = detailRisk;

		_detailRiskSupplier = null;
	}

	@JsonIgnore
	public void setDetailRisk(
		UnsafeSupplier<String, Exception> detailRiskUnsafeSupplier) {

		_detailRiskSupplier = () -> {
			try {
				return detailRiskUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String detailRisk;

	@JsonIgnore
	private Supplier<String> _detailRiskSupplier;

	@Schema(example = "test")
	public String getFromDate() {
		if (_fromDateSupplier != null) {
			fromDate = _fromDateSupplier.get();

			_fromDateSupplier = null;
		}

		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;

		_fromDateSupplier = null;
	}

	@JsonIgnore
	public void setFromDate(
		UnsafeSupplier<String, Exception> fromDateUnsafeSupplier) {

		_fromDateSupplier = () -> {
			try {
				return fromDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fromDate;

	@JsonIgnore
	private Supplier<String> _fromDateSupplier;

	@Schema(example = "test")
	public String getImpact() {
		if (_impactSupplier != null) {
			impact = _impactSupplier.get();

			_impactSupplier = null;
		}

		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;

		_impactSupplier = null;
	}

	@JsonIgnore
	public void setImpact(
		UnsafeSupplier<String, Exception> impactUnsafeSupplier) {

		_impactSupplier = () -> {
			try {
				return impactUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String impact;

	@JsonIgnore
	private Supplier<String> _impactSupplier;

	@Schema(example = "test")
	public String getImpactEndDate() {
		if (_impactEndDateSupplier != null) {
			impactEndDate = _impactEndDateSupplier.get();

			_impactEndDateSupplier = null;
		}

		return impactEndDate;
	}

	public void setImpactEndDate(String impactEndDate) {
		this.impactEndDate = impactEndDate;

		_impactEndDateSupplier = null;
	}

	@JsonIgnore
	public void setImpactEndDate(
		UnsafeSupplier<String, Exception> impactEndDateUnsafeSupplier) {

		_impactEndDateSupplier = () -> {
			try {
				return impactEndDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String impactEndDate;

	@JsonIgnore
	private Supplier<String> _impactEndDateSupplier;

	@Schema(example = "test")
	public String getImpactStartDate() {
		if (_impactStartDateSupplier != null) {
			impactStartDate = _impactStartDateSupplier.get();

			_impactStartDateSupplier = null;
		}

		return impactStartDate;
	}

	public void setImpactStartDate(String impactStartDate) {
		this.impactStartDate = impactStartDate;

		_impactStartDateSupplier = null;
	}

	@JsonIgnore
	public void setImpactStartDate(
		UnsafeSupplier<String, Exception> impactStartDateUnsafeSupplier) {

		_impactStartDateSupplier = () -> {
			try {
				return impactStartDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String impactStartDate;

	@JsonIgnore
	private Supplier<String> _impactStartDateSupplier;

	@Schema
	public String getImplementationDuration() {
		if (_implementationDurationSupplier != null) {
			implementationDuration = _implementationDurationSupplier.get();

			_implementationDurationSupplier = null;
		}

		return implementationDuration;
	}

	public void setImplementationDuration(String implementationDuration) {
		this.implementationDuration = implementationDuration;

		_implementationDurationSupplier = null;
	}

	@JsonIgnore
	public void setImplementationDuration(
		UnsafeSupplier<String, Exception>
			implementationDurationUnsafeSupplier) {

		_implementationDurationSupplier = () -> {
			try {
				return implementationDurationUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String implementationDuration;

	@JsonIgnore
	private Supplier<String> _implementationDurationSupplier;

	@Schema(example = "test")
	public String getImplementationPlan() {
		if (_implementationPlanSupplier != null) {
			implementationPlan = _implementationPlanSupplier.get();

			_implementationPlanSupplier = null;
		}

		return implementationPlan;
	}

	public void setImplementationPlan(String implementationPlan) {
		this.implementationPlan = implementationPlan;

		_implementationPlanSupplier = null;
	}

	@JsonIgnore
	public void setImplementationPlan(
		UnsafeSupplier<String, Exception> implementationPlanUnsafeSupplier) {

		_implementationPlanSupplier = () -> {
			try {
				return implementationPlanUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String implementationPlan;

	@JsonIgnore
	private Supplier<String> _implementationPlanSupplier;

	@Schema
	public String getJustification() {
		if (_justificationSupplier != null) {
			justification = _justificationSupplier.get();

			_justificationSupplier = null;
		}

		return justification;
	}

	public void setJustification(String justification) {
		this.justification = justification;

		_justificationSupplier = null;
	}

	@JsonIgnore
	public void setJustification(
		UnsafeSupplier<String, Exception> justificationUnsafeSupplier) {

		_justificationSupplier = () -> {
			try {
				return justificationUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String justification;

	@JsonIgnore
	private Supplier<String> _justificationSupplier;

	@Schema
	public String getLastUpdatedOn() {
		if (_lastUpdatedOnSupplier != null) {
			lastUpdatedOn = _lastUpdatedOnSupplier.get();

			_lastUpdatedOnSupplier = null;
		}

		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;

		_lastUpdatedOnSupplier = null;
	}

	@JsonIgnore
	public void setLastUpdatedOn(
		UnsafeSupplier<String, Exception> lastUpdatedOnUnsafeSupplier) {

		_lastUpdatedOnSupplier = () -> {
			try {
				return lastUpdatedOnUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lastUpdatedOn;

	@JsonIgnore
	private Supplier<String> _lastUpdatedOnSupplier;

	@Schema
	@Valid
	public Notes getNotes() {
		if (_notesSupplier != null) {
			notes = _notesSupplier.get();

			_notesSupplier = null;
		}

		return notes;
	}

	public void setNotes(Notes notes) {
		this.notes = notes;

		_notesSupplier = null;
	}

	@JsonIgnore
	public void setNotes(UnsafeSupplier<Notes, Exception> notesUnsafeSupplier) {
		_notesSupplier = () -> {
			try {
				return notesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Notes notes;

	@JsonIgnore
	private Supplier<Notes> _notesSupplier;

	@Schema(example = "test")
	public String getOrgName() {
		if (_orgNameSupplier != null) {
			orgName = _orgNameSupplier.get();

			_orgNameSupplier = null;
		}

		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;

		_orgNameSupplier = null;
	}

	@JsonIgnore
	public void setOrgName(
		UnsafeSupplier<String, Exception> orgNameUnsafeSupplier) {

		_orgNameSupplier = () -> {
			try {
				return orgNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String orgName;

	@JsonIgnore
	private Supplier<String> _orgNameSupplier;

	@Schema
	public String getOtherImpactingServices() {
		if (_otherImpactingServicesSupplier != null) {
			otherImpactingServices = _otherImpactingServicesSupplier.get();

			_otherImpactingServicesSupplier = null;
		}

		return otherImpactingServices;
	}

	public void setOtherImpactingServices(String otherImpactingServices) {
		this.otherImpactingServices = otherImpactingServices;

		_otherImpactingServicesSupplier = null;
	}

	@JsonIgnore
	public void setOtherImpactingServices(
		UnsafeSupplier<String, Exception>
			otherImpactingServicesUnsafeSupplier) {

		_otherImpactingServicesSupplier = () -> {
			try {
				return otherImpactingServicesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String otherImpactingServices;

	@JsonIgnore
	private Supplier<String> _otherImpactingServicesSupplier;

	@Schema
	public String getOtherImpactingServicesSysId() {
		if (_otherImpactingServicesSysIdSupplier != null) {
			otherImpactingServicesSysId =
				_otherImpactingServicesSysIdSupplier.get();

			_otherImpactingServicesSysIdSupplier = null;
		}

		return otherImpactingServicesSysId;
	}

	public void setOtherImpactingServicesSysId(
		String otherImpactingServicesSysId) {

		this.otherImpactingServicesSysId = otherImpactingServicesSysId;

		_otherImpactingServicesSysIdSupplier = null;
	}

	@JsonIgnore
	public void setOtherImpactingServicesSysId(
		UnsafeSupplier<String, Exception>
			otherImpactingServicesSysIdUnsafeSupplier) {

		_otherImpactingServicesSysIdSupplier = () -> {
			try {
				return otherImpactingServicesSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String otherImpactingServicesSysId;

	@JsonIgnore
	private Supplier<String> _otherImpactingServicesSysIdSupplier;

	@Schema
	public String getPostImplementationPlan() {
		if (_postImplementationPlanSupplier != null) {
			postImplementationPlan = _postImplementationPlanSupplier.get();

			_postImplementationPlanSupplier = null;
		}

		return postImplementationPlan;
	}

	public void setPostImplementationPlan(String postImplementationPlan) {
		this.postImplementationPlan = postImplementationPlan;

		_postImplementationPlanSupplier = null;
	}

	@JsonIgnore
	public void setPostImplementationPlan(
		UnsafeSupplier<String, Exception>
			postImplementationPlanUnsafeSupplier) {

		_postImplementationPlanSupplier = () -> {
			try {
				return postImplementationPlanUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String postImplementationPlan;

	@JsonIgnore
	private Supplier<String> _postImplementationPlanSupplier;

	@Schema(example = "test")
	public String getPriority() {
		if (_prioritySupplier != null) {
			priority = _prioritySupplier.get();

			_prioritySupplier = null;
		}

		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;

		_prioritySupplier = null;
	}

	@JsonIgnore
	public void setPriority(
		UnsafeSupplier<String, Exception> priorityUnsafeSupplier) {

		_prioritySupplier = () -> {
			try {
				return priorityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priority;

	@JsonIgnore
	private Supplier<String> _prioritySupplier;

	@Schema
	public String getProposedSolution() {
		if (_proposedSolutionSupplier != null) {
			proposedSolution = _proposedSolutionSupplier.get();

			_proposedSolutionSupplier = null;
		}

		return proposedSolution;
	}

	public void setProposedSolution(String proposedSolution) {
		this.proposedSolution = proposedSolution;

		_proposedSolutionSupplier = null;
	}

	@JsonIgnore
	public void setProposedSolution(
		UnsafeSupplier<String, Exception> proposedSolutionUnsafeSupplier) {

		_proposedSolutionSupplier = () -> {
			try {
				return proposedSolutionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String proposedSolution;

	@JsonIgnore
	private Supplier<String> _proposedSolutionSupplier;

	@Schema
	public String getRaisedBy() {
		if (_raisedBySupplier != null) {
			raisedBy = _raisedBySupplier.get();

			_raisedBySupplier = null;
		}

		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;

		_raisedBySupplier = null;
	}

	@JsonIgnore
	public void setRaisedBy(
		UnsafeSupplier<String, Exception> raisedByUnsafeSupplier) {

		_raisedBySupplier = () -> {
			try {
				return raisedByUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String raisedBy;

	@JsonIgnore
	private Supplier<String> _raisedBySupplier;

	@Schema(example = "test")
	public String getRisk() {
		if (_riskSupplier != null) {
			risk = _riskSupplier.get();

			_riskSupplier = null;
		}

		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;

		_riskSupplier = null;
	}

	@JsonIgnore
	public void setRisk(UnsafeSupplier<String, Exception> riskUnsafeSupplier) {
		_riskSupplier = () -> {
			try {
				return riskUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String risk;

	@JsonIgnore
	private Supplier<String> _riskSupplier;

	@Schema
	public String getRollbackPlan() {
		if (_rollbackPlanSupplier != null) {
			rollbackPlan = _rollbackPlanSupplier.get();

			_rollbackPlanSupplier = null;
		}

		return rollbackPlan;
	}

	public void setRollbackPlan(String rollbackPlan) {
		this.rollbackPlan = rollbackPlan;

		_rollbackPlanSupplier = null;
	}

	@JsonIgnore
	public void setRollbackPlan(
		UnsafeSupplier<String, Exception> rollbackPlanUnsafeSupplier) {

		_rollbackPlanSupplier = () -> {
			try {
				return rollbackPlanUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String rollbackPlan;

	@JsonIgnore
	private Supplier<String> _rollbackPlanSupplier;

	@Schema(example = "test")
	public String getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@JsonIgnore
	private Supplier<String> _statusSupplier;

	@Schema(example = "test")
	public String getSubCategory() {
		if (_subCategorySupplier != null) {
			subCategory = _subCategorySupplier.get();

			_subCategorySupplier = null;
		}

		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;

		_subCategorySupplier = null;
	}

	@JsonIgnore
	public void setSubCategory(
		UnsafeSupplier<String, Exception> subCategoryUnsafeSupplier) {

		_subCategorySupplier = () -> {
			try {
				return subCategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String subCategory;

	@JsonIgnore
	private Supplier<String> _subCategorySupplier;

	@Schema
	public String getSummary() {
		if (_summarySupplier != null) {
			summary = _summarySupplier.get();

			_summarySupplier = null;
		}

		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;

		_summarySupplier = null;
	}

	@JsonIgnore
	public void setSummary(
		UnsafeSupplier<String, Exception> summaryUnsafeSupplier) {

		_summarySupplier = () -> {
			try {
				return summaryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String summary;

	@JsonIgnore
	private Supplier<String> _summarySupplier;

	@Schema(example = "test")
	public String getSysId() {
		if (_sysIdSupplier != null) {
			sysId = _sysIdSupplier.get();

			_sysIdSupplier = null;
		}

		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;

		_sysIdSupplier = null;
	}

	@JsonIgnore
	public void setSysId(
		UnsafeSupplier<String, Exception> sysIdUnsafeSupplier) {

		_sysIdSupplier = () -> {
			try {
				return sysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String sysId;

	@JsonIgnore
	private Supplier<String> _sysIdSupplier;

	@Schema(example = "test")
	public String getToDate() {
		if (_toDateSupplier != null) {
			toDate = _toDateSupplier.get();

			_toDateSupplier = null;
		}

		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;

		_toDateSupplier = null;
	}

	@JsonIgnore
	public void setToDate(
		UnsafeSupplier<String, Exception> toDateUnsafeSupplier) {

		_toDateSupplier = () -> {
			try {
				return toDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String toDate;

	@JsonIgnore
	private Supplier<String> _toDateSupplier;

	@Schema
	public String getUrgency() {
		if (_urgencySupplier != null) {
			urgency = _urgencySupplier.get();

			_urgencySupplier = null;
		}

		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;

		_urgencySupplier = null;
	}

	@JsonIgnore
	public void setUrgency(
		UnsafeSupplier<String, Exception> urgencyUnsafeSupplier) {

		_urgencySupplier = () -> {
			try {
				return urgencyUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String urgency;

	@JsonIgnore
	private Supplier<String> _urgencySupplier;

	@Schema
	public String getWatchFlag() {
		if (_watchFlagSupplier != null) {
			watchFlag = _watchFlagSupplier.get();

			_watchFlagSupplier = null;
		}

		return watchFlag;
	}

	public void setWatchFlag(String watchFlag) {
		this.watchFlag = watchFlag;

		_watchFlagSupplier = null;
	}

	@JsonIgnore
	public void setWatchFlag(
		UnsafeSupplier<String, Exception> watchFlagUnsafeSupplier) {

		_watchFlagSupplier = () -> {
			try {
				return watchFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String watchFlag;

	@JsonIgnore
	private Supplier<String> _watchFlagSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Change)) {
			return false;
		}

		Change change = (Change)object;

		return Objects.equals(toString(), change.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String CIRef = getCIRef();

		if (CIRef != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"CIRef\": ");

			sb.append("\"");

			sb.append(_escape(CIRef));

			sb.append("\"");
		}

		String actualEndDate = getActualEndDate();

		if (actualEndDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"actualEndDate\": ");

			sb.append("\"");

			sb.append(_escape(actualEndDate));

			sb.append("\"");
		}

		String actualStartDate = getActualStartDate();

		if (actualStartDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"actualStartDate\": ");

			sb.append("\"");

			sb.append(_escape(actualStartDate));

			sb.append("\"");
		}

		String address = getAddress();

		if (address != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"address\": ");

			sb.append("\"");

			sb.append(_escape(address));

			sb.append("\"");
		}

		String approvalFlag = getApprovalFlag();

		if (approvalFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"approvalFlag\": ");

			sb.append("\"");

			sb.append(_escape(approvalFlag));

			sb.append("\"");
		}

		String assignmentGroup = getAssignmentGroup();

		if (assignmentGroup != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"assignmentGroup\": ");

			sb.append("\"");

			sb.append(_escape(assignmentGroup));

			sb.append("\"");
		}

		Attachments attachments = getAttachments();

		if (attachments != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"attachments\": ");

			sb.append(String.valueOf(attachments));
		}

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String businessServiceSysID = getBusinessServiceSysID();

		if (businessServiceSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessServiceSysID\": ");

			sb.append("\"");

			sb.append(_escape(businessServiceSysID));

			sb.append("\"");
		}

		String category = getCategory();

		if (category != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"category\": ");

			sb.append("\"");

			sb.append(_escape(category));

			sb.append("\"");
		}

		String changeReference = getChangeReference();

		if (changeReference != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"changeReference\": ");

			sb.append("\"");

			sb.append(_escape(changeReference));

			sb.append("\"");
		}

		String changeType = getChangeType();

		if (changeType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"changeType\": ");

			sb.append("\"");

			sb.append(_escape(changeType));

			sb.append("\"");
		}

		String country = getCountry();

		if (country != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"country\": ");

			sb.append("\"");

			sb.append(_escape(country));

			sb.append("\"");
		}

		String customerImpact = getCustomerImpact();

		if (customerImpact != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerImpact\": ");

			sb.append("\"");

			sb.append(_escape(customerImpact));

			sb.append("\"");
		}

		String customerRef = getCustomerRef();

		if (customerRef != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerRef\": ");

			sb.append("\"");

			sb.append(_escape(customerRef));

			sb.append("\"");
		}

		String dateRaised = getDateRaised();

		if (dateRaised != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateRaised\": ");

			sb.append("\"");

			sb.append(_escape(dateRaised));

			sb.append("\"");
		}

		String description = getDescription();

		if (description != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(description));

			sb.append("\"");
		}

		String detailRisk = getDetailRisk();

		if (detailRisk != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"detailRisk\": ");

			sb.append("\"");

			sb.append(_escape(detailRisk));

			sb.append("\"");
		}

		String fromDate = getFromDate();

		if (fromDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fromDate\": ");

			sb.append("\"");

			sb.append(_escape(fromDate));

			sb.append("\"");
		}

		String impact = getImpact();

		if (impact != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"impact\": ");

			sb.append("\"");

			sb.append(_escape(impact));

			sb.append("\"");
		}

		String impactEndDate = getImpactEndDate();

		if (impactEndDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"impactEndDate\": ");

			sb.append("\"");

			sb.append(_escape(impactEndDate));

			sb.append("\"");
		}

		String impactStartDate = getImpactStartDate();

		if (impactStartDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"impactStartDate\": ");

			sb.append("\"");

			sb.append(_escape(impactStartDate));

			sb.append("\"");
		}

		String implementationDuration = getImplementationDuration();

		if (implementationDuration != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"implementationDuration\": ");

			sb.append("\"");

			sb.append(_escape(implementationDuration));

			sb.append("\"");
		}

		String implementationPlan = getImplementationPlan();

		if (implementationPlan != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"implementationPlan\": ");

			sb.append("\"");

			sb.append(_escape(implementationPlan));

			sb.append("\"");
		}

		String justification = getJustification();

		if (justification != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"justification\": ");

			sb.append("\"");

			sb.append(_escape(justification));

			sb.append("\"");
		}

		String lastUpdatedOn = getLastUpdatedOn();

		if (lastUpdatedOn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lastUpdatedOn\": ");

			sb.append("\"");

			sb.append(_escape(lastUpdatedOn));

			sb.append("\"");
		}

		Notes notes = getNotes();

		if (notes != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"notes\": ");

			sb.append(String.valueOf(notes));
		}

		String orgName = getOrgName();

		if (orgName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"orgName\": ");

			sb.append("\"");

			sb.append(_escape(orgName));

			sb.append("\"");
		}

		String otherImpactingServices = getOtherImpactingServices();

		if (otherImpactingServices != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"otherImpactingServices\": ");

			sb.append("\"");

			sb.append(_escape(otherImpactingServices));

			sb.append("\"");
		}

		String otherImpactingServicesSysId = getOtherImpactingServicesSysId();

		if (otherImpactingServicesSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"otherImpactingServicesSysId\": ");

			sb.append("\"");

			sb.append(_escape(otherImpactingServicesSysId));

			sb.append("\"");
		}

		String postImplementationPlan = getPostImplementationPlan();

		if (postImplementationPlan != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"postImplementationPlan\": ");

			sb.append("\"");

			sb.append(_escape(postImplementationPlan));

			sb.append("\"");
		}

		String priority = getPriority();

		if (priority != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priority\": ");

			sb.append("\"");

			sb.append(_escape(priority));

			sb.append("\"");
		}

		String proposedSolution = getProposedSolution();

		if (proposedSolution != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"proposedSolution\": ");

			sb.append("\"");

			sb.append(_escape(proposedSolution));

			sb.append("\"");
		}

		String raisedBy = getRaisedBy();

		if (raisedBy != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"raisedBy\": ");

			sb.append("\"");

			sb.append(_escape(raisedBy));

			sb.append("\"");
		}

		String risk = getRisk();

		if (risk != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"risk\": ");

			sb.append("\"");

			sb.append(_escape(risk));

			sb.append("\"");
		}

		String rollbackPlan = getRollbackPlan();

		if (rollbackPlan != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"rollbackPlan\": ");

			sb.append("\"");

			sb.append(_escape(rollbackPlan));

			sb.append("\"");
		}

		String status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		String subCategory = getSubCategory();

		if (subCategory != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"subCategory\": ");

			sb.append("\"");

			sb.append(_escape(subCategory));

			sb.append("\"");
		}

		String summary = getSummary();

		if (summary != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"summary\": ");

			sb.append("\"");

			sb.append(_escape(summary));

			sb.append("\"");
		}

		String sysId = getSysId();

		if (sysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sysId\": ");

			sb.append("\"");

			sb.append(_escape(sysId));

			sb.append("\"");
		}

		String toDate = getToDate();

		if (toDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"toDate\": ");

			sb.append("\"");

			sb.append(_escape(toDate));

			sb.append("\"");
		}

		String urgency = getUrgency();

		if (urgency != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"urgency\": ");

			sb.append("\"");

			sb.append(_escape(urgency));

			sb.append("\"");
		}

		String watchFlag = getWatchFlag();

		if (watchFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"watchFlag\": ");

			sb.append("\"");

			sb.append(_escape(watchFlag));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.changerequest.api.dto.v1_0_0.Change",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}