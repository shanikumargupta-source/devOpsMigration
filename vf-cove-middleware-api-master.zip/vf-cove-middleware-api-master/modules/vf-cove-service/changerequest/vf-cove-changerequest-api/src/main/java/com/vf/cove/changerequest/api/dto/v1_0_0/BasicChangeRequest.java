package com.vf.cove.changerequest.api.dto.v1_0_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author SwatiKeshari
 * @generated
 */
@Generated("")
@GraphQLName("BasicChangeRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "BasicChangeRequest")
public class BasicChangeRequest implements Serializable {

	public static BasicChangeRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(BasicChangeRequest.class, json);
	}

	public static BasicChangeRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(BasicChangeRequest.class, json);
	}

	@Schema
	public String getCoveFlag() {
		if (_coveFlagSupplier != null) {
			coveFlag = _coveFlagSupplier.get();

			_coveFlagSupplier = null;
		}

		return coveFlag;
	}

	public void setCoveFlag(String coveFlag) {
		this.coveFlag = coveFlag;

		_coveFlagSupplier = null;
	}

	@JsonIgnore
	public void setCoveFlag(
		UnsafeSupplier<String, Exception> coveFlagUnsafeSupplier) {

		_coveFlagSupplier = () -> {
			try {
				return coveFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String coveFlag;

	@JsonIgnore
	private Supplier<String> _coveFlagSupplier;

	@Schema
	public String getCustomerRefNum() {
		if (_customerRefNumSupplier != null) {
			customerRefNum = _customerRefNumSupplier.get();

			_customerRefNumSupplier = null;
		}

		return customerRefNum;
	}

	public void setCustomerRefNum(String customerRefNum) {
		this.customerRefNum = customerRefNum;

		_customerRefNumSupplier = null;
	}

	@JsonIgnore
	public void setCustomerRefNum(
		UnsafeSupplier<String, Exception> customerRefNumUnsafeSupplier) {

		_customerRefNumSupplier = () -> {
			try {
				return customerRefNumUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerRefNum;

	@JsonIgnore
	private Supplier<String> _customerRefNumSupplier;

	@Schema
	public String getNoteContent() {
		if (_noteContentSupplier != null) {
			noteContent = _noteContentSupplier.get();

			_noteContentSupplier = null;
		}

		return noteContent;
	}

	public void setNoteContent(String noteContent) {
		this.noteContent = noteContent;

		_noteContentSupplier = null;
	}

	@JsonIgnore
	public void setNoteContent(
		UnsafeSupplier<String, Exception> noteContentUnsafeSupplier) {

		_noteContentSupplier = () -> {
			try {
				return noteContentUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String noteContent;

	@JsonIgnore
	private Supplier<String> _noteContentSupplier;

	@Schema
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Schema
	public String getUsernameProfile() {
		if (_usernameProfileSupplier != null) {
			usernameProfile = _usernameProfileSupplier.get();

			_usernameProfileSupplier = null;
		}

		return usernameProfile;
	}

	public void setUsernameProfile(String usernameProfile) {
		this.usernameProfile = usernameProfile;

		_usernameProfileSupplier = null;
	}

	@JsonIgnore
	public void setUsernameProfile(
		UnsafeSupplier<String, Exception> usernameProfileUnsafeSupplier) {

		_usernameProfileSupplier = () -> {
			try {
				return usernameProfileUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String usernameProfile;

	@JsonIgnore
	private Supplier<String> _usernameProfileSupplier;

	@Schema
	public String getValue() {
		if (_valueSupplier != null) {
			value = _valueSupplier.get();

			_valueSupplier = null;
		}

		return value;
	}

	public void setValue(String value) {
		this.value = value;

		_valueSupplier = null;
	}

	@JsonIgnore
	public void setValue(
		UnsafeSupplier<String, Exception> valueUnsafeSupplier) {

		_valueSupplier = () -> {
			try {
				return valueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String value;

	@JsonIgnore
	private Supplier<String> _valueSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof BasicChangeRequest)) {
			return false;
		}

		BasicChangeRequest basicChangeRequest = (BasicChangeRequest)object;

		return Objects.equals(toString(), basicChangeRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String coveFlag = getCoveFlag();

		if (coveFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"coveFlag\": ");

			sb.append("\"");

			sb.append(_escape(coveFlag));

			sb.append("\"");
		}

		String customerRefNum = getCustomerRefNum();

		if (customerRefNum != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerRefNum\": ");

			sb.append("\"");

			sb.append(_escape(customerRefNum));

			sb.append("\"");
		}

		String noteContent = getNoteContent();

		if (noteContent != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"noteContent\": ");

			sb.append("\"");

			sb.append(_escape(noteContent));

			sb.append("\"");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		String usernameProfile = getUsernameProfile();

		if (usernameProfile != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"usernameProfile\": ");

			sb.append("\"");

			sb.append(_escape(usernameProfile));

			sb.append("\"");
		}

		String value = getValue();

		if (value != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"value\": ");

			sb.append("\"");

			sb.append(_escape(value));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.changerequest.api.dto.v1_0_0.BasicChangeRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}