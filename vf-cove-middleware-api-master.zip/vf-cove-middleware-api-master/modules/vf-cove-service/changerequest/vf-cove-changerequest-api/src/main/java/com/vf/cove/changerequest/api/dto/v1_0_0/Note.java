package com.vf.cove.changerequest.api.dto.v1_0_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author SwatiKeshari
 * @generated
 */
@Generated("")
@GraphQLName("Note")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Note")
public class Note implements Serializable {

	public static Note toDTO(String json) {
		return ObjectMapperUtil.readValue(Note.class, json);
	}

	public static Note unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Note.class, json);
	}

	@Schema
	public String getCommentedBy() {
		if (_commentedBySupplier != null) {
			commentedBy = _commentedBySupplier.get();

			_commentedBySupplier = null;
		}

		return commentedBy;
	}

	public void setCommentedBy(String commentedBy) {
		this.commentedBy = commentedBy;

		_commentedBySupplier = null;
	}

	@JsonIgnore
	public void setCommentedBy(
		UnsafeSupplier<String, Exception> commentedByUnsafeSupplier) {

		_commentedBySupplier = () -> {
			try {
				return commentedByUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String commentedBy;

	@JsonIgnore
	private Supplier<String> _commentedBySupplier;

	@Schema
	public String getCommentedWhen() {
		if (_commentedWhenSupplier != null) {
			commentedWhen = _commentedWhenSupplier.get();

			_commentedWhenSupplier = null;
		}

		return commentedWhen;
	}

	public void setCommentedWhen(String commentedWhen) {
		this.commentedWhen = commentedWhen;

		_commentedWhenSupplier = null;
	}

	@JsonIgnore
	public void setCommentedWhen(
		UnsafeSupplier<String, Exception> commentedWhenUnsafeSupplier) {

		_commentedWhenSupplier = () -> {
			try {
				return commentedWhenUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String commentedWhen;

	@JsonIgnore
	private Supplier<String> _commentedWhenSupplier;

	@Schema
	public String getContent() {
		if (_contentSupplier != null) {
			content = _contentSupplier.get();

			_contentSupplier = null;
		}

		return content;
	}

	public void setContent(String content) {
		this.content = content;

		_contentSupplier = null;
	}

	@JsonIgnore
	public void setContent(
		UnsafeSupplier<String, Exception> contentUnsafeSupplier) {

		_contentSupplier = () -> {
			try {
				return contentUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String content;

	@JsonIgnore
	private Supplier<String> _contentSupplier;

	@Schema
	public String getCustUpdatedFlag() {
		if (_custUpdatedFlagSupplier != null) {
			custUpdatedFlag = _custUpdatedFlagSupplier.get();

			_custUpdatedFlagSupplier = null;
		}

		return custUpdatedFlag;
	}

	public void setCustUpdatedFlag(String custUpdatedFlag) {
		this.custUpdatedFlag = custUpdatedFlag;

		_custUpdatedFlagSupplier = null;
	}

	@JsonIgnore
	public void setCustUpdatedFlag(
		UnsafeSupplier<String, Exception> custUpdatedFlagUnsafeSupplier) {

		_custUpdatedFlagSupplier = () -> {
			try {
				return custUpdatedFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String custUpdatedFlag;

	@JsonIgnore
	private Supplier<String> _custUpdatedFlagSupplier;

	@Schema
	public String getRoot() {
		if (_rootSupplier != null) {
			root = _rootSupplier.get();

			_rootSupplier = null;
		}

		return root;
	}

	public void setRoot(String root) {
		this.root = root;

		_rootSupplier = null;
	}

	@JsonIgnore
	public void setRoot(UnsafeSupplier<String, Exception> rootUnsafeSupplier) {
		_rootSupplier = () -> {
			try {
				return rootUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String root;

	@JsonIgnore
	private Supplier<String> _rootSupplier;

	@Schema
	public String getVfUpdatedFlag() {
		if (_vfUpdatedFlagSupplier != null) {
			vfUpdatedFlag = _vfUpdatedFlagSupplier.get();

			_vfUpdatedFlagSupplier = null;
		}

		return vfUpdatedFlag;
	}

	public void setVfUpdatedFlag(String vfUpdatedFlag) {
		this.vfUpdatedFlag = vfUpdatedFlag;

		_vfUpdatedFlagSupplier = null;
	}

	@JsonIgnore
	public void setVfUpdatedFlag(
		UnsafeSupplier<String, Exception> vfUpdatedFlagUnsafeSupplier) {

		_vfUpdatedFlagSupplier = () -> {
			try {
				return vfUpdatedFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String vfUpdatedFlag;

	@JsonIgnore
	private Supplier<String> _vfUpdatedFlagSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Note)) {
			return false;
		}

		Note note = (Note)object;

		return Objects.equals(toString(), note.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String commentedBy = getCommentedBy();

		if (commentedBy != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"commentedBy\": ");

			sb.append("\"");

			sb.append(_escape(commentedBy));

			sb.append("\"");
		}

		String commentedWhen = getCommentedWhen();

		if (commentedWhen != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"commentedWhen\": ");

			sb.append("\"");

			sb.append(_escape(commentedWhen));

			sb.append("\"");
		}

		String content = getContent();

		if (content != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"content\": ");

			sb.append("\"");

			sb.append(_escape(content));

			sb.append("\"");
		}

		String custUpdatedFlag = getCustUpdatedFlag();

		if (custUpdatedFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"custUpdatedFlag\": ");

			sb.append("\"");

			sb.append(_escape(custUpdatedFlag));

			sb.append("\"");
		}

		String root = getRoot();

		if (root != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"root\": ");

			sb.append("\"");

			sb.append(_escape(root));

			sb.append("\"");
		}

		String vfUpdatedFlag = getVfUpdatedFlag();

		if (vfUpdatedFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"vfUpdatedFlag\": ");

			sb.append("\"");

			sb.append(_escape(vfUpdatedFlag));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.changerequest.api.dto.v1_0_0.Note",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}