package com.vf.cove.changerequest.api.dto.v1_0_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author SwatiKeshari
 * @generated
 */
@Generated("")
@GraphQLName("ChangeListFilter")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ChangeListFilter")
public class ChangeListFilter implements Serializable {

	public static ChangeListFilter toDTO(String json) {
		return ObjectMapperUtil.readValue(ChangeListFilter.class, json);
	}

	public static ChangeListFilter unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(ChangeListFilter.class, json);
	}

	@Schema
	public String[] getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String[] businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String[], Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] businessService;

	@JsonIgnore
	private Supplier<String[]> _businessServiceSupplier;

	@Schema
	public String[] getChangeType() {
		if (_changeTypeSupplier != null) {
			changeType = _changeTypeSupplier.get();

			_changeTypeSupplier = null;
		}

		return changeType;
	}

	public void setChangeType(String[] changeType) {
		this.changeType = changeType;

		_changeTypeSupplier = null;
	}

	@JsonIgnore
	public void setChangeType(
		UnsafeSupplier<String[], Exception> changeTypeUnsafeSupplier) {

		_changeTypeSupplier = () -> {
			try {
				return changeTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] changeType;

	@JsonIgnore
	private Supplier<String[]> _changeTypeSupplier;

	@Schema(example = "2019-11-28T07:31:21.168Z")
	public String getFromDate() {
		if (_fromDateSupplier != null) {
			fromDate = _fromDateSupplier.get();

			_fromDateSupplier = null;
		}

		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;

		_fromDateSupplier = null;
	}

	@JsonIgnore
	public void setFromDate(
		UnsafeSupplier<String, Exception> fromDateUnsafeSupplier) {

		_fromDateSupplier = () -> {
			try {
				return fromDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fromDate;

	@JsonIgnore
	private Supplier<String> _fromDateSupplier;

	@Schema(example = "0")
	public Integer getPageIndex() {
		if (_pageIndexSupplier != null) {
			pageIndex = _pageIndexSupplier.get();

			_pageIndexSupplier = null;
		}

		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;

		_pageIndexSupplier = null;
	}

	@JsonIgnore
	public void setPageIndex(
		UnsafeSupplier<Integer, Exception> pageIndexUnsafeSupplier) {

		_pageIndexSupplier = () -> {
			try {
				return pageIndexUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer pageIndex;

	@JsonIgnore
	private Supplier<Integer> _pageIndexSupplier;

	@Schema
	public String[] getPriority() {
		if (_prioritySupplier != null) {
			priority = _prioritySupplier.get();

			_prioritySupplier = null;
		}

		return priority;
	}

	public void setPriority(String[] priority) {
		this.priority = priority;

		_prioritySupplier = null;
	}

	@JsonIgnore
	public void setPriority(
		UnsafeSupplier<String[], Exception> priorityUnsafeSupplier) {

		_prioritySupplier = () -> {
			try {
				return priorityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] priority;

	@JsonIgnore
	private Supplier<String[]> _prioritySupplier;

	@Schema(example = "20")
	public Integer getRecordsPerPage() {
		if (_recordsPerPageSupplier != null) {
			recordsPerPage = _recordsPerPageSupplier.get();

			_recordsPerPageSupplier = null;
		}

		return recordsPerPage;
	}

	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;

		_recordsPerPageSupplier = null;
	}

	@JsonIgnore
	public void setRecordsPerPage(
		UnsafeSupplier<Integer, Exception> recordsPerPageUnsafeSupplier) {

		_recordsPerPageSupplier = () -> {
			try {
				return recordsPerPageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer recordsPerPage;

	@JsonIgnore
	private Supplier<Integer> _recordsPerPageSupplier;

	@Schema(example = "")
	public String getSearchType() {
		if (_searchTypeSupplier != null) {
			searchType = _searchTypeSupplier.get();

			_searchTypeSupplier = null;
		}

		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;

		_searchTypeSupplier = null;
	}

	@JsonIgnore
	public void setSearchType(
		UnsafeSupplier<String, Exception> searchTypeUnsafeSupplier) {

		_searchTypeSupplier = () -> {
			try {
				return searchTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchType;

	@JsonIgnore
	private Supplier<String> _searchTypeSupplier;

	@Schema(example = "")
	public String getSearchValue() {
		if (_searchValueSupplier != null) {
			searchValue = _searchValueSupplier.get();

			_searchValueSupplier = null;
		}

		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;

		_searchValueSupplier = null;
	}

	@JsonIgnore
	public void setSearchValue(
		UnsafeSupplier<String, Exception> searchValueUnsafeSupplier) {

		_searchValueSupplier = () -> {
			try {
				return searchValueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchValue;

	@JsonIgnore
	private Supplier<String> _searchValueSupplier;

	@Schema
	@Valid
	public SortOrder[] getSortOrder() {
		if (_sortOrderSupplier != null) {
			sortOrder = _sortOrderSupplier.get();

			_sortOrderSupplier = null;
		}

		return sortOrder;
	}

	public void setSortOrder(SortOrder[] sortOrder) {
		this.sortOrder = sortOrder;

		_sortOrderSupplier = null;
	}

	@JsonIgnore
	public void setSortOrder(
		UnsafeSupplier<SortOrder[], Exception> sortOrderUnsafeSupplier) {

		_sortOrderSupplier = () -> {
			try {
				return sortOrderUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected SortOrder[] sortOrder;

	@JsonIgnore
	private Supplier<SortOrder[]> _sortOrderSupplier;

	@Schema
	public String[] getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String[] status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String[], Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] status;

	@JsonIgnore
	private Supplier<String[]> _statusSupplier;

	@Schema(example = "2019-11-28T07:31:21.168Z")
	public String getToDate() {
		if (_toDateSupplier != null) {
			toDate = _toDateSupplier.get();

			_toDateSupplier = null;
		}

		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;

		_toDateSupplier = null;
	}

	@JsonIgnore
	public void setToDate(
		UnsafeSupplier<String, Exception> toDateUnsafeSupplier) {

		_toDateSupplier = () -> {
			try {
				return toDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String toDate;

	@JsonIgnore
	private Supplier<String> _toDateSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ChangeListFilter)) {
			return false;
		}

		ChangeListFilter changeListFilter = (ChangeListFilter)object;

		return Objects.equals(toString(), changeListFilter.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String[] businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("[");

			for (int i = 0; i < businessService.length; i++) {
				sb.append("\"");

				sb.append(_escape(businessService[i]));

				sb.append("\"");

				if ((i + 1) < businessService.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] changeType = getChangeType();

		if (changeType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"changeType\": ");

			sb.append("[");

			for (int i = 0; i < changeType.length; i++) {
				sb.append("\"");

				sb.append(_escape(changeType[i]));

				sb.append("\"");

				if ((i + 1) < changeType.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String fromDate = getFromDate();

		if (fromDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fromDate\": ");

			sb.append("\"");

			sb.append(_escape(fromDate));

			sb.append("\"");
		}

		Integer pageIndex = getPageIndex();

		if (pageIndex != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"pageIndex\": ");

			sb.append(pageIndex);
		}

		String[] priority = getPriority();

		if (priority != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priority\": ");

			sb.append("[");

			for (int i = 0; i < priority.length; i++) {
				sb.append("\"");

				sb.append(_escape(priority[i]));

				sb.append("\"");

				if ((i + 1) < priority.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		Integer recordsPerPage = getRecordsPerPage();

		if (recordsPerPage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"recordsPerPage\": ");

			sb.append(recordsPerPage);
		}

		String searchType = getSearchType();

		if (searchType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchType\": ");

			sb.append("\"");

			sb.append(_escape(searchType));

			sb.append("\"");
		}

		String searchValue = getSearchValue();

		if (searchValue != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchValue\": ");

			sb.append("\"");

			sb.append(_escape(searchValue));

			sb.append("\"");
		}

		SortOrder[] sortOrder = getSortOrder();

		if (sortOrder != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sortOrder\": ");

			sb.append("[");

			for (int i = 0; i < sortOrder.length; i++) {
				sb.append(String.valueOf(sortOrder[i]));

				if ((i + 1) < sortOrder.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("[");

			for (int i = 0; i < status.length; i++) {
				sb.append("\"");

				sb.append(_escape(status[i]));

				sb.append("\"");

				if ((i + 1) < status.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String toDate = getToDate();

		if (toDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"toDate\": ");

			sb.append("\"");

			sb.append(_escape(toDate));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.changerequest.api.dto.v1_0_0.ChangeListFilter",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}