package com.vf.cove.changerequest.internal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.changerequest.api.internal.service.ReportService;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ReportServiceTest {

	@Mock
	private CoveResponseParser responseParser;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	//@Mock
	private static ReportService reportService;

	private String successResponse;
	private String failureResponse;
	private static final String MESSAGE_ID = "testMessageId";

	 private CoveResponse esbResponse;
	 private String reportRequest;
	 private static ObjectMapper mapper;

	@BeforeEach
	public void setUp() throws Exception {
        mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true);

		successResponse = TestUtils.inputStreamToString("src/test/resources/reportResponse_DXL.json");
		failureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");
		esbResponse = new CoveResponse();
		reportService = new ReportService();

        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
        when(responseParser.getCoveMapper()).thenReturn(mapper);
	}

	@Test
	public void reportSuccessResponse() throws Exception {
		esbResponse.setData(successResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		Assertions.assertThatThrownBy(() -> reportService.getReport(reportRequest, MESSAGE_ID))
        .isInstanceOf(NullPointerException.class);
	}

	@Test
	public void reportFailureResponse() throws Exception {
		esbResponse.setData(failureResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		Assertions.assertThatThrownBy(() -> reportService.getReport(reportRequest, MESSAGE_ID))
        .isInstanceOf(NullPointerException.class);

	}
}
