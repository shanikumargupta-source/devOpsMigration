package com.vf.cove.changerequest.internal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.changerequest.api.dto.v1_0_0.Change;
import com.vf.cove.changerequest.api.internal.service.ChangeDetailService;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.InputStream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ChangeDetailServiceTest {

    @Mock
    private CoveResponseParser responseParser;

    @Mock
    private RestAPIProcessor restAPIProcessor;

    @InjectMocks
    private ChangeDetailService changeDetailService;

    private String successResponse;
    private String failureResponse;
    private static final String MESSAGE_ID = "testMessageId";

    private CoveResponse esbResponse;
    private String changeDetailsRequest;
    private static ObjectMapper mapper;

    @BeforeEach
    public void setUp() throws Exception {
        mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true);

        successResponse = TestUtils.inputStreamToString("src/test/resources/changeDetailsResponse_DXL.json");
        failureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");
        esbResponse = new CoveResponse();

        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
        when(responseParser.getCoveMapper()).thenReturn(mapper);
    }

    @Test
    public void changeDetailSuccessResponse() throws Exception {
        String mappedResponse = TestUtils.inputStreamToString("src/test/resources/changeDetailsResponse_mapped_DXL.json");
        JsonNode data = mapper.readTree(mappedResponse);
        esbResponse.setData(successResponse);
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
        when(responseParser.parse(any(InputStream.class), anyString())).thenReturn(data);
        final Change response = changeDetailService.getDetail(changeDetailsRequest, MESSAGE_ID);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getAttachments().getAttachment().length).isEqualTo(1);
        Assertions.assertThat(response.getAttachments().getAttachment()[0].getName()).isEqualTo("download.jpg");
            }

    @Test
    public void changeDetailFailureResponse() throws Exception {
        esbResponse.setData(failureResponse);
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
        final Change response = changeDetailService.getDetail(changeDetailsRequest, MESSAGE_ID);
        Assertions.assertThat(response).isNull();

    }
}
