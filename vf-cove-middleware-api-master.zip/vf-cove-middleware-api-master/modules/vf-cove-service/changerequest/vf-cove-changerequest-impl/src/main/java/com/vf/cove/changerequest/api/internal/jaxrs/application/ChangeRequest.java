package com.vf.cove.changerequest.api.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author SwatiKeshari
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false",
		"osgi.jaxrs.application.base=/vf-cove-changerequest",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=vf-cove-changerequest"
	},
	service = Application.class
)
@Generated("")
public class ChangeRequest extends Application {
}