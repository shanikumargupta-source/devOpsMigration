package com.vf.cove.changerequest.api.internal.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.vulcan.pagination.Page;
import com.vf.cove.changerequest.api.dto.v1_0_0.ReportResponse;
import com.vf.cove.changerequest.api.internal.constants.ChangeReportConstants;
import com.vf.cove.changerequest.api.internal.resource.v1_0_0.ReportResponseResourceImpl;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Component(service = ReportService.class)
public class ReportService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChangeDetailService.class);

    @Reference(target = "(backend=DXL)")
    private RestAPIProcessor restAPIProcessor;

    @Reference(unbind = "-")
    private CoveResponseParser responseParser;

    public Page<ReportResponse> getReport(String request, String messageId) throws IOException {

        List<ReportResponse> reportResponseList = new ArrayList<>();

        String relativeUrl = ChangeReportConstants.CHANGE_REPORT_API_URL;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
        restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);
        CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

        if (!Validator.isBlank(dxlResponse.getData())) {

            InputStream in = ReportResponseResourceImpl.class
                .getResourceAsStream(ChangeReportConstants.CHANGE_REPORT_API_RESPONSE_DEFINITION);
            JsonNode transformedJsonNode = responseParser.parse(in, dxlResponse.getData());
            LOGGER.debug("Report: transformedString   {}", transformedJsonNode);


            transformedJsonNode.forEach(node -> {
                ReportResponse report = null;
                try {
                    report = responseParser.getCoveMapper().readValue(node.toString(), ReportResponse.class);

                } catch (JsonProcessingException e) {
                    LOGGER.error("JsonProcessingException  ", e);
                }

                reportResponseList.add(report);

            });
            LOGGER.debug("Report: responseOfReport   {}", reportResponseList);


        } else {
            LOGGER.info("Response is Blank  ");
        }


        return Page.of(reportResponseList);
    }
}
