<@compress single_line=true>
{
  "id": [
    {
      "value": "${reference}",
      "schemeName": "changeId"
    }
  ],
  "parts": {
  	  <#if request.customerRefNum?has_content>
  	  "externalReference": [
        {
          "referenceId": {
            "value": "${request.customerRefNum}",
            "schemeName": "customerTicketReference"
    			}
  		 }
       ]
	  </#if>
     <#if request.customerRefNum?has_content && request.coveFlag?has_content>
     ,
     </#if>
     <#if request.customerRefNum?has_content && request.noteContent?has_content && !request.coveFlag?has_content>
     ,
	 </#if>
      <#if request.coveFlag?has_content>
      "approval": {
        "name": "${request.coveFlag}",
        "desc": "coveFlag"
      }
      </#if>
      <#if request.noteContent?has_content && request.coveFlag?has_content>
     ,
     </#if>
    <#if request.noteContent?has_content>
    "note": [
      {
        "content": "${request.noteContent}"
      }
    ]
    </#if>
  }
}
</@compress>