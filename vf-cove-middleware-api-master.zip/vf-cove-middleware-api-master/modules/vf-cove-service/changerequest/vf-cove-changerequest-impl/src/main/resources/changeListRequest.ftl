<@compress single_line=true>
{
	"queryOptions": {
		"pagination": {
            "count": ${request.pageIndex}<#if request.recordsPerPage != 0>,
            "limit": ${request.recordsPerPage}
			</#if>
		}<#if sorting?has_content>,
		"sorting": "${sorting}"
		</#if>
	},
	"queries": [
		{
			"query": "$.roles.requester.organisation.id[*].value=${orgID}"
		},
		{
			"operator": "AND"
		},
		{
			"query": "$.roles.requester.contactName.id[*].value=${userName}"
		}<#if type?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.type=${type}"
		}</#if><#if request.businessService?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.parts.service[*].name=${request.businessService}"
		}</#if><#if request.fromDate?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.details.plannedStartDate.dateString.value>=${request.fromDate}"
		}
		</#if><#if request.toDate?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.details.plannedStartDate.dateString.value<=${request.toDate}"
		}</#if><#if status?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.status=${status}"
		}</#if><#if customerTicketReference?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.parts.externalReference[*].referenceId[?(@.schemeName=='customerTicketReference')].value=${customerTicketReference}"
		}</#if><#if priority?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.details.priorityCode=${priority}"

		}</#if><#if changeRequestIdRef?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.id[?(@.schemeName=='changeRequestIdRef')].value=${changeRequestIdRef}"
		}
		</#if>
	]
}
</@compress>