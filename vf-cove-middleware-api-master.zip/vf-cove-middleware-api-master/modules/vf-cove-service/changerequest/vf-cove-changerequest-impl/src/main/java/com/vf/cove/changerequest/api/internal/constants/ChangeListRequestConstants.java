package com.vf.cove.changerequest.api.internal.constants;

public class ChangeListRequestConstants {
    private ChangeListRequestConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String CHANGE_LIST_API_URL = "/vbps/dxl/changeRequestAPI/v2/changeRequest/search";

	public static final String CHANGE_LIST_API_RESPONSE_DEFINITION = "/changeListResponse.json";

	public static final String CHANGE_LIST_API_REQUEST_DEFINITION = "/changeListRequest.ftl";

	public static final String BUSINESS_SERVICE_PARAM = "businessService";

	public static final String PRIORITY_PARAM = "priority";

	public static final String STATUS_PARAM = "status";

	public static final String TICKET_REF_PARAM = "customerTicketReference";

	public static final String REQ_ID_PARAM = "changeRequestIdRef";



	public static final String TYPE_PARAM = "type";


	public static final String NO_DATA = "No data found";

	public static final String ZERO_COUNT = "0";
}
