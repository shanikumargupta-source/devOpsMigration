package com.vf.cove.changerequest.api.internal.util;

import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.ftlutils.utils.StreamToStringUtil;
import com.vf.cove.core.restutils.constants.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Map;

@Component(immediate = true, service = { ChangeRequestUtils.class })
public class ChangeRequestUtils {
    @Reference(unbind = "-")
    private FtlTemplateService ftlTemplateService;

    public String getDXLRequest(Object request, Map<String, Object> params, String templateName) throws Exception{
        if (request != null) {
            params.put(Constants.REQUEST_PARAM_NAME, request);
        }
        final InputStream resourceAsStream = this.getClass().getResourceAsStream(templateName);
        String templateStr = StreamToStringUtil.getString(resourceAsStream);
        return ftlTemplateService.renderTemplate(templateName, templateStr, params);
    }

}
