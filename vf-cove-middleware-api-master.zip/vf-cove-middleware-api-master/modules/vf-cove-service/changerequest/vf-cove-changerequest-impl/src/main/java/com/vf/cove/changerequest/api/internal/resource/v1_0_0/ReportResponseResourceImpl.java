package com.vf.cove.changerequest.api.internal.resource.v1_0_0;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.vulcan.pagination.Page;
import com.vf.cove.changerequest.api.dto.v1_0_0.ReportResponse;
import com.vf.cove.changerequest.api.internal.constants.ChangeReportConstants;
import com.vf.cove.changerequest.api.internal.service.ReportService;
import com.vf.cove.changerequest.api.internal.util.ChangeRequestUtils;
import com.vf.cove.changerequest.api.resource.v1_0_0.ReportResponseResource;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

/**
 * @author SwatiKeshari
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0_0/report-response.properties",
	scope = ServiceScope.PROTOTYPE, service = ReportResponseResource.class
)
public class ReportResponseResourceImpl extends BaseReportResponseResourceImpl {

private static final Logger LOGGER = LoggerFactory.getLogger(ReportResponseResourceImpl.class);

	@Reference(target = "(backend=DXL)")
    private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	@Reference(unbind = "-")
	private ReportService reportService;

    @Reference(unbind = "-")
    private FtlTemplateService ftlTemplateService;
    @Reference(unbind = "-")
    private ChangeRequestUtils changeRequestUtils;

	@Override
	public Page<ReportResponse> getChangeRequestReportPage(String status, String heroFlag) throws Exception {

		LOGGER.info("In ReportResponseResourceImpl: getChangeRequestReportPage method");

		String messageId = RequestUtils.getUUID();
		Map<String, Object> additionalParams = populateParams(status,heroFlag);
        String request = changeRequestUtils.getDXLRequest(null,additionalParams,ChangeReportConstants.CHANGE_REPORT_API_REQUEST_DEFINITION);
		LOGGER.debug(" Report Request:    {}", request);
		return reportService.getReport(request, messageId );
	}


	private Map<String, Object> populateParams(String status, String heroFlag)
			throws PortalException, IOException {
		Map<String, Object> additionalParams = RequestUtils.populateUserAndOrg(contextUser);

		String[] defaultStatus = {};
		LOGGER.debug("status...{}",status);
		LOGGER.debug("heroFlag...{}",heroFlag);
		additionalParams.put(ChangeReportConstants.STATUS_PARAM,
				 ( status != null ) ? status.split(",") : defaultStatus);
		additionalParams.put(ChangeReportConstants.HERO_FLAG_PARAM,heroFlag);
		LOGGER.debug("additionalParams...{}", additionalParams);
		return additionalParams;
	}
}
