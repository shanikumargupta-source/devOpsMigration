package com.vf.cove.changerequest.api.internal.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.changerequest.api.dto.v1_0_0.Change;
import com.vf.cove.changerequest.api.dto.v1_0_0.Changes;
import com.vf.cove.changerequest.api.dto.v1_0_0.ChangesResponse;
import com.vf.cove.changerequest.api.internal.constants.ChangeListRequestConstants;
import com.vf.cove.changerequest.api.internal.resource.v1_0_0.ChangesResponseResourceImpl;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.ResponseUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Component(service = ChangeListService.class)
public class ChangeListService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChangeDetailService.class);

    @Reference(target = "(backend=DXL)")
    private RestAPIProcessor restAPIProcessor;

    @Reference(unbind = "-")
    private CoveResponseParser responseParser;

    public ChangesResponse getList(String request, String messageId) throws IOException {

        ChangesResponse changesResponse = new ChangesResponse();

        String relativeUrl = ChangeListRequestConstants.CHANGE_LIST_API_URL;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
        restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);
        CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

        if (!Validator.isBlank(dxlResponse.getData())) {
            String status = dxlResponse.getHeaders().get(Constants.RESULT_STATUS_HEADER);
            changesResponse.setStatus(status);
            InputStream in = ChangesResponseResourceImpl.class
                .getResourceAsStream(ChangeListRequestConstants.CHANGE_LIST_API_RESPONSE_DEFINITION);
            JsonNode transformedJsonNode = responseParser.parse(in, dxlResponse.getData());
            LOGGER.debug("ChangeListService : transformedString   {}", transformedJsonNode);
            Changes response = new Changes();
            changesResponse.setResponse(response);
            List<Change> tableDatas = new ArrayList<Change>();
            transformedJsonNode.forEach(node -> {
                Change tableData = null;
                try {
                    tableData = responseParser.getCoveMapper().readValue(node.toString(), Change.class);
                    convertDateValues(tableData);
                } catch (JsonProcessingException e) {
                    LOGGER.error("JsonProcessingException   ", e);
                }

                tableDatas.add(tableData);

            });
            response.setChanges(tableDatas.toArray(new Change[tableDatas.size()]));
            String totalCount = dxlResponse.getHeaders().get("x-total-count");
            LOGGER.info("ChangeList: totalCount   {}", totalCount);
            response.setTotalCount(responseParser.getCoveMapper().readValue(totalCount, String.class));

        } else {
            changesResponse.setStatus(Constants.NO_RESPONSE);
        }
        return changesResponse;
    }

    private void convertDateValues(Change tableData) {
        tableData.setActualStartDate(ResponseUtils.getCoveDate(tableData.getActualStartDate()));
        tableData.setActualEndDate(ResponseUtils.getCoveDate(tableData.getActualEndDate()));
        tableData.setFromDate(ResponseUtils.getCoveDate(tableData.getFromDate()));
        tableData.setToDate(ResponseUtils.getCoveDate(tableData.getToDate()));
        tableData.setImpactStartDate(ResponseUtils.getCoveDate(tableData.getImpactStartDate()));
        tableData.setImpactEndDate(ResponseUtils.getCoveDate(tableData.getImpactEndDate()));
        tableData.setDateRaised(ResponseUtils.getCoveDate(tableData.getDateRaised()));
    }
}

