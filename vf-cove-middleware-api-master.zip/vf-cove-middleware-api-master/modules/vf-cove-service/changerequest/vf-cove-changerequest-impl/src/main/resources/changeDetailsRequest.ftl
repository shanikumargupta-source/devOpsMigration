<@compress single_line=true>
{
    "queries": [
     	{
		    "query": "$.roles.requester.organisation.id[*].value=${orgID}"
		},
		
		 {
            "operator": "AND"
        },
		{
		    "query": "$.roles.requester.contactName.id[*].value=${userName}"
		},
		 {
            "operator": "AND"
        },		
		{
		    "query": "$.id[?(@.schemeName=='changeRequestId')].value=${request.changeReference}"
		}     	   
		 
    ]
}
</@compress>