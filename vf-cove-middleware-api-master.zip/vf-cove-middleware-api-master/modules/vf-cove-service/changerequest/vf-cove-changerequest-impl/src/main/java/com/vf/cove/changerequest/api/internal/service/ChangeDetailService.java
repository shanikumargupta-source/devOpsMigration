package com.vf.cove.changerequest.api.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vf.cove.changerequest.api.dto.v1_0_0.Change;
import com.vf.cove.changerequest.api.internal.constants.ChangeDetailsConstants;
import com.vf.cove.changerequest.api.internal.resource.v1_0_0.ChangeResourceImpl;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.ResponseUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Component(service = ChangeDetailService.class)
public class ChangeDetailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChangeDetailService.class);

	 @Reference(target="(backend=DXL)")
    private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	public Change getDetail(String request , String messageId ) throws IOException {

		  Change response = null;

		 String relativeUrl = ChangeDetailsConstants.CHANGE_DETAILS_API_URL;
	        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
	        restAPIRequest.setRelativeUrl(relativeUrl);
	        restAPIRequest.setRequest(request);
	        restAPIRequest.setTransactionId(messageId);


	        CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

	        Map<String, String> headers = new HashMap<>();
	        headers.put(Constants.DESTINATION_SYSTEM_HEADER, Constants.DESTINATION_SYSTEM_SNOW);

	        if (StringUtils.isNotEmpty(dxlResponse.getData())) {
	            InputStream in = ChangeResourceImpl.class
	                .getResourceAsStream(ChangeDetailsConstants.CHANGE_DETAILS_API_RESPONSE_DEFINITION);
	            JsonNode transformedJsonNode = responseParser.parse(in, dxlResponse.getData());
	            LOGGER.debug("ChangeDetailService : transformedString   {}" , transformedJsonNode);
	            if (transformedJsonNode != null && !transformedJsonNode.isEmpty()) {
	                 response = responseParser.getCoveMapper().readValue(transformedJsonNode.get(0).toString(),
	                    Change.class);
	                convertDateValues(response);
	            }

	        }

	        return response;

	}

	 public static void convertDateValues(Change tableData) {
	        tableData.setActualStartDate(ResponseUtils.getCoveDate(tableData.getActualStartDate()));
	        tableData.setActualEndDate(ResponseUtils.getCoveDate(tableData.getActualEndDate()));
	        tableData.setFromDate(ResponseUtils.getCoveDate(tableData.getFromDate()));
	        tableData.setToDate(ResponseUtils.getCoveDate(tableData.getToDate()));
	        tableData.setImpactStartDate(ResponseUtils.getCoveDate(tableData.getImpactStartDate()));
	        tableData.setImpactEndDate(ResponseUtils.getCoveDate(tableData.getImpactEndDate()));
	        tableData.setDateRaised(ResponseUtils.getCoveDate(tableData.getDateRaised()));
	    }

}
