package com.vf.cove.changerequest.api.internal.resource.v1_0_0;

import com.vf.cove.changerequest.api.dto.v1_0_0.Change;
import com.vf.cove.changerequest.api.internal.constants.ChangeDetailsConstants;
import com.vf.cove.changerequest.api.internal.service.ChangeDetailService;
import com.vf.cove.changerequest.api.internal.util.ChangeRequestUtils;
import com.vf.cove.changerequest.api.resource.v1_0_0.ChangeResource;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * @author SwatiKeshari
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0_0/change.properties",
	scope = ServiceScope.PROTOTYPE, service = ChangeResource.class
)
public class ChangeResourceImpl extends BaseChangeResourceImpl {

	  private static final Logger LOGGER = LoggerFactory.getLogger(ChangeResourceImpl.class);

	    @Reference(unbind = "-")
		private ChangeDetailService changeDetailService;

	    @Reference(unbind = "-")
	    private CoveResponseParser responseParser;

        @Reference(unbind = "-")
        private FtlTemplateService ftlTemplateService;

        @Reference(unbind = "-")
        private ChangeRequestUtils changeRequestUtils;

	    @Override
	    public Change getChange(String refId)throws Exception {
	        LOGGER.info("In ChangeResourceImpl: getChange method with refId {} ",refId);

	        Change change = new Change();
	        change.setChangeReference(refId);
	        String messageId = RequestUtils.getUUID();

            Map<String, Object> additionalParams=  RequestUtils.populateUserAndOrg(contextUser);
            String request = changeRequestUtils.getDXLRequest(change,additionalParams, ChangeDetailsConstants.CHANGE_DETAILS_API_REQUEST_DEFINITION);
	        return  changeDetailService.getDetail(request, messageId );

	    }

}
