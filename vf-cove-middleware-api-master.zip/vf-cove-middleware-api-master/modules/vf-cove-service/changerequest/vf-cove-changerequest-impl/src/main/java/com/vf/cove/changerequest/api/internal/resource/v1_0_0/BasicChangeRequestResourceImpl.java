package com.vf.cove.changerequest.api.internal.resource.v1_0_0;

import com.liferay.portal.kernel.exception.PortalException;
import com.vf.cove.changerequest.api.dto.v1_0_0.BasicChangeRequest;
import com.vf.cove.changerequest.api.internal.constants.ChangeUpdateDetailsConstants;
import com.vf.cove.changerequest.api.internal.service.UpdateChangeDetailService;
import com.vf.cove.changerequest.api.internal.util.ChangeRequestUtils;
import com.vf.cove.changerequest.api.resource.v1_0_0.BasicChangeRequestResource;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;


/**
 * @author SwatiKeshari
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0_0/basic-change-request.properties",
	scope = ServiceScope.PROTOTYPE, service = BasicChangeRequestResource.class
)
public class BasicChangeRequestResourceImpl
	extends BaseBasicChangeRequestResourceImpl {

private static final Logger LOGGER = LoggerFactory.getLogger(BasicChangeRequestResourceImpl.class);

	@Reference(target = "(backend=DXL)")
    private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	 @Reference(unbind = "-")
     private UpdateChangeDetailService updateChangeDetailService;
    @Reference(unbind = "-")
    private ChangeRequestUtils changeRequestUtils;

	 @Override
		public BasicChangeRequest putChangeRef(String refId,
				BasicChangeRequest basicChangeRequest) throws Exception {

			LOGGER.info("BasicChangeRequestResourceImpl : putChangeRef refId {} and basicChangeRequest {} ",refId,basicChangeRequest);

            String messageId = RequestUtils.getUUID();
            Map<String, Object> additionalParams = populateParams(refId);
            String request = changeRequestUtils.getDXLRequest(basicChangeRequest,additionalParams, ChangeUpdateDetailsConstants.CHANGE_UPDATE_API_REQUEST_DEFINITION);
            LOGGER.info("BasicChangeRequestResourceImpl: Request:    {}", request);
            return  updateChangeDetailService.getUpdate(request, refId , messageId );
		}

		private Map<String, Object> populateParams(String refId)
				throws PortalException, IOException {
			Map<String, Object> additionalParams = RequestUtils.populateUserAndOrg(contextUser);

			additionalParams.put(ChangeUpdateDetailsConstants.REFERENCE_PARAM, refId);

			return additionalParams;
		}

}
