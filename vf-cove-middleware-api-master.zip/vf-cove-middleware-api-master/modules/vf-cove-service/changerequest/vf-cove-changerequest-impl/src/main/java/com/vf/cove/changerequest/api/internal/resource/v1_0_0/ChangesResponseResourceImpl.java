package com.vf.cove.changerequest.api.internal.resource.v1_0_0;

import com.liferay.portal.kernel.exception.PortalException;
import com.vf.cove.changerequest.api.dto.v1_0_0.ChangeListFilter;
import com.vf.cove.changerequest.api.dto.v1_0_0.ChangesResponse;
import com.vf.cove.changerequest.api.dto.v1_0_0.SortOrder;
import com.vf.cove.changerequest.api.internal.constants.ChangeListRequestConstants;
import com.vf.cove.changerequest.api.internal.service.ChangeListService;
import com.vf.cove.changerequest.api.internal.util.ChangeRequestUtils;
import com.vf.cove.changerequest.api.resource.v1_0_0.ChangesResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 * @author SwatiKeshari
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0_0/changes-response.properties",
	scope = ServiceScope.PROTOTYPE, service = ChangesResponseResource.class
)
public class ChangesResponseResourceImpl
	extends BaseChangesResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChangesResponseResourceImpl.class);

	@Reference(unbind = "-")
	private ChangeListService changeListService;

    @Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

    @Reference(unbind = "-")
    private CoveRequestParser requestParser;

    @Reference(unbind = "-")
    private ChangeRequestUtils changeRequestUtils;
	@Override
	public ChangesResponse postChange(ChangeListFilter changeListFilter) throws Exception {
		LOGGER.info("In ChangesResponseResourceImpl: postChange method ");

		String messageId = RequestUtils.getUUID();
		LOGGER.debug("changeListRequest {}",changeListFilter);
		Map<String, Object> additionalParams = populateParams(changeListFilter);
        String request = changeRequestUtils.getDXLRequest(changeListFilter,additionalParams, ChangeListRequestConstants.CHANGE_LIST_API_REQUEST_DEFINITION);
		return  changeListService.getList(request, messageId );
	}


	private Map<String, Object> populateParams(ChangeListFilter changeListFilter)
			throws PortalException, IOException {
		Map<String, Object> additionalParams = RequestUtils.populateUserAndOrg(contextUser);

		changeListFilter.setPageIndex(changeListFilter.getPageIndex() * changeListFilter.getRecordsPerPage());
		additionalParams.put(ChangeListRequestConstants.BUSINESS_SERVICE_PARAM,
				RequestUtils.getValueFromArray(changeListFilter.getBusinessService()));
		additionalParams.put(ChangeListRequestConstants.PRIORITY_PARAM,
				RequestUtils.getValueFromArray(changeListFilter.getPriority()));
		additionalParams.put(ChangeListRequestConstants.STATUS_PARAM,
				RequestUtils.getValueFromArray(changeListFilter.getStatus()));
		additionalParams.put(ChangeListRequestConstants.TYPE_PARAM,
				RequestUtils.getValueFromArray(changeListFilter.getChangeType()));
		if (StringUtils.equalsIgnoreCase(changeListFilter.getSearchType(),
				ChangeListRequestConstants.TICKET_REF_PARAM)) {
			additionalParams.put(ChangeListRequestConstants.TICKET_REF_PARAM, changeListFilter.getSearchValue());
		} else if (StringUtils.equalsIgnoreCase(changeListFilter.getSearchType(),
				ChangeListRequestConstants.REQ_ID_PARAM)) {
			additionalParams.put(ChangeListRequestConstants.REQ_ID_PARAM, changeListFilter.getSearchValue());
		}

		additionalParams.put(Constants.SORTING_PARAM, getSortOrder(changeListFilter.getSortOrder(),
				ChangeListRequestConstants.CHANGE_LIST_API_RESPONSE_DEFINITION));
		LOGGER.debug("ChangeList: additionalParams {}",additionalParams);
		return additionalParams;
	}


	 public String getSortOrder(@Valid SortOrder[] sortOrders, String responseParserFileName) throws IOException {
	        if (sortOrders != null && sortOrders.length > 0) {
	            StringBuilder stringBuilder = new StringBuilder();

	            for (int i = 1; i <= sortOrders.length; i++) {
	                if (StringUtils.equalsIgnoreCase(sortOrders[i - 1].getValue(), Constants.ASC)) {
	                    stringBuilder.append(Constants.PLUS);
	                } else {
	                    stringBuilder.append(Constants.MINUS);
	                }
                    final InputStream in = this.getClass().getResourceAsStream(responseParserFileName);
	                stringBuilder.append(requestParser.getESBSortParam(sortOrders[i - 1].getKey(), in));
	                if (i != sortOrders.length) {
	                    stringBuilder.append(Constants.COMMA);
	                }
	            }
	            return stringBuilder.toString();
	        }
	        return StringUtils.EMPTY;
	    }
}
