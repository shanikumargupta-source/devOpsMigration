package com.vf.cove.changerequest.api.internal.constants;

public class ChangeUpdateDetailsConstants {
    private ChangeUpdateDetailsConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String INTERNAL_SERVER_ERROR = "Internal server error";

	public static final String CHANGE_UPDATE_API_URL = "/vbps/dxl/changeRequestAPI/v2/changeRequest/";

	public static final String CHANGE_UPDATE_API_RESPONSE_DEFINITION = "/updateChangeDetailResponse.json";

	public static final String CHANGE_UPDATE_API_REQUEST_DEFINITION = "/updateChangeDetailRequest.ftl";

	public static final String REFERENCE_PARAM = "reference";

	public static final int ERROR_CODE_500 = 500;

	public static final String SOURCE_SYSTEM_HEADER = "X-Source-System";

    public static final String SOURCE_SYSTEM_COVE = "COVE";
}

