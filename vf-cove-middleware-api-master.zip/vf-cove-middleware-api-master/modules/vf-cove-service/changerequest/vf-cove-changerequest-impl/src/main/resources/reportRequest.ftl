<@compress single_line=true>
{
  "reportQuery": {
    "queryExpression": {
      "valueExpression": [
        {
          "queryOperatorCode": "EQUALS",
          "path": "$.roles.requester.organisation.id[*].value",
          "value": [
            {
              "value":"${orgID}"
            }
          ]
        },
        {
          "queryOperatorCode": "EQUALS",
          "path": "$.roles.requester.contactName.id[*].value",
          "value": [
            {
              "value":"${userName}"
            }
          ]
        },
        {
          "queryOperatorCode": "IN",
          "path": "$.status",
          "value": [
          <#list status as stat>
            {
				"value": "${stat}"
			}
            <#if stat?is_last><#else>,</#if>		    
			</#list>
          ]
        }
        
      ]
    },
	"groupingExpression": {
		"path": [
				<#if heroFlag ?has_content>
		        {
		           "value": "$.status"
		        }
		        <#else> {
		           "value": "$.details.priorityCode"
		        }
		        </#if>
			]
		},
 	"aggregateFunction": {
 		"function": [
				{
					"name": "COUNT",
					"path": "$.id[*].value"
				}
			 ]
		 }

  }
}
</@compress>