package com.vf.cove.changerequest.api.internal.constants;

public class ChangeReportConstants {
    private ChangeReportConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String INTERNAL_SERVER_ERROR = "Internal server error";

	public static final String CHANGE_REPORT_API_URL = "/vbps/dxl/changeRequestAPI/v2/changeRequest/report";

	public static final String CHANGE_REPORT_API_RESPONSE_DEFINITION = "/reportResponse.json";

	public static final String CHANGE_REPORT_API_REQUEST_DEFINITION = "/reportRequest.ftl";

	public static final String STATUS_PARAM = "status";
	public static final String HERO_FLAG_PARAM = "heroFlag";

	public static final int ERROR_CODE_500 = 500;

}
