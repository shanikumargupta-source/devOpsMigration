package com.vf.cove.changerequest.api.internal.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.changerequest.api.dto.v1_0_0.BasicChangeRequest;
import com.vf.cove.changerequest.api.internal.constants.ChangeUpdateDetailsConstants;
import com.vf.cove.changerequest.api.internal.resource.v1_0_0.BasicChangeRequestResourceImpl;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Component(service = UpdateChangeDetailService.class)
public class UpdateChangeDetailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateChangeDetailService.class);

	@Reference(target="(backend=DXL)")
    private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	public BasicChangeRequest getUpdate(String request , String referenceURL, String messageId ) throws IOException {

	   BasicChangeRequest response = new BasicChangeRequest();

		String relativeUrl = ChangeUpdateDetailsConstants.CHANGE_UPDATE_API_URL;
		String updatedRelativeUrl = relativeUrl + referenceURL;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(updatedRelativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);
        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            restAPIRequest.addHeader(ChangeUpdateDetailsConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
        LOGGER.info("Request Headers.. {}", restAPIRequest.getHeaders());
		CoveResponse dxlResponse = restAPIProcessor.put(restAPIRequest);


		if (!Validator.isBlank(dxlResponse.getData())) {

			if (StringUtils.isNotEmpty(dxlResponse.getData())) {
				InputStream in = BasicChangeRequestResourceImpl.class
						.getResourceAsStream(ChangeUpdateDetailsConstants.CHANGE_UPDATE_API_RESPONSE_DEFINITION);
				JsonNode transformedJsonNode = responseParser.parse(in, dxlResponse.getData());
				LOGGER.debug("UpdateChangeDetailService : transformedString   {}", transformedJsonNode);


				transformedJsonNode.forEach(node -> {

					try {
						BasicChangeRequest basicChangeRequest = responseParser.getCoveMapper().readValue(node.toString(), BasicChangeRequest.class);
						response.setValue(basicChangeRequest.getValue());
					} catch (JsonMappingException e) {
						LOGGER.error("JsonMappingException   ", e);
					} catch (JsonProcessingException e) {
						LOGGER.error("JsonProcessingException  ", e);
					}
                });
				LOGGER.info("UpdateChangeDetail : updateChangeDetailResponse   {}", response);

			}
		} else {
			LOGGER.info("Response is Blank  ");
		}


		return response;
	}

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }
}
