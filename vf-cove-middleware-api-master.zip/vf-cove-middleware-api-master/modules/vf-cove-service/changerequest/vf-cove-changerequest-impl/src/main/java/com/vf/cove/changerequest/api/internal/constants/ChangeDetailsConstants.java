package com.vf.cove.changerequest.api.internal.constants;

public class ChangeDetailsConstants {
    private ChangeDetailsConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String CHANGE_DETAILS_API_URL = "/vbps/dxl/changeRequestAPI/v2/changeRequest/search";

	public static final String CHANGE_DETAILS_API_RESPONSE_DEFINITION = "/changeDetailsResponse.json";

	public static final String CHANGE_DETAILS_API_REQUEST_DEFINITION = "/changeDetailsRequest.ftl";

}
