package com.vf.cove.genericInventory.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Ravi Rajamani
 * @generated
 */
@Generated("")
@GraphQLName("GetChildCustomer")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetChildCustomer")
public class GetChildCustomer implements Serializable {

	public static GetChildCustomer toDTO(String json) {
		return ObjectMapperUtil.readValue(GetChildCustomer.class, json);
	}

	public static GetChildCustomer unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(GetChildCustomer.class, json);
	}

	@Schema
	public String getChildAccountType() {
		if (_childAccountTypeSupplier != null) {
			childAccountType = _childAccountTypeSupplier.get();

			_childAccountTypeSupplier = null;
		}

		return childAccountType;
	}

	public void setChildAccountType(String childAccountType) {
		this.childAccountType = childAccountType;

		_childAccountTypeSupplier = null;
	}

	@JsonIgnore
	public void setChildAccountType(
		UnsafeSupplier<String, Exception> childAccountTypeUnsafeSupplier) {

		_childAccountTypeSupplier = () -> {
			try {
				return childAccountTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childAccountType;

	@JsonIgnore
	private Supplier<String> _childAccountTypeSupplier;

	@Schema
	public String getChildCustLegalOrgId() {
		if (_childCustLegalOrgIdSupplier != null) {
			childCustLegalOrgId = _childCustLegalOrgIdSupplier.get();

			_childCustLegalOrgIdSupplier = null;
		}

		return childCustLegalOrgId;
	}

	public void setChildCustLegalOrgId(String childCustLegalOrgId) {
		this.childCustLegalOrgId = childCustLegalOrgId;

		_childCustLegalOrgIdSupplier = null;
	}

	@JsonIgnore
	public void setChildCustLegalOrgId(
		UnsafeSupplier<String, Exception> childCustLegalOrgIdUnsafeSupplier) {

		_childCustLegalOrgIdSupplier = () -> {
			try {
				return childCustLegalOrgIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childCustLegalOrgId;

	@JsonIgnore
	private Supplier<String> _childCustLegalOrgIdSupplier;

	@Schema
	public String getChildCustName() {
		if (_childCustNameSupplier != null) {
			childCustName = _childCustNameSupplier.get();

			_childCustNameSupplier = null;
		}

		return childCustName;
	}

	public void setChildCustName(String childCustName) {
		this.childCustName = childCustName;

		_childCustNameSupplier = null;
	}

	@JsonIgnore
	public void setChildCustName(
		UnsafeSupplier<String, Exception> childCustNameUnsafeSupplier) {

		_childCustNameSupplier = () -> {
			try {
				return childCustNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childCustName;

	@JsonIgnore
	private Supplier<String> _childCustNameSupplier;

	@Schema
	public String getChildCustSysId() {
		if (_childCustSysIdSupplier != null) {
			childCustSysId = _childCustSysIdSupplier.get();

			_childCustSysIdSupplier = null;
		}

		return childCustSysId;
	}

	public void setChildCustSysId(String childCustSysId) {
		this.childCustSysId = childCustSysId;

		_childCustSysIdSupplier = null;
	}

	@JsonIgnore
	public void setChildCustSysId(
		UnsafeSupplier<String, Exception> childCustSysIdUnsafeSupplier) {

		_childCustSysIdSupplier = () -> {
			try {
				return childCustSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childCustSysId;

	@JsonIgnore
	private Supplier<String> _childCustSysIdSupplier;

	@Schema
	public String getContractEndDate() {
		if (_contractEndDateSupplier != null) {
			contractEndDate = _contractEndDateSupplier.get();

			_contractEndDateSupplier = null;
		}

		return contractEndDate;
	}

	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;

		_contractEndDateSupplier = null;
	}

	@JsonIgnore
	public void setContractEndDate(
		UnsafeSupplier<String, Exception> contractEndDateUnsafeSupplier) {

		_contractEndDateSupplier = () -> {
			try {
				return contractEndDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String contractEndDate;

	@JsonIgnore
	private Supplier<String> _contractEndDateSupplier;

	@Schema
	public String getContractStartDate() {
		if (_contractStartDateSupplier != null) {
			contractStartDate = _contractStartDateSupplier.get();

			_contractStartDateSupplier = null;
		}

		return contractStartDate;
	}

	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;

		_contractStartDateSupplier = null;
	}

	@JsonIgnore
	public void setContractStartDate(
		UnsafeSupplier<String, Exception> contractStartDateUnsafeSupplier) {

		_contractStartDateSupplier = () -> {
			try {
				return contractStartDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String contractStartDate;

	@JsonIgnore
	private Supplier<String> _contractStartDateSupplier;

	@Schema
	public String getGoLiveDate() {
		if (_goLiveDateSupplier != null) {
			goLiveDate = _goLiveDateSupplier.get();

			_goLiveDateSupplier = null;
		}

		return goLiveDate;
	}

	public void setGoLiveDate(String goLiveDate) {
		this.goLiveDate = goLiveDate;

		_goLiveDateSupplier = null;
	}

	@JsonIgnore
	public void setGoLiveDate(
		UnsafeSupplier<String, Exception> goLiveDateUnsafeSupplier) {

		_goLiveDateSupplier = () -> {
			try {
				return goLiveDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String goLiveDate;

	@JsonIgnore
	private Supplier<String> _goLiveDateSupplier;

	@Schema
	public String getMarketPlaceId() {
		if (_marketPlaceIdSupplier != null) {
			marketPlaceId = _marketPlaceIdSupplier.get();

			_marketPlaceIdSupplier = null;
		}

		return marketPlaceId;
	}

	public void setMarketPlaceId(String marketPlaceId) {
		this.marketPlaceId = marketPlaceId;

		_marketPlaceIdSupplier = null;
	}

	@JsonIgnore
	public void setMarketPlaceId(
		UnsafeSupplier<String, Exception> marketPlaceIdUnsafeSupplier) {

		_marketPlaceIdSupplier = () -> {
			try {
				return marketPlaceIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String marketPlaceId;

	@JsonIgnore
	private Supplier<String> _marketPlaceIdSupplier;

	@Schema
	public String getMultiTierFlag() {
		if (_multiTierFlagSupplier != null) {
			multiTierFlag = _multiTierFlagSupplier.get();

			_multiTierFlagSupplier = null;
		}

		return multiTierFlag;
	}

	public void setMultiTierFlag(String multiTierFlag) {
		this.multiTierFlag = multiTierFlag;

		_multiTierFlagSupplier = null;
	}

	@JsonIgnore
	public void setMultiTierFlag(
		UnsafeSupplier<String, Exception> multiTierFlagUnsafeSupplier) {

		_multiTierFlagSupplier = () -> {
			try {
				return multiTierFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String multiTierFlag;

	@JsonIgnore
	private Supplier<String> _multiTierFlagSupplier;

	@Schema
	public String getOnboardingType() {
		if (_onboardingTypeSupplier != null) {
			onboardingType = _onboardingTypeSupplier.get();

			_onboardingTypeSupplier = null;
		}

		return onboardingType;
	}

	public void setOnboardingType(String onboardingType) {
		this.onboardingType = onboardingType;

		_onboardingTypeSupplier = null;
	}

	@JsonIgnore
	public void setOnboardingType(
		UnsafeSupplier<String, Exception> onboardingTypeUnsafeSupplier) {

		_onboardingTypeSupplier = () -> {
			try {
				return onboardingTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String onboardingType;

	@JsonIgnore
	private Supplier<String> _onboardingTypeSupplier;

	@Schema
	public String getParentLegalOrgId() {
		if (_parentLegalOrgIdSupplier != null) {
			parentLegalOrgId = _parentLegalOrgIdSupplier.get();

			_parentLegalOrgIdSupplier = null;
		}

		return parentLegalOrgId;
	}

	public void setParentLegalOrgId(String parentLegalOrgId) {
		this.parentLegalOrgId = parentLegalOrgId;

		_parentLegalOrgIdSupplier = null;
	}

	@JsonIgnore
	public void setParentLegalOrgId(
		UnsafeSupplier<String, Exception> parentLegalOrgIdUnsafeSupplier) {

		_parentLegalOrgIdSupplier = () -> {
			try {
				return parentLegalOrgIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String parentLegalOrgId;

	@JsonIgnore
	private Supplier<String> _parentLegalOrgIdSupplier;

	@Schema
	public String getServiceAccountId() {
		if (_serviceAccountIdSupplier != null) {
			serviceAccountId = _serviceAccountIdSupplier.get();

			_serviceAccountIdSupplier = null;
		}

		return serviceAccountId;
	}

	public void setServiceAccountId(String serviceAccountId) {
		this.serviceAccountId = serviceAccountId;

		_serviceAccountIdSupplier = null;
	}

	@JsonIgnore
	public void setServiceAccountId(
		UnsafeSupplier<String, Exception> serviceAccountIdUnsafeSupplier) {

		_serviceAccountIdSupplier = () -> {
			try {
				return serviceAccountIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String serviceAccountId;

	@JsonIgnore
	private Supplier<String> _serviceAccountIdSupplier;

	@Schema
	public String getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@JsonIgnore
	private Supplier<String> _statusSupplier;

	@Schema
	public String getVgeFlag() {
		if (_vgeFlagSupplier != null) {
			vgeFlag = _vgeFlagSupplier.get();

			_vgeFlagSupplier = null;
		}

		return vgeFlag;
	}

	public void setVgeFlag(String vgeFlag) {
		this.vgeFlag = vgeFlag;

		_vgeFlagSupplier = null;
	}

	@JsonIgnore
	public void setVgeFlag(
		UnsafeSupplier<String, Exception> vgeFlagUnsafeSupplier) {

		_vgeFlagSupplier = () -> {
			try {
				return vgeFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String vgeFlag;

	@JsonIgnore
	private Supplier<String> _vgeFlagSupplier;

	@Schema
	public String getVodafoneOpcoUsers() {
		if (_vodafoneOpcoUsersSupplier != null) {
			vodafoneOpcoUsers = _vodafoneOpcoUsersSupplier.get();

			_vodafoneOpcoUsersSupplier = null;
		}

		return vodafoneOpcoUsers;
	}

	public void setVodafoneOpcoUsers(String vodafoneOpcoUsers) {
		this.vodafoneOpcoUsers = vodafoneOpcoUsers;

		_vodafoneOpcoUsersSupplier = null;
	}

	@JsonIgnore
	public void setVodafoneOpcoUsers(
		UnsafeSupplier<String, Exception> vodafoneOpcoUsersUnsafeSupplier) {

		_vodafoneOpcoUsersSupplier = () -> {
			try {
				return vodafoneOpcoUsersUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String vodafoneOpcoUsers;

	@JsonIgnore
	private Supplier<String> _vodafoneOpcoUsersSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetChildCustomer)) {
			return false;
		}

		GetChildCustomer getChildCustomer = (GetChildCustomer)object;

		return Objects.equals(toString(), getChildCustomer.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String childAccountType = getChildAccountType();

		if (childAccountType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childAccountType\": ");

			sb.append("\"");

			sb.append(_escape(childAccountType));

			sb.append("\"");
		}

		String childCustLegalOrgId = getChildCustLegalOrgId();

		if (childCustLegalOrgId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childCustLegalOrgId\": ");

			sb.append("\"");

			sb.append(_escape(childCustLegalOrgId));

			sb.append("\"");
		}

		String childCustName = getChildCustName();

		if (childCustName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childCustName\": ");

			sb.append("\"");

			sb.append(_escape(childCustName));

			sb.append("\"");
		}

		String childCustSysId = getChildCustSysId();

		if (childCustSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childCustSysId\": ");

			sb.append("\"");

			sb.append(_escape(childCustSysId));

			sb.append("\"");
		}

		String contractEndDate = getContractEndDate();

		if (contractEndDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractEndDate\": ");

			sb.append("\"");

			sb.append(_escape(contractEndDate));

			sb.append("\"");
		}

		String contractStartDate = getContractStartDate();

		if (contractStartDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractStartDate\": ");

			sb.append("\"");

			sb.append(_escape(contractStartDate));

			sb.append("\"");
		}

		String goLiveDate = getGoLiveDate();

		if (goLiveDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"goLiveDate\": ");

			sb.append("\"");

			sb.append(_escape(goLiveDate));

			sb.append("\"");
		}

		String marketPlaceId = getMarketPlaceId();

		if (marketPlaceId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"marketPlaceId\": ");

			sb.append("\"");

			sb.append(_escape(marketPlaceId));

			sb.append("\"");
		}

		String multiTierFlag = getMultiTierFlag();

		if (multiTierFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"multiTierFlag\": ");

			sb.append("\"");

			sb.append(_escape(multiTierFlag));

			sb.append("\"");
		}

		String onboardingType = getOnboardingType();

		if (onboardingType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"onboardingType\": ");

			sb.append("\"");

			sb.append(_escape(onboardingType));

			sb.append("\"");
		}

		String parentLegalOrgId = getParentLegalOrgId();

		if (parentLegalOrgId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"parentLegalOrgId\": ");

			sb.append("\"");

			sb.append(_escape(parentLegalOrgId));

			sb.append("\"");
		}

		String serviceAccountId = getServiceAccountId();

		if (serviceAccountId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"serviceAccountId\": ");

			sb.append("\"");

			sb.append(_escape(serviceAccountId));

			sb.append("\"");
		}

		String status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		String vgeFlag = getVgeFlag();

		if (vgeFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"vgeFlag\": ");

			sb.append("\"");

			sb.append(_escape(vgeFlag));

			sb.append("\"");
		}

		String vodafoneOpcoUsers = getVodafoneOpcoUsers();

		if (vodafoneOpcoUsers != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"vodafoneOpcoUsers\": ");

			sb.append("\"");

			sb.append(_escape(vodafoneOpcoUsers));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.genericInventory.dto.v1_0.GetChildCustomer",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}