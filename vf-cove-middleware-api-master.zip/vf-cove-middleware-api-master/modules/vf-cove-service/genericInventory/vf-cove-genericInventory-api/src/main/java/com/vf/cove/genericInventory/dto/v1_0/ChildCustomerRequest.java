package com.vf.cove.genericInventory.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Ravi Rajamani
 * @generated
 */
@Generated("")
@GraphQLName("ChildCustomerRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ChildCustomerRequest")
public class ChildCustomerRequest implements Serializable {

	public static ChildCustomerRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(ChildCustomerRequest.class, json);
	}

	public static ChildCustomerRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			ChildCustomerRequest.class, json);
	}

	@Schema
	public String getBusinessServiceId() {
		if (_businessServiceIdSupplier != null) {
			businessServiceId = _businessServiceIdSupplier.get();

			_businessServiceIdSupplier = null;
		}

		return businessServiceId;
	}

	public void setBusinessServiceId(String businessServiceId) {
		this.businessServiceId = businessServiceId;

		_businessServiceIdSupplier = null;
	}

	@JsonIgnore
	public void setBusinessServiceId(
		UnsafeSupplier<String, Exception> businessServiceIdUnsafeSupplier) {

		_businessServiceIdSupplier = () -> {
			try {
				return businessServiceIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessServiceId;

	@JsonIgnore
	private Supplier<String> _businessServiceIdSupplier;

	@Schema
	public String getCapability() {
		if (_capabilitySupplier != null) {
			capability = _capabilitySupplier.get();

			_capabilitySupplier = null;
		}

		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;

		_capabilitySupplier = null;
	}

	@JsonIgnore
	public void setCapability(
		UnsafeSupplier<String, Exception> capabilityUnsafeSupplier) {

		_capabilitySupplier = () -> {
			try {
				return capabilityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String capability;

	@JsonIgnore
	private Supplier<String> _capabilitySupplier;

	@Schema
	public String getCatalogueItemSysID() {
		if (_catalogueItemSysIDSupplier != null) {
			catalogueItemSysID = _catalogueItemSysIDSupplier.get();

			_catalogueItemSysIDSupplier = null;
		}

		return catalogueItemSysID;
	}

	public void setCatalogueItemSysID(String catalogueItemSysID) {
		this.catalogueItemSysID = catalogueItemSysID;

		_catalogueItemSysIDSupplier = null;
	}

	@JsonIgnore
	public void setCatalogueItemSysID(
		UnsafeSupplier<String, Exception> catalogueItemSysIDUnsafeSupplier) {

		_catalogueItemSysIDSupplier = () -> {
			try {
				return catalogueItemSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String catalogueItemSysID;

	@JsonIgnore
	private Supplier<String> _catalogueItemSysIDSupplier;

	@Schema
	public String getFromDate() {
		if (_fromDateSupplier != null) {
			fromDate = _fromDateSupplier.get();

			_fromDateSupplier = null;
		}

		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;

		_fromDateSupplier = null;
	}

	@JsonIgnore
	public void setFromDate(
		UnsafeSupplier<String, Exception> fromDateUnsafeSupplier) {

		_fromDateSupplier = () -> {
			try {
				return fromDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fromDate;

	@JsonIgnore
	private Supplier<String> _fromDateSupplier;

	@Schema
	public String getOnboardingType() {
		if (_onboardingTypeSupplier != null) {
			onboardingType = _onboardingTypeSupplier.get();

			_onboardingTypeSupplier = null;
		}

		return onboardingType;
	}

	public void setOnboardingType(String onboardingType) {
		this.onboardingType = onboardingType;

		_onboardingTypeSupplier = null;
	}

	@JsonIgnore
	public void setOnboardingType(
		UnsafeSupplier<String, Exception> onboardingTypeUnsafeSupplier) {

		_onboardingTypeSupplier = () -> {
			try {
				return onboardingTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String onboardingType;

	@JsonIgnore
	private Supplier<String> _onboardingTypeSupplier;

	@Schema(example = "0")
	public Integer getPageIndex() {
		if (_pageIndexSupplier != null) {
			pageIndex = _pageIndexSupplier.get();

			_pageIndexSupplier = null;
		}

		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;

		_pageIndexSupplier = null;
	}

	@JsonIgnore
	public void setPageIndex(
		UnsafeSupplier<Integer, Exception> pageIndexUnsafeSupplier) {

		_pageIndexSupplier = () -> {
			try {
				return pageIndexUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer pageIndex;

	@JsonIgnore
	private Supplier<Integer> _pageIndexSupplier;

	@Schema(example = "20")
	public Integer getRecordsPerPage() {
		if (_recordsPerPageSupplier != null) {
			recordsPerPage = _recordsPerPageSupplier.get();

			_recordsPerPageSupplier = null;
		}

		return recordsPerPage;
	}

	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;

		_recordsPerPageSupplier = null;
	}

	@JsonIgnore
	public void setRecordsPerPage(
		UnsafeSupplier<Integer, Exception> recordsPerPageUnsafeSupplier) {

		_recordsPerPageSupplier = () -> {
			try {
				return recordsPerPageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer recordsPerPage;

	@JsonIgnore
	private Supplier<Integer> _recordsPerPageSupplier;

	@Schema
	public String getSearchType() {
		if (_searchTypeSupplier != null) {
			searchType = _searchTypeSupplier.get();

			_searchTypeSupplier = null;
		}

		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;

		_searchTypeSupplier = null;
	}

	@JsonIgnore
	public void setSearchType(
		UnsafeSupplier<String, Exception> searchTypeUnsafeSupplier) {

		_searchTypeSupplier = () -> {
			try {
				return searchTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchType;

	@JsonIgnore
	private Supplier<String> _searchTypeSupplier;

	@Schema
	public String getSearchValue() {
		if (_searchValueSupplier != null) {
			searchValue = _searchValueSupplier.get();

			_searchValueSupplier = null;
		}

		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;

		_searchValueSupplier = null;
	}

	@JsonIgnore
	public void setSearchValue(
		UnsafeSupplier<String, Exception> searchValueUnsafeSupplier) {

		_searchValueSupplier = () -> {
			try {
				return searchValueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchValue;

	@JsonIgnore
	private Supplier<String> _searchValueSupplier;

	@Schema
	@Valid
	public SortOrder[] getSortOrder() {
		if (_sortOrderSupplier != null) {
			sortOrder = _sortOrderSupplier.get();

			_sortOrderSupplier = null;
		}

		return sortOrder;
	}

	public void setSortOrder(SortOrder[] sortOrder) {
		this.sortOrder = sortOrder;

		_sortOrderSupplier = null;
	}

	@JsonIgnore
	public void setSortOrder(
		UnsafeSupplier<SortOrder[], Exception> sortOrderUnsafeSupplier) {

		_sortOrderSupplier = () -> {
			try {
				return sortOrderUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected SortOrder[] sortOrder;

	@JsonIgnore
	private Supplier<SortOrder[]> _sortOrderSupplier;

	@Schema
	public String[] getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String[] status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String[], Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] status;

	@JsonIgnore
	private Supplier<String[]> _statusSupplier;

	@Schema
	public String getToDate() {
		if (_toDateSupplier != null) {
			toDate = _toDateSupplier.get();

			_toDateSupplier = null;
		}

		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;

		_toDateSupplier = null;
	}

	@JsonIgnore
	public void setToDate(
		UnsafeSupplier<String, Exception> toDateUnsafeSupplier) {

		_toDateSupplier = () -> {
			try {
				return toDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String toDate;

	@JsonIgnore
	private Supplier<String> _toDateSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ChildCustomerRequest)) {
			return false;
		}

		ChildCustomerRequest childCustomerRequest =
			(ChildCustomerRequest)object;

		return Objects.equals(toString(), childCustomerRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String businessServiceId = getBusinessServiceId();

		if (businessServiceId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessServiceId\": ");

			sb.append("\"");

			sb.append(_escape(businessServiceId));

			sb.append("\"");
		}

		String capability = getCapability();

		if (capability != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"capability\": ");

			sb.append("\"");

			sb.append(_escape(capability));

			sb.append("\"");
		}

		String catalogueItemSysID = getCatalogueItemSysID();

		if (catalogueItemSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"catalogueItemSysID\": ");

			sb.append("\"");

			sb.append(_escape(catalogueItemSysID));

			sb.append("\"");
		}

		String fromDate = getFromDate();

		if (fromDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fromDate\": ");

			sb.append("\"");

			sb.append(_escape(fromDate));

			sb.append("\"");
		}

		String onboardingType = getOnboardingType();

		if (onboardingType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"onboardingType\": ");

			sb.append("\"");

			sb.append(_escape(onboardingType));

			sb.append("\"");
		}

		Integer pageIndex = getPageIndex();

		if (pageIndex != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"pageIndex\": ");

			sb.append(pageIndex);
		}

		Integer recordsPerPage = getRecordsPerPage();

		if (recordsPerPage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"recordsPerPage\": ");

			sb.append(recordsPerPage);
		}

		String searchType = getSearchType();

		if (searchType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchType\": ");

			sb.append("\"");

			sb.append(_escape(searchType));

			sb.append("\"");
		}

		String searchValue = getSearchValue();

		if (searchValue != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchValue\": ");

			sb.append("\"");

			sb.append(_escape(searchValue));

			sb.append("\"");
		}

		SortOrder[] sortOrder = getSortOrder();

		if (sortOrder != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sortOrder\": ");

			sb.append("[");

			for (int i = 0; i < sortOrder.length; i++) {
				sb.append(String.valueOf(sortOrder[i]));

				if ((i + 1) < sortOrder.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("[");

			for (int i = 0; i < status.length; i++) {
				sb.append("\"");

				sb.append(_escape(status[i]));

				sb.append("\"");

				if ((i + 1) < status.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String toDate = getToDate();

		if (toDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"toDate\": ");

			sb.append("\"");

			sb.append(_escape(toDate));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.genericInventory.dto.v1_0.ChildCustomerRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}