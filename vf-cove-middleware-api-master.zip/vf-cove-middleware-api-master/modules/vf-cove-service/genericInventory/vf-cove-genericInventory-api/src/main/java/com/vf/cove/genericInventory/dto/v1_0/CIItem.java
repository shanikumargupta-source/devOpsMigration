package com.vf.cove.genericInventory.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Ravi Rajamani
 * @generated
 */
@Generated("")
@GraphQLName("CIItem")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CIItem")
public class CIItem implements Serializable {

	public static CIItem toDTO(String json) {
		return ObjectMapperUtil.readValue(CIItem.class, json);
	}

	public static CIItem unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CIItem.class, json);
	}

	@Schema(example = "")
	public String getCmdbType() {
		if (_CmdbTypeSupplier != null) {
			CmdbType = _CmdbTypeSupplier.get();

			_CmdbTypeSupplier = null;
		}

		return CmdbType;
	}

	public void setCmdbType(String CmdbType) {
		this.CmdbType = CmdbType;

		_CmdbTypeSupplier = null;
	}

	@JsonIgnore
	public void setCmdbType(
		UnsafeSupplier<String, Exception> CmdbTypeUnsafeSupplier) {

		_CmdbTypeSupplier = () -> {
			try {
				return CmdbTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String CmdbType;

	@JsonIgnore
	private Supplier<String> _CmdbTypeSupplier;

	@Schema(example = "")
	public String getModelNumber() {
		if (_ModelNumberSupplier != null) {
			ModelNumber = _ModelNumberSupplier.get();

			_ModelNumberSupplier = null;
		}

		return ModelNumber;
	}

	public void setModelNumber(String ModelNumber) {
		this.ModelNumber = ModelNumber;

		_ModelNumberSupplier = null;
	}

	@JsonIgnore
	public void setModelNumber(
		UnsafeSupplier<String, Exception> ModelNumberUnsafeSupplier) {

		_ModelNumberSupplier = () -> {
			try {
				return ModelNumberUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ModelNumber;

	@JsonIgnore
	private Supplier<String> _ModelNumberSupplier;

	@Schema(example = "")
	public String getSerialNumber() {
		if (_SerialNumberSupplier != null) {
			SerialNumber = _SerialNumberSupplier.get();

			_SerialNumberSupplier = null;
		}

		return SerialNumber;
	}

	public void setSerialNumber(String SerialNumber) {
		this.SerialNumber = SerialNumber;

		_SerialNumberSupplier = null;
	}

	@JsonIgnore
	public void setSerialNumber(
		UnsafeSupplier<String, Exception> SerialNumberUnsafeSupplier) {

		_SerialNumberSupplier = () -> {
			try {
				return SerialNumberUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String SerialNumber;

	@JsonIgnore
	private Supplier<String> _SerialNumberSupplier;

	@Schema(example = "")
	public String getBusinessServicesId() {
		if (_businessServicesIdSupplier != null) {
			businessServicesId = _businessServicesIdSupplier.get();

			_businessServicesIdSupplier = null;
		}

		return businessServicesId;
	}

	public void setBusinessServicesId(String businessServicesId) {
		this.businessServicesId = businessServicesId;

		_businessServicesIdSupplier = null;
	}

	@JsonIgnore
	public void setBusinessServicesId(
		UnsafeSupplier<String, Exception> businessServicesIdUnsafeSupplier) {

		_businessServicesIdSupplier = () -> {
			try {
				return businessServicesIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessServicesId;

	@JsonIgnore
	private Supplier<String> _businessServicesIdSupplier;

	@Schema(example = "")
	public String getBusinessServicesName() {
		if (_businessServicesNameSupplier != null) {
			businessServicesName = _businessServicesNameSupplier.get();

			_businessServicesNameSupplier = null;
		}

		return businessServicesName;
	}

	public void setBusinessServicesName(String businessServicesName) {
		this.businessServicesName = businessServicesName;

		_businessServicesNameSupplier = null;
	}

	@JsonIgnore
	public void setBusinessServicesName(
		UnsafeSupplier<String, Exception> businessServicesNameUnsafeSupplier) {

		_businessServicesNameSupplier = () -> {
			try {
				return businessServicesNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessServicesName;

	@JsonIgnore
	private Supplier<String> _businessServicesNameSupplier;

	@Schema(example = "")
	public String getCiClass() {
		if (_ciClassSupplier != null) {
			ciClass = _ciClassSupplier.get();

			_ciClassSupplier = null;
		}

		return ciClass;
	}

	public void setCiClass(String ciClass) {
		this.ciClass = ciClass;

		_ciClassSupplier = null;
	}

	@JsonIgnore
	public void setCiClass(
		UnsafeSupplier<String, Exception> ciClassUnsafeSupplier) {

		_ciClassSupplier = () -> {
			try {
				return ciClassUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciClass;

	@JsonIgnore
	private Supplier<String> _ciClassSupplier;

	@Schema(example = "")
	public String getCiDescription() {
		if (_ciDescriptionSupplier != null) {
			ciDescription = _ciDescriptionSupplier.get();

			_ciDescriptionSupplier = null;
		}

		return ciDescription;
	}

	public void setCiDescription(String ciDescription) {
		this.ciDescription = ciDescription;

		_ciDescriptionSupplier = null;
	}

	@JsonIgnore
	public void setCiDescription(
		UnsafeSupplier<String, Exception> ciDescriptionUnsafeSupplier) {

		_ciDescriptionSupplier = () -> {
			try {
				return ciDescriptionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciDescription;

	@JsonIgnore
	private Supplier<String> _ciDescriptionSupplier;

	@Schema(example = "")
	public String getCiId() {
		if (_ciIdSupplier != null) {
			ciId = _ciIdSupplier.get();

			_ciIdSupplier = null;
		}

		return ciId;
	}

	public void setCiId(String ciId) {
		this.ciId = ciId;

		_ciIdSupplier = null;
	}

	@JsonIgnore
	public void setCiId(UnsafeSupplier<String, Exception> ciIdUnsafeSupplier) {
		_ciIdSupplier = () -> {
			try {
				return ciIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciId;

	@JsonIgnore
	private Supplier<String> _ciIdSupplier;

	@Schema(example = "")
	public String getCiName() {
		if (_ciNameSupplier != null) {
			ciName = _ciNameSupplier.get();

			_ciNameSupplier = null;
		}

		return ciName;
	}

	public void setCiName(String ciName) {
		this.ciName = ciName;

		_ciNameSupplier = null;
	}

	@JsonIgnore
	public void setCiName(
		UnsafeSupplier<String, Exception> ciNameUnsafeSupplier) {

		_ciNameSupplier = () -> {
			try {
				return ciNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciName;

	@JsonIgnore
	private Supplier<String> _ciNameSupplier;

	@Schema(example = "")
	public String getCiStatus() {
		if (_ciStatusSupplier != null) {
			ciStatus = _ciStatusSupplier.get();

			_ciStatusSupplier = null;
		}

		return ciStatus;
	}

	public void setCiStatus(String ciStatus) {
		this.ciStatus = ciStatus;

		_ciStatusSupplier = null;
	}

	@JsonIgnore
	public void setCiStatus(
		UnsafeSupplier<String, Exception> ciStatusUnsafeSupplier) {

		_ciStatusSupplier = () -> {
			try {
				return ciStatusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciStatus;

	@JsonIgnore
	private Supplier<String> _ciStatusSupplier;

	@Schema(example = "")
	public String getContractEndDate() {
		if (_contractEndDateSupplier != null) {
			contractEndDate = _contractEndDateSupplier.get();

			_contractEndDateSupplier = null;
		}

		return contractEndDate;
	}

	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;

		_contractEndDateSupplier = null;
	}

	@JsonIgnore
	public void setContractEndDate(
		UnsafeSupplier<String, Exception> contractEndDateUnsafeSupplier) {

		_contractEndDateSupplier = () -> {
			try {
				return contractEndDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String contractEndDate;

	@JsonIgnore
	private Supplier<String> _contractEndDateSupplier;

	@Schema(example = "")
	public String getCustomerFriendlyName() {
		if (_customerFriendlyNameSupplier != null) {
			customerFriendlyName = _customerFriendlyNameSupplier.get();

			_customerFriendlyNameSupplier = null;
		}

		return customerFriendlyName;
	}

	public void setCustomerFriendlyName(String customerFriendlyName) {
		this.customerFriendlyName = customerFriendlyName;

		_customerFriendlyNameSupplier = null;
	}

	@JsonIgnore
	public void setCustomerFriendlyName(
		UnsafeSupplier<String, Exception> customerFriendlyNameUnsafeSupplier) {

		_customerFriendlyNameSupplier = () -> {
			try {
				return customerFriendlyNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerFriendlyName;

	@JsonIgnore
	private Supplier<String> _customerFriendlyNameSupplier;

	@Schema(example = "")
	public String getCustomerFriendlyNameRequired() {
		if (_customerFriendlyNameRequiredSupplier != null) {
			customerFriendlyNameRequired =
				_customerFriendlyNameRequiredSupplier.get();

			_customerFriendlyNameRequiredSupplier = null;
		}

		return customerFriendlyNameRequired;
	}

	public void setCustomerFriendlyNameRequired(
		String customerFriendlyNameRequired) {

		this.customerFriendlyNameRequired = customerFriendlyNameRequired;

		_customerFriendlyNameRequiredSupplier = null;
	}

	@JsonIgnore
	public void setCustomerFriendlyNameRequired(
		UnsafeSupplier<String, Exception>
			customerFriendlyNameRequiredUnsafeSupplier) {

		_customerFriendlyNameRequiredSupplier = () -> {
			try {
				return customerFriendlyNameRequiredUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerFriendlyNameRequired;

	@JsonIgnore
	private Supplier<String> _customerFriendlyNameRequiredSupplier;

	@Schema(example = "")
	public String getDlmId() {
		if (_dlmIdSupplier != null) {
			dlmId = _dlmIdSupplier.get();

			_dlmIdSupplier = null;
		}

		return dlmId;
	}

	public void setDlmId(String dlmId) {
		this.dlmId = dlmId;

		_dlmIdSupplier = null;
	}

	@JsonIgnore
	public void setDlmId(
		UnsafeSupplier<String, Exception> dlmIdUnsafeSupplier) {

		_dlmIdSupplier = () -> {
			try {
				return dlmIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dlmId;

	@JsonIgnore
	private Supplier<String> _dlmIdSupplier;

	@Schema(example = "")
	public String getGscategory() {
		if (_gscategorySupplier != null) {
			gscategory = _gscategorySupplier.get();

			_gscategorySupplier = null;
		}

		return gscategory;
	}

	public void setGscategory(String gscategory) {
		this.gscategory = gscategory;

		_gscategorySupplier = null;
	}

	@JsonIgnore
	public void setGscategory(
		UnsafeSupplier<String, Exception> gscategoryUnsafeSupplier) {

		_gscategorySupplier = () -> {
			try {
				return gscategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String gscategory;

	@JsonIgnore
	private Supplier<String> _gscategorySupplier;

	@Schema(example = "")
	public String getLocation() {
		if (_locationSupplier != null) {
			location = _locationSupplier.get();

			_locationSupplier = null;
		}

		return location;
	}

	public void setLocation(String location) {
		this.location = location;

		_locationSupplier = null;
	}

	@JsonIgnore
	public void setLocation(
		UnsafeSupplier<String, Exception> locationUnsafeSupplier) {

		_locationSupplier = () -> {
			try {
				return locationUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String location;

	@JsonIgnore
	private Supplier<String> _locationSupplier;

	@Schema(example = "")
	public String getMsisdn() {
		if (_msisdnSupplier != null) {
			msisdn = _msisdnSupplier.get();

			_msisdnSupplier = null;
		}

		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;

		_msisdnSupplier = null;
	}

	@JsonIgnore
	public void setMsisdn(
		UnsafeSupplier<String, Exception> msisdnUnsafeSupplier) {

		_msisdnSupplier = () -> {
			try {
				return msisdnUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String msisdn;

	@JsonIgnore
	private Supplier<String> _msisdnSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CIItem)) {
			return false;
		}

		CIItem ciItem = (CIItem)object;

		return Objects.equals(toString(), ciItem.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String CmdbType = getCmdbType();

		if (CmdbType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"CmdbType\": ");

			sb.append("\"");

			sb.append(_escape(CmdbType));

			sb.append("\"");
		}

		String ModelNumber = getModelNumber();

		if (ModelNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ModelNumber\": ");

			sb.append("\"");

			sb.append(_escape(ModelNumber));

			sb.append("\"");
		}

		String SerialNumber = getSerialNumber();

		if (SerialNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"SerialNumber\": ");

			sb.append("\"");

			sb.append(_escape(SerialNumber));

			sb.append("\"");
		}

		String businessServicesId = getBusinessServicesId();

		if (businessServicesId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessServicesId\": ");

			sb.append("\"");

			sb.append(_escape(businessServicesId));

			sb.append("\"");
		}

		String businessServicesName = getBusinessServicesName();

		if (businessServicesName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessServicesName\": ");

			sb.append("\"");

			sb.append(_escape(businessServicesName));

			sb.append("\"");
		}

		String ciClass = getCiClass();

		if (ciClass != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciClass\": ");

			sb.append("\"");

			sb.append(_escape(ciClass));

			sb.append("\"");
		}

		String ciDescription = getCiDescription();

		if (ciDescription != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciDescription\": ");

			sb.append("\"");

			sb.append(_escape(ciDescription));

			sb.append("\"");
		}

		String ciId = getCiId();

		if (ciId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciId\": ");

			sb.append("\"");

			sb.append(_escape(ciId));

			sb.append("\"");
		}

		String ciName = getCiName();

		if (ciName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciName\": ");

			sb.append("\"");

			sb.append(_escape(ciName));

			sb.append("\"");
		}

		String ciStatus = getCiStatus();

		if (ciStatus != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciStatus\": ");

			sb.append("\"");

			sb.append(_escape(ciStatus));

			sb.append("\"");
		}

		String contractEndDate = getContractEndDate();

		if (contractEndDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractEndDate\": ");

			sb.append("\"");

			sb.append(_escape(contractEndDate));

			sb.append("\"");
		}

		String customerFriendlyName = getCustomerFriendlyName();

		if (customerFriendlyName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerFriendlyName\": ");

			sb.append("\"");

			sb.append(_escape(customerFriendlyName));

			sb.append("\"");
		}

		String customerFriendlyNameRequired = getCustomerFriendlyNameRequired();

		if (customerFriendlyNameRequired != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerFriendlyNameRequired\": ");

			sb.append("\"");

			sb.append(_escape(customerFriendlyNameRequired));

			sb.append("\"");
		}

		String dlmId = getDlmId();

		if (dlmId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dlmId\": ");

			sb.append("\"");

			sb.append(_escape(dlmId));

			sb.append("\"");
		}

		String gscategory = getGscategory();

		if (gscategory != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"gscategory\": ");

			sb.append("\"");

			sb.append(_escape(gscategory));

			sb.append("\"");
		}

		String location = getLocation();

		if (location != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"location\": ");

			sb.append("\"");

			sb.append(_escape(location));

			sb.append("\"");
		}

		String msisdn = getMsisdn();

		if (msisdn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"msisdn\": ");

			sb.append("\"");

			sb.append(_escape(msisdn));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.genericInventory.dto.v1_0.CIItem",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}