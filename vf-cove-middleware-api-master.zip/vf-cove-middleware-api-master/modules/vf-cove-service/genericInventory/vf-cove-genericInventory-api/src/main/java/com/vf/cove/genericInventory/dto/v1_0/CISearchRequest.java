package com.vf.cove.genericInventory.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Ravi Rajamani
 * @generated
 */
@Generated("")
@GraphQLName("CISearchRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CISearchRequest")
public class CISearchRequest implements Serializable {

	public static CISearchRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(CISearchRequest.class, json);
	}

	public static CISearchRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CISearchRequest.class, json);
	}

	@Schema
	public String getCategory() {
		if (_CategorySupplier != null) {
			Category = _CategorySupplier.get();

			_CategorySupplier = null;
		}

		return Category;
	}

	public void setCategory(String Category) {
		this.Category = Category;

		_CategorySupplier = null;
	}

	@JsonIgnore
	public void setCategory(
		UnsafeSupplier<String, Exception> CategoryUnsafeSupplier) {

		_CategorySupplier = () -> {
			try {
				return CategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String Category;

	@JsonIgnore
	private Supplier<String> _CategorySupplier;

	@Schema
	public String getChildCustomerId() {
		if (_childCustomerIdSupplier != null) {
			childCustomerId = _childCustomerIdSupplier.get();

			_childCustomerIdSupplier = null;
		}

		return childCustomerId;
	}

	public void setChildCustomerId(String childCustomerId) {
		this.childCustomerId = childCustomerId;

		_childCustomerIdSupplier = null;
	}

	@JsonIgnore
	public void setChildCustomerId(
		UnsafeSupplier<String, Exception> childCustomerIdUnsafeSupplier) {

		_childCustomerIdSupplier = () -> {
			try {
				return childCustomerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childCustomerId;

	@JsonIgnore
	private Supplier<String> _childCustomerIdSupplier;

	@Schema
	public String getCurrentDate() {
		if (_currentDateSupplier != null) {
			currentDate = _currentDateSupplier.get();

			_currentDateSupplier = null;
		}

		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;

		_currentDateSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDate(
		UnsafeSupplier<String, Exception> currentDateUnsafeSupplier) {

		_currentDateSupplier = () -> {
			try {
				return currentDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentDate;

	@JsonIgnore
	private Supplier<String> _currentDateSupplier;

	@Schema
	public String getCustomerId() {
		if (_customerIdSupplier != null) {
			customerId = _customerIdSupplier.get();

			_customerIdSupplier = null;
		}

		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;

		_customerIdSupplier = null;
	}

	@JsonIgnore
	public void setCustomerId(
		UnsafeSupplier<String, Exception> customerIdUnsafeSupplier) {

		_customerIdSupplier = () -> {
			try {
				return customerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerId;

	@JsonIgnore
	private Supplier<String> _customerIdSupplier;

	@Schema
	public String getJourneyType() {
		if (_journeyTypeSupplier != null) {
			journeyType = _journeyTypeSupplier.get();

			_journeyTypeSupplier = null;
		}

		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;

		_journeyTypeSupplier = null;
	}

	@JsonIgnore
	public void setJourneyType(
		UnsafeSupplier<String, Exception> journeyTypeUnsafeSupplier) {

		_journeyTypeSupplier = () -> {
			try {
				return journeyTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String journeyType;

	@JsonIgnore
	private Supplier<String> _journeyTypeSupplier;

	@Schema
	public String getMessageId() {
		if (_messageIdSupplier != null) {
			messageId = _messageIdSupplier.get();

			_messageIdSupplier = null;
		}

		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;

		_messageIdSupplier = null;
	}

	@JsonIgnore
	public void setMessageId(
		UnsafeSupplier<String, Exception> messageIdUnsafeSupplier) {

		_messageIdSupplier = () -> {
			try {
				return messageIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String messageId;

	@JsonIgnore
	private Supplier<String> _messageIdSupplier;

	@Schema
	public String getOamuserId() {
		if (_oamuserIdSupplier != null) {
			oamuserId = _oamuserIdSupplier.get();

			_oamuserIdSupplier = null;
		}

		return oamuserId;
	}

	public void setOamuserId(String oamuserId) {
		this.oamuserId = oamuserId;

		_oamuserIdSupplier = null;
	}

	@JsonIgnore
	public void setOamuserId(
		UnsafeSupplier<String, Exception> oamuserIdUnsafeSupplier) {

		_oamuserIdSupplier = () -> {
			try {
				return oamuserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String oamuserId;

	@JsonIgnore
	private Supplier<String> _oamuserIdSupplier;

	@Schema
	public Integer getPageIndex() {
		if (_pageIndexSupplier != null) {
			pageIndex = _pageIndexSupplier.get();

			_pageIndexSupplier = null;
		}

		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;

		_pageIndexSupplier = null;
	}

	@JsonIgnore
	public void setPageIndex(
		UnsafeSupplier<Integer, Exception> pageIndexUnsafeSupplier) {

		_pageIndexSupplier = () -> {
			try {
				return pageIndexUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer pageIndex;

	@JsonIgnore
	private Supplier<Integer> _pageIndexSupplier;

	@Schema
	public String[] getProductSysId() {
		if (_productSysIdSupplier != null) {
			productSysId = _productSysIdSupplier.get();

			_productSysIdSupplier = null;
		}

		return productSysId;
	}

	public void setProductSysId(String[] productSysId) {
		this.productSysId = productSysId;

		_productSysIdSupplier = null;
	}

	@JsonIgnore
	public void setProductSysId(
		UnsafeSupplier<String[], Exception> productSysIdUnsafeSupplier) {

		_productSysIdSupplier = () -> {
			try {
				return productSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] productSysId;

	@JsonIgnore
	private Supplier<String[]> _productSysIdSupplier;

	@Schema
	public Integer getRecordsPerPage() {
		if (_recordsPerPageSupplier != null) {
			recordsPerPage = _recordsPerPageSupplier.get();

			_recordsPerPageSupplier = null;
		}

		return recordsPerPage;
	}

	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;

		_recordsPerPageSupplier = null;
	}

	@JsonIgnore
	public void setRecordsPerPage(
		UnsafeSupplier<Integer, Exception> recordsPerPageUnsafeSupplier) {

		_recordsPerPageSupplier = () -> {
			try {
				return recordsPerPageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer recordsPerPage;

	@JsonIgnore
	private Supplier<Integer> _recordsPerPageSupplier;

	@Schema
	public String getSearchValue() {
		if (_searchValueSupplier != null) {
			searchValue = _searchValueSupplier.get();

			_searchValueSupplier = null;
		}

		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;

		_searchValueSupplier = null;
	}

	@JsonIgnore
	public void setSearchValue(
		UnsafeSupplier<String, Exception> searchValueUnsafeSupplier) {

		_searchValueSupplier = () -> {
			try {
				return searchValueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchValue;

	@JsonIgnore
	private Supplier<String> _searchValueSupplier;

	@Schema
	@Valid
	public SortOrder[] getSortOrder() {
		if (_sortOrderSupplier != null) {
			sortOrder = _sortOrderSupplier.get();

			_sortOrderSupplier = null;
		}

		return sortOrder;
	}

	public void setSortOrder(SortOrder[] sortOrder) {
		this.sortOrder = sortOrder;

		_sortOrderSupplier = null;
	}

	@JsonIgnore
	public void setSortOrder(
		UnsafeSupplier<SortOrder[], Exception> sortOrderUnsafeSupplier) {

		_sortOrderSupplier = () -> {
			try {
				return sortOrderUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected SortOrder[] sortOrder;

	@JsonIgnore
	private Supplier<SortOrder[]> _sortOrderSupplier;

	@Schema
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CISearchRequest)) {
			return false;
		}

		CISearchRequest ciSearchRequest = (CISearchRequest)object;

		return Objects.equals(toString(), ciSearchRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String Category = getCategory();

		if (Category != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Category\": ");

			sb.append("\"");

			sb.append(_escape(Category));

			sb.append("\"");
		}

		String childCustomerId = getChildCustomerId();

		if (childCustomerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childCustomerId\": ");

			sb.append("\"");

			sb.append(_escape(childCustomerId));

			sb.append("\"");
		}

		String currentDate = getCurrentDate();

		if (currentDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDate\": ");

			sb.append("\"");

			sb.append(_escape(currentDate));

			sb.append("\"");
		}

		String customerId = getCustomerId();

		if (customerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerId\": ");

			sb.append("\"");

			sb.append(_escape(customerId));

			sb.append("\"");
		}

		String journeyType = getJourneyType();

		if (journeyType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"journeyType\": ");

			sb.append("\"");

			sb.append(_escape(journeyType));

			sb.append("\"");
		}

		String messageId = getMessageId();

		if (messageId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"messageId\": ");

			sb.append("\"");

			sb.append(_escape(messageId));

			sb.append("\"");
		}

		String oamuserId = getOamuserId();

		if (oamuserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"oamuserId\": ");

			sb.append("\"");

			sb.append(_escape(oamuserId));

			sb.append("\"");
		}

		Integer pageIndex = getPageIndex();

		if (pageIndex != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"pageIndex\": ");

			sb.append(pageIndex);
		}

		String[] productSysId = getProductSysId();

		if (productSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"productSysId\": ");

			sb.append("[");

			for (int i = 0; i < productSysId.length; i++) {
				sb.append("\"");

				sb.append(_escape(productSysId[i]));

				sb.append("\"");

				if ((i + 1) < productSysId.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		Integer recordsPerPage = getRecordsPerPage();

		if (recordsPerPage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"recordsPerPage\": ");

			sb.append(recordsPerPage);
		}

		String searchValue = getSearchValue();

		if (searchValue != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchValue\": ");

			sb.append("\"");

			sb.append(_escape(searchValue));

			sb.append("\"");
		}

		SortOrder[] sortOrder = getSortOrder();

		if (sortOrder != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sortOrder\": ");

			sb.append("[");

			for (int i = 0; i < sortOrder.length; i++) {
				sb.append(String.valueOf(sortOrder[i]));

				if ((i + 1) < sortOrder.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.genericInventory.dto.v1_0.CISearchRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}