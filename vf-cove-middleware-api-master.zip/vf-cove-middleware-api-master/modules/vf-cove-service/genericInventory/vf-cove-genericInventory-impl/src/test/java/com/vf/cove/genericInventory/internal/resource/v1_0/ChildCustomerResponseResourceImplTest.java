package com.vf.cove.genericInventory.internal.resource.v1_0;

import com.liferay.expando.kernel.model.ExpandoBridge;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerRequest;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerResponse;
import com.vf.cove.genericInventory.dto.v1_0.GetChildCustomer;
import com.vf.cove.genericInventory.dto.v1_0.SortOrder;
import com.vf.cove.genericInventory.internal.constants.GenericInventoryConstants;
import com.vf.cove.genericInventory.internal.service.ChildCustomerService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ChildCustomerResponseResourceImplTest {

	@Mock
	private ChildCustomerService childCustomerService;
    @Mock
    private CoveRequestParser coveRequestParser;
	@InjectMocks
	private ChildCustomerResponseResourceImpl childCustomerResponseResource;

	private ChildCustomerResponse childCustomerResponse;

	private ChildCustomerRequest childCustomerRequest;

	@Mock
	private User contextUser;

	private List<Organization> organisationList = new ArrayList<Organization>();

	@Mock
	private Organization organization;

	@Mock
	private ExpandoBridge expandoBridge;

	@BeforeEach
	public void setUp() throws Exception {

		childCustomerResponseResource.setContextUser(contextUser);

		organisationList.add(organization);

		childCustomerRequest = new ChildCustomerRequest();
		childCustomerRequest.setBusinessServiceId("fwaefo73ro23jifg32o87r23pyr32j");
		childCustomerRequest.setCatalogueItemSysID("27ry2ur23jdo329");
		childCustomerRequest.setCapability(GenericInventoryConstants.RAISE_TICKET_CAPABILITY);
		childCustomerRequest.setFromDate("2020-12-01");
		childCustomerRequest.setToDate("2021-01-01");
		childCustomerRequest.setOnboardingType("Simple");
		childCustomerRequest.setPageIndex(1);
		childCustomerRequest.setRecordsPerPage(20);
		childCustomerRequest.setSearchValue("test");
		SortOrder[] sortOrder = new SortOrder[1];
		SortOrder sortOrderItem = new SortOrder();
		sortOrder[0] = sortOrderItem;
		childCustomerRequest.setSortOrder(sortOrder);


		childCustomerResponse = new ChildCustomerResponse();
		childCustomerResponse.setTotalcount("2");
		GetChildCustomer[] childCustomers = new GetChildCustomer[2];
		GetChildCustomer customer1 = new GetChildCustomer();
		customer1.setChildCustName("Vodafone Germany");
		customer1.setMarketPlaceId("marketplaceid123");
		childCustomers[0] = customer1;
		GetChildCustomer customer2 = new GetChildCustomer();
		customer2.setChildCustName("Vodafone UK");
		customer2.setMarketPlaceId("marketplaceid1234");
		childCustomers[1] = customer2;
		childCustomerResponse.setGetChildCustomers(childCustomers);

		when(contextUser.getEmailAddress()).thenReturn("test@liferay.com");
		when(contextUser.getOrganizations()).thenReturn(organisationList);
		when(organization.getExpandoBridge()).thenReturn(expandoBridge);
		when(expandoBridge.getAttribute(eq(Constants.LEGAL_ORG_ID))).thenReturn("123456");

	}

	@Test
	public void testPostGetChildCustomer() throws Exception {
		when(childCustomerService.postGetChildCustomer(eq(childCustomerRequest), anyString(), any(), any()))
				.thenReturn(childCustomerResponse);
		ArgumentCaptor<ChildCustomerRequest> capture = ArgumentCaptor.forClass(ChildCustomerRequest.class);
		ChildCustomerResponse childCustomerResponse = childCustomerResponseResource
				.postGetChildCustomer(childCustomerRequest);
		verify(childCustomerService).postGetChildCustomer(capture.capture(), anyString(), any(), any());
		Assertions.assertThat(capture.getValue().getPageIndex()).isEqualTo(20);
		Assertions.assertThat(childCustomerResponse.getTotalcount()).isEqualTo("2");
		Assertions.assertThat(childCustomerResponse.getGetChildCustomers()[0].getChildCustName())
				.isEqualTo("Vodafone Germany");
		Assertions.assertThat(childCustomerResponse.getGetChildCustomers()[0].getMarketPlaceId())
		.isEqualTo("marketplaceid123");
		Assertions.assertThat(capture.getValue().getStatus()[0]).isEqualTo(GenericInventoryConstants.STATUS_ACTIVE);

	}

	@Test
	public void testPostGetChildCustomerNoDataForManageCustomerCapability() throws Exception {
		String[] statusArray = new String[1];
		String status = "inactive";
		statusArray[0] = status;
		childCustomerRequest.setStatus(statusArray);
		childCustomerRequest.setCapability(GenericInventoryConstants.MANAGE_CUSTOMER_CAPABILITY);

		when(childCustomerService.postGetChildCustomer(eq(childCustomerRequest), anyString(), any(), any()))
				.thenThrow(new DataNotFoundException("No data"));

		ArgumentCaptor<ChildCustomerRequest> capture = ArgumentCaptor.forClass(ChildCustomerRequest.class);
		Assertions.assertThatThrownBy(() -> childCustomerResponseResource.postGetChildCustomer(childCustomerRequest))
				.isInstanceOf(DataNotFoundException.class);
		verify(childCustomerService).postGetChildCustomer(capture.capture(), anyString(), any(), any());
		Assertions.assertThat(capture.getValue().getPageIndex()).isEqualTo(20);
		Assertions.assertThat(capture.getValue().getStatus()[0]).isEqualTo(GenericInventoryConstants.STATUS_INACTIVE);

	}

	@Test
	public void testPostGetChildCustomerNoDataForRaiseIncCapability() throws Exception {
		String[] statusArray = new String[1];
		String status = "active";
		statusArray[0] = status;
		childCustomerRequest.setStatus(statusArray);
        when(coveRequestParser.getESBSortParam(any(),any(InputStream.class))).thenReturn("");
		when(childCustomerService.postGetChildCustomer(eq(childCustomerRequest), anyString(), any(), any()))
				.thenThrow(new DataNotFoundException("No data"));
		ArgumentCaptor<ChildCustomerRequest> capture = ArgumentCaptor.forClass(ChildCustomerRequest.class);
		try {
			childCustomerResponseResource.postGetChildCustomer(childCustomerRequest);
		} catch (DataNotFoundException dnfe) {
			fail("DataNotFoundException thrown");
		}
		verify(childCustomerService).postGetChildCustomer(capture.capture(), anyString(), any(), any());
		Assertions.assertThat(capture.getValue().getPageIndex()).isEqualTo(20);
		Assertions.assertThat(capture.getValue().getStatus()[0]).isEqualTo(GenericInventoryConstants.STATUS_ACTIVE);

	}

}
