package com.vf.cove.genericInventory.internal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.ftlutils.utils.StreamToStringUtil;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerRequest;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerResponse;
import com.vf.cove.genericInventory.internal.constants.GenericInventoryConstants;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ChildCustomerServiceTest {

	@Mock
	private RestAPIProcessor restAPIProcessor;

	@InjectMocks
	ChildCustomerService childCustomerService;

	@Mock
	private CoveResponseParser responseParser;

	private String esbSuccessResponseString;

	private CoveResponse esbSuccessResponse;

	Map<String, Object> params = new HashMap<>();

	Map<String, String> headers = new HashMap<>();

	private static final String MESSAGE_ID = "testMessageId";

    private JsonNode jsonNode;
    private ChildCustomerRequest childCustomerRequest;
    private static ObjectMapper mapper;

    @Mock
    private FtlTemplateService ftlTemplateService;
	@BeforeEach
	public void setUp() throws Exception {
        mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true);

		byte[] encoded = Files.readAllBytes(Paths.get("src/test/resources/childCustomerSuccess.json"));
		esbSuccessResponseString = new String(encoded, StandardCharsets.US_ASCII);
		esbSuccessResponse = new CoveResponse();
		esbSuccessResponse.setData(esbSuccessResponseString);
		Map<String, String> responseHeaders = new HashMap<String, String>();
		responseHeaders.put(GenericInventoryConstants.GET_CHILD_CUSTOMER_TOTALCOUNT_HEADER, "2");
		esbSuccessResponse.setHeaders(responseHeaders);
		jsonNode = mapper.readTree(new File("src/test/resources/childCustomer.json"));

		childCustomerRequest = new ChildCustomerRequest();
		childCustomerRequest.setBusinessServiceId("fwaefo73ro23jifg32o87r23pyr32j");
		childCustomerRequest.setCatalogueItemSysID("27ry2ur23jdo329");
		childCustomerRequest.setCapability("Manage customer");
		childCustomerRequest.setFromDate("2020-12-01");
		childCustomerRequest.setToDate("2021-01-01");
		childCustomerRequest.setOnboardingType("Simple");
		childCustomerRequest.setSearchValue("test");

		String[] statusArray = new String[1];
		String status = "active";
		statusArray[0] = status;
		childCustomerRequest.setStatus(statusArray);
		params.put(GenericInventoryConstants.LEGALORG_ID, "123456");
		params.put(GenericInventoryConstants.USER_ID, "test@liferay.com");
        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());

        final InputStream resourceAsStream = this.getClass().getResourceAsStream(GenericInventoryConstants.GET_CHILD_CUSTOMER_API_REQUEST_DEFINITION);
        String templateStr = StreamToStringUtil.getString(resourceAsStream);
        if (childCustomerRequest != null) {
            params.put(Constants.REQUEST_PARAM_NAME, childCustomerRequest);
        }
        when(ftlTemplateService.renderTemplate(GenericInventoryConstants.GET_CHILD_CUSTOMER_API_REQUEST_DEFINITION, templateStr, params)).thenReturn("resourceAsStream");
    }

	@Test
	public void getChildCustomerSuccessResponse() throws Exception {
		childCustomerRequest.setPageIndex(0);
		childCustomerRequest.setRecordsPerPage(20);
		params.put(GenericInventoryConstants.SORTING_PARAM, "test");

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbSuccessResponse);

		when(responseParser.parse(any(InputStream.class), eq(esbSuccessResponse.getData()))).thenReturn(jsonNode);
        when(responseParser.getCoveMapper()).thenReturn(mapper);
		ChildCustomerResponse chResponsse = childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID,
				params, headers);
		Assertions.assertThat(chResponsse.getTotalcount()).isEqualTo("2");
		Assertions.assertThat(chResponsse.getGetChildCustomers()[0].getChildCustName()).isEqualTo("Child customer one");
		Assertions.assertThat(chResponsse.getGetChildCustomers()[0].getMarketPlaceId()).isEqualTo("marketplaceid123");
	}

    @Test
    public void getChildCustomerNoPagination() throws Exception {
        params.put(GenericInventoryConstants.SORTING_PARAM, "test");
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbSuccessResponse);
        when(responseParser.parse(any(InputStream.class), eq(esbSuccessResponse.getData()))).thenReturn(jsonNode);
        when(responseParser.getCoveMapper()).thenReturn(mapper);
        ChildCustomerResponse chResponsse = childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID,
            params, headers);
        Assertions.assertThat(chResponsse.getTotalcount()).isEqualTo("2");
        Assertions.assertThat(chResponsse.getGetChildCustomers()[0].getChildCustName()).isEqualTo("Child customer one");
    }

	@Test
	public void getChildCustomerNoPaginationAndSortOrder() throws Exception {

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbSuccessResponse);

		when(responseParser.parse(any(InputStream.class), eq(esbSuccessResponse.getData()))).thenReturn(jsonNode);
        when(responseParser.getCoveMapper()).thenReturn(mapper);
		ChildCustomerResponse chResponsse = childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID,
				params, headers);
		Assertions.assertThat(chResponsse.getTotalcount()).isEqualTo("2");
		Assertions.assertThat(chResponsse.getGetChildCustomers()[0].getChildCustName()).isEqualTo("Child customer one");
	}

	@Test
	public void getChildCustomerNoSortOrder() throws Exception {
		childCustomerRequest.setPageIndex(0);
		childCustomerRequest.setRecordsPerPage(20);

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbSuccessResponse);

		when(responseParser.parse(any(InputStream.class), eq(esbSuccessResponse.getData()))).thenReturn(jsonNode);
        when(responseParser.getCoveMapper()).thenReturn(mapper);
		ChildCustomerResponse chResponsse = childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID,
				params, headers);
		Assertions.assertThat(chResponsse.getTotalcount()).isEqualTo("2");
		Assertions.assertThat(chResponsse.getGetChildCustomers()[0].getChildCustName()).isEqualTo("Child customer one");
	}

	@Test
	public void getChildCustomerStatus() throws Exception {
		childCustomerRequest.setPageIndex(0);
		childCustomerRequest.setRecordsPerPage(20);
		params.put(GenericInventoryConstants.SORTING_PARAM, "test");

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbSuccessResponse);

		when(responseParser.parse(any(InputStream.class), eq(esbSuccessResponse.getData()))).thenReturn(jsonNode);
        when(responseParser.getCoveMapper()).thenReturn(mapper);
		ChildCustomerResponse chResponsse = childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID,
				params, headers);
		Assertions.assertThat(chResponsse.getGetChildCustomers()[0].getStatus()).isEqualTo("active");
		Assertions.assertThat(chResponsse.getGetChildCustomers()[1].getStatus()).isEqualTo("inactive");
	}

	@Test
	public void getChildCustomerEmptyResponse() throws Exception {
		childCustomerRequest.setPageIndex(0);
		childCustomerRequest.setRecordsPerPage(20);
		params.put(GenericInventoryConstants.SORTING_PARAM, "test");

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(null);
		Assertions.assertThatThrownBy(
				() -> childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID, params, headers))
				.isInstanceOf(ServiceException.class);
	}

	@Test
	public void getChildCustomerFailureResponse() throws Exception {
		childCustomerRequest.setPageIndex(0);
		childCustomerRequest.setRecordsPerPage(20);
		params.put(GenericInventoryConstants.SORTING_PARAM, "test");

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenThrow(new ServiceException("Test service exception"));

		Assertions.assertThatThrownBy(
				() -> childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID, params, headers))
				.isInstanceOf(ServiceException.class);
	}

	@Test
	public void getChildCustomerDataNotFoundResponse() throws Exception {
		childCustomerRequest.setPageIndex(0);
		childCustomerRequest.setRecordsPerPage(20);
		params.put(GenericInventoryConstants.SORTING_PARAM, "test");
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenThrow(new DataNotFoundException("Test data not found exception"));
		Assertions.assertThatThrownBy(
				() -> childCustomerService.postGetChildCustomer(childCustomerRequest, MESSAGE_ID, params, headers))
				.isInstanceOf(DataNotFoundException.class);
	}

}
