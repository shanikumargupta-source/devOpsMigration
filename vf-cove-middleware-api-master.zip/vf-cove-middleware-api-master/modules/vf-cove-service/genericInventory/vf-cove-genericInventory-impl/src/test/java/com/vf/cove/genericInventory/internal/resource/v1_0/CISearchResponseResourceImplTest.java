package com.vf.cove.genericInventory.internal.resource.v1_0;

import com.liferay.portal.kernel.model.User;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.genericInventory.dto.v1_0.CIItem;
import com.vf.cove.genericInventory.dto.v1_0.CISearchRequest;
import com.vf.cove.genericInventory.dto.v1_0.CISearchResponse;
import com.vf.cove.genericInventory.internal.service.GetCISearchService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CISearchResponseResourceImplTest {

	@Mock
	private GetCISearchService getCISearchService;

	@InjectMocks
	private CISearchResponseResourceImpl ciSearchResponseResource;

	private CISearchResponse ciSearchResponse;

	private CISearchRequest ciSearchRequest;

	@Mock
	private User contextUser;

	@BeforeEach
	public void setUp() throws Exception {
		ciSearchRequest = new CISearchRequest();

		ciSearchResponseResource.setContextUser(contextUser);

		ciSearchResponse = new CISearchResponse();
		ciSearchResponse.setTotalCount(2);
		CIItem[] ciItems = new CIItem[2];
		CIItem ciItem1 = new CIItem();
		ciItem1.setCiName("TestCI1");
		ciItems[0] = ciItem1;
		CIItem ciItem2 = new CIItem();
		ciItem2.setCiName("TestCI2");
		ciItems[1] = ciItem2;
		ciSearchResponse.setCIItem(ciItems);
	}

	@Test
	public void testPostGetChildCustomer() throws Exception {
		ciSearchRequest.setSearchValue("test");
		when(getCISearchService.postGetCISearchService(eq(ciSearchRequest), eq(contextUser)))
				.thenReturn(ciSearchResponse);
		Assertions.assertThat(ciSearchResponseResource.postCiSearch(ciSearchRequest).getTotalCount().intValue())
				.isEqualTo(2);
		Assertions.assertThat(ciSearchResponseResource.postCiSearch(ciSearchRequest).getCIItem()[0].getCiName())
				.isEqualTo("TestCI1");
	}

	@Test
	public void testPostGetChildCustomerValidation() throws Exception {
		Assertions.assertThatThrownBy(() -> ciSearchResponseResource.postCiSearch(ciSearchRequest))
				.isInstanceOf(ValidationException.class);
	}
}
