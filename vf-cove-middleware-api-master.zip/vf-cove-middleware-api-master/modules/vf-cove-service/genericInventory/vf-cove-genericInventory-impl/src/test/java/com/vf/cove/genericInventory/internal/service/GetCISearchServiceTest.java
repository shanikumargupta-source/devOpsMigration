package com.vf.cove.genericInventory.internal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.expando.kernel.model.ExpandoBridge;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.core.restutils.configuration.RestServicesCommonConfiguration;
import com.vf.cove.core.restutils.configuration.RestServicesCommonConfigurationHelper;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.genericInventory.dto.v1_0.CISearchRequest;
import com.vf.cove.genericInventory.dto.v1_0.CISearchResponse;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
//@MockitoSettings(strictness = Strictness.LENIENT)
public class GetCISearchServiceTest {

	@Mock
	private RestAPIProcessor restAPIProcessor;
    @Mock
    private CoveResponseParser coveResponseParser;

	@InjectMocks
	GetCISearchService getCISearchService;

	//@Mock
	CISearchRequest ciSearchRequest =  new CISearchRequest();

	private String SuccessResponseString;

	private CoveResponse esbSuccessResponse = new CoveResponse();

	private String ciSearchRequestString;

	@Mock
	private CoveRequestParser coveRequestParser;

	@Mock
	private RestServicesCommonConfigurationHelper restServicesCommonConfigurationHelper;

	@Mock
	private RestServicesCommonConfiguration restServicesCommonConfiguration;

	@Mock
	private User contextUser;

	private List<Organization> organisationList = new ArrayList<Organization>();

	@Mock
	private Organization organization;

	@Mock
	private ExpandoBridge expandoBridge;





    private String SuccessResponse;
	private String FailureResponse;

	private CoveResponse coveResponse;
	private JsonNode jsonNode;
    private static ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	public void setUp() throws Exception {

        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true);
		SuccessResponse = TestUtils.inputStreamToString("src/test/resources/CISearchSuccess.json");
		FailureResponse = TestUtils.inputStreamToString("src/test/resources/CISearchFailure.json");
		coveResponse = new CoveResponse();

		when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
		Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("HEADER", "COVE");
        coveResponse.setHeaders(responseHeaders);
        jsonNode = mapper.readTree(SuccessResponse);

		organisationList.add(organization);
		when(contextUser.getEmailAddress()).thenReturn("test@liferay.com");
		when(contextUser.getOrganizations()).thenReturn(organisationList);
		when(organization.getExpandoBridge()).thenReturn(expandoBridge);
		when(expandoBridge.getAttribute(eq(Constants.LEGAL_ORG_ID))).thenReturn("123456");

        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setAttribute("sourceSystemHeader","sourceSystemHeader");
        ServiceContextThreadLocal.pushServiceContext(serviceContext);


    }


	@Test
	public void getCISearchSuccessResponse() throws Exception {

		when(coveResponseParser.getCoveMapper()).thenReturn(mapper);
		when(coveRequestParser.parseRequestToJson(any())).thenReturn(SuccessResponse);

		coveResponse.setData(SuccessResponse);
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(coveResponse);

		ciSearchRequest.setMessageId("23432");
		ciSearchRequest.setCustomerId("12");
		ciSearchRequest.setPageIndex(2);
		String[] sysIds = {"132"};
		ciSearchRequest.setProductSysId(sysIds);
		ciSearchRequest.setSearchValue("test");
		ciSearchRequest.setRecordsPerPage(3);
		ciSearchRequest.setCurrentDate("2020-12-01");


		CISearchResponse ciSearchResponse = getCISearchService.postGetCISearchService(ciSearchRequest,contextUser);
		Assertions.assertThat(ciSearchResponse).isNotNull();
	}

	@Test
	public void getCISearchFailureResponse() throws Exception {

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenThrow(new ServiceException("Internal server error"));
		Assertions.assertThatThrownBy(
						() -> getCISearchService.postGetCISearchService(ciSearchRequest,contextUser))
				.isInstanceOf(ServiceException.class);
	}

	@Test
	public void getCISearchNoDataResponse() throws Exception {

		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(null);
		Assertions.assertThatThrownBy(
						() -> getCISearchService.postGetCISearchService(ciSearchRequest,contextUser))
				.isInstanceOf(ServiceException.class);
	}

}

