<@compress single_line=true>
{
	<#if (request.pageIndex?has_content && request.recordsPerPage?has_content) || sorting?has_content>
	"queryOptions": {
	<#if request.pageIndex?has_content && request.recordsPerPage?has_content>
		"pagination": {
            "count": ${request.pageIndex},
            "limit": ${request.recordsPerPage?c}
		}</#if><#if sorting?has_content><#if request.pageIndex?has_content && request.recordsPerPage?has_content>,</#if>
		"sorting": "${sorting}"
		</#if>
	},
	</#if>
	"queries": [
		<#if legalOrgId?has_content>
		{
			"query": "$.roles.holder.id[?(@.schemeName=='legalOrgId')].value=${legalOrgId}"
		}</#if><#if userId?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.roles.holder.contactPoint[*].id[?(@.schemeName=='userId')].value=${userId}"
		}</#if><#if request.businessServiceId?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.parts.specification.id[?(@.schemeName=='businessServiceId')].value=${request.businessServiceId}"
		}</#if><#if request.catalogueItemSysID?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.parts.specification.id[?(@.schemeName=='catalogueItemId')].value=${request.catalogueItemSysID}"
		}</#if><#if request.onboardingType?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.parts.specification.characteristicsValue[?(@.characteristicName=='onboardingType')].value=${request.onboardingType}"
		}</#if><#if status?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.status=${status?c}"
		}
		</#if><#if request.searchValue?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.name=@${request.searchValue}"
		}</#if><#if request.capability?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.parts.specification.characteristicsValue[?(@.characteristicName=='capability')].value=${request.capability}"
		}</#if>
	]
}
</@compress>
