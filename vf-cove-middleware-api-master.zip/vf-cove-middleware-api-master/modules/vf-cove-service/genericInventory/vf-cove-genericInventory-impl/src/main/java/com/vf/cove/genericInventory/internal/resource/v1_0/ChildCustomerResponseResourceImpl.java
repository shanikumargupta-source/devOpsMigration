package com.vf.cove.genericInventory.internal.resource.v1_0;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerRequest;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerResponse;
import com.vf.cove.genericInventory.dto.v1_0.SortOrder;
import com.vf.cove.genericInventory.internal.constants.GenericInventoryConstants;
import com.vf.cove.genericInventory.internal.service.ChildCustomerService;
import com.vf.cove.genericInventory.internal.util.RequestTransformationUtil;
import com.vf.cove.genericInventory.resource.v1_0.ChildCustomerResponseResource;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Ravi Rajamani
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/child-customer-response.properties", scope = ServiceScope.PROTOTYPE, service = ChildCustomerResponseResource.class)
public class ChildCustomerResponseResourceImpl extends BaseChildCustomerResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChildCustomerResponseResourceImpl.class);

	@Reference(unbind = "-")
	private ChildCustomerService childCustomerService;
    @Reference(unbind = "-")
    private CoveRequestParser coveRequestParser;

	@Override
	public ChildCustomerResponse postGetChildCustomer(ChildCustomerRequest childCustomerRequest) throws Exception {
		ChildCustomerResponse childCustomerResponse = null;
		try {
			String messageId = RequestUtils.getUUID();
			LOGGER.info("Invoking postGetChildCustomer API for messageId {} ", messageId);
			Map<String, Object> params = populateParams(childCustomerRequest);
			Map<String, String> headers = populateHeaders(messageId);
			childCustomerResponse = childCustomerService.postGetChildCustomer(childCustomerRequest, messageId, params,
					headers);
		} catch (DataNotFoundException dnfe) {
			if (StringUtils.equalsIgnoreCase(childCustomerRequest.getCapability(),
					GenericInventoryConstants.MANAGE_CUSTOMER_CAPABILITY)) {
				throw dnfe;
			} else {
				LOGGER.error("Data not found exception", dnfe);
			}
		}
		return childCustomerResponse;
	}

	private Map<String, Object> populateParams(ChildCustomerRequest childCustomerRequest)
			throws PortalException, IOException {

		childCustomerRequest.setPageIndex(RequestTransformationUtil
				.getPageIndexValue(childCustomerRequest.getPageIndex(), childCustomerRequest.getRecordsPerPage()));

		Map<String, Object> additionalParams = new HashMap<>();
		if (Validator.isNotNull(contextUser)) {
			if (Validator.isNotNull(contextUser.getOrganizations()) && !contextUser.getOrganizations().isEmpty()
					&& Validator.isNotNull(contextUser.getOrganizations().get(0))) {
				additionalParams.put(GenericInventoryConstants.LEGALORG_ID, String.valueOf(
						contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
			}
			additionalParams.put(GenericInventoryConstants.USER_ID, contextUser.getEmailAddress());
		}

		additionalParams.put(GenericInventoryConstants.SORTING_PARAM, getSortOrder(childCustomerRequest.getSortOrder(),
				GenericInventoryConstants.GET_CHILD_CUSTOMER_API_RESPONSE_DEFINITION));

		if (StringUtils.equalsIgnoreCase(childCustomerRequest.getCapability(),
				GenericInventoryConstants.RAISE_TICKET_CAPABILITY)) {
			String[] status = new String[1];
			status[0] = GenericInventoryConstants.STATUS_ACTIVE;
			childCustomerRequest.setStatus(status);
		}
		if (childCustomerRequest.getStatus() != null && childCustomerRequest.getStatus().length > 0) {
			String statusInRequest = childCustomerRequest.getStatus()[0];
			if (StringUtils.equalsIgnoreCase(GenericInventoryConstants.STATUS_ACTIVE, statusInRequest)) {
				additionalParams.put(GenericInventoryConstants.STATUS, true);
			} else {
				additionalParams.put(GenericInventoryConstants.STATUS, false);
			}
		}
		return additionalParams;
	}

	private Map<String, String> populateHeaders(String messageId) {
		String sysDate = RequestUtils.getUTCDate();
		Map<String, String> headers = new HashMap<>();
		headers.put(Constants.CORRELATION_ID_HEADER, messageId);
		headers.put(Constants.SOURCE_SYSTEM_HEADER, Constants.SOURCE_SYSTEM_COVE);
		headers.put(Constants.SOURCE_OPERATOR, Constants.VODAFONE);
		headers.put(Constants.SOURCE_TIMESTAMP, sysDate.substring(0, sysDate.length() - 5));
		headers.put(Constants.MESSAGE_ID, messageId);
		headers.put(Constants.DESTINATION_SYSTEM_HEADER, Constants.DESTINATION_SERVICE_NOW);
		return headers;
	}

	private String getSortOrder(@Valid SortOrder[] sortOrders, String responseParserFileName) throws IOException {
		if (Validator.isNotNull(sortOrders) && sortOrders.length > 0) {
			StringBuilder stringBuilder = new StringBuilder();

			for (int i = 1; i <= sortOrders.length; i++) {
				if (StringUtil.equalsIgnoreCase(sortOrders[i - 1].getValue(), Constants.ASC)) {

					stringBuilder.append(Constants.PLUS);
				} else {
					stringBuilder.append(Constants.MINUS);
				}
				InputStream in = ChildCustomerResponseResourceImpl.class.getResourceAsStream(responseParserFileName);
				stringBuilder.append(coveRequestParser.getESBSortParam(sortOrders[i - 1].getKey(), in));
				if (i != sortOrders.length) {
					stringBuilder.append(Constants.COMMA);
				}
			}
			return stringBuilder.toString();
		}
		return StringPool.BLANK;
	}
}
