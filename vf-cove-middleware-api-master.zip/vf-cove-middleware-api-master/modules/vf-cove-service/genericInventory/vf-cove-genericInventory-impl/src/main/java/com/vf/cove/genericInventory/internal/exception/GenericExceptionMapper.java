package com.vf.cove.genericInventory.internal.exception;

import com.vf.cove.genericInventory.dto.v1_0.ErrorMessage;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;


@Component(properties = "OSGI-INF/liferay/rest/v1_0/exception-mapper.properties", scope = ServiceScope.PROTOTYPE)
@Produces(MediaType.APPLICATION_JSON)
@Provider
public class GenericExceptionMapper implements ExceptionMapper<Throwable> {
    private static final Logger LOGGER = LoggerFactory.getLogger(GenericExceptionMapper.class);

	@Override
	public Response toResponse(Throwable ex) {
		LOGGER.error("Exception occured :::::::", ex);
		ErrorMessage error = new ErrorMessage();
		error.setErrorCode(500);
		error.setErrorMessage(ex.getMessage());
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(error).build();
	}

}
