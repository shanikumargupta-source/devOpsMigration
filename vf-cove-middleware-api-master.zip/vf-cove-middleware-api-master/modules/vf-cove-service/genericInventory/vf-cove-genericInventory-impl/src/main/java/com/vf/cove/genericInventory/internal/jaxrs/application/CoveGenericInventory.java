package com.vf.cove.genericInventory.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author Ravi Rajamani
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false",
		"osgi.jaxrs.application.base=/genericInventory",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=vf-cove-genericInventory"
	},
	service = Application.class
)
@Generated("")
public class CoveGenericInventory extends Application {
}