package com.vf.cove.genericInventory.internal.dto;

public class SortOrder {

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	protected String key;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	protected String value;

}