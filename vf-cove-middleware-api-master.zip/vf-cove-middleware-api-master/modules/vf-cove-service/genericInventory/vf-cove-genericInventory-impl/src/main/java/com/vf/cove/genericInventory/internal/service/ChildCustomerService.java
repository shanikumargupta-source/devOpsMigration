package com.vf.cove.genericInventory.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.ftlutils.utils.StreamToStringUtil;
import com.vf.cove.core.restutils.configuration.RestServicesCommonConfigurationHelper;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerRequest;
import com.vf.cove.genericInventory.dto.v1_0.ChildCustomerResponse;
import com.vf.cove.genericInventory.dto.v1_0.GetChildCustomer;
import com.vf.cove.genericInventory.internal.constants.GenericInventoryConstants;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component(service = ChildCustomerService.class)
public class ChildCustomerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChildCustomerService.class);

	 @Reference(target="(backend=DXL)")
	    private RestAPIProcessor restAPIProcessor;

	 @Reference(unbind = "-")
		private CoveResponseParser responseParser;

	@Reference(unbind = "-")
	private RestServicesCommonConfigurationHelper restServicesCommonConfigurationHelper;

    @Reference(unbind = "-")
    private FtlTemplateService ftlTemplateService;

    public ChildCustomerResponse postGetChildCustomer(ChildCustomerRequest childCustomerRequest, String messageId,
			Map<String, Object> params, Map<String, String> headers) throws Exception {
		LOGGER.info("Child Customer service");
		ChildCustomerResponse childCustomerResponse = new ChildCustomerResponse();

        String payload = getDXLRequest(childCustomerRequest, params);

        String relativeUrl = GenericInventoryConstants.GET_CHILD_CUSTOMER_API_URL;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(payload);
        restAPIRequest.setTransactionId(messageId);
        restAPIRequest.setHeaders(headers);
		CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

		if (dxlResponse != null && dxlResponse.getData() != null) {
			String esbResponseBody = dxlResponse.getData();
			LOGGER.debug("ESB Raw Response {}", esbResponseBody);
			InputStream in = ChildCustomerService.class
					.getResourceAsStream(GenericInventoryConstants.GET_CHILD_CUSTOMER_API_RESPONSE_DEFINITION);
			JsonNode transformedJsonNode = responseParser.parse(in, esbResponseBody);
			LOGGER.debug("Transformed Response {}", transformedJsonNode);
			List<GetChildCustomer> childCustomerDetailList = new ArrayList<>();
			transformedJsonNode.forEach(node -> {
				GetChildCustomer childCustomerDetail = null;
				try {
					childCustomerDetail = responseParser.getCoveMapper().readValue(node.toString(), GetChildCustomer.class);
					String status = node.get("status") != null ? node.get("status").asText() : StringUtils.EMPTY;
					if (StringUtils.equalsIgnoreCase(status, GenericInventoryConstants.TRUE_STRING)) {
						childCustomerDetail.setStatus(GenericInventoryConstants.STATUS_ACTIVE);
					} else {
						childCustomerDetail.setStatus(GenericInventoryConstants.STATUS_INACTIVE);
					}
				} catch (Exception e) {
					LOGGER.error("Exception", e);
				}
				if (Validator.isNotNull(childCustomerDetail)) {
					childCustomerDetailList.add(childCustomerDetail);
				}
			});

			childCustomerResponse.setGetChildCustomers(
					childCustomerDetailList.toArray(new GetChildCustomer[childCustomerDetailList.size()]));

			if (dxlResponse.getHeaders() != null && dxlResponse.getHeaders()
					.get(GenericInventoryConstants.GET_CHILD_CUSTOMER_TOTALCOUNT_HEADER) != null) {
				childCustomerResponse.setTotalcount(
						dxlResponse.getHeaders().get(GenericInventoryConstants.GET_CHILD_CUSTOMER_TOTALCOUNT_HEADER));
			}
		} else {
			throw new ServiceException(500, "Invalid response from ESB");
		}
		return childCustomerResponse;
	}

    private String getDXLRequest(ChildCustomerRequest childCustomerRequest,Map<String, Object> params) throws Exception{
        if (childCustomerRequest != null) {
            params.put(Constants.REQUEST_PARAM_NAME, childCustomerRequest);
        }
        final InputStream resourceAsStream = this.getClass().getResourceAsStream(GenericInventoryConstants.GET_CHILD_CUSTOMER_API_REQUEST_DEFINITION);
        String templateStr = StreamToStringUtil.getString(resourceAsStream);
        return ftlTemplateService.renderTemplate(GenericInventoryConstants.GET_CHILD_CUSTOMER_API_REQUEST_DEFINITION, templateStr, params);
    }

}
