package com.vf.cove.genericInventory.internal.resource.v1_0;

import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import com.vf.cove.genericInventory.dto.v1_0.CISearchRequest;
import com.vf.cove.genericInventory.dto.v1_0.CISearchResponse;
import com.vf.cove.genericInventory.internal.service.GetCISearchService;
import com.vf.cove.genericInventory.resource.v1_0.CISearchResponseResource;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Ravi Rajamani
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/ci-search-response.properties", scope = ServiceScope.PROTOTYPE, service = CISearchResponseResource.class)
public class CISearchResponseResourceImpl extends BaseCISearchResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CISearchResponseResourceImpl.class);

	@Reference(unbind = "-")
	private GetCISearchService getCISearchService;

	@Override
	public CISearchResponse postCiSearch(CISearchRequest ciSearchRequest) throws Exception {

		LOGGER.debug("CISearch API Request  {} ", ciSearchRequest);

		if (StringUtils.isBlank(ciSearchRequest.getSearchValue())) {
			throw new ValidationException(400, "Missing mandatory input (searchValue)");
		}
		ciSearchRequest.setMessageId(RequestUtils.getUUID());
		ciSearchRequest.setCurrentDate(RequestUtils.getUTCDate());

		return getCISearchService.postGetCISearchService(ciSearchRequest, contextUser);

	}

}
