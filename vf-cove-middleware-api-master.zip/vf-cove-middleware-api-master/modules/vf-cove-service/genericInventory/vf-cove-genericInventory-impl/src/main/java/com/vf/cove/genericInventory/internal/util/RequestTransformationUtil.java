package com.vf.cove.genericInventory.internal.util;

public class RequestTransformationUtil {

	public static Integer getPageIndexValue(Integer pageIndex, Integer recordsPerPage) {
		Integer modifiedPageIndex = null;
		if (pageIndex != null && recordsPerPage != null) {
			modifiedPageIndex = pageIndex * recordsPerPage;
		}
		return modifiedPageIndex;
	}
}
