package com.vf.cove.genericInventory.internal.constants;

public class GenericInventoryConstants {

	public static final String CISEARCH_ESB = "/cove/customerServiceInventoryItem/getCustomerServiceInventoryItem";

	public static final String RESPONSE_DATA = "responseData";

	public static final String RESPONSE = "response";

	public static final String STATUS = "status";

	public static final String TOTAL_COUNT = "TotalCount";


	public static final int ERROR_CODE_500 = 500;

	public static final int ERROR_CODE_491 = 491;


	public static final String INTERNAL_SERVER_ERROR = "Internal server error";

	public static final String NO_DATA_FOUND = "No data found";

	public static final String STATUS_CODE = "1";


	public static final String SORTING_PARAM = "sorting";
	public static final String ASC = "ASC";
	public static final String PLUS = "+";
	public static final String MINUS = "-";
	public static final String SORT_PREFIX = "$.";
	public static final String TYPE_PARAM = "type";
	public static final String LEGALORG_ID = "legalOrgId";
	public static final String USER_ID = "userId";


	public static final String GET_CI_SEAECH_JOURNEY_TYPE = "InventoryBySearchText";
	public static final String GET_CI_SEAECH_CATEGORY = "GenericInventory_CISearch";

	public static final String GET_CHILD_CUSTOMER_API_URL = "/auth/customerAccountAPI/v2/customerAccount/search";
	public static final String GET_CHILD_CUSTOMER_API_RESPONSE_DEFINITION = "/getChildCustomerResponse.json";
	public static final String GET_CHILD_CUSTOMER_API_REQUEST_DEFINITION = "/getChildCustomerRequest.ftl";

	public static final String GET_CHILD_CUSTOMER_TOTALCOUNT_HEADER = "x-total-count";

	public static final String STATUS_ACTIVE = "active";

	public static final String STATUS_INACTIVE = "inactive";

	public static final String TRUE_STRING = "true";

	public static final String MANAGE_CUSTOMER_CAPABILITY = "Manage customer";

	public static final String RAISE_TICKET_CAPABILITY = "Raise ticket";

    public static final String REG_EX_CDATA = "<!\\[CDATA\\[(.*?)\\]\\]>";

    public static final String REG_EX = "$1";

    public static final String SOURCE_SYSTEM_HEADER = "X-Source-System";
}
