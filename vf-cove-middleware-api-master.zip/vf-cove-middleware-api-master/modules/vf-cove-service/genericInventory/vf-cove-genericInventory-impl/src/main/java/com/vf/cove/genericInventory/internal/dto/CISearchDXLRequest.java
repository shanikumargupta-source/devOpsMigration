package com.vf.cove.genericInventory.internal.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CISearchDXLRequest {

	public CISearchDXLRequest () {

	}

	@JsonProperty("Category")
	public String getCategory() {
		return category;
	}

	public void setCategory(String Category) {
		this.category = Category;
	}

	protected String category;

	public String getChildCustomerId() {
		return childCustomerId;
	}

	public void setChildCustomerId(String childCustomerId) {
		this.childCustomerId = childCustomerId;
	}

	protected String childCustomerId;

	public String getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}

	protected String currentDate;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	protected String customerId;

	public String getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

	protected String journeyType;

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	protected String messageId;

	public String getOamuserId() {
		return oamuserId;
	}

	public void setOamuserId(String oamuserId) {
		this.oamuserId = oamuserId;
	}

	protected String oamuserId;

	public Integer getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}

	protected Integer pageIndex;

	public String[] getProductSysId() {
		return productSysId;
	}

	public void setProductSysId(String[] productSysId) {
		this.productSysId = productSysId;
	}

	protected String[] productSysId;

	public Integer getRecordsPerPage() {
		return recordsPerPage;
	}

	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	protected Integer recordsPerPage;

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	protected String searchValue;

	public SortOrder[] getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(SortOrder[] sortOrder) {
		this.sortOrder = sortOrder;
	}

	protected SortOrder[] sortOrder;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	protected String userId;
}
