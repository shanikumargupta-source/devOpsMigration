package com.vf.cove.genericInventory.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.core.restutils.configuration.RestServicesCommonConfigurationHelper;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.genericInventory.dto.v1_0.CIItem;
import com.vf.cove.genericInventory.dto.v1_0.CISearchRequest;
import com.vf.cove.genericInventory.dto.v1_0.CISearchResponse;
import com.vf.cove.genericInventory.internal.constants.GenericInventoryConstants;
import com.vf.cove.genericInventory.internal.dto.CISearchDXLRequest;
import com.vf.cove.genericInventory.internal.dto.SortOrder;
import com.vf.cove.genericInventory.internal.util.RequestTransformationUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Component(service = GetCISearchService.class)
public class GetCISearchService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GetCISearchService.class);

	@Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private RestServicesCommonConfigurationHelper restServicesCommonConfigurationHelper;
    @Reference(unbind = "-")

    private CoveRequestParser coveRequestParser;
    @Reference(unbind = "-")
	private CoveResponseParser coveResponseParser;

	public CISearchResponse postGetCISearchService(CISearchRequest ciSearchRequest, User contextUser) throws Exception {
		CISearchResponse ciSearchResponse = new CISearchResponse();

		if (Validator.isNotNull(ciSearchRequest)) {

			CISearchDXLRequest ciSearchDXLRequest = populateDXLRequest(ciSearchRequest, contextUser);
			String request = coveRequestParser.parseRequestToJson(ciSearchDXLRequest);

			RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
			restAPIRequest.setRelativeUrl(GenericInventoryConstants.CISEARCH_ESB);
			restAPIRequest.setRequest(request);
			restAPIRequest.setTransactionId(ciSearchRequest.getMessageId());

            String sourceSystem = getSourceSystemHeader();
            if(StringUtils.isNotEmpty(sourceSystem)){
                restAPIRequest.addHeader(GenericInventoryConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
            }

			CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

			LOGGER.debug("CI Search  DXL Responce  {}", dxlResponse);

			if (Validator.isNull(dxlResponse) || Validator.isNull(dxlResponse.getData())) {

				throw new ServiceException(GenericInventoryConstants.ERROR_CODE_500,
						GenericInventoryConstants.INTERNAL_SERVER_ERROR);
			}
			JsonNode rootNode = coveResponseParser.getCoveMapper().readTree(dxlResponse.getData());
			JsonNode responseData = rootNode.get(GenericInventoryConstants.RESPONSE_DATA);
			JsonNode json = responseData.get(GenericInventoryConstants.RESPONSE);
			ciSearchResponse = coveResponseParser.getCoveMapper().readValue(json.toString(), CISearchResponse.class);

		}
        LOGGER.info("CI Search output with CDATA tag ", ciSearchResponse);
        getCiSearchResponseAfterParsingCDATA(ciSearchResponse);
		return ciSearchResponse;
	}

	CISearchDXLRequest populateDXLRequest(CISearchRequest ciSearchRequest, User contextUser)
			throws PortalException {

		CISearchDXLRequest ciSearchDXLRequest = new CISearchDXLRequest();

		ciSearchDXLRequest.setChildCustomerId(ciSearchRequest.getChildCustomerId());

		ciSearchDXLRequest.setPageIndex(RequestTransformationUtil.getPageIndexValue(ciSearchRequest.getPageIndex(),
				ciSearchRequest.getRecordsPerPage()));
		ciSearchDXLRequest.setProductSysId(ciSearchRequest.getProductSysId());
		ciSearchDXLRequest.setSearchValue(ciSearchRequest.getSearchValue());
		ciSearchDXLRequest.setRecordsPerPage(ciSearchRequest.getRecordsPerPage());
		List<SortOrder> sortOrderList = new ArrayList<SortOrder>();
		if (ArrayUtils.isNotEmpty(ciSearchRequest.getSortOrder())) {
			for (com.vf.cove.genericInventory.dto.v1_0.@Valid SortOrder sortOrderItem : ciSearchRequest
					.getSortOrder()) {
				SortOrder sortOrder = new SortOrder();
				sortOrder.setKey(sortOrderItem.getKey());
				sortOrder.setValue(sortOrderItem.getValue());
				sortOrderList.add(sortOrder);
			}
		}

		ciSearchDXLRequest.setSortOrder(sortOrderList.toArray(new SortOrder[sortOrderList.size()]));
		ciSearchDXLRequest.setMessageId(ciSearchRequest.getMessageId());
		ciSearchDXLRequest.setCurrentDate(ciSearchRequest.getCurrentDate());

		ciSearchDXLRequest.setOamuserId(contextUser.getEmailAddress());
		ciSearchDXLRequest.setUserId(contextUser.getEmailAddress());
		ciSearchDXLRequest.setJourneyType(GenericInventoryConstants.GET_CI_SEAECH_JOURNEY_TYPE);
		ciSearchDXLRequest.setCategory(GenericInventoryConstants.GET_CI_SEAECH_CATEGORY);

		if (!contextUser.getOrganizations().isEmpty()) {
			ciSearchDXLRequest.setCustomerId(String.valueOf(
					contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
		}

		return ciSearchDXLRequest;
	}

    private CISearchResponse getCiSearchResponseAfterParsingCDATA(CISearchResponse ciSearchResponse){
        CIItem ciItems [] = ciSearchResponse.getCIItem();
        for (CIItem ciItem:ciItems) {
            String location = ciItem.getLocation()==null?"":ciItem.getLocation();
            ciItem.setLocation(location.replaceAll(GenericInventoryConstants.REG_EX_CDATA,GenericInventoryConstants.REG_EX));
        }
        LOGGER.info("CI Search output after parsing CDATA tag", ciSearchResponse);
        return ciSearchResponse;
    }

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }
}
