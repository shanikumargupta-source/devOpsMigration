package com.vf.cove.escalationmatrix.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("GetEscalationPlan")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetEscalationPlan")
public class GetEscalationPlan implements Serializable {

	public static GetEscalationPlan toDTO(String json) {
		return ObjectMapperUtil.readValue(GetEscalationPlan.class, json);
	}

	public static GetEscalationPlan unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(GetEscalationPlan.class, json);
	}

	@Schema
	public String getCurrentLevel() {
		if (_currentLevelSupplier != null) {
			currentLevel = _currentLevelSupplier.get();

			_currentLevelSupplier = null;
		}

		return currentLevel;
	}

	public void setCurrentLevel(String currentLevel) {
		this.currentLevel = currentLevel;

		_currentLevelSupplier = null;
	}

	@JsonIgnore
	public void setCurrentLevel(
		UnsafeSupplier<String, Exception> currentLevelUnsafeSupplier) {

		_currentLevelSupplier = () -> {
			try {
				return currentLevelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentLevel;

	@JsonIgnore
	private Supplier<String> _currentLevelSupplier;

	@Schema
	public String getEscalationReason() {
		if (_escalationReasonSupplier != null) {
			escalationReason = _escalationReasonSupplier.get();

			_escalationReasonSupplier = null;
		}

		return escalationReason;
	}

	public void setEscalationReason(String escalationReason) {
		this.escalationReason = escalationReason;

		_escalationReasonSupplier = null;
	}

	@JsonIgnore
	public void setEscalationReason(
		UnsafeSupplier<String, Exception> escalationReasonUnsafeSupplier) {

		_escalationReasonSupplier = () -> {
			try {
				return escalationReasonUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String escalationReason;

	@JsonIgnore
	private Supplier<String> _escalationReasonSupplier;

	@Schema
	public String getLevel() {
		if (_levelSupplier != null) {
			level = _levelSupplier.get();

			_levelSupplier = null;
		}

		return level;
	}

	public void setLevel(String level) {
		this.level = level;

		_levelSupplier = null;
	}

	@JsonIgnore
	public void setLevel(
		UnsafeSupplier<String, Exception> levelUnsafeSupplier) {

		_levelSupplier = () -> {
			try {
				return levelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String level;

	@JsonIgnore
	private Supplier<String> _levelSupplier;

	@Schema
	public String getTeam() {
		if (_teamSupplier != null) {
			team = _teamSupplier.get();

			_teamSupplier = null;
		}

		return team;
	}

	public void setTeam(String team) {
		this.team = team;

		_teamSupplier = null;
	}

	@JsonIgnore
	public void setTeam(UnsafeSupplier<String, Exception> teamUnsafeSupplier) {
		_teamSupplier = () -> {
			try {
				return teamUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String team;

	@JsonIgnore
	private Supplier<String> _teamSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetEscalationPlan)) {
			return false;
		}

		GetEscalationPlan getEscalationPlan = (GetEscalationPlan)object;

		return Objects.equals(toString(), getEscalationPlan.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String currentLevel = getCurrentLevel();

		if (currentLevel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentLevel\": ");

			sb.append("\"");

			sb.append(_escape(currentLevel));

			sb.append("\"");
		}

		String escalationReason = getEscalationReason();

		if (escalationReason != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationReason\": ");

			sb.append("\"");

			sb.append(_escape(escalationReason));

			sb.append("\"");
		}

		String level = getLevel();

		if (level != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"level\": ");

			sb.append("\"");

			sb.append(_escape(level));

			sb.append("\"");
		}

		String team = getTeam();

		if (team != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"team\": ");

			sb.append("\"");

			sb.append(_escape(team));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.escalationmatrix.dto.v1_0.GetEscalationPlan",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}