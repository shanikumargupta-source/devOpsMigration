package com.vf.cove.escalationmatrix.internal.constants;

public class EscalationmatrixConstants {

	public static final String INTERNAL_SERVER_ERROR = "Internal server error";
    public static final String NO_DATA_FOUND = "No data found";
    public static final String STATUS_CODE = "1";
    public static final String RESPONSE_DATA = "responseData";
    public static final String RESPONSE = "response";
    public static final String STATUS = "status";
    public static final String ESCALATION_PLAN = "/escalationPlan/getEscalationList";
    public static final String ESCALATION_DETAILS = "escalationDetails";
    public static final String MISSING_REQUIRED_ATTRIBUTES = "Missing required attributes as part of the request";
    public static final int ERROR_CODE_500 = 500;
    public static final int ERROR_CODE_400 = 400;
    public static final int ERROR_CODE_491 = 491;

    public static final String COVE = "/cove";

    public static final String SOURCE_SYSTEM_HEADER = "X-Source-System";
}
