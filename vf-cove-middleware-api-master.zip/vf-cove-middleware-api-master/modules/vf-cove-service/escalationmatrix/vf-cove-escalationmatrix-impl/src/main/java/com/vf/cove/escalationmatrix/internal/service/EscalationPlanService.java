package com.vf.cove.escalationmatrix.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.escalationmatrix.dto.v1_0.EscalationPlanRequest;
import com.vf.cove.escalationmatrix.dto.v1_0.EscalationPlanResponse;
import com.vf.cove.escalationmatrix.dto.v1_0.GetEscalationPlan;
import com.vf.cove.escalationmatrix.internal.constants.EscalationmatrixConstants;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * @author Virtusa
 */
@Component(service = EscalationPlanService.class)
public class EscalationPlanService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EscalationPlanService.class);

	 @Reference(target="(backend=DXL)")
	    private RestAPIProcessor restAPIProcessor;

	 @Reference(unbind = "-")
		private CoveResponseParser responseParser;

	public EscalationPlanResponse postGetEscalationPlan(EscalationPlanRequest escalationPlanRequest, String messageId)
			throws Exception {
		LOGGER.info("Escalation Plan service");
		EscalationPlanResponse coveResponse = new EscalationPlanResponse();

		final String request = escalationPlanRequest.toString();
        String relativeUrl = EscalationmatrixConstants.COVE+EscalationmatrixConstants.ESCALATION_PLAN;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);

        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            restAPIRequest.addHeader(EscalationmatrixConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
        LOGGER.info("Request Headers.. {}", restAPIRequest.getHeaders());

        CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

        if(StringUtils.isEmpty(dxlResponse.getData())) {

			throw new ServiceException(EscalationmatrixConstants.ERROR_CODE_500,
					EscalationmatrixConstants.INTERNAL_SERVER_ERROR);
		}

		JsonNode rootNode = responseParser.getCoveMapper().readTree(dxlResponse.getData());
		JsonNode responseData = rootNode.get(EscalationmatrixConstants.RESPONSE_DATA);

		JsonNode responseStatus = responseData.get(EscalationmatrixConstants.STATUS);
		String status = responseParser.getCoveMapper().readValue(responseStatus.toString(), String.class);
		if (status.equalsIgnoreCase(EscalationmatrixConstants.STATUS_CODE)) {
			throw new DataNotFoundException(EscalationmatrixConstants.ERROR_CODE_491,
					EscalationmatrixConstants.NO_DATA_FOUND);
		}

		JsonNode response = responseData.get(EscalationmatrixConstants.RESPONSE);

		List<GetEscalationPlan> escalationPlanList = new ArrayList<>();
		ArrayNode arrayNode = (ArrayNode) response.get(EscalationmatrixConstants.ESCALATION_DETAILS);
		arrayNode.forEach(node -> {
			try {
				escalationPlanList
						.add(responseParser.getCoveMapper().readValue(node.toString(), GetEscalationPlan.class));
			} catch (IOException e) {
				LOGGER.error("Exception {} ", e);
			}
		});
		coveResponse.setGetEscalationPlan(escalationPlanList.toArray(new GetEscalationPlan[escalationPlanList.size()]));

		return coveResponse;
	}

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }
}
