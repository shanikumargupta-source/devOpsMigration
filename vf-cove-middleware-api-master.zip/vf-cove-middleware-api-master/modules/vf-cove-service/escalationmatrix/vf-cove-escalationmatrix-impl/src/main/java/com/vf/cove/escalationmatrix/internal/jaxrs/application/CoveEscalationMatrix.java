package com.vf.cove.escalationmatrix.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author Virtusa
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false",
		"osgi.jaxrs.application.base=/vf-cove-escalationmatrix",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=vf-cove-escalationmatrix"
	},
	service = Application.class
)
@Generated("")
public class CoveEscalationMatrix extends Application {
}