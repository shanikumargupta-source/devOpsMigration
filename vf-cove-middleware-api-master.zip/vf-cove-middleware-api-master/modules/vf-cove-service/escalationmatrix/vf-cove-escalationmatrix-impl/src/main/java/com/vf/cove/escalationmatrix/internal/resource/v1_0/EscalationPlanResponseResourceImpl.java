package com.vf.cove.escalationmatrix.internal.resource.v1_0;

import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import com.vf.cove.escalationmatrix.dto.v1_0.EscalationPlanRequest;
import com.vf.cove.escalationmatrix.dto.v1_0.EscalationPlanResponse;
import com.vf.cove.escalationmatrix.internal.constants.EscalationmatrixConstants;
import com.vf.cove.escalationmatrix.internal.service.EscalationPlanService;
import com.vf.cove.escalationmatrix.resource.v1_0.EscalationPlanResponseResource;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Virtusa
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/escalation-plan-response.properties", scope = ServiceScope.PROTOTYPE, service = EscalationPlanResponseResource.class)
public class EscalationPlanResponseResourceImpl extends BaseEscalationPlanResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(EscalationPlanResponseResourceImpl.class);

	@Reference(unbind = "-")
	private EscalationPlanService escalationPlanService;

	@Override
	public EscalationPlanResponse postGetEscalationPlan(EscalationPlanRequest escalationPlanRequest) throws Exception {
		String messageId = RequestUtils.getUUID();
		requiredFieldValidations(escalationPlanRequest);
		LOGGER.info("Invoking postGetEscalationPlan API for messageId {} " + messageId);
		if (ObjectUtils.isNotEmpty(escalationPlanRequest) && ObjectUtils.isNotEmpty(contextUser)) {
			escalationPlanRequest.setUserId(contextUser.getEmailAddress());
			escalationPlanRequest.setCurrentDate(RequestUtils.getUTCDate());
			escalationPlanRequest.setOamuserId(contextUser.getEmailAddress());
			if (contextUser.getOrganizations().size() > 0) {
				escalationPlanRequest.setCustomerId(String.valueOf(
						contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));

			}
			escalationPlanRequest.setMessageId(messageId);
			return escalationPlanService.postGetEscalationPlan(escalationPlanRequest, messageId);
		}

		return new EscalationPlanResponse();
	}

	private void requiredFieldValidations(EscalationPlanRequest request) throws Exception {
        LOGGER.debug("Inside postGetEscalationPlan - requiredFieldValidations()");
        if(StringUtils.isEmpty(request.getBusinessService())) {
        	throw new ValidationException(EscalationmatrixConstants.ERROR_CODE_400, EscalationmatrixConstants.MISSING_REQUIRED_ATTRIBUTES);
        }
    }
}
