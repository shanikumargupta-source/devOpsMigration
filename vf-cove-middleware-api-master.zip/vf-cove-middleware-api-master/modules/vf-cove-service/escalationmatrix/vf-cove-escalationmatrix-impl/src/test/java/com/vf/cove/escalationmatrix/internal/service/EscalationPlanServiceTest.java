package com.vf.cove.escalationmatrix.internal.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.escalationmatrix.dto.v1_0.EscalationPlanRequest;
import com.vf.cove.escalationmatrix.dto.v1_0.EscalationPlanResponse;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class EscalationPlanServiceTest {

	@Mock
	private CoveResponseParser responseParser;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	@InjectMocks
	EscalationPlanService escalationPlanService;

	private String successResponse;
	private String failureResponse;
	private static final String MESSAGE_ID = "testMessageId";

	  private CoveResponse esbResponse;
	  private EscalationPlanRequest escalationPlanRequest;
	  private static ObjectMapper mapper;

	@BeforeEach
	public void setUp() throws Exception {
        mapper = new ObjectMapper();

		successResponse = TestUtils.inputStreamToString("src/test/resources/EscalationSuccessResp.json");
		failureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");
		esbResponse = new CoveResponse();
		escalationPlanRequest = new EscalationPlanRequest();

        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
        when(responseParser.getCoveMapper()).thenReturn(mapper);

        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setAttribute("contentLength","123");
        ServiceContextThreadLocal.pushServiceContext(serviceContext);
	}

	@Test
	public void getEscalationPlanSuccessResponse() throws Exception {
		esbResponse.setData(successResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);

		EscalationPlanResponse eResponse = escalationPlanService.postGetEscalationPlan(escalationPlanRequest, MESSAGE_ID);
		Assertions.assertThat(eResponse).isNotNull();
	}

	@Test
	public void getEscalationPlanFailureResponse() throws Exception {
		esbResponse.setData(failureResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		Assertions.assertThatThrownBy(() -> escalationPlanService.postGetEscalationPlan(escalationPlanRequest, MESSAGE_ID))
		.isInstanceOf(DataNotFoundException.class);
	}
}
