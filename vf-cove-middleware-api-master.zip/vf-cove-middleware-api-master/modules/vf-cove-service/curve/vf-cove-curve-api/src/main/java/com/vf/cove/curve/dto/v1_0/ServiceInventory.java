package com.vf.cove.curve.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Curve team
 * @generated
 */
@Generated("")
@GraphQLName("ServiceInventory")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ServiceInventory")
public class ServiceInventory implements Serializable {

	public static ServiceInventory toDTO(String json) {
		return ObjectMapperUtil.readValue(ServiceInventory.class, json);
	}

	public static ServiceInventory unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(ServiceInventory.class, json);
	}

	@Schema
	public String getActivationDate() {
		if (_activationDateSupplier != null) {
			activationDate = _activationDateSupplier.get();

			_activationDateSupplier = null;
		}

		return activationDate;
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;

		_activationDateSupplier = null;
	}

	@JsonIgnore
	public void setActivationDate(
		UnsafeSupplier<String, Exception> activationDateUnsafeSupplier) {

		_activationDateSupplier = () -> {
			try {
				return activationDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String activationDate;

	@JsonIgnore
	private Supplier<String> _activationDateSupplier;

	@Schema
	public String getBan() {
		if (_banSupplier != null) {
			ban = _banSupplier.get();

			_banSupplier = null;
		}

		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;

		_banSupplier = null;
	}

	@JsonIgnore
	public void setBan(UnsafeSupplier<String, Exception> banUnsafeSupplier) {
		_banSupplier = () -> {
			try {
				return banUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ban;

	@JsonIgnore
	private Supplier<String> _banSupplier;

	@Schema
	public String getContractEndDate() {
		if (_contractEndDateSupplier != null) {
			contractEndDate = _contractEndDateSupplier.get();

			_contractEndDateSupplier = null;
		}

		return contractEndDate;
	}

	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;

		_contractEndDateSupplier = null;
	}

	@JsonIgnore
	public void setContractEndDate(
		UnsafeSupplier<String, Exception> contractEndDateUnsafeSupplier) {

		_contractEndDateSupplier = () -> {
			try {
				return contractEndDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String contractEndDate;

	@JsonIgnore
	private Supplier<String> _contractEndDateSupplier;

	@Schema
	public String getContractStartDate() {
		if (_contractStartDateSupplier != null) {
			contractStartDate = _contractStartDateSupplier.get();

			_contractStartDateSupplier = null;
		}

		return contractStartDate;
	}

	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;

		_contractStartDateSupplier = null;
	}

	@JsonIgnore
	public void setContractStartDate(
		UnsafeSupplier<String, Exception> contractStartDateUnsafeSupplier) {

		_contractStartDateSupplier = () -> {
			try {
				return contractStartDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String contractStartDate;

	@JsonIgnore
	private Supplier<String> _contractStartDateSupplier;

	@Schema
	public Integer getCurrentDevice() {
		if (_currentDeviceSupplier != null) {
			currentDevice = _currentDeviceSupplier.get();

			_currentDeviceSupplier = null;
		}

		return currentDevice;
	}

	public void setCurrentDevice(Integer currentDevice) {
		this.currentDevice = currentDevice;

		_currentDeviceSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDevice(
		UnsafeSupplier<Integer, Exception> currentDeviceUnsafeSupplier) {

		_currentDeviceSupplier = () -> {
			try {
				return currentDeviceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer currentDevice;

	@JsonIgnore
	private Supplier<Integer> _currentDeviceSupplier;

	@Schema
	public String getCustomerCode() {
		if (_customerCodeSupplier != null) {
			customerCode = _customerCodeSupplier.get();

			_customerCodeSupplier = null;
		}

		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;

		_customerCodeSupplier = null;
	}

	@JsonIgnore
	public void setCustomerCode(
		UnsafeSupplier<String, Exception> customerCodeUnsafeSupplier) {

		_customerCodeSupplier = () -> {
			try {
				return customerCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerCode;

	@JsonIgnore
	private Supplier<String> _customerCodeSupplier;

	@Schema
	public String getDevideModel() {
		if (_devideModelSupplier != null) {
			devideModel = _devideModelSupplier.get();

			_devideModelSupplier = null;
		}

		return devideModel;
	}

	public void setDevideModel(String devideModel) {
		this.devideModel = devideModel;

		_devideModelSupplier = null;
	}

	@JsonIgnore
	public void setDevideModel(
		UnsafeSupplier<String, Exception> devideModelUnsafeSupplier) {

		_devideModelSupplier = () -> {
			try {
				return devideModelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String devideModel;

	@JsonIgnore
	private Supplier<String> _devideModelSupplier;

	@Schema
	public String getEndUserId() {
		if (_endUserIdSupplier != null) {
			endUserId = _endUserIdSupplier.get();

			_endUserIdSupplier = null;
		}

		return endUserId;
	}

	public void setEndUserId(String endUserId) {
		this.endUserId = endUserId;

		_endUserIdSupplier = null;
	}

	@JsonIgnore
	public void setEndUserId(
		UnsafeSupplier<String, Exception> endUserIdUnsafeSupplier) {

		_endUserIdSupplier = () -> {
			try {
				return endUserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String endUserId;

	@JsonIgnore
	private Supplier<String> _endUserIdSupplier;

	@Schema
	public String getEquipmentType() {
		if (_equipmentTypeSupplier != null) {
			equipmentType = _equipmentTypeSupplier.get();

			_equipmentTypeSupplier = null;
		}

		return equipmentType;
	}

	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;

		_equipmentTypeSupplier = null;
	}

	@JsonIgnore
	public void setEquipmentType(
		UnsafeSupplier<String, Exception> equipmentTypeUnsafeSupplier) {

		_equipmentTypeSupplier = () -> {
			try {
				return equipmentTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String equipmentType;

	@JsonIgnore
	private Supplier<String> _equipmentTypeSupplier;

	@Schema
	public String getImei() {
		if (_imeiSupplier != null) {
			imei = _imeiSupplier.get();

			_imeiSupplier = null;
		}

		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;

		_imeiSupplier = null;
	}

	@JsonIgnore
	public void setImei(UnsafeSupplier<String, Exception> imeiUnsafeSupplier) {
		_imeiSupplier = () -> {
			try {
				return imeiUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String imei;

	@JsonIgnore
	private Supplier<String> _imeiSupplier;

	@Schema
	public String getMsisdn() {
		if (_msisdnSupplier != null) {
			msisdn = _msisdnSupplier.get();

			_msisdnSupplier = null;
		}

		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;

		_msisdnSupplier = null;
	}

	@JsonIgnore
	public void setMsisdn(
		UnsafeSupplier<String, Exception> msisdnUnsafeSupplier) {

		_msisdnSupplier = () -> {
			try {
				return msisdnUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String msisdn;

	@JsonIgnore
	private Supplier<String> _msisdnSupplier;

	@Schema
	public String getMultiSIM() {
		if (_multiSIMSupplier != null) {
			multiSIM = _multiSIMSupplier.get();

			_multiSIMSupplier = null;
		}

		return multiSIM;
	}

	public void setMultiSIM(String multiSIM) {
		this.multiSIM = multiSIM;

		_multiSIMSupplier = null;
	}

	@JsonIgnore
	public void setMultiSIM(
		UnsafeSupplier<String, Exception> multiSIMUnsafeSupplier) {

		_multiSIMSupplier = () -> {
			try {
				return multiSIMUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String multiSIM;

	@JsonIgnore
	private Supplier<String> _multiSIMSupplier;

	@Schema
	public String getOrderId() {
		if (_orderIdSupplier != null) {
			orderId = _orderIdSupplier.get();

			_orderIdSupplier = null;
		}

		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;

		_orderIdSupplier = null;
	}

	@JsonIgnore
	public void setOrderId(
		UnsafeSupplier<String, Exception> orderIdUnsafeSupplier) {

		_orderIdSupplier = () -> {
			try {
				return orderIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String orderId;

	@JsonIgnore
	private Supplier<String> _orderIdSupplier;

	@Schema
	public String getProductCode() {
		if (_productCodeSupplier != null) {
			productCode = _productCodeSupplier.get();

			_productCodeSupplier = null;
		}

		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;

		_productCodeSupplier = null;
	}

	@JsonIgnore
	public void setProductCode(
		UnsafeSupplier<String, Exception> productCodeUnsafeSupplier) {

		_productCodeSupplier = () -> {
			try {
				return productCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String productCode;

	@JsonIgnore
	private Supplier<String> _productCodeSupplier;

	@Schema
	public String getTarrif() {
		if (_tarrifSupplier != null) {
			tarrif = _tarrifSupplier.get();

			_tarrifSupplier = null;
		}

		return tarrif;
	}

	public void setTarrif(String tarrif) {
		this.tarrif = tarrif;

		_tarrifSupplier = null;
	}

	@JsonIgnore
	public void setTarrif(
		UnsafeSupplier<String, Exception> tarrifUnsafeSupplier) {

		_tarrifSupplier = () -> {
			try {
				return tarrifUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String tarrif;

	@JsonIgnore
	private Supplier<String> _tarrifSupplier;

	@Schema
	public String getTarrifCode() {
		if (_tarrifCodeSupplier != null) {
			tarrifCode = _tarrifCodeSupplier.get();

			_tarrifCodeSupplier = null;
		}

		return tarrifCode;
	}

	public void setTarrifCode(String tarrifCode) {
		this.tarrifCode = tarrifCode;

		_tarrifCodeSupplier = null;
	}

	@JsonIgnore
	public void setTarrifCode(
		UnsafeSupplier<String, Exception> tarrifCodeUnsafeSupplier) {

		_tarrifCodeSupplier = () -> {
			try {
				return tarrifCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String tarrifCode;

	@JsonIgnore
	private Supplier<String> _tarrifCodeSupplier;

	@Schema
	public String getTransactionType() {
		if (_transactionTypeSupplier != null) {
			transactionType = _transactionTypeSupplier.get();

			_transactionTypeSupplier = null;
		}

		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;

		_transactionTypeSupplier = null;
	}

	@JsonIgnore
	public void setTransactionType(
		UnsafeSupplier<String, Exception> transactionTypeUnsafeSupplier) {

		_transactionTypeSupplier = () -> {
			try {
				return transactionTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String transactionType;

	@JsonIgnore
	private Supplier<String> _transactionTypeSupplier;

	@Schema
	public String getUpgradeDate() {
		if (_upgradeDateSupplier != null) {
			upgradeDate = _upgradeDateSupplier.get();

			_upgradeDateSupplier = null;
		}

		return upgradeDate;
	}

	public void setUpgradeDate(String upgradeDate) {
		this.upgradeDate = upgradeDate;

		_upgradeDateSupplier = null;
	}

	@JsonIgnore
	public void setUpgradeDate(
		UnsafeSupplier<String, Exception> upgradeDateUnsafeSupplier) {

		_upgradeDateSupplier = () -> {
			try {
				return upgradeDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String upgradeDate;

	@JsonIgnore
	private Supplier<String> _upgradeDateSupplier;

	@Schema
	public String getVipUser() {
		if (_vipUserSupplier != null) {
			vipUser = _vipUserSupplier.get();

			_vipUserSupplier = null;
		}

		return vipUser;
	}

	public void setVipUser(String vipUser) {
		this.vipUser = vipUser;

		_vipUserSupplier = null;
	}

	@JsonIgnore
	public void setVipUser(
		UnsafeSupplier<String, Exception> vipUserUnsafeSupplier) {

		_vipUserSupplier = () -> {
			try {
				return vipUserUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String vipUser;

	@JsonIgnore
	private Supplier<String> _vipUserSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ServiceInventory)) {
			return false;
		}

		ServiceInventory serviceInventory = (ServiceInventory)object;

		return Objects.equals(toString(), serviceInventory.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String activationDate = getActivationDate();

		if (activationDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"activationDate\": ");

			sb.append("\"");

			sb.append(_escape(activationDate));

			sb.append("\"");
		}

		String ban = getBan();

		if (ban != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ban\": ");

			sb.append("\"");

			sb.append(_escape(ban));

			sb.append("\"");
		}

		String contractEndDate = getContractEndDate();

		if (contractEndDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractEndDate\": ");

			sb.append("\"");

			sb.append(_escape(contractEndDate));

			sb.append("\"");
		}

		String contractStartDate = getContractStartDate();

		if (contractStartDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractStartDate\": ");

			sb.append("\"");

			sb.append(_escape(contractStartDate));

			sb.append("\"");
		}

		Integer currentDevice = getCurrentDevice();

		if (currentDevice != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDevice\": ");

			sb.append(currentDevice);
		}

		String customerCode = getCustomerCode();

		if (customerCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerCode\": ");

			sb.append("\"");

			sb.append(_escape(customerCode));

			sb.append("\"");
		}

		String devideModel = getDevideModel();

		if (devideModel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"devideModel\": ");

			sb.append("\"");

			sb.append(_escape(devideModel));

			sb.append("\"");
		}

		String endUserId = getEndUserId();

		if (endUserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"endUserId\": ");

			sb.append("\"");

			sb.append(_escape(endUserId));

			sb.append("\"");
		}

		String equipmentType = getEquipmentType();

		if (equipmentType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"equipmentType\": ");

			sb.append("\"");

			sb.append(_escape(equipmentType));

			sb.append("\"");
		}

		String imei = getImei();

		if (imei != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"imei\": ");

			sb.append("\"");

			sb.append(_escape(imei));

			sb.append("\"");
		}

		String msisdn = getMsisdn();

		if (msisdn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"msisdn\": ");

			sb.append("\"");

			sb.append(_escape(msisdn));

			sb.append("\"");
		}

		String multiSIM = getMultiSIM();

		if (multiSIM != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"multiSIM\": ");

			sb.append("\"");

			sb.append(_escape(multiSIM));

			sb.append("\"");
		}

		String orderId = getOrderId();

		if (orderId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"orderId\": ");

			sb.append("\"");

			sb.append(_escape(orderId));

			sb.append("\"");
		}

		String productCode = getProductCode();

		if (productCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"productCode\": ");

			sb.append("\"");

			sb.append(_escape(productCode));

			sb.append("\"");
		}

		String tarrif = getTarrif();

		if (tarrif != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tarrif\": ");

			sb.append("\"");

			sb.append(_escape(tarrif));

			sb.append("\"");
		}

		String tarrifCode = getTarrifCode();

		if (tarrifCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tarrifCode\": ");

			sb.append("\"");

			sb.append(_escape(tarrifCode));

			sb.append("\"");
		}

		String transactionType = getTransactionType();

		if (transactionType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"transactionType\": ");

			sb.append("\"");

			sb.append(_escape(transactionType));

			sb.append("\"");
		}

		String upgradeDate = getUpgradeDate();

		if (upgradeDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"upgradeDate\": ");

			sb.append("\"");

			sb.append(_escape(upgradeDate));

			sb.append("\"");
		}

		String vipUser = getVipUser();

		if (vipUser != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"vipUser\": ");

			sb.append("\"");

			sb.append(_escape(vipUser));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.curve.dto.v1_0.ServiceInventory",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}