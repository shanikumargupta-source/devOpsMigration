package com.vf.cove.curve.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Curve team
 * @generated
 */
@Generated("")
@GraphQLName("BulkUserValidationResponse")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "BulkUserValidationResponse")
public class BulkUserValidationResponse implements Serializable {

	public static BulkUserValidationResponse toDTO(String json) {
		return ObjectMapperUtil.readValue(
			BulkUserValidationResponse.class, json);
	}

	public static BulkUserValidationResponse unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			BulkUserValidationResponse.class, json);
	}

	@Schema
	@Valid
	public Error[] getErrors() {
		if (_errorsSupplier != null) {
			errors = _errorsSupplier.get();

			_errorsSupplier = null;
		}

		return errors;
	}

	public void setErrors(Error[] errors) {
		this.errors = errors;

		_errorsSupplier = null;
	}

	@JsonIgnore
	public void setErrors(
		UnsafeSupplier<Error[], Exception> errorsUnsafeSupplier) {

		_errorsSupplier = () -> {
			try {
				return errorsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Error[] errors;

	@JsonIgnore
	private Supplier<Error[]> _errorsSupplier;

	@Schema
	public String[] getExistingUserId() {
		if (_existingUserIdSupplier != null) {
			existingUserId = _existingUserIdSupplier.get();

			_existingUserIdSupplier = null;
		}

		return existingUserId;
	}

	public void setExistingUserId(String[] existingUserId) {
		this.existingUserId = existingUserId;

		_existingUserIdSupplier = null;
	}

	@JsonIgnore
	public void setExistingUserId(
		UnsafeSupplier<String[], Exception> existingUserIdUnsafeSupplier) {

		_existingUserIdSupplier = () -> {
			try {
				return existingUserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] existingUserId;

	@JsonIgnore
	private Supplier<String[]> _existingUserIdSupplier;

	@Schema
	public Integer getInvalidUserCount() {
		if (_invalidUserCountSupplier != null) {
			invalidUserCount = _invalidUserCountSupplier.get();

			_invalidUserCountSupplier = null;
		}

		return invalidUserCount;
	}

	public void setInvalidUserCount(Integer invalidUserCount) {
		this.invalidUserCount = invalidUserCount;

		_invalidUserCountSupplier = null;
	}

	@JsonIgnore
	public void setInvalidUserCount(
		UnsafeSupplier<Integer, Exception> invalidUserCountUnsafeSupplier) {

		_invalidUserCountSupplier = () -> {
			try {
				return invalidUserCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer invalidUserCount;

	@JsonIgnore
	private Supplier<Integer> _invalidUserCountSupplier;

	@Schema
	public Boolean getIsStructureError() {
		if (_isStructureErrorSupplier != null) {
			isStructureError = _isStructureErrorSupplier.get();

			_isStructureErrorSupplier = null;
		}

		return isStructureError;
	}

	public void setIsStructureError(Boolean isStructureError) {
		this.isStructureError = isStructureError;

		_isStructureErrorSupplier = null;
	}

	@JsonIgnore
	public void setIsStructureError(
		UnsafeSupplier<Boolean, Exception> isStructureErrorUnsafeSupplier) {

		_isStructureErrorSupplier = () -> {
			try {
				return isStructureErrorUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isStructureError;

	@JsonIgnore
	private Supplier<Boolean> _isStructureErrorSupplier;

	@Schema
	public Boolean getIsValid() {
		if (_isValidSupplier != null) {
			isValid = _isValidSupplier.get();

			_isValidSupplier = null;
		}

		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;

		_isValidSupplier = null;
	}

	@JsonIgnore
	public void setIsValid(
		UnsafeSupplier<Boolean, Exception> isValidUnsafeSupplier) {

		_isValidSupplier = () -> {
			try {
				return isValidUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isValid;

	@JsonIgnore
	private Supplier<Boolean> _isValidSupplier;

	@Schema
	public Integer getValidUserCount() {
		if (_validUserCountSupplier != null) {
			validUserCount = _validUserCountSupplier.get();

			_validUserCountSupplier = null;
		}

		return validUserCount;
	}

	public void setValidUserCount(Integer validUserCount) {
		this.validUserCount = validUserCount;

		_validUserCountSupplier = null;
	}

	@JsonIgnore
	public void setValidUserCount(
		UnsafeSupplier<Integer, Exception> validUserCountUnsafeSupplier) {

		_validUserCountSupplier = () -> {
			try {
				return validUserCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer validUserCount;

	@JsonIgnore
	private Supplier<Integer> _validUserCountSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof BulkUserValidationResponse)) {
			return false;
		}

		BulkUserValidationResponse bulkUserValidationResponse =
			(BulkUserValidationResponse)object;

		return Objects.equals(
			toString(), bulkUserValidationResponse.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		Error[] errors = getErrors();

		if (errors != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"errors\": ");

			sb.append("[");

			for (int i = 0; i < errors.length; i++) {
				sb.append(String.valueOf(errors[i]));

				if ((i + 1) < errors.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] existingUserId = getExistingUserId();

		if (existingUserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"existingUserId\": ");

			sb.append("[");

			for (int i = 0; i < existingUserId.length; i++) {
				sb.append("\"");

				sb.append(_escape(existingUserId[i]));

				sb.append("\"");

				if ((i + 1) < existingUserId.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		Integer invalidUserCount = getInvalidUserCount();

		if (invalidUserCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"invalidUserCount\": ");

			sb.append(invalidUserCount);
		}

		Boolean isStructureError = getIsStructureError();

		if (isStructureError != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isStructureError\": ");

			sb.append(isStructureError);
		}

		Boolean isValid = getIsValid();

		if (isValid != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isValid\": ");

			sb.append(isValid);
		}

		Integer validUserCount = getValidUserCount();

		if (validUserCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"validUserCount\": ");

			sb.append(validUserCount);
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.curve.dto.v1_0.BulkUserValidationResponse",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}