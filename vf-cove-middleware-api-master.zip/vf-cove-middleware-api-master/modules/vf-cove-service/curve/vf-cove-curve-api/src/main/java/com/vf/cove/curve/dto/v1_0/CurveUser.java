package com.vf.cove.curve.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Curve team
 * @generated
 */
@Generated("")
@GraphQLName("CurveUser")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CurveUser")
public class CurveUser implements Serializable {

	public static CurveUser toDTO(String json) {
		return ObjectMapperUtil.readValue(CurveUser.class, json);
	}

	public static CurveUser unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CurveUser.class, json);
	}

	@Schema
	public String getActivationDate() {
		if (_activationDateSupplier != null) {
			activationDate = _activationDateSupplier.get();

			_activationDateSupplier = null;
		}

		return activationDate;
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;

		_activationDateSupplier = null;
	}

	@JsonIgnore
	public void setActivationDate(
		UnsafeSupplier<String, Exception> activationDateUnsafeSupplier) {

		_activationDateSupplier = () -> {
			try {
				return activationDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String activationDate;

	@JsonIgnore
	private Supplier<String> _activationDateSupplier;

	@Schema
	public String[] getActiveProducts() {
		if (_activeProductsSupplier != null) {
			activeProducts = _activeProductsSupplier.get();

			_activeProductsSupplier = null;
		}

		return activeProducts;
	}

	public void setActiveProducts(String[] activeProducts) {
		this.activeProducts = activeProducts;

		_activeProductsSupplier = null;
	}

	@JsonIgnore
	public void setActiveProducts(
		UnsafeSupplier<String[], Exception> activeProductsUnsafeSupplier) {

		_activeProductsSupplier = () -> {
			try {
				return activeProductsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] activeProducts;

	@JsonIgnore
	private Supplier<String[]> _activeProductsSupplier;

	@Schema
	public String getCode() {
		if (_codeSupplier != null) {
			code = _codeSupplier.get();

			_codeSupplier = null;
		}

		return code;
	}

	public void setCode(String code) {
		this.code = code;

		_codeSupplier = null;
	}

	@JsonIgnore
	public void setCode(UnsafeSupplier<String, Exception> codeUnsafeSupplier) {
		_codeSupplier = () -> {
			try {
				return codeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String code;

	@JsonIgnore
	private Supplier<String> _codeSupplier;

	@Schema
	public String getDescription() {
		if (_descriptionSupplier != null) {
			description = _descriptionSupplier.get();

			_descriptionSupplier = null;
		}

		return description;
	}

	public void setDescription(String description) {
		this.description = description;

		_descriptionSupplier = null;
	}

	@JsonIgnore
	public void setDescription(
		UnsafeSupplier<String, Exception> descriptionUnsafeSupplier) {

		_descriptionSupplier = () -> {
			try {
				return descriptionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String description;

	@JsonIgnore
	private Supplier<String> _descriptionSupplier;

	@Schema
	public String getDisplayName() {
		if (_displayNameSupplier != null) {
			displayName = _displayNameSupplier.get();

			_displayNameSupplier = null;
		}

		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;

		_displayNameSupplier = null;
	}

	@JsonIgnore
	public void setDisplayName(
		UnsafeSupplier<String, Exception> displayNameUnsafeSupplier) {

		_displayNameSupplier = () -> {
			try {
				return displayNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String displayName;

	@JsonIgnore
	private Supplier<String> _displayNameSupplier;

	@Schema
	@Valid
	public ErrorMessage getErrorMessage() {
		if (_errorMessageSupplier != null) {
			errorMessage = _errorMessageSupplier.get();

			_errorMessageSupplier = null;
		}

		return errorMessage;
	}

	public void setErrorMessage(ErrorMessage errorMessage) {
		this.errorMessage = errorMessage;

		_errorMessageSupplier = null;
	}

	@JsonIgnore
	public void setErrorMessage(
		UnsafeSupplier<ErrorMessage, Exception> errorMessageUnsafeSupplier) {

		_errorMessageSupplier = () -> {
			try {
				return errorMessageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ErrorMessage errorMessage;

	@JsonIgnore
	private Supplier<ErrorMessage> _errorMessageSupplier;

	@Schema
	public String[] getErroredProducts() {
		if (_erroredProductsSupplier != null) {
			erroredProducts = _erroredProductsSupplier.get();

			_erroredProductsSupplier = null;
		}

		return erroredProducts;
	}

	public void setErroredProducts(String[] erroredProducts) {
		this.erroredProducts = erroredProducts;

		_erroredProductsSupplier = null;
	}

	@JsonIgnore
	public void setErroredProducts(
		UnsafeSupplier<String[], Exception> erroredProductsUnsafeSupplier) {

		_erroredProductsSupplier = () -> {
			try {
				return erroredProductsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] erroredProducts;

	@JsonIgnore
	private Supplier<String[]> _erroredProductsSupplier;

	@Schema
	@Valid
	public ExternalReference[] getExternalReference() {
		if (_externalReferenceSupplier != null) {
			externalReference = _externalReferenceSupplier.get();

			_externalReferenceSupplier = null;
		}

		return externalReference;
	}

	public void setExternalReference(ExternalReference[] externalReference) {
		this.externalReference = externalReference;

		_externalReferenceSupplier = null;
	}

	@JsonIgnore
	public void setExternalReference(
		UnsafeSupplier<ExternalReference[], Exception>
			externalReferenceUnsafeSupplier) {

		_externalReferenceSupplier = () -> {
			try {
				return externalReferenceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ExternalReference[] externalReference;

	@JsonIgnore
	private Supplier<ExternalReference[]> _externalReferenceSupplier;

	@Schema
	public String getFamilyName() {
		if (_familyNameSupplier != null) {
			familyName = _familyNameSupplier.get();

			_familyNameSupplier = null;
		}

		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;

		_familyNameSupplier = null;
	}

	@JsonIgnore
	public void setFamilyName(
		UnsafeSupplier<String, Exception> familyNameUnsafeSupplier) {

		_familyNameSupplier = () -> {
			try {
				return familyNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String familyName;

	@JsonIgnore
	private Supplier<String> _familyNameSupplier;

	@Schema
	public String getFormattedName() {
		if (_formattedNameSupplier != null) {
			formattedName = _formattedNameSupplier.get();

			_formattedNameSupplier = null;
		}

		return formattedName;
	}

	public void setFormattedName(String formattedName) {
		this.formattedName = formattedName;

		_formattedNameSupplier = null;
	}

	@JsonIgnore
	public void setFormattedName(
		UnsafeSupplier<String, Exception> formattedNameUnsafeSupplier) {

		_formattedNameSupplier = () -> {
			try {
				return formattedNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String formattedName;

	@JsonIgnore
	private Supplier<String> _formattedNameSupplier;

	@Schema
	public String getFullName() {
		if (_fullNameSupplier != null) {
			fullName = _fullNameSupplier.get();

			_fullNameSupplier = null;
		}

		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;

		_fullNameSupplier = null;
	}

	@JsonIgnore
	public void setFullName(
		UnsafeSupplier<String, Exception> fullNameUnsafeSupplier) {

		_fullNameSupplier = () -> {
			try {
				return fullNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fullName;

	@JsonIgnore
	private Supplier<String> _fullNameSupplier;

	@Schema
	public String getGender() {
		if (_genderSupplier != null) {
			gender = _genderSupplier.get();

			_genderSupplier = null;
		}

		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;

		_genderSupplier = null;
	}

	@JsonIgnore
	public void setGender(
		UnsafeSupplier<String, Exception> genderUnsafeSupplier) {

		_genderSupplier = () -> {
			try {
				return genderUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String gender;

	@JsonIgnore
	private Supplier<String> _genderSupplier;

	@Schema
	public String getGivenName() {
		if (_givenNameSupplier != null) {
			givenName = _givenNameSupplier.get();

			_givenNameSupplier = null;
		}

		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;

		_givenNameSupplier = null;
	}

	@JsonIgnore
	public void setGivenName(
		UnsafeSupplier<String, Exception> givenNameUnsafeSupplier) {

		_givenNameSupplier = () -> {
			try {
				return givenNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String givenName;

	@JsonIgnore
	private Supplier<String> _givenNameSupplier;

	@Schema
	public String getGranterEmail() {
		if (_granterEmailSupplier != null) {
			granterEmail = _granterEmailSupplier.get();

			_granterEmailSupplier = null;
		}

		return granterEmail;
	}

	public void setGranterEmail(String granterEmail) {
		this.granterEmail = granterEmail;

		_granterEmailSupplier = null;
	}

	@JsonIgnore
	public void setGranterEmail(
		UnsafeSupplier<String, Exception> granterEmailUnsafeSupplier) {

		_granterEmailSupplier = () -> {
			try {
				return granterEmailUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String granterEmail;

	@JsonIgnore
	private Supplier<String> _granterEmailSupplier;

	@Schema
	public String getHref() {
		if (_hrefSupplier != null) {
			href = _hrefSupplier.get();

			_hrefSupplier = null;
		}

		return href;
	}

	public void setHref(String href) {
		this.href = href;

		_hrefSupplier = null;
	}

	@JsonIgnore
	public void setHref(UnsafeSupplier<String, Exception> hrefUnsafeSupplier) {
		_hrefSupplier = () -> {
			try {
				return hrefUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String href;

	@JsonIgnore
	private Supplier<String> _hrefSupplier;

	@Schema
	public String getId() {
		if (_idSupplier != null) {
			id = _idSupplier.get();

			_idSupplier = null;
		}

		return id;
	}

	public void setId(String id) {
		this.id = id;

		_idSupplier = null;
	}

	@JsonIgnore
	public void setId(UnsafeSupplier<String, Exception> idUnsafeSupplier) {
		_idSupplier = () -> {
			try {
				return idUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String id;

	@JsonIgnore
	private Supplier<String> _idSupplier;

	@Schema
	public Boolean getIsAccountDisabled() {
		if (_isAccountDisabledSupplier != null) {
			isAccountDisabled = _isAccountDisabledSupplier.get();

			_isAccountDisabledSupplier = null;
		}

		return isAccountDisabled;
	}

	public void setIsAccountDisabled(Boolean isAccountDisabled) {
		this.isAccountDisabled = isAccountDisabled;

		_isAccountDisabledSupplier = null;
	}

	@JsonIgnore
	public void setIsAccountDisabled(
		UnsafeSupplier<Boolean, Exception> isAccountDisabledUnsafeSupplier) {

		_isAccountDisabledSupplier = () -> {
			try {
				return isAccountDisabledUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isAccountDisabled;

	@JsonIgnore
	private Supplier<Boolean> _isAccountDisabledSupplier;

	@Schema
	public Boolean getIsEmailOtpDisabled() {
		if (_isEmailOtpDisabledSupplier != null) {
			isEmailOtpDisabled = _isEmailOtpDisabledSupplier.get();

			_isEmailOtpDisabledSupplier = null;
		}

		return isEmailOtpDisabled;
	}

	public void setIsEmailOtpDisabled(Boolean isEmailOtpDisabled) {
		this.isEmailOtpDisabled = isEmailOtpDisabled;

		_isEmailOtpDisabledSupplier = null;
	}

	@JsonIgnore
	public void setIsEmailOtpDisabled(
		UnsafeSupplier<Boolean, Exception> isEmailOtpDisabledUnsafeSupplier) {

		_isEmailOtpDisabledSupplier = () -> {
			try {
				return isEmailOtpDisabledUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isEmailOtpDisabled;

	@JsonIgnore
	private Supplier<Boolean> _isEmailOtpDisabledSupplier;

	@Schema
	public String getLegalName() {
		if (_legalNameSupplier != null) {
			legalName = _legalNameSupplier.get();

			_legalNameSupplier = null;
		}

		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;

		_legalNameSupplier = null;
	}

	@JsonIgnore
	public void setLegalName(
		UnsafeSupplier<String, Exception> legalNameUnsafeSupplier) {

		_legalNameSupplier = () -> {
			try {
				return legalNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String legalName;

	@JsonIgnore
	private Supplier<String> _legalNameSupplier;

	@Schema
	public String getLineManager() {
		if (_lineManagerSupplier != null) {
			lineManager = _lineManagerSupplier.get();

			_lineManagerSupplier = null;
		}

		return lineManager;
	}

	public void setLineManager(String lineManager) {
		this.lineManager = lineManager;

		_lineManagerSupplier = null;
	}

	@JsonIgnore
	public void setLineManager(
		UnsafeSupplier<String, Exception> lineManagerUnsafeSupplier) {

		_lineManagerSupplier = () -> {
			try {
				return lineManagerUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lineManager;

	@JsonIgnore
	private Supplier<String> _lineManagerSupplier;

	@Schema
	public String getLocale() {
		if (_localeSupplier != null) {
			locale = _localeSupplier.get();

			_localeSupplier = null;
		}

		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;

		_localeSupplier = null;
	}

	@JsonIgnore
	public void setLocale(
		UnsafeSupplier<String, Exception> localeUnsafeSupplier) {

		_localeSupplier = () -> {
			try {
				return localeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String locale;

	@JsonIgnore
	private Supplier<String> _localeSupplier;

	@Schema
	public String getMessage() {
		if (_messageSupplier != null) {
			message = _messageSupplier.get();

			_messageSupplier = null;
		}

		return message;
	}

	public void setMessage(String message) {
		this.message = message;

		_messageSupplier = null;
	}

	@JsonIgnore
	public void setMessage(
		UnsafeSupplier<String, Exception> messageUnsafeSupplier) {

		_messageSupplier = () -> {
			try {
				return messageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String message;

	@JsonIgnore
	private Supplier<String> _messageSupplier;

	@Schema
	public String getMiddleName() {
		if (_middleNameSupplier != null) {
			middleName = _middleNameSupplier.get();

			_middleNameSupplier = null;
		}

		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;

		_middleNameSupplier = null;
	}

	@JsonIgnore
	public void setMiddleName(
		UnsafeSupplier<String, Exception> middleNameUnsafeSupplier) {

		_middleNameSupplier = () -> {
			try {
				return middleNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String middleName;

	@JsonIgnore
	private Supplier<String> _middleNameSupplier;

	@Schema
	public String getNickName() {
		if (_nickNameSupplier != null) {
			nickName = _nickNameSupplier.get();

			_nickNameSupplier = null;
		}

		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;

		_nickNameSupplier = null;
	}

	@JsonIgnore
	public void setNickName(
		UnsafeSupplier<String, Exception> nickNameUnsafeSupplier) {

		_nickNameSupplier = () -> {
			try {
				return nickNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String nickName;

	@JsonIgnore
	private Supplier<String> _nickNameSupplier;

	@Schema
	@Valid
	public Note[] getNote() {
		if (_noteSupplier != null) {
			note = _noteSupplier.get();

			_noteSupplier = null;
		}

		return note;
	}

	public void setNote(Note[] note) {
		this.note = note;

		_noteSupplier = null;
	}

	@JsonIgnore
	public void setNote(UnsafeSupplier<Note[], Exception> noteUnsafeSupplier) {
		_noteSupplier = () -> {
			try {
				return noteUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Note[] note;

	@JsonIgnore
	private Supplier<Note[]> _noteSupplier;

	@Schema
	public String getPreferredLanguage() {
		if (_preferredLanguageSupplier != null) {
			preferredLanguage = _preferredLanguageSupplier.get();

			_preferredLanguageSupplier = null;
		}

		return preferredLanguage;
	}

	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;

		_preferredLanguageSupplier = null;
	}

	@JsonIgnore
	public void setPreferredLanguage(
		UnsafeSupplier<String, Exception> preferredLanguageUnsafeSupplier) {

		_preferredLanguageSupplier = () -> {
			try {
				return preferredLanguageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String preferredLanguage;

	@JsonIgnore
	private Supplier<String> _preferredLanguageSupplier;

	@Schema
	@Valid
	public UserProduct[] getProduct() {
		if (_productSupplier != null) {
			product = _productSupplier.get();

			_productSupplier = null;
		}

		return product;
	}

	public void setProduct(UserProduct[] product) {
		this.product = product;

		_productSupplier = null;
	}

	@JsonIgnore
	public void setProduct(
		UnsafeSupplier<UserProduct[], Exception> productUnsafeSupplier) {

		_productSupplier = () -> {
			try {
				return productUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected UserProduct[] product;

	@JsonIgnore
	private Supplier<UserProduct[]> _productSupplier;

	@Schema
	public String getReason() {
		if (_reasonSupplier != null) {
			reason = _reasonSupplier.get();

			_reasonSupplier = null;
		}

		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;

		_reasonSupplier = null;
	}

	@JsonIgnore
	public void setReason(
		UnsafeSupplier<String, Exception> reasonUnsafeSupplier) {

		_reasonSupplier = () -> {
			try {
				return reasonUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String reason;

	@JsonIgnore
	private Supplier<String> _reasonSupplier;

	@Schema
	@Valid
	public RelatedParty[] getRelatedParty() {
		if (_relatedPartySupplier != null) {
			relatedParty = _relatedPartySupplier.get();

			_relatedPartySupplier = null;
		}

		return relatedParty;
	}

	public void setRelatedParty(RelatedParty[] relatedParty) {
		this.relatedParty = relatedParty;

		_relatedPartySupplier = null;
	}

	@JsonIgnore
	public void setRelatedParty(
		UnsafeSupplier<RelatedParty[], Exception> relatedPartyUnsafeSupplier) {

		_relatedPartySupplier = () -> {
			try {
				return relatedPartyUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected RelatedParty[] relatedParty;

	@JsonIgnore
	private Supplier<RelatedParty[]> _relatedPartySupplier;

	@Schema
	@Valid
	public UserRole[] getRole() {
		if (_roleSupplier != null) {
			role = _roleSupplier.get();

			_roleSupplier = null;
		}

		return role;
	}

	public void setRole(UserRole[] role) {
		this.role = role;

		_roleSupplier = null;
	}

	@JsonIgnore
	public void setRole(
		UnsafeSupplier<UserRole[], Exception> roleUnsafeSupplier) {

		_roleSupplier = () -> {
			try {
				return roleUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected UserRole[] role;

	@JsonIgnore
	private Supplier<UserRole[]> _roleSupplier;

	@Schema
	@Valid
	public ServiceInventory[] getServiceInventory() {
		if (_serviceInventorySupplier != null) {
			serviceInventory = _serviceInventorySupplier.get();

			_serviceInventorySupplier = null;
		}

		return serviceInventory;
	}

	public void setServiceInventory(ServiceInventory[] serviceInventory) {
		this.serviceInventory = serviceInventory;

		_serviceInventorySupplier = null;
	}

	@JsonIgnore
	public void setServiceInventory(
		UnsafeSupplier<ServiceInventory[], Exception>
			serviceInventoryUnsafeSupplier) {

		_serviceInventorySupplier = () -> {
			try {
				return serviceInventoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ServiceInventory[] serviceInventory;

	@JsonIgnore
	private Supplier<ServiceInventory[]> _serviceInventorySupplier;

	@Schema
	public String getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@JsonIgnore
	private Supplier<String> _statusSupplier;

	@Schema
	public String getTimestamp() {
		if (_timestampSupplier != null) {
			timestamp = _timestampSupplier.get();

			_timestampSupplier = null;
		}

		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;

		_timestampSupplier = null;
	}

	@JsonIgnore
	public void setTimestamp(
		UnsafeSupplier<String, Exception> timestampUnsafeSupplier) {

		_timestampSupplier = () -> {
			try {
				return timestampUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String timestamp;

	@JsonIgnore
	private Supplier<String> _timestampSupplier;

	@Schema
	public String getTimezone() {
		if (_timezoneSupplier != null) {
			timezone = _timezoneSupplier.get();

			_timezoneSupplier = null;
		}

		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;

		_timezoneSupplier = null;
	}

	@JsonIgnore
	public void setTimezone(
		UnsafeSupplier<String, Exception> timezoneUnsafeSupplier) {

		_timezoneSupplier = () -> {
			try {
				return timezoneUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String timezone;

	@JsonIgnore
	private Supplier<String> _timezoneSupplier;

	@Schema
	public String getTitle() {
		if (_titleSupplier != null) {
			title = _titleSupplier.get();

			_titleSupplier = null;
		}

		return title;
	}

	public void setTitle(String title) {
		this.title = title;

		_titleSupplier = null;
	}

	@JsonIgnore
	public void setTitle(
		UnsafeSupplier<String, Exception> titleUnsafeSupplier) {

		_titleSupplier = () -> {
			try {
				return titleUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String title;

	@JsonIgnore
	private Supplier<String> _titleSupplier;

	@Schema
	@Valid
	public UserCharacteristic[] getUserCharacteristic() {
		if (_userCharacteristicSupplier != null) {
			userCharacteristic = _userCharacteristicSupplier.get();

			_userCharacteristicSupplier = null;
		}

		return userCharacteristic;
	}

	public void setUserCharacteristic(UserCharacteristic[] userCharacteristic) {
		this.userCharacteristic = userCharacteristic;

		_userCharacteristicSupplier = null;
	}

	@JsonIgnore
	public void setUserCharacteristic(
		UnsafeSupplier<UserCharacteristic[], Exception>
			userCharacteristicUnsafeSupplier) {

		_userCharacteristicSupplier = () -> {
			try {
				return userCharacteristicUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected UserCharacteristic[] userCharacteristic;

	@JsonIgnore
	private Supplier<UserCharacteristic[]> _userCharacteristicSupplier;

	@Schema
	public String getUserName() {
		if (_userNameSupplier != null) {
			userName = _userNameSupplier.get();

			_userNameSupplier = null;
		}

		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;

		_userNameSupplier = null;
	}

	@JsonIgnore
	public void setUserName(
		UnsafeSupplier<String, Exception> userNameUnsafeSupplier) {

		_userNameSupplier = () -> {
			try {
				return userNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userName;

	@JsonIgnore
	private Supplier<String> _userNameSupplier;

	@Schema
	public String getUserType() {
		if (_userTypeSupplier != null) {
			userType = _userTypeSupplier.get();

			_userTypeSupplier = null;
		}

		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;

		_userTypeSupplier = null;
	}

	@JsonIgnore
	public void setUserType(
		UnsafeSupplier<String, Exception> userTypeUnsafeSupplier) {

		_userTypeSupplier = () -> {
			try {
				return userTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userType;

	@JsonIgnore
	private Supplier<String> _userTypeSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CurveUser)) {
			return false;
		}

		CurveUser curveUser = (CurveUser)object;

		return Objects.equals(toString(), curveUser.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String activationDate = getActivationDate();

		if (activationDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"activationDate\": ");

			sb.append("\"");

			sb.append(_escape(activationDate));

			sb.append("\"");
		}

		String[] activeProducts = getActiveProducts();

		if (activeProducts != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"activeProducts\": ");

			sb.append("[");

			for (int i = 0; i < activeProducts.length; i++) {
				sb.append("\"");

				sb.append(_escape(activeProducts[i]));

				sb.append("\"");

				if ((i + 1) < activeProducts.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String code = getCode();

		if (code != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"code\": ");

			sb.append("\"");

			sb.append(_escape(code));

			sb.append("\"");
		}

		String description = getDescription();

		if (description != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(description));

			sb.append("\"");
		}

		String displayName = getDisplayName();

		if (displayName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"displayName\": ");

			sb.append("\"");

			sb.append(_escape(displayName));

			sb.append("\"");
		}

		ErrorMessage errorMessage = getErrorMessage();

		if (errorMessage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"errorMessage\": ");

			sb.append(String.valueOf(errorMessage));
		}

		String[] erroredProducts = getErroredProducts();

		if (erroredProducts != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"erroredProducts\": ");

			sb.append("[");

			for (int i = 0; i < erroredProducts.length; i++) {
				sb.append("\"");

				sb.append(_escape(erroredProducts[i]));

				sb.append("\"");

				if ((i + 1) < erroredProducts.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		ExternalReference[] externalReference = getExternalReference();

		if (externalReference != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"externalReference\": ");

			sb.append("[");

			for (int i = 0; i < externalReference.length; i++) {
				sb.append(String.valueOf(externalReference[i]));

				if ((i + 1) < externalReference.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String familyName = getFamilyName();

		if (familyName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"familyName\": ");

			sb.append("\"");

			sb.append(_escape(familyName));

			sb.append("\"");
		}

		String formattedName = getFormattedName();

		if (formattedName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"formattedName\": ");

			sb.append("\"");

			sb.append(_escape(formattedName));

			sb.append("\"");
		}

		String fullName = getFullName();

		if (fullName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fullName\": ");

			sb.append("\"");

			sb.append(_escape(fullName));

			sb.append("\"");
		}

		String gender = getGender();

		if (gender != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"gender\": ");

			sb.append("\"");

			sb.append(_escape(gender));

			sb.append("\"");
		}

		String givenName = getGivenName();

		if (givenName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"givenName\": ");

			sb.append("\"");

			sb.append(_escape(givenName));

			sb.append("\"");
		}

		String granterEmail = getGranterEmail();

		if (granterEmail != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"granterEmail\": ");

			sb.append("\"");

			sb.append(_escape(granterEmail));

			sb.append("\"");
		}

		String href = getHref();

		if (href != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"href\": ");

			sb.append("\"");

			sb.append(_escape(href));

			sb.append("\"");
		}

		String id = getId();

		if (id != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"id\": ");

			sb.append("\"");

			sb.append(_escape(id));

			sb.append("\"");
		}

		Boolean isAccountDisabled = getIsAccountDisabled();

		if (isAccountDisabled != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isAccountDisabled\": ");

			sb.append(isAccountDisabled);
		}

		Boolean isEmailOtpDisabled = getIsEmailOtpDisabled();

		if (isEmailOtpDisabled != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isEmailOtpDisabled\": ");

			sb.append(isEmailOtpDisabled);
		}

		String legalName = getLegalName();

		if (legalName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"legalName\": ");

			sb.append("\"");

			sb.append(_escape(legalName));

			sb.append("\"");
		}

		String lineManager = getLineManager();

		if (lineManager != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lineManager\": ");

			sb.append("\"");

			sb.append(_escape(lineManager));

			sb.append("\"");
		}

		String locale = getLocale();

		if (locale != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"locale\": ");

			sb.append("\"");

			sb.append(_escape(locale));

			sb.append("\"");
		}

		String message = getMessage();

		if (message != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"message\": ");

			sb.append("\"");

			sb.append(_escape(message));

			sb.append("\"");
		}

		String middleName = getMiddleName();

		if (middleName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"middleName\": ");

			sb.append("\"");

			sb.append(_escape(middleName));

			sb.append("\"");
		}

		String nickName = getNickName();

		if (nickName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"nickName\": ");

			sb.append("\"");

			sb.append(_escape(nickName));

			sb.append("\"");
		}

		Note[] note = getNote();

		if (note != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"note\": ");

			sb.append("[");

			for (int i = 0; i < note.length; i++) {
				sb.append(String.valueOf(note[i]));

				if ((i + 1) < note.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String preferredLanguage = getPreferredLanguage();

		if (preferredLanguage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"preferredLanguage\": ");

			sb.append("\"");

			sb.append(_escape(preferredLanguage));

			sb.append("\"");
		}

		UserProduct[] product = getProduct();

		if (product != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"product\": ");

			sb.append("[");

			for (int i = 0; i < product.length; i++) {
				sb.append(String.valueOf(product[i]));

				if ((i + 1) < product.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String reason = getReason();

		if (reason != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"reason\": ");

			sb.append("\"");

			sb.append(_escape(reason));

			sb.append("\"");
		}

		RelatedParty[] relatedParty = getRelatedParty();

		if (relatedParty != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"relatedParty\": ");

			sb.append("[");

			for (int i = 0; i < relatedParty.length; i++) {
				sb.append(String.valueOf(relatedParty[i]));

				if ((i + 1) < relatedParty.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		UserRole[] role = getRole();

		if (role != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"role\": ");

			sb.append("[");

			for (int i = 0; i < role.length; i++) {
				sb.append(String.valueOf(role[i]));

				if ((i + 1) < role.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		ServiceInventory[] serviceInventory = getServiceInventory();

		if (serviceInventory != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"serviceInventory\": ");

			sb.append("[");

			for (int i = 0; i < serviceInventory.length; i++) {
				sb.append(String.valueOf(serviceInventory[i]));

				if ((i + 1) < serviceInventory.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		String timestamp = getTimestamp();

		if (timestamp != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"timestamp\": ");

			sb.append("\"");

			sb.append(_escape(timestamp));

			sb.append("\"");
		}

		String timezone = getTimezone();

		if (timezone != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"timezone\": ");

			sb.append("\"");

			sb.append(_escape(timezone));

			sb.append("\"");
		}

		String title = getTitle();

		if (title != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"title\": ");

			sb.append("\"");

			sb.append(_escape(title));

			sb.append("\"");
		}

		UserCharacteristic[] userCharacteristic = getUserCharacteristic();

		if (userCharacteristic != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userCharacteristic\": ");

			sb.append("[");

			for (int i = 0; i < userCharacteristic.length; i++) {
				sb.append(String.valueOf(userCharacteristic[i]));

				if ((i + 1) < userCharacteristic.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String userName = getUserName();

		if (userName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userName\": ");

			sb.append("\"");

			sb.append(_escape(userName));

			sb.append("\"");
		}

		String userType = getUserType();

		if (userType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userType\": ");

			sb.append("\"");

			sb.append(_escape(userType));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.curve.dto.v1_0.CurveUser",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}