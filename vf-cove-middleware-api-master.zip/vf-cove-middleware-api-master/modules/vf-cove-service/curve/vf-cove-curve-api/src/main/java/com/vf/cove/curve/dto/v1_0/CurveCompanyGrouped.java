package com.vf.cove.curve.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Curve team
 * @generated
 */
@Generated("")
@GraphQLName("CurveCompanyGrouped")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CurveCompanyGrouped")
public class CurveCompanyGrouped implements Serializable {

	public static CurveCompanyGrouped toDTO(String json) {
		return ObjectMapperUtil.readValue(CurveCompanyGrouped.class, json);
	}

	public static CurveCompanyGrouped unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			CurveCompanyGrouped.class, json);
	}

	@Schema
	@Valid
	public CurveCompany[] getCompanies() {
		if (_companiesSupplier != null) {
			companies = _companiesSupplier.get();

			_companiesSupplier = null;
		}

		return companies;
	}

	public void setCompanies(CurveCompany[] companies) {
		this.companies = companies;

		_companiesSupplier = null;
	}

	@JsonIgnore
	public void setCompanies(
		UnsafeSupplier<CurveCompany[], Exception> companiesUnsafeSupplier) {

		_companiesSupplier = () -> {
			try {
				return companiesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected CurveCompany[] companies;

	@JsonIgnore
	private Supplier<CurveCompany[]> _companiesSupplier;

	@Schema
	public String getCompanyName() {
		if (_companyNameSupplier != null) {
			companyName = _companyNameSupplier.get();

			_companyNameSupplier = null;
		}

		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;

		_companyNameSupplier = null;
	}

	@JsonIgnore
	public void setCompanyName(
		UnsafeSupplier<String, Exception> companyNameUnsafeSupplier) {

		_companyNameSupplier = () -> {
			try {
				return companyNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String companyName;

	@JsonIgnore
	private Supplier<String> _companyNameSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CurveCompanyGrouped)) {
			return false;
		}

		CurveCompanyGrouped curveCompanyGrouped = (CurveCompanyGrouped)object;

		return Objects.equals(toString(), curveCompanyGrouped.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		CurveCompany[] companies = getCompanies();

		if (companies != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"companies\": ");

			sb.append("[");

			for (int i = 0; i < companies.length; i++) {
				sb.append(String.valueOf(companies[i]));

				if ((i + 1) < companies.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String companyName = getCompanyName();

		if (companyName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"companyName\": ");

			sb.append("\"");

			sb.append(_escape(companyName));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.curve.dto.v1_0.CurveCompanyGrouped",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}