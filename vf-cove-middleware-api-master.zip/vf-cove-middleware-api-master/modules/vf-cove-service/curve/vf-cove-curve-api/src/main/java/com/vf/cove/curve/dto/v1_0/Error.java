package com.vf.cove.curve.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;
/* if the code fails add the import javax.lang.model.type.ErrorType; back */
import javax.lang.model.type.ErrorType;

/**
 * @author Curve team
 * @generated
 */
@Generated("")
@GraphQLName("Error")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Error")
public class Error implements Serializable {

	public static Error toDTO(String json) {
		return ObjectMapperUtil.readValue(Error.class, json);
	}

	public static Error unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Error.class, json);
	}

	@Schema
	public String getColumn() {
		if (_ColumnSupplier != null) {
			Column = _ColumnSupplier.get();

			_ColumnSupplier = null;
		}

		return Column;
	}

	public void setColumn(String Column) {
		this.Column = Column;

		_ColumnSupplier = null;
	}

	@JsonIgnore
	public void setColumn(
		UnsafeSupplier<String, Exception> ColumnUnsafeSupplier) {

		_ColumnSupplier = () -> {
			try {
				return ColumnUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String Column;

	@JsonIgnore
	private Supplier<String> _ColumnSupplier;

	@Schema
	public String getErrorMessage() {
		if (_errorMessageSupplier != null) {
			errorMessage = _errorMessageSupplier.get();

			_errorMessageSupplier = null;
		}

		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;

		_errorMessageSupplier = null;
	}

	@JsonIgnore
	public void setErrorMessage(
		UnsafeSupplier<String, Exception> errorMessageUnsafeSupplier) {

		_errorMessageSupplier = () -> {
			try {
				return errorMessageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String errorMessage;

	@JsonIgnore
	private Supplier<String> _errorMessageSupplier;

	@Schema
	@Valid
	public ErrorType getErrorType() {
		if (_errorTypeSupplier != null) {
			errorType = _errorTypeSupplier.get();

			_errorTypeSupplier = null;
		}

		return errorType;
	}

	public void setErrorType(ErrorType errorType) {
		this.errorType = errorType;

		_errorTypeSupplier = null;
	}

	@JsonIgnore
	public void setErrorType(
		UnsafeSupplier<ErrorType, Exception> errorTypeUnsafeSupplier) {

		_errorTypeSupplier = () -> {
			try {
				return errorTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ErrorType errorType;

	@JsonIgnore
	private Supplier<ErrorType> _errorTypeSupplier;

	@Schema
	public Integer getRow() {
		if (_rowSupplier != null) {
			row = _rowSupplier.get();

			_rowSupplier = null;
		}

		return row;
	}

	public void setRow(Integer row) {
		this.row = row;

		_rowSupplier = null;
	}

	@JsonIgnore
	public void setRow(UnsafeSupplier<Integer, Exception> rowUnsafeSupplier) {
		_rowSupplier = () -> {
			try {
				return rowUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer row;

	@JsonIgnore
	private Supplier<Integer> _rowSupplier;

	@Schema
	public String getValue() {
		if (_valueSupplier != null) {
			value = _valueSupplier.get();

			_valueSupplier = null;
		}

		return value;
	}

	public void setValue(String value) {
		this.value = value;

		_valueSupplier = null;
	}

	@JsonIgnore
	public void setValue(
		UnsafeSupplier<String, Exception> valueUnsafeSupplier) {

		_valueSupplier = () -> {
			try {
				return valueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String value;

	@JsonIgnore
	private Supplier<String> _valueSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Error)) {
			return false;
		}

		Error error = (Error)object;

		return Objects.equals(toString(), error.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String Column = getColumn();

		if (Column != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Column\": ");

			sb.append("\"");

			sb.append(_escape(Column));

			sb.append("\"");
		}

		String errorMessage = getErrorMessage();

		if (errorMessage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"errorMessage\": ");

			sb.append("\"");

			sb.append(_escape(errorMessage));

			sb.append("\"");
		}

		ErrorType errorType = getErrorType();

		if (errorType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"errorType\": ");

			sb.append(errorType);
		}

		Integer row = getRow();

		if (row != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"row\": ");

			sb.append(row);
		}

		String value = getValue();

		if (value != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"value\": ");

			sb.append("\"");

			sb.append(_escape(value));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.curve.dto.v1_0.Error", name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}
