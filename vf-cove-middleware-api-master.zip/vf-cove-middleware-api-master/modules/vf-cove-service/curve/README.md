# Module CURVE

---
## Red Flex Multiple User Creation Template
The XLSM template file is versioned in the middleware repo, in this location:
`modules/vf-cove-service/curve/vf-cove-curve-impl/src/main/resources/Red Flex Multiple User Creation template.xlsm`

> Whenever file is being updated, version number from the `Instructions` sheet is increasesd manually, in the XLSM file.
![img.png](vf-cove-curve-impl/src/main/resources/static/template-version.png)Red Flex Multiple User Creation Template.xlsm

## Endpoints

### vf-cove-curve/1.0/company
When doing local development with
- /o/vf-cove-curve/1.0/company/upload/userGroups
- /o/vf-cove-curve/1.0/company/UserGroups?companyName=BYOx20CompNonFedSITUK&country=GB

first create the folder structure `'data/uploads'` in the root of the project.

