package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.BulkUserValidationResponse;
import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.internal.client.CurveUserClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.BulkUserValidationDTO;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.model.ErrorTypeEnum;
import com.vf.cove.curve.internal.model.UserDTO;
import com.vf.cove.curve.internal.utils.BulkUserValidationUtil;
import org.apache.commons.codec.binary.Base64InputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.TestUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Disabled
@ExtendWith(MockitoExtension.class)
public class BulkUserValidationServiceCSVTest {

    static String VALID_FILE_PATH = "src/test/resources/template/csv/Red Flex Bulk User-v0.1.csv";
    static String INVALID_STRUCTURE_FILE_PATH = "src/test/resources/template/csv/Red Flex Bulk User-v0.1-Invalid-Structure.csv";
    static String INVALID_DATA_FILE_PATH = "src/test/resources/template/csv/Red Flex Bulk User-v0.1-Invalid-Data.csv";

    @InjectMocks
    BulkUserValidationService bulkUserValidationService;

    @Mock
    CurveApiConfiguration curveApiConfiguration;

    @Mock
    BulkUserValidationUtil bulkUserValidationUtilMock;

    @Mock
    private CurveUserClient userClientMock;

    @Mock
    CurveHttpRequestDTO httpRequestDTO;

    @Mock
    List<CurveUser> createUserResponseFixture;

    CurveUser[] createUserRequestFixture;

    String filePath = "src/test/resources/";

    String createUserResponseFileName = "curve-create-user-response.json";

    String createUserRequestFileName = "curve-create-user-request.json";

    BulkUserValidationDTO validationDTOFixture;

    List<CurveUser> curveUserFixture;

    Error error1;

    UserDTO userDTO;

    CurveUser curveUser;

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);

        error1 = new Error();
        error1.setErrorMessage("Please provide the latest template version");

        httpRequestDTO = new CurveHttpRequestDTO();
        httpRequestDTO.setGranterEmail("mukesh.Kumar@abc");
        httpRequestDTO.setOrgId("71e25cb2-2d96-4b4e-88a8-17b7d6e1dcad");
        httpRequestDTO.setCiamToken("asdfdgfhg");
        httpRequestDTO.setDxlToken("DFSDGFG");

        createUserRequestFixture = TestUtils.getCreateUserRequest(filePath + createUserRequestFileName);
        createUserResponseFixture = TestUtils.getCurveResponseList(filePath + createUserResponseFileName, CurveUser.class);

        userDTO = new UserDTO();
        userDTO.setEmail("test@vodafone.com");
        userDTO.setRowIndex(6);

        validationDTOFixture = new BulkUserValidationDTO();
        validationDTOFixture.setUserList(Arrays.asList(userDTO));
        validationDTOFixture.setErrorList(new ArrayList<>());

        curveUser = new CurveUser();
        curveUser.setUserName("test name");
        curveUserFixture = Arrays.asList(curveUser);


    }

    @Disabled
    @Test
    void validaBulkUserSubmittedFile_ValidFileStructureAndData() throws IOException {

        when(bulkUserValidationUtilMock.validateBulkUserFile(any(), any())).thenReturn(validationDTOFixture);
        when(bulkUserValidationUtilMock.mapToCurveUser(Arrays.asList(userDTO), Collections.emptyMap())).thenReturn(Arrays.asList(curveUser));
        when(userClientMock.createUser(curveUserFixture.stream().toArray(CurveUser[]::new), httpRequestDTO)).thenReturn(curveUserFixture);

        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(new FileInputStream(VALID_FILE_PATH), new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertEquals(true, response.getIsValid());
        assertEquals(false, response.getIsStructureError());
        assertEquals(0, response.getInvalidUserCount());
        assertEquals(1, response.getValidUserCount());

    }

    @Test
    void validaBulkUserSubmittedFile_InvalidFileStructure() throws IOException {
        final InputStream inputStream = Files.newInputStream(Paths.get(INVALID_STRUCTURE_FILE_PATH));
//        final InputStream encodedInputStream = new Base64InputStream(inputStream, true);

        Error error = new Error();
        error.setErrorMessage(" Column First Name not found. Please ensure you are using the latest template");
        error.setValue("");
        error.setErrorType(ErrorTypeEnum.FILE_STRUCTURE);

        validationDTOFixture.setErrorList(Arrays.asList(error));
        when(bulkUserValidationUtilMock.validateBulkUserFile(any(), any())).thenReturn(validationDTOFixture);

        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(inputStream, new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertEquals(false, response.getIsValid());
        assertEquals(true, response.getIsStructureError());
        assertEquals(0, response.getInvalidUserCount());
        assertEquals(0, response.getValidUserCount());

    }

    @Test
    void validaBulkUserSubmittedFile_InValidFileData() throws IOException {
        final InputStream inputStream = Files.newInputStream(Paths.get(INVALID_DATA_FILE_PATH));
        final InputStream encodedInputStream = new Base64InputStream(inputStream, true);

        userDTO = new UserDTO();
        userDTO.setFirstName("");
        userDTO.setEmail("test@vodafone.com");
        userDTO.setRowIndex(6);

        validationDTOFixture.setUserList(Arrays.asList(userDTO));


        Error error = new Error();
        error.setErrorMessage(" First Name needs to be populated as it is a mandatory field");
        error.setValue("");
        error.setRow(6);
        error.setColumn("First Name");
        error.setErrorType(ErrorTypeEnum.FORMAT);

        validationDTOFixture.setErrorList(Arrays.asList(error));
        when(bulkUserValidationUtilMock.validateBulkUserFile(any(), any())).thenReturn(validationDTOFixture);

        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(inputStream, new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertEquals(false, response.getIsValid());
        assertEquals(false, response.getIsStructureError());
        assertEquals(1, response.getInvalidUserCount());
        assertEquals(0, response.getValidUserCount());

    }


}
