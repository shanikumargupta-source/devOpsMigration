package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.CurveProduct;
import com.vf.cove.curve.internal.client.CurveProductClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.TestUtils;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CurveProductServiceTest {

    @InjectMocks
    private CurveProductService productService;

    @InjectMocks
    CurveUtils curveUtils;

    @Mock
    private CurveProductClient productClient;

    @Mock
    private CurveApiConfiguration curveApiConfiguration;

    @Mock
    CurveHttpRequestDTO httpRequestDTO;

    @Mock
    List<CurveProduct> productListFixture;

    @Mock
    CurveProduct productFixture;

    String filePath = "src/test/resources/";

    String productListFileName = "curve-product-list-response.json";

    String productFileName = "curve-product-response.json";

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);
        productListFixture = TestUtils.getCurveResponseList(filePath + productListFileName, CurveProduct.class);
        productFixture = TestUtils.getCurveResponse(filePath + productFileName, CurveProduct.class);
        httpRequestDTO = new CurveHttpRequestDTO();
        httpRequestDTO.setOrgId("71e25cb2-2d96-4b4e-88a8-17b7d6e1dcad");
        httpRequestDTO.setDxlToken("DFSDGFG");
    }

    @Test
    void getProductListTest_Success() throws Exception {
        when(productClient.getProductList(httpRequestDTO)).thenReturn(productListFixture);
        List<CurveProduct> curveProducts = productService.getCurveProductList(httpRequestDTO);
        assertEquals(productListFixture, curveProducts);
    }

    @Test
    void getProductListTest_Failure() throws Exception {
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(500)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void getProductListTest_invalidAuthorizationHeader() throws Exception {
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void getProductListTest_NoAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken(null);
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void getProductListTest_NoOrgIdParameter() throws Exception {
        httpRequestDTO.setOrgId(null);
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(400)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void etProductListTest_InvalidOrgId() throws Exception {
        httpRequestDTO.setOrgId("xxx-yyy-zzz");
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(400)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void getProductListTest_Offset() throws Exception {
        httpRequestDTO.setOffset(1);
        when(productClient.getProductList(httpRequestDTO)).thenReturn(productListFixture);
        List<CurveProduct> products = productClient.getProductList(httpRequestDTO);
        assertEquals(productListFixture, products);
    }


    @Test
    void etProductListTest_InvalidOffset() throws Exception {
        httpRequestDTO.setOffset(5000000);
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(400)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void etProductListTest_Limit() throws Exception {
        httpRequestDTO.setLimit(1);
        when(productClient.getProductList(httpRequestDTO)).thenReturn(productListFixture);
        List<CurveProduct> products = productClient.getProductList(httpRequestDTO);
        assertEquals(productListFixture, products);
    }

    @Test
    void getProductListTest_InvalidLimit() throws Exception {
        httpRequestDTO.setLimit(5000000);
        when(productClient.getProductList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(400)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductList(httpRequestDTO);
        });
    }

    @Test
    void getProductByIdTest_Success() throws Exception {
        when(productClient.getProductById(httpRequestDTO)).thenReturn(productFixture);
        CurveProduct curveProduct = productService.getCurveProductById(httpRequestDTO);
        Assertions.assertThat(curveProduct.getId()).isEqualTo("CAFF102FFA69414BE053306F12C6C062");
    }

    @Test
    void getProductByIdTest_Failure() throws Exception {
        when(productClient.getProductById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(500)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductById(httpRequestDTO);
        });
    }

    @Test
    void getProductByIdTest_NoAuthorizationHeader() throws Exception {
        httpRequestDTO.setCiamToken(null);
        when(productClient.getProductById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductById(httpRequestDTO);
        });
    }

    @Test
    void getProductByIdTest_InvalidId() throws Exception {
        httpRequestDTO.setProductId("xxx-yyy-zzz");
        when(productClient.getProductById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            productClient.getProductById(httpRequestDTO);
        });
    }

}
