package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.BulkUserDownloadResponse;
import com.vf.cove.curve.dto.v1_0.BulkUserUploadResponse;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.TemplateNotFoundException;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class BulkUserTemplateServiceTest {

    static String EXCEL_FILE_PATH = "src/test/resources/template/excel/Red Flex Bulk User-v0.1.xlsx";
    static String WRONG_FILE_PATH = "src/test/";

    @InjectMocks
    BulkUserTemplateService bulkUserTemplateService;
    @Mock
    CurveApiConfiguration curveApiConfiguration;

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void uploadBulkUserTemplateTest_Success() throws IOException {
        when(curveApiConfiguration.liferayDataVolumePath()).thenReturn("");
        BulkUserUploadResponse response = bulkUserTemplateService.uploadFile(new FileInputStream(EXCEL_FILE_PATH), EXCEL_FILE_PATH);

        assertNotNull(response);
        assertEquals(HttpStatus.SC_CREATED, response.getStatus());
        assertEquals("The File is uploaded successfully" , response.getMessage());
    }

    @Test
    void uploadBulkUserTemplateTest_Failure() throws IOException {
        BulkUserUploadResponse response = bulkUserTemplateService.uploadFile(new FileInputStream(EXCEL_FILE_PATH), WRONG_FILE_PATH);

        assertNotNull(response);
        assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, response.getStatus());
        assertEquals("The system failed to upload the file" , response.getMessage());
    }

    @Test
    void uploadBulkUserTemplateTest_NoFileSelected() throws IOException {
        BulkUserUploadResponse response = bulkUserTemplateService.uploadFile(new ByteArrayInputStream(new byte[0]), EXCEL_FILE_PATH);

        assertNotNull(response);
        assertEquals(HttpStatus.SC_NOT_FOUND, response.getStatus());
        assertEquals("No file is selected" , response.getMessage());
    }

    @Test
    void uploadBulkUserTemplateTest_FileNotFoundException() {
        assertThrows(FileNotFoundException.class, () -> {
            bulkUserTemplateService.uploadFile(new FileInputStream(WRONG_FILE_PATH), EXCEL_FILE_PATH);
        });
    }

    @Test
    void downloadBulkUserTemplate_Success() throws IOException {
        when(curveApiConfiguration.liferayDataVolumePath()).thenReturn("");
        when(curveApiConfiguration.bulkUserFileName()).thenReturn(EXCEL_FILE_PATH);
        BulkUserDownloadResponse response = bulkUserTemplateService.downloadBulkUserTemplate();

        assertNotNull(response);
        assertFalse(response.getFile().isEmpty());
    }

    @Test
    void downloadBulkUserTemplate_TemplateNotFoundException() {
        when(curveApiConfiguration.bulkUserFileName()).thenReturn("some-wrong-file-name.xlsx");
        assertThrows(TemplateNotFoundException.class, () -> {
            bulkUserTemplateService.downloadBulkUserTemplate();
        });
    }

}
