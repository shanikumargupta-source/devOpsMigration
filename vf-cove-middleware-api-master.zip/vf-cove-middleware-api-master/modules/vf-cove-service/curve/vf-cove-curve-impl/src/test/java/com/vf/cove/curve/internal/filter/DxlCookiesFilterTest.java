package com.vf.cove.curve.internal.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.configuration.impl.CurveApiConfigurationImpl;
import com.vf.cove.curve.internal.model.CurveApigeeSuccessResponse;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.DxlAccessTokenService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import utils.TestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DxlCookiesFilterTest {

    private String TOKEN_TYPE = "Bearer";

    @InjectMocks
    private CurveDxlCookiesFilter curveDxlCookiesFilter;

    @Mock
    DxlAccessTokenService dxlAccessTokenService;

    @InjectMocks
    private CurveHttpRequestDTO requestDto;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    private FilterChain filterChain = new MockFilterChain();

    @Mock
    private CurveApiConfiguration curveApiConfiguration = new CurveApiConfigurationImpl();

    @Mock
    private List<String> cookiesNames;
    private CurveApigeeSuccessResponse successResponse;
    private static ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setUp() {
        cookiesNames = mockCookiesNames();
    }

    @Test
    void dxlCookieFilterNotEnabled() throws IOException, ServletException {
        when(curveApiConfiguration.isCurveDxlFilterEnabled()).thenReturn(false);
        when(request.getCookies()).thenReturn(mockCookiesWithCookiesNames(cookiesNames));
        curveDxlCookiesFilter.doFilter(request, response, filterChain);
        String authorizationHeader = request.getHeader(CurveConstant.DXL_TOKEN);
        Assertions.assertThat(authorizationHeader).isNullOrEmpty();
    }

    @Test
    void dxlCookieFilterEnabledAndTokenNotExistTest() throws IOException, ServletException {
        String successResponseBody = TestUtils.inputStreamToString("src/test/resources/curve-apigee-success-response.json");
        successResponse = objectMapper.readValue(successResponseBody, CurveApigeeSuccessResponse.class);
        when(curveApiConfiguration.isCurveDxlFilterEnabled()).thenReturn(true);
        when(request.getCookies()).thenReturn(new Cookie[0]);
        when(request.getHeaderNames()).thenReturn(Collections.emptyEnumeration());
        requestDto = new CurveHttpRequestDTO(CurveUtils.getHeadersAsMap(request), request, response);
        when(dxlAccessTokenService.getDxlAccessToken(requestDto)).thenReturn(successResponse);
        curveDxlCookiesFilter.doFilter(request, response, filterChain);
        MockFilterChain mockFilterChain = (MockFilterChain) filterChain;
        HttpServletRequest afterFilterRequest = (HttpServletRequest) mockFilterChain.getRequest();
        String authorizationHeader = afterFilterRequest.getHeader(CurveConstant.DXL_TOKEN);
        Assertions.assertThat(authorizationHeader).isNotEmpty().contains(TOKEN_TYPE);
    }

    @Test
    void dxlCookieFilterEnabledAndTokenExistTest() throws IOException, ServletException {
        when(curveApiConfiguration.isCurveDxlFilterEnabled()).thenReturn(true);
        when(request.getCookies()).thenReturn(mockCookiesWithCookiesNames(cookiesNames));
        curveDxlCookiesFilter.doFilter(request, response, filterChain);
        MockFilterChain mockFilterChain = (MockFilterChain) filterChain;
        HttpServletRequest afterFilterRequest = (HttpServletRequest) mockFilterChain.getRequest();
        String authorizationHeader = afterFilterRequest.getHeader(CurveConstant.DXL_TOKEN);
        Assertions.assertThat(authorizationHeader).isNotEmpty().contains(TOKEN_TYPE);
    }

    private static List<String> mockCookiesNames() {
        List<String> cookiesNames = new ArrayList<>();
        cookiesNames.add("JSESESSIONID");
        cookiesNames.add(CurveConstant.DXL_ACCESS_TOKEN_COOKIE);
        return cookiesNames;
    }

    private static Cookie[] mockCookiesWithCookiesNames(List<String> names) {
        List<Cookie> cookies = new ArrayList<>();
        for (String name : names) {
            Cookie tempCookie = new Cookie(name, UUID.randomUUID().toString());
            cookies.add(tempCookie);
        }
        return cookies.toArray(new Cookie[cookies.size()]);
    }

}
