package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.vf.cove.curve.dto.v1_0.CiamAccessToken;
import com.vf.cove.curve.internal.model.CiamAccessTokenDTO;
import com.vf.cove.curve.internal.service.CiamAccessTokenService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CiamAccessTokenResourceImplTest {

    @Mock
    private CiamAccessTokenService accessTokenService;
    @InjectMocks
    private CiamAccessTokenResourceImpl resource;

    @Test
    void getAccessToken() throws ConfigurationException {
        CiamAccessTokenDTO data = new CiamAccessTokenDTO();
        data.setAccessToken("7232203f-be6f-3616-92b1-54d0e462c843");
        data.setRefreshToken("36c5b7da-2953-36ea-b6c0-cf20e06d21e6");
        data.setScope("openid");
        data.setIdToken("eyJ4NXQiOiJOamhtTWpFNFpEQTNZMk5oTW1SallUSTROR1JoWW1JNE1tVTRPREZpWXpJNFltVTVOREkzWW1SaU5qTXlNMlF5WVRsbU4yWmpOamczWTJKbVpHRXhOQSIsImtpZCI6Ik5qaG1NakU0WkRBM1kyTmhNbVJqWVRJNE5HUmhZbUk0TW1VNE9ERmlZekk0WW1VNU5ESTNZbVJpTmpNeU0yUXlZVGxtTjJaak5qZzNZMkptWkdFeE5BX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJpc2siOiIzM2M1NGRiZmVlMzgwZTNmYjgyZDk3ZmM1NzM3ZDdiOGQ5NTc3NGY5YmQ3MWM1MTQxZTAzMWY5ODUzMWY2MDY5IiwiYXRfaGFzaCI6IklUVlJGX3VTQzBualBNWXJpOHIzVHciLCJhdWQiOiI1ZVpLZnFTcEpTRjJwZjRfaklYX1RRdEIzVG9hIiwiY19oYXNoIjoiaFdQZVJrb3Y2ak1uV2Jwa2pKa1NFdyIsInN1YiI6Ijk0ZmQzYjA2LTJjYjktNDdhMy1hMzlkLWFiYTA5ZGM1YmQ0NSIsIm5iZiI6MTcxODg5MTU1OCwiYXpwIjoiNWVaS2ZxU3BKU0YycGY0X2pJWF9UUXRCM1RvYSIsImFtciI6WyJTZXNzaW9uRXhlY3V0b3IiLCJFbWFpbE9UUCIsImN1c3RvbS1wYXNzd29yZC1yZXNldC1hdXRoZW50aWNhdG9yIiwiTXVsdGlBdHRyaWJ1dGVBdXRoZW50aWNhdG9yIiwicGFzc3dvcmQtcmVzZXQtZW5mb3JjZXIiXSwiaXNzIjoiaHR0cHM6XC9cL2NpYW1zc28uc2l0MS5jaWFtLnZvZGFmb25lLmNvbVwvb2F1dGgyXC90b2tlbiIsImV4cCI6MTcxODg5NTE1OCwiaWF0IjoxNzE4ODkxNTU4LCJzaWQiOiI0YjFhZjY3Yy1kMDUxLTQ4MTAtYjdmZi1kZjM3Y2UyNjQ0OTEifQ.kCpNWc_EN0RkpWWzNo3Mvb-6AELGrcFedtrdZFL5BPGSATSYUODWWza3BQVfsUkPROqzH0kYZMDhTe4gAygD4F2I4YNKArYIr5WczkLKKpIwj2REvKWjftX-IyJfyhBWsFr58MQy18dj-Dvc5qfcX6KHkjMix6_aG_HuR-rA0xUgHn7tqL3A8K3eqWX1cXpaV51M5CvyqjG8yyR9lPYhw7QJ_ZppirLwJlaTtJR-vVoE8ra67uX3lc5BeDS0LJYdttU5C-H3z_v5k21Jyq9JbNSCRP1UUMBRmfu5iB-YkDoB80ptmiof7e1hM1yV0v6Z-RR-Fj9fqonhDQmQt_hY1Q");
        data.setTokenType("Bearer");
        data.setExpiresIn(3329);


        when(accessTokenService.getAccessToken(any())).thenReturn(data);

        final CiamAccessToken code = resource.getAccessToken("CODE", false);

        assertNotNull(code);
    }

}
