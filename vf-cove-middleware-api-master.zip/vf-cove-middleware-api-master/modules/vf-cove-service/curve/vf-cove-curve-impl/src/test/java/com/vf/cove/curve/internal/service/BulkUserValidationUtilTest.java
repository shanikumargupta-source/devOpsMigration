package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.BulkUserValidationDTO;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.utils.BulkUserValidationUtil;
import com.vf.cove.curve.internal.utils.CommonUserDataValidationUtil;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BulkUserValidationUtilTest {

    @InjectMocks
    BulkUserValidationUtil bulkUserValidationUtil;

    @Spy
    CurveApiConfiguration config;

    @Mock
    UserGroupsUploadFileService userGroupsUploadFileService;

    @Mock
    CurveUtils curveUtils;

    @Spy
    CommonUserDataValidationUtil commonUserDataValidationUtil;

    private static final String ORGANISATION_NAME = "organisationName";

    private static final String COUNTRY_CODE = "countryCode";

    private static final Map<String, String> PARAMS_MAP = new HashMap<String, String>() {{
        put("organisationName", ORGANISATION_NAME);
        put("countryCode", COUNTRY_CODE);
    }};

    @BeforeEach
    void init() {

        when(config.firstNameHeader()).thenReturn("First Name");
        when(config.lastNameHeader()).thenReturn("Last Name");
        when(config.emailHeader()).thenReturn("Email");
        when(config.activationDateHeader()).thenReturn("Activation Date");
        when(config.sendEmailHeader()).thenReturn("Send email");
        when(config.roleHeader()).thenReturn("Role");
        when(config.userGroupHeader()).thenReturn("User Group");
        when(config.phoneNumberHeader()).thenReturn("Phone Number");
        when(config.tariffHeader()).thenReturn("Tariff");
        when(config.upgradeDateHeader()).thenReturn("Upgrade Date");

        CompanyLevel companyLevel = new CompanyLevel();
        companyLevel.setCompanyName(ORGANISATION_NAME);
        companyLevel.setCountry(COUNTRY_CODE);
        companyLevel.setLevel("L3");

        Set<String> userGroups = new HashSet<>();
        userGroups.add("OOB_UG1");
        companyLevel.setUserGroups(userGroups);
        when(userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(ORGANISATION_NAME, COUNTRY_CODE)).thenReturn(companyLevel);
    }

    @Test
    void invalidSheetStructure() {
        reset(config);
        reset(userGroupsUploadFileService);

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-sheet-structure.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertNull(result.getUserList());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FILE_STRUCTURE", error.getErrorType().toString());
            assertNull(error.getColumn());
            assertNull(error.getRow());
            assertNull(error.getValue());
            assertEquals("Please provide a valid file", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidFirstName() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-first-name.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("First Name", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("First@", error.getValue());
            assertEquals("Name cannot contain any special characters", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidLastName() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-last-name.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Last Name", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("Last@", error.getValue());
            assertEquals("Name cannot contain any special characters", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidEmail() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-email.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Email", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("emailOct26!#()!@domain.com", error.getValue());
            assertEquals("Invalid email format", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void emptySendEmail() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-empty-send-mail.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("REQUIRED", error.getErrorType().toString());
            assertEquals("Send email", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("", error.getValue());
            assertEquals("Send email Field needs to be populated with Yes or No", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void emptyRole() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-empty-role.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("REQUIRED", error.getErrorType().toString());
            assertEquals("Role", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("", error.getValue());
            assertEquals("Role needs to be populated as it is a mandatory field", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidRole() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-role.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Role", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("Bla", error.getValue());
            assertEquals("Role must be set to User", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void emptyUserGroup() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-empty-user-group.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(2, result.getErrorList().size());

            Error errorNotPopulated = result.getErrorList().get(0);
            assertNotNull(errorNotPopulated);
            assertEquals("REQUIRED", errorNotPopulated.getErrorType().toString());
            assertEquals("User Group", errorNotPopulated.getColumn());
            assertEquals(6, errorNotPopulated.getRow());
            assertEquals("", errorNotPopulated.getValue());
            assertEquals("User Group needs to be populated as it is a mandatory field", errorNotPopulated.getErrorMessage());

            Error error = result.getErrorList().get(1);
            assertNotNull(error);
            assertEquals("NOT_ALLOWED", error.getErrorType().toString());
            assertEquals("User Group", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("", error.getValue());
            assertEquals("User group not found for your organisation", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidSendEmail() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-send-mail.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Send email", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("Y", error.getValue());
            assertEquals("Value must be Yes or No", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidActivationDate() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-activation-date.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Activation Date", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("30/10/2002", error.getValue());
            assertEquals("Activation date must be in the future", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidActivationDateWrongFormat() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-activation-date-format.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Activation Date", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("30-10-2099", error.getValue());
            assertEquals("Incorrect format. Needs to be in the format dd/mm/yyyy", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidPhoneNumber() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-phone-number.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = Optional.ofNullable(result.getErrorList()).get().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Phone Number", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("44999999999", error.getValue());
            assertEquals("Phone number is in an incorrect format", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void validPhoneNumberNoTariff() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-valid-phone-number-no-tariff.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("REQUIRED", error.getErrorType().toString());
            assertEquals("Tariff", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("", error.getValue());
            assertEquals(" Field must be populated when a phone number is provided", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void validPhoneNumberNoUpgradeDateL2Organization() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-valid-phone-number-no-upgrade-date.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void validPhoneNumberNoUpgradeDateL3Organization() {

        CompanyLevel companyLevel = new CompanyLevel();
        companyLevel.setCompanyName(ORGANISATION_NAME);
        companyLevel.setCountry(COUNTRY_CODE);
        companyLevel.setLevel("L3");

        Set<String> userGroups = new HashSet<>();
        userGroups.add("OOB_UG1");
        companyLevel.setUserGroups(userGroups);
        when(userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(ORGANISATION_NAME, COUNTRY_CODE)).thenReturn(companyLevel);

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-valid-phone-number-no-upgrade-date.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("REQUIRED", error.getErrorType().toString());
            assertEquals("Upgrade Date", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("", error.getValue());
            assertEquals(" Field must be populated when a phone number is provided", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void validTariffVoiceDataData() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-valid-voiceData-data.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(2, result.getUserList().size());
            assertTrue(result.getErrorList().isEmpty());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void validTariffVoiceData() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-valid-tariff-voiceData.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertTrue(result.getErrorList().isEmpty());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void validTariffData() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-valid-tariff-data.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertTrue(result.getErrorList().isEmpty());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidTariffData() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-tariff-Data.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Tariff", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("Data", error.getValue());
            assertEquals("Tariff must be either voiceData or data", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidTariffVoiceData() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-tariff-VoiceData.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Tariff", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("VoiceData", error.getValue());
            assertEquals("Tariff must be either voiceData or data", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidUpgradeDate() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-upgrade-date.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Upgrade Date", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("30-10-2099", error.getValue());
            assertEquals("Incorrect format. Needs to be in the format dd/mm/yyyy ", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidUpgradeDateEmptyPhoneNumberL3Organization() {

        CompanyLevel companyLevel = new CompanyLevel();
        companyLevel.setCompanyName(ORGANISATION_NAME);
        companyLevel.setCountry(COUNTRY_CODE);
        companyLevel.setLevel("L3");

        Set<String> userGroups = new HashSet<>();
        userGroups.add("OOB_UG1");
        companyLevel.setUserGroups(userGroups);
        when(userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(ORGANISATION_NAME, COUNTRY_CODE)).thenReturn(companyLevel);

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-upgrade-date-empty-phone-number.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Upgrade Date", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("30/10/2099", error.getValue());
            assertEquals("Upgrade Date should only be provided when phone number is populated", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void invalidUpgradeDateEmptyPhoneNumber() {

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-upgrade-date-empty-phone-number.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("FORMAT", error.getErrorType().toString());
            assertEquals("Upgrade Date", error.getColumn());
            assertEquals(6, error.getRow());
            assertEquals("30/10/2099", error.getValue());
            assertEquals("Upgrade Date should only be provided when phone number is populated", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void legalOrgIdNotMapped() {

        when(curveUtils.getLegalOrgId(COUNTRY_CODE, ORGANISATION_NAME)).thenThrow(new BackendSystemException(""));

        try (InputStream input = Files.newInputStream(new File("src/test/resources/bulkUser/bulk-user-invalid-legal-org-id.csv").toPath())) {

            BulkUserValidationDTO result = bulkUserValidationUtil.validateBulkUserFile(input, PARAMS_MAP);

            assertFalse(result.getUserList().isEmpty());
            assertEquals(1, result.getUserList().size());
            assertFalse(result.getErrorList().isEmpty());
            assertEquals(1, result.getErrorList().size());

            Error error = result.getErrorList().get(0);
            assertNotNull(error);
            assertEquals("NOT_ALLOWED", error.getErrorType().toString());
            assertEquals("LegalOrgId must be mapped before creating user for this company", error.getErrorMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
