import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.CurveCompanyErrorResponse;
import com.vf.cove.curve.internal.model.mapper.CurveCompanyDTO;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.fluent.Response;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.mockito.Mockito.*;

public class CurveTestUtils {

    private static ObjectMapper objectMapper = new ObjectMapper();

    public static <T> T parseStringToObject(String json, Class<T> object) throws IOException{
        return objectMapper.readValue(json, object);
    }

    public static javax.ws.rs.core.Response mockHttpCompaniesResponse(CurveCompanyDTO[] curveCompanies, Integer statusCode) throws IOException{
        javax.ws.rs.core.Response response = mock(javax.ws.rs.core.Response.class);
        when(response.getStatus()).thenReturn(statusCode);
        when(response.readEntity(CurveCompanyDTO[].class)).thenReturn(curveCompanies);
        return response;
    }

    public static javax.ws.rs.core.Response mockHttpCompanyByIdResponse(CurveCompanyDTO curveCompany, Integer statusCode) throws IOException{
        javax.ws.rs.core.Response response = mock(javax.ws.rs.core.Response.class);
        when(response.getStatus()).thenReturn(statusCode);
        when(response.readEntity(CurveCompanyDTO.class)).thenReturn(curveCompany);
        return response;
    }

    public static javax.ws.rs.core.Response mockHttpUnauthorizedErrorResponse(CurveCompanyErrorResponse curveCompanyBusinessErrorResponse, Integer statusCode) throws IOException{
        javax.ws.rs.core.Response response = mock(javax.ws.rs.core.Response.class);
        when(response.getStatus()).thenReturn(statusCode);
        when(response.readEntity(CurveCompanyErrorResponse.class)).thenReturn(curveCompanyBusinessErrorResponse);
        return response;
    }

    public static Response mockHttpResponse(String body, Integer statusCode) throws IOException {
        Response response = mock(Response.class);
        HttpResponse httpResponse = mock(HttpResponse.class);
        StatusLine statusLine = mock(StatusLine.class);
        HttpEntity entity = mock(HttpEntity.class);
        lenient().when(statusLine.getStatusCode()).thenReturn(statusCode.intValue());
        lenient().when(entity.getContent()).thenReturn(new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
        lenient().when(httpResponse.getStatusLine()).thenReturn(statusLine);
        lenient().when(httpResponse.getEntity()).thenReturn(entity);
        lenient().when(response.returnResponse()).thenReturn(httpResponse);
        return response;
    }

    public static void mockCurveApiConfiguration(CurveApiConfiguration curveApiConfiguration){
        when(curveApiConfiguration.dxlOrchestratorBaseUrl()).thenReturn(new String());
        when(curveApiConfiguration.dxlAccessTokenEndpoint()).thenReturn(new String());
        when(curveApiConfiguration.dxlClientId()).thenReturn(new String());
        when(curveApiConfiguration.dxlClientSecret()).thenReturn(new String());
        when(curveApiConfiguration.dxlScope()).thenReturn(new String());
        when(curveApiConfiguration.dxlGrantType()).thenReturn(new String());
    }

    public static void mockCurveCompanyApiConfiguration(CurveApiConfiguration curveApiConfiguration){
        when(curveApiConfiguration.dxlOrchestratorBaseUrl()).thenReturn(new String());
        when(curveApiConfiguration.dxlOrchestratorCurveVersion()).thenReturn(new String());
        when(curveApiConfiguration.companyEndpoint()).thenReturn(new String());
    }
}
