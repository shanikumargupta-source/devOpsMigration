package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.internal.client.CurveCiamClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.CiamAccessTokenDTO;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.TestUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CiamAccessTokenServiceTest {
    @InjectMocks
    CiamAccessTokenService ciamAccessTokenService;

    @Mock
    CurveCiamClient ciamClient;

    @Mock
    private CurveApiConfiguration curveApiConfiguration;

    @Mock
    CurveHttpRequestDTO httpRequestDTO;

    @Mock
    Response response;

    @Mock
    CiamAccessTokenDTO ciamResponseFixture;

    CiamAccessTokenDTO ciamErrorResponse;

    String filePath ="src/test/resources/";

    String accessTokenResponseFileName = "ciam-access-token-response.json";


    @InjectMocks
    CurveUtils curveUtils;

    @Mock
    HttpServletRequest httpRequest;

    @Mock
    HttpServletResponse httpResponse;

    @Mock
    CurveHttpRequestDTO curveHttpRequestDTO;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        ciamResponseFixture =  TestUtils.getCurveResponse(filePath + accessTokenResponseFileName, CiamAccessTokenDTO.class);
        ciamErrorResponse = new CiamAccessTokenDTO();
    }

    @Test
     void getCiamAccessTokenTest_Success() throws Exception {
        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamResponseFixture);
        when(ciamClient.getCiamAccessToken("xxx", "", false)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, "xxx", false);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamResponseFixture, accessTokenDTO);
    }

    @Test
    void getCiamAccessTokenTest_Failure() throws Exception {
        when(ciamClient.getCiamAccessToken("xxx", "", false)).thenThrow(new BackendSystemException("Ciam response is empty"));

        assertThrows(BackendSystemException.class, () -> {ciamClient.getCiamAccessToken("xxx","", false);});
    }

    @Test
    void getCiamAccessTokenTest_NoIsExpiredParameter() throws Exception {
        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamResponseFixture);
        when(ciamClient.getCiamAccessToken("xxx", "", null)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, "xxx", null);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamResponseFixture, accessTokenDTO);
    }

    @Test
    void getCiamAccessTokenTest_NoCodeParameter() throws Exception {
        ciamErrorResponse.setError("invalid_request");
        ciamErrorResponse.setErrorDescription("Missing parameters: code");

        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamErrorResponse);
        when(ciamClient.getCiamAccessToken(null, "", false)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, null, false);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamErrorResponse, accessTokenDTO);
    }

    @Test
    void getCiamAccessTokenTest_InvalidCodeParameter() throws Exception {
        ciamErrorResponse.setError("invalid_grant");
        ciamErrorResponse.setErrorDescription("Inactive authorization code received from token request");

        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamErrorResponse);
        when(ciamClient.getCiamAccessToken(null, "", false)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, null, false);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamErrorResponse, accessTokenDTO);
    }

    @Test
    void getCiamAccessTokenTest_RefreshToken() throws Exception {
        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamResponseFixture);
        when(ciamClient.getCiamAccessToken("xxx", "",true)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, "xxx", true);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamResponseFixture, accessTokenDTO);
    }

    @Test
    void getCiamAccessTokenTest_RefreshTokenFailure() throws Exception {
        when(ciamClient.getCiamAccessToken("xxx", "", true)).thenThrow(new BackendSystemException("Ciam response is empty"));

        assertThrows(BackendSystemException.class, () -> {ciamClient.getCiamAccessToken("xxx", "", true);});
    }

    @Test
    void getCiamAccessTokenTest_MissingRefreshTokenParameter() throws Exception {
        ciamErrorResponse.setError("invalid_request");
        ciamErrorResponse.setErrorDescription("Missing parameters: refresh_token");

        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamErrorResponse);
        when(ciamClient.getCiamAccessToken("xxx", "", true)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, "xxx", true);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamErrorResponse, accessTokenDTO);
    }

    @Test
    void getCiamAccessTokenTest_InvalidRefreshTokenParameter() throws Exception {
        ciamErrorResponse.setError("invalid_grant");
        ciamErrorResponse.setErrorDescription("Invalid refresh token state");

        when(response.readEntity(CiamAccessTokenDTO.class)).thenReturn(ciamErrorResponse);
        when(ciamClient.getCiamAccessToken("xxx", "", true)).thenReturn(response);

        curveHttpRequestDTO = CurveUtils.getCiamAccessTokenRequestDto(httpRequest, httpResponse, "xxx", true);
        CiamAccessTokenDTO accessTokenDTO = ciamAccessTokenService.getAccessToken(curveHttpRequestDTO);
        assertEquals(ciamErrorResponse, accessTokenDTO);
    }

}
