package utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.vf.cove.curve.dto.v1_0.CurveUser;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class TestUtils {

    private static ObjectMapper objectMapper = new ObjectMapper();


    public static <T> List<T> getCurveResponseList(String filePath, Class<T> classType) throws IOException{
        return objectMapper.readValue(new File(filePath), new TypeReference<List<T>>() {});
    }

    public static <T> T getCurveResponse(String filePath, Class<T> classType) throws IOException{
        return objectMapper.readValue(new File(filePath), classType);
    }

    public static CurveUser[] getCreateUserRequest(String filePath) throws IOException{
        return objectMapper.readValue(new File(filePath), CurveUser[].class);
    }

    public static String inputStreamToString(String fileName) {
        try {
            InputStream input = new FileInputStream(new File(fileName));
            Throwable var2 = null;

            String var3;
            try {
                var3 = IOUtils.toString(input, StandardCharsets.UTF_8);
            } catch (Throwable var13) {
                var2 = var13;
                throw var13;
            } finally {
                if (input != null) {
                    if (var2 != null) {
                        try {
                            input.close();
                        } catch (Throwable var12) {
                            var2.addSuppressed(var12);
                        }
                    } else {
                        input.close();
                    }
                }

            }

            return var3;
        } catch (IOException var15) {
            throw new RuntimeException("Reading from file failed " + fileName, var15);
        }
    }

    public static <E> E deserializeObject(Class<E> entityClass, String objectJson) {
        try {
            return objectMapper.readValue(objectJson, entityClass);
        } catch (Exception var3) {
            throw new RuntimeException("Error deserializing entity " + entityClass, var3);
        }
    }

    public static String serializeObject(Object entity) {
        try {
            return objectMapper.writeValueAsString(entity);
        } catch (Exception var2) {
            throw new RuntimeException("Error serializing entity " + entity, var2);
        }
    }

    static {
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    }
}
