package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.CurveCompany;
import com.vf.cove.curve.dto.v1_0.CurveCompanyGrouped;
import com.vf.cove.curve.internal.client.CurveCompanyClient;
import com.vf.cove.curve.internal.client.CurveSnowClient;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.exception.DataNotFoundException;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.CurveTestUtils;
import utils.TestUtils;

import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CurveCompanyServiceTest {

    @InjectMocks
    private CurveCompanyService curveCompanyService;

    @Mock
    private CurveCompanyClient curveCompanyClient;

    @Mock
    private CurveSnowClient snowClient;

    @InjectMocks
    private CurveHttpRequestDTO requestDto;

    @Mock
    private CurveUtils curveUtils;

    private CurveCompany curveCompany;

    private List<CurveCompany> allCurveCompanies;

    private List<CurveCompany> snowCompanies;

    private List<CurveCompany> snowCompaniesWithUUIDList;



    @BeforeEach
    public void setUp() throws IOException {
        String successCompanyResponse = TestUtils.inputStreamToString("src/test/resources/curve-get-company-success-response.json");
        curveCompany = CurveTestUtils.parseStringToObject(successCompanyResponse, CurveCompany.class);

        String successCompaniesResponse = TestUtils.inputStreamToString("src/test/resources/curve-get-all-companies-success-response.json");
        allCurveCompanies = CurveTestUtils.parseStringToListOfObject(successCompaniesResponse, CurveCompany.class);

        String snowCompanyResponse = TestUtils.inputStreamToString("src/test/resources/curve-snow-companies-success-response.json");
        snowCompanies = CurveTestUtils.parseStringToListOfObject(snowCompanyResponse, CurveCompany.class);

        snowCompaniesWithUUIDList = new ArrayList<>();
        snowCompaniesWithUUIDList.add(allCurveCompanies.get(0));
    }

    @Test
    void getCompanyByIdSuccessResponse(){
        Response clientSuccessResponse = CurveTestUtils.mockHttpCompanyByIdResponse(curveCompany, 200);
        when(curveCompanyClient.getCompanyById(requestDto)).thenReturn(clientSuccessResponse);
        CurveCompany curveCompany = curveCompanyService.getCompanyById(requestDto);
        Assertions.assertThat(curveCompany.getId()).isEqualTo("f5983129-fb58-4aeb-b391-3ec90fb2bb0a");
    }

    @Test
    void getCompanyList_ExternalUserFlow_Success(){
        when(curveCompanyClient.getCompanyList(requestDto)).thenReturn(allCurveCompanies);
        when(curveUtils.getLegalOrgId("GB", "test1")).thenReturn("123");
        when(curveUtils.getLegalOrgId("GB", "test2")).thenReturn("321");

        List<CurveCompanyGrouped> allCompanies = curveCompanyService.getCompanyList(requestDto);
        Assertions.assertThat(allCompanies.size()).isEqualTo(2);
    }

    @Test
    void getCompanyList_ExternalUserFlow_NoDataFound(){
        when(curveCompanyClient.getCompanyList(requestDto)).thenReturn(new ArrayList<>());
        Assertions.assertThatThrownBy(() -> curveCompanyService.getCompanyList(requestDto)).isInstanceOf(DataNotFoundException.class);
        Assertions.assertThatThrownBy(() -> curveCompanyService.getCompanyList(requestDto)).hasMessage("No companies found");
    }


    @Test
    void getCompanyList_InternalUserFlow_Success(){
        requestDto.setGranterEmail("testUser@vodafone.com");

        when(curveUtils.isInternalUser(requestDto.getGranterEmail())).thenReturn(Boolean.TRUE);
        when(snowClient.getCompanyListByGranterEmail(requestDto)).thenReturn(snowCompanies);
        when(curveCompanyClient.getCompanyList(requestDto)).thenReturn(snowCompaniesWithUUIDList);

        when(curveUtils.getLegalOrgId("GB", "test1")).thenReturn("123");

        List<CurveCompanyGrouped> companyList = curveCompanyService.getCompanyList(requestDto);
        Assertions.assertThat(companyList.size()).isEqualTo(1);

    }

    @Test
    void getCompanyList_InternalUserFlow_NoDataFound(){
        when(curveUtils.isInternalUser(requestDto.getGranterEmail())).thenReturn(Boolean.TRUE);
        when(snowClient.getCompanyListByGranterEmail(requestDto)).thenReturn(new ArrayList<>());

        Assertions.assertThatThrownBy(() -> curveCompanyService.getCompanyList(requestDto)).isInstanceOf(DataNotFoundException.class);
        Assertions.assertThatThrownBy(() -> curveCompanyService.getCompanyList(requestDto)).hasMessage("No snow companies found");
    }

    @Test
    void getAllCompaniesSuccessReducedResponse(){
        when(curveCompanyClient.getCompanyList(requestDto)).thenReturn(allCurveCompanies);
        when(curveUtils.getLegalOrgId("GB", "test1")).thenReturn("123");
        when(curveUtils.getLegalOrgId("GB", "test2")).thenReturn("321");
        when(curveUtils.getLegalOrgId("NL", "test3")).thenReturn("456");
        when(curveUtils.getLegalOrgId("NL", "test4")).thenThrow(new BackendSystemException());

        List<CurveCompanyGrouped> allCompanies = curveCompanyService.getCompanyList(requestDto);
        Assertions.assertThat(allCompanies.size()).isEqualTo(3);
    }

    @Test
    void getUnauthorizedErrorResponse(){
        when(curveCompanyClient.getCompanyList(requestDto)).thenThrow(new ServiceException("Error getting companies ::"+ anyString()));
        Assertions.assertThatThrownBy(() -> curveCompanyService.getCompanyList(requestDto)).isInstanceOf(ServiceException.class);
    }

}
