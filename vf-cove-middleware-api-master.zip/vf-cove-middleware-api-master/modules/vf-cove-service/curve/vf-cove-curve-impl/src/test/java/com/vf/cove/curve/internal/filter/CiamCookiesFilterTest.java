package com.vf.cove.curve.internal.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.configuration.impl.CurveApiConfigurationImpl;
import com.vf.cove.curve.internal.model.CiamAccessTokenDTO;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.service.CiamAccessTokenService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import utils.TestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CiamCookiesFilterTest {

    private String TOKEN_TYPE = "Bearer";

    @InjectMocks
    private CurveCiamCookiesFilter curveCiamCookiesFilter;

    @Mock
    private CiamAccessTokenService ciamAccessTokenService;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    private FilterChain filterChain = new MockFilterChain();

    @Mock
    private CurveApiConfiguration curveApiConfiguration = new CurveApiConfigurationImpl();

    private List<String> cookiesNames;

    private static ObjectMapper objectMapper = new ObjectMapper();

    private CiamAccessTokenDTO ciamAccessTokenDTO;

    @Test
    void ciamCookieFilterNotEnabled() throws IOException, ServletException {
        cookiesNames = mockFullCookiesNames();
        when(curveApiConfiguration.isCurveCiamFilterEnabled()).thenReturn(false);
        when(request.getCookies()).thenReturn(mockCookiesWithCookiesNames(cookiesNames));
        curveCiamCookiesFilter.doFilter(request, response, filterChain);
        String xCiamTokenHeader = request.getHeader(CurveConstant.X_CIAM_TOKEN);
        Assertions.assertThat(xCiamTokenHeader).isNullOrEmpty();
    }

    @Test
    void ciamCookieFilterEnabledAndAccessTokenExistAndRefreshTokenExist() throws IOException, ServletException {
        cookiesNames = mockFullCookiesNames();
        when(curveApiConfiguration.isCurveCiamFilterEnabled()).thenReturn(true);
        when(request.getCookies()).thenReturn(mockCookiesWithCookiesNames(cookiesNames));
        curveCiamCookiesFilter.doFilter(request, response, filterChain);
        MockFilterChain mockFilterChain = (MockFilterChain) filterChain;
        HttpServletRequest afterFilterRequest = (HttpServletRequest) mockFilterChain.getRequest();
        String xCiamTokenHeader = afterFilterRequest.getHeader(CurveConstant.X_CIAM_TOKEN);
        Assertions.assertThat(xCiamTokenHeader).isNotEmpty().contains(TOKEN_TYPE);
    }

    @Test
    void ciamCookieFilterEnabledAndAccessTokenNotExistAndRefreshExist() throws IOException, ServletException, ConfigurationException {
        String successResponseBody = TestUtils.inputStreamToString("src/test/resources/ciam_oauth_refresh_token_success_response.json");
        ciamAccessTokenDTO = objectMapper.readValue(successResponseBody, CiamAccessTokenDTO.class);
        cookiesNames = mockRefreshCookieName();
        when(curveApiConfiguration.isCurveCiamFilterEnabled()).thenReturn(true);
        when(request.getCookies()).thenReturn(mockCookiesWithCookiesNames(cookiesNames));
        when(ciamAccessTokenService.getAccessToken(any())).thenReturn(ciamAccessTokenDTO);
        curveCiamCookiesFilter.doFilter(request, response, filterChain);
        MockFilterChain mockFilterChain = (MockFilterChain) filterChain;
        HttpServletRequest afterFilterRequest = (HttpServletRequest) mockFilterChain.getRequest();
        String xCiamTokenHeader = afterFilterRequest.getHeader(CurveConstant.X_CIAM_TOKEN);
        Assertions.assertThat(xCiamTokenHeader).isNotEmpty().isEqualTo("Bearer 072d5b93-1c8d-3ffc-add1-f18aafcb00f0");
    }

    private static List<String> mockFullCookiesNames() {
        List<String> cookiesNames = new ArrayList<>();
        cookiesNames.add("JSESESSIONID");
        cookiesNames.add(CurveConstant.CIAM_ACCESS_TOKEN_COOKIE);
        cookiesNames.add(CurveConstant.CIAM_REFRESH_TOKEN_COOKIE);
        return cookiesNames;
    }

    private static List<String> mockRefreshCookieName() {
        List<String> cookiesNames = new ArrayList<>();
        cookiesNames.add("JSESESSIONID");
        cookiesNames.add(CurveConstant.CIAM_REFRESH_TOKEN_COOKIE);
        return cookiesNames;
    }

    private static Cookie[] mockCookiesWithCookiesNames(List<String> names) {
        List<Cookie> cookies = new ArrayList<>();
        for (String name : names) {
            Cookie tempCookie = new Cookie(name, UUID.randomUUID().toString());
            cookies.add(tempCookie);
        }
        return cookies.toArray(new Cookie[cookies.size()]);
    }

}
