package utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.vf.cove.curve.dto.v1_0.CurveCompany;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.model.CurveCompanyErrorResponse;

import javax.ws.rs.core.GenericType;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CurveTestUtils {

    private static ObjectMapper objectMapper = new ObjectMapper();

    public static <T> T parseStringToObject(String json, Class<T> object) throws IOException{
        return objectMapper.readValue(json, object);
    }

    public static <T> List<T> parseStringToListOfObject(String json, Class<T> object) throws IOException{
        CollectionType listType = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, object);
        return objectMapper.readValue(json, listType);
    }

    public static javax.ws.rs.core.Response mockHttpCompaniesResponse(List<CurveCompany> curveCompanies, Integer statusCode){
        javax.ws.rs.core.Response response = mock(javax.ws.rs.core.Response.class);
        when(response.getStatus()).thenReturn(statusCode);
        when(response.readEntity(new GenericType<List<CurveCompany>>(){})).thenReturn(curveCompanies);
        return response;
    }

    public static javax.ws.rs.core.Response mockHttpCompanyByIdResponse(CurveCompany curveCompany, Integer statusCode){
        javax.ws.rs.core.Response response = mock(javax.ws.rs.core.Response.class);
        when(response.getStatus()).thenReturn(statusCode);
        when(response.readEntity(CurveCompany.class)).thenReturn(curveCompany);
        return response;
    }

    public static javax.ws.rs.core.Response mockHttpUnauthorizedErrorResponse(CurveCompanyErrorResponse curveCompanyBusinessErrorResponse, Integer statusCode){
        javax.ws.rs.core.Response response = mock(javax.ws.rs.core.Response.class);
        when(response.getStatus()).thenReturn(statusCode);
        when(response.readEntity(CurveCompanyErrorResponse.class)).thenReturn(curveCompanyBusinessErrorResponse);
        return response;
    }

    public static Map<String, CompanyLevel> mockInMemoryMap(){
        Map<String, CompanyLevel> inMemoryMap = new HashMap<>();
        CompanyLevel company1 = new CompanyLevel();
        company1.setCompanyName("cisco");
        company1.setLevel("L1");
        company1.setCountry("UK");
        company1.getUserGroups().add("Standard");

        CompanyLevel company2 = new CompanyLevel();
        company2.setCompanyName("pfizer");
        company2.setLevel("L2");
        company2.setCountry("US");
        company2.getUserGroups().add("Standard");

        inMemoryMap.put("cisco_uk", company1);
        inMemoryMap.put("pfizer_us", company2);

        return inMemoryMap;
    }

}
