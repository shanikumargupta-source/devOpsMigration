package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.internal.client.CurveUserClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.TestUtils;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CurveUserServiceTest {
    @InjectMocks
    private CurveUserService userService;

    @InjectMocks
    CurveUtils curveUtils;

    @Mock
    private CurveUserClient userClient;

    @Mock
    private CurveApiConfiguration curveApiConfiguration;

    @Mock
    CurveHttpRequestDTO httpRequestDTO;

    @Mock
    List<CurveUser> userListFixture;

    @Mock
    CurveUser userFixture;

    CurveUser[] createUserRequestFixture;

    @Mock
    List<CurveUser> createUserResponseFixture;

    String filePath = "src/test/resources/";

    String userListFileName = "curve-user-list-response.json";

    String userFileName = "curve-user-response.json";

    String createUserRequestFileName = "curve-create-user-response.json";

    String createUserResponseFileName = "curve-create-user-request.json";

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);
        userListFixture = TestUtils.getCurveResponseList(filePath + userListFileName, CurveUser.class);
        userFixture = TestUtils.getCurveResponse(filePath + userFileName, CurveUser.class);

        createUserRequestFixture = TestUtils.getCreateUserRequest(filePath + createUserRequestFileName);
        System.out.println("FIXTURE " + createUserRequestFixture);
        createUserResponseFixture = TestUtils.getCurveResponseList(filePath + createUserResponseFileName, CurveUser.class);

        httpRequestDTO = new CurveHttpRequestDTO();
        httpRequestDTO.setGranterEmail("mukesh.Kumar@abc");
        httpRequestDTO.setOrgId("71e25cb2-2d96-4b4e-88a8-17b7d6e1dcad");
        httpRequestDTO.setCiamToken("asdfdgfhg");
        httpRequestDTO.setDxlToken("DFSDGFG");
    }

    @Test
    void getCurveUserListTest_Success() throws Exception {
        when(userClient.getUserList(httpRequestDTO)).thenReturn(userListFixture);
        List<CurveUser> curveUsers = userService.getCurveUserList(httpRequestDTO);
        assertEquals(userListFixture, curveUsers);
    }

    @Test
    void getCurveUserListTest_FilterBySearch() throws Exception {
        httpRequestDTO.setSearch("mukesh");
        when(userClient.getUserList(httpRequestDTO)).thenReturn(userListFixture);
        List<CurveUser> curveUsers = userService.getCurveUserList(httpRequestDTO);
        assertEquals(userListFixture, curveUsers);
    }

    @Test
    void getCurveUserListTest_FilterBySort() throws Exception {
        httpRequestDTO.setSort("id:desc");
        when(userClient.getUserList(httpRequestDTO)).thenReturn(userListFixture);
        List<CurveUser> curveUsers = userService.getCurveUserList(httpRequestDTO);
        assertEquals(userListFixture.get(0), curveUsers.get(0));
    }

    @Test
    void getCurveUserListTest_FilterByStatus() throws Exception {
        httpRequestDTO.setStatus("ACTIVE");

        when(userClient.getUserList(httpRequestDTO)).thenReturn(userListFixture);
        List<CurveUser> curveUsers = userService.getCurveUserList(httpRequestDTO);
        assertEquals(userListFixture, curveUsers);

    }

    @Test
    void getCurveUserListTest_Failure() throws Exception {
        when(userClient.getUserList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(500)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserList(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserListTest_NoAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken(null);
        when(userClient.getUserList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserList(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserListTest_invalidAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken("xxxxx");
        when(userClient.getUserList(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserList(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserByIdTest_Success() throws Exception {
        when(userClient.getUserById(httpRequestDTO)).thenReturn(userFixture);
        CurveUser curveUser = userService.getCurveUserById(httpRequestDTO);
        assertEquals(userFixture, curveUser);
    }

    @Test
    void getCurveUserByIdTest_Failure() throws Exception {
        when(userClient.getUserById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(500)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserById(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserByIdTest_NotFound() throws Exception {
        when(userClient.getUserById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(404)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserById(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserByIdTest_InvalidId() throws Exception {
        httpRequestDTO.setUserId("xxx-yyy-zzz");
        when(userClient.getUserById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(400)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserById(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserByIdTest_NoAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken(null);
        when(userClient.getUserById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserById(httpRequestDTO);
        });
    }

    @Test
    void getCurveUserByIdTest_invalidAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken("xxxxx");
        when(userClient.getUserById(httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            userClient.getUserById(httpRequestDTO);
        });
    }

    @Test
    void createUserTest_Success() throws Exception {
        when(userClient.createUser(createUserRequestFixture, httpRequestDTO)).thenReturn(createUserResponseFixture);
        List<CurveUser> curveUsers = userService.createCurveUser(createUserRequestFixture, httpRequestDTO);
        assertEquals(createUserResponseFixture, curveUsers);
    }

    @Test
    void createUserTest_Failure() throws Exception {
        when(userClient.createUser(createUserRequestFixture, httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(500)));
        assertThrows(BackendSystemException.class, () -> {
            userService.createCurveUser(createUserRequestFixture, httpRequestDTO);
        });
    }

    @Test
    void createUserTest_NoAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken(null);
        when(userClient.createUser(createUserRequestFixture, httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            userService.createCurveUser(createUserRequestFixture, httpRequestDTO);
        });
    }

    @Test
    void createUserTest_invalidAuthorizationHeader() throws Exception {
        httpRequestDTO.setDxlToken("xxxxx");
        when(userClient.createUser(createUserRequestFixture, httpRequestDTO)).thenThrow(new BackendSystemException(curveUtils.getStatusMessage(401)));
        assertThrows(BackendSystemException.class, () -> {
            userService.createCurveUser(createUserRequestFixture, httpRequestDTO);
        });
    }
}
