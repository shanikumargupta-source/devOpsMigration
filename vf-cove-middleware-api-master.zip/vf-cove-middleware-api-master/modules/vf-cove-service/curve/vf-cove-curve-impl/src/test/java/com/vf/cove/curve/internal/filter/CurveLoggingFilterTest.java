package com.vf.cove.curve.internal.filter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;

import javax.ws.rs.client.ClientRequestContext;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CurveLoggingFilterTest {

    @Mock
    CurveLoggingFilter curveLoggingFilter;

    @Mock
    Logger logger;

    @Mock
    ClientRequestContext clientRequestContext;

    @Mock
    URI uri;

    @Test
    void filter_requestContextIsNull() throws IOException {
        clientRequestContext = null;
        curveLoggingFilter = new CurveLoggingFilter(logger);
        curveLoggingFilter.filter(clientRequestContext);
        BDDMockito.verifyNoInteractions(logger);
    }

    @Test
    void filter_getUriIsNotNull() throws IOException, URISyntaxException {
        curveLoggingFilter = new CurveLoggingFilter(logger);
        when(clientRequestContext.getUri()).thenReturn(new URI("https://host.com/curve/api"));
        curveLoggingFilter.filter(clientRequestContext);
        BDDMockito.verify(logger).info("Request URI :: {} ", "https://host.com/curve/api");
    }

    @Test
    void filter_getEntityIsNotNull() throws IOException{
        curveLoggingFilter = new CurveLoggingFilter(logger);
        when(clientRequestContext.getEntity()).thenReturn("entity");
        curveLoggingFilter.filter(clientRequestContext);
        BDDMockito.verify(logger).info("Request body :: {} ", "entity");
    }
}
