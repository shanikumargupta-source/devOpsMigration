package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.BulkUserValidationResponse;
import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.internal.client.CurveUserClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.TestUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@Disabled("To be used in validating excel file scenario")
@ExtendWith(MockitoExtension.class)
 class BulkUserValidationServiceExcelTest {

    static String VALID_FILE_PATH = "src/test/resources/template/excel/Red Flex Bulk User-v0.1.xlsx";
    static String INVALID_STRUCTURE_FILE_PATH = "src/test/resources/template/excel/Red Flex Bulk User-v0.1-Invalid-Structure.xlsx";
    static String INVALID_DATA_FILE_PATH = "src/test/resources/template/excel/Red Flex Bulk User-v0.1-Invalid-Data.xlsx";
    static String INVALID_VERSION_FILE_PATH = "src/test/resources/template/excel/Red Flex Bulk User-v0.1-Invalid-Version.xlsx";

    @InjectMocks
    BulkUserValidationService bulkUserValidationService;

    @Mock
    private CurveUserClient userClient;

    @Mock
    CurveApiConfiguration curveApiConfiguration;

    @Mock
    CurveHttpRequestDTO httpRequestDTO;

    @Mock
    List<CurveUser> createUserResponseFixture;

    CurveUser[] createUserRequestFixture;

    String filePath = "src/test/resources/";

    String createUserResponseFileName = "curve-create-user-response.json";

    String createUserRequestFileName = "curve-create-user-request.json";

    Error error;

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);

        error = new Error();
        error.setErrorMessage("Please provide the latest template version");

        httpRequestDTO = new CurveHttpRequestDTO();
        httpRequestDTO.setGranterEmail("mukesh.Kumar@abc");
        httpRequestDTO.setOrgId("71e25cb2-2d96-4b4e-88a8-17b7d6e1dcad");
        httpRequestDTO.setCiamToken("asdfdgfhg");
        httpRequestDTO.setDxlToken("DFSDGFG");

        createUserRequestFixture = TestUtils.getCreateUserRequest(filePath + createUserRequestFileName);
        createUserResponseFixture = TestUtils.getCurveResponseList(filePath + createUserResponseFileName, CurveUser.class);
    }

    @Test
    void validaBulkUserSubmittedFile_LatestTemplateAndValidFileStructureAndData() throws IOException {
        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(new FileInputStream(VALID_FILE_PATH), new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertEquals(Boolean.TRUE, response.getIsValid());

    }

    @Test
    void validaBulkUserSubmittedFile_LatestTemplateAndInvalidFileStructure() throws IOException {
        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(new FileInputStream(INVALID_STRUCTURE_FILE_PATH), new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertNotNull(response.getErrors());
        assertEquals(3, response.getErrors().length);
        assertEquals(Boolean.FALSE, response.getIsValid());
    }

    @Test
    void validaBulkUserSubmittedFile_LatestTemplateAndInValidFileData() throws IOException {
        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(new FileInputStream(INVALID_DATA_FILE_PATH), new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertNotNull(response.getErrors());
        assertEquals(8, response.getErrors().length);
        assertEquals(Boolean.FALSE, response.getIsValid());
    }


    @Test
    void validaBulkUserSubmittedFile_IsNotLatestTemplate() throws IOException {
        BulkUserValidationResponse response = bulkUserValidationService.validaBulkUserSubmittedFile(new FileInputStream(INVALID_VERSION_FILE_PATH), new HashMap(), httpRequestDTO);

        assertNotNull(response);
        assertArrayEquals(Arrays.asList(error).stream().toArray(Error[]::new), response.getErrors());
        assertEquals(Boolean.FALSE, response.getIsValid());

    }

}
