package com.vf.cove.curve.internal.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.curve.internal.client.CurveDxlClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.configuration.impl.CurveApiConfigurationImpl;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveApigeeErrorResponse;
import com.vf.cove.curve.internal.model.CurveApigeeSuccessResponse;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.TestUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.util.HashMap;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DxlAccessTokenServiceTest {

    @InjectMocks
    private DxlAccessTokenService dxlAccessTokenService;

    @Mock
    private CurveDxlClient curveDxlClient;

    @Mock
    private CurveApiConfiguration curveApiConfiguration = new CurveApiConfigurationImpl();

    @InjectMocks
    private CurveHttpRequestDTO requestDto;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private HttpServletResponse httpServletResponse;

    @Mock
    private HashMap<String, String> headers = new HashMap<>();

    private CurveApigeeSuccessResponse clientSuccessResponse;
    private CurveApigeeErrorResponse clientErrorResponse;
    private static ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setUp() throws Exception {
        String successResponseBody = TestUtils.inputStreamToString("src/test/resources/curve-apigee-success-response.json");
        clientSuccessResponse = objectMapper.readValue(successResponseBody, CurveApigeeSuccessResponse.class);

        String errorResponseBody = TestUtils.inputStreamToString("src/test/resources/curve-apigee-error-response.json");
        clientErrorResponse = objectMapper.readValue(errorResponseBody, CurveApigeeErrorResponse.class);
    }

    @Test
    void dxlAccessTokenSuccessResponse() throws Exception {
        Response response = mock(Response.class);
        when(response.readEntity(CurveApigeeSuccessResponse.class)).thenReturn(clientSuccessResponse);
        when(response.getStatus()).thenReturn(200);
        when(curveDxlClient.getDxlAccessToken(requestDto)).thenReturn(response);
        CurveApigeeSuccessResponse successResponse = dxlAccessTokenService.getDxlAccessToken(requestDto);
        Assertions.assertThat(successResponse.getAccessToken()).isEqualTo("MsI87ZVdgiNBKFsAu3wmBTVdTqAJ");
    }

    @Test
    void dxlAccessTokenErrorResponse() throws Exception {
        Response response = mock(Response.class);
        when(response.readEntity(CurveApigeeErrorResponse.class)).thenReturn(clientErrorResponse);
        when(response.getStatus()).thenReturn(500);
        when(curveDxlClient.getDxlAccessToken(requestDto)).thenReturn(response);
        Assertions.assertThatThrownBy(() -> dxlAccessTokenService.getDxlAccessToken(requestDto))
            .isInstanceOf(ServiceException.class);

    }
}
