package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.CompanyLevel;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import utils.CurveTestUtils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserGroupsUploadFileServiceTest {

    static String RED_FLEX_EXCEL_FILE_PATH= "src/test/resources/RedFlexUserGroupForUI.xlsx";
    static String RED_FLEX_EXCEL_NOT_EXIST_FILE_PATH = "src/test/resources/RedFlexUserGroup.xlsx";
    static String RED_FLEX_EXCEL_DIFFERENT_FORMAT_FILE_PATH = "src/test/resources/curve-user-response.json";
    static String RED_FLEX_EXCEL_SHEET_NAME= "user_groups";
    static String RED_FLEX_WRONG_EXCEL_SHEET_NAME = "wrong_sheet";

    @InjectMocks
    UserGroupsUploadFileService userGroupsUploadFileService;

    @Mock
    CurveApiConfiguration curveApiConfiguration;

    Map<String, CompanyLevel> inMemoryMap = CurveTestUtils.mockInMemoryMap();

    @Test
    void activate_FileNotExist(){
        when(curveApiConfiguration.userGroupsFileName()).thenReturn(RED_FLEX_EXCEL_NOT_EXIST_FILE_PATH);
        userGroupsUploadFileService.activate();
        assertNull(userGroupsUploadFileService.getInMemoryMap());
    }

    @Test
    void activate_FileExist(){
        when(curveApiConfiguration.liferayDataVolumePath()).thenReturn("");
        when(curveApiConfiguration.userGroupsFileName()).thenReturn(RED_FLEX_EXCEL_FILE_PATH);
        when(curveApiConfiguration.userGroupsSheetName()).thenReturn(RED_FLEX_EXCEL_SHEET_NAME);
        userGroupsUploadFileService.activate();
        assertNotNull(userGroupsUploadFileService.getInMemoryMap());
    }

    @Test
    void getCompanyUserGroupsByCompanyNameAndCountry_CompanyNameNotExist(){
        userGroupsUploadFileService.setInMemoryMap(inMemoryMap);
        CompanyLevel company = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry("pepsi", "UK");
        assertNull(company.getLevel());
    }

    @Test
    void getCompanyUserGroupsByCompanyNameAndCountry_CompanyNameExistWithDifferentCountry(){
        userGroupsUploadFileService.setInMemoryMap(inMemoryMap);
        CompanyLevel company = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry("cisco", "US");
        assertNull(company.getLevel());
    }

    @Test
    void getCompanyUserGroupsByCompanyNameAndCountry_CompanyExist(){
        userGroupsUploadFileService.setInMemoryMap(inMemoryMap);
        CompanyLevel company = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry("cisco", "UK");
        assertEquals("L1", company.getLevel());
    }

    @Test
    void getCompanyUserGroupsByCompanyNameAndCountry_CompanyNameWithRandomCases(){
        userGroupsUploadFileService.setInMemoryMap(inMemoryMap);
        CompanyLevel company = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry("CIscO", "UK");
        assertEquals("L1", company.getLevel());
    }

    @Test
    void createInMemoryMapFromExcelFile_FileNotExist(){
        Assertions.assertThatThrownBy(() ->
            userGroupsUploadFileService.createInMemoryMapFromExcelFile(RED_FLEX_EXCEL_NOT_EXIST_FILE_PATH,
                RED_FLEX_WRONG_EXCEL_SHEET_NAME)).isInstanceOf(FileNotFoundException.class);
    }

    @Test
    void createInMemoryMapFromExcelFile_FileWithDifferentFormatType(){
        Assertions.assertThatThrownBy(() ->
            userGroupsUploadFileService.createInMemoryMapFromExcelFile(RED_FLEX_EXCEL_DIFFERENT_FORMAT_FILE_PATH,
                RED_FLEX_WRONG_EXCEL_SHEET_NAME)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void createInMemoryMapFromExcelFile_FileExistAndSheetNameNotExist(){
        Assertions.assertThatThrownBy(() ->
            userGroupsUploadFileService.createInMemoryMapFromExcelFile(RED_FLEX_EXCEL_FILE_PATH,
                RED_FLEX_WRONG_EXCEL_SHEET_NAME)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void createInMemoryMapFromExcelFile_FileExist() throws IOException {
        userGroupsUploadFileService.createInMemoryMapFromExcelFile(RED_FLEX_EXCEL_FILE_PATH, RED_FLEX_EXCEL_SHEET_NAME);
        assertNotNull(userGroupsUploadFileService.getInMemoryMap());
    }

}
