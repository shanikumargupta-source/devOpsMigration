package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.CurveCompany;
import com.vf.cove.curve.dto.v1_0.CurveCompanyGrouped;
import com.vf.cove.curve.dto.v1_0.Location;
import com.vf.cove.curve.internal.client.CurveCompanyClient;
import com.vf.cove.curve.internal.client.CurveSnowClient;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.exception.DataNotFoundException;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveCompanyErrorResponse;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.http.HttpStatus;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component(
    service = CurveCompanyService.class
)
public class CurveCompanyService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveCompanyService.class);

    @Reference(unbind = "-")
    private CurveCompanyClient ciamClient;

    @Reference(unbind = "-")
    private CurveSnowClient snowClient;


    @Reference(unbind = "-")
    private CurveUtils curveUtils;

    public List<CurveCompanyGrouped> getCompanyList(CurveHttpRequestDTO requestDto){
         List<CurveCompany> companyList = null;
         List<CurveCompany> clientCompanyList = null;

         if(curveUtils.isInternalUser(requestDto.getGranterEmail())){
             LOGGER.info("internal user flow :: start");
             clientCompanyList = getSnowCompanies(requestDto);
             LOGGER.info("internal user flow :: end");

         }else{
             LOGGER.info("external user flow :: start");
             clientCompanyList= getCiamCompanies(requestDto);
             LOGGER.info("external user flow :: end");

         }

        LOGGER.info("company list before legalOrgId filtration :: " + clientCompanyList);
        companyList= filterCompaniesWithLegalOrgIdMapped(clientCompanyList);
        LOGGER.info("company list after legalOrgId filtration :: " + companyList);

        return groupCompaniesByName(companyList);
    }

    private List<CurveCompany> getCiamCompanies(CurveHttpRequestDTO requestDto){
        LOGGER.info("getCiamCompanies :: start");
        List<CurveCompany> companies = ciamClient.getCompanyList(requestDto);

        if(ObjectUtils.isEmpty(companies)){
            throw new DataNotFoundException("No companies found");
        }

        LOGGER.info("getCiamCompanies :: end");
        return companies;
    }

    private List<CurveCompany> getSnowCompanies(CurveHttpRequestDTO requestDto){
        LOGGER.info("getSnowCompanies :: start");

        //calls snow client to get company list
        List<CurveCompany> companies = snowClient.getCompanyListByGranterEmail(requestDto);
        List<CurveCompany> companyList = new ArrayList<>();

        // Get snow company full object from ciam including UUID to be able to call /product?orgId = {orgUUID} in a later step
        if(ObjectUtils.isNotEmpty(companies)){
            for (CurveCompany snowCompany : companies){
                CurveCompany company = getCompanyWithUUID(snowCompany, requestDto);
                if(ObjectUtils.isNotEmpty(company)){
                    companyList.add(company);

                }else {
                    LOGGER.info("snow company "+ snowCompany.getName() +" is not found in ciam");
                }
            }

        }else{
            throw new DataNotFoundException("No snow companies found");
        }

        LOGGER.info("internal user flow  :: company list :: " + companyList);
        LOGGER.info("getSnowCompanies :: end");

        return companyList;
    }

    private CurveCompany getCompanyWithUUID(CurveCompany snowCompany, CurveHttpRequestDTO requestDto){

        CurveCompany company = null;
        String companyName = snowCompany.getName();
        LOGGER.info("getting legalOrgId name={}", snowCompany.getId());
        LOGGER.info("display name name={}", snowCompany.getDisplayName());
        String legalOrgId = snowCompany.getId();

        try {
            requestDto.setCompanyName(companyName);
            requestDto.setLegalOrgId(legalOrgId);
            List<CurveCompany> companyWithCiamUUID = getCiamCompanies(requestDto);

            if(ObjectUtils.isNotEmpty(companyWithCiamUUID)){
                company = companyWithCiamUUID.get(0);

            }else {
                LOGGER.info("snow company name :: "+ companyName + " :: is not found in ciam");
            }

        }catch (DataNotFoundException | ServiceException ex){
            LOGGER.error("Exception message :: " + ex.getMessage());
            LOGGER.info("DataNotFoundException :: snow company name :: "+ companyName + " :: is not found in ciam");
        }

        return company;

    }

    public CurveCompany getCompanyById(CurveHttpRequestDTO requestDto){
        return processGetCompanyByIdRequest(requestDto);
    }

    private CurveCompany processGetCompanyByIdRequest(CurveHttpRequestDTO requestDto){
        CurveCompany company = null;
        Response response = ciamClient.getCompanyById(requestDto);

        Integer statusCode = response.getStatus();
        if (statusCode.intValue() == HttpStatus.SC_OK || statusCode.intValue() == HttpStatus.SC_ACCEPTED) {
            company = response.readEntity(CurveCompany.class);
            LOGGER.info(company.toString());
        }else {
            CurveCompanyErrorResponse errorResponse = response.readEntity(CurveCompanyErrorResponse.class);
            LOGGER.error("Error {}", errorResponse);
            throw new ServiceException("Error from curve orchestrator: ".concat(errorResponse.getMessage()));
        }
        return company;
    }

    private static List<CurveCompanyGrouped> groupCompaniesByName(List<CurveCompany> companies){
        LOGGER.info("company grouping :: start");

        HashMap<String, List<CurveCompany>> map = new HashMap<>();
        List<CurveCompanyGrouped> groupedCompanies = new ArrayList<>();

        for (CurveCompany company : companies) {
            String key = company.getName().toLowerCase();

            if (!map.containsKey(key)){
                List<CurveCompany> temp = new ArrayList<>();
                temp.add(company);
                map.put(key, temp);

            } else {
                List<CurveCompany> value = map.get(key);
                value.add(company);
                map.put(company.getName().toLowerCase(), value);
            }
        }

        for (Map.Entry<String, List<CurveCompany>> entry: map.entrySet()){
            CurveCompanyGrouped groupedCompany = new CurveCompanyGrouped();
            Integer companySize = entry.getValue().size();
            groupedCompany.setCompanyName(entry.getKey());
            groupedCompany.setCompanies(entry.getValue().toArray(new CurveCompany[companySize]));
            groupedCompanies.add(groupedCompany);
        }

        LOGGER.info("company grouping :: end");
        LOGGER.info("groupedCompanies :: " + groupedCompanies);
        LOGGER.info("getCompanyList :: end");

        return groupedCompanies;
    }

    private List<CurveCompany> filterCompaniesWithLegalOrgIdMapped(List<CurveCompany> unfilteredCompanies) {
        return unfilteredCompanies.stream().filter( company -> {
            Location[] locations = company.getLocation();
            if (locations.length <= 0) {
                return false;
            }
            LOGGER.info("company :: " + company);

            List<Location> filteredLocations = new ArrayList<>();
            for (Location location : locations) {
                try {
                    boolean hasLegalOrgIdMapped =  curveUtils.getLegalOrgId(location.getCountryCode(), company.getDisplayName()) != null;
                    if (hasLegalOrgIdMapped) {
                        filteredLocations.add(location);
                    }
                } catch (BackendSystemException exception) {
                    LOGGER.info("Company " + company.getDisplayName() + " from " + location.getCountryCode() + " does not have legalOrgId mapped");
                }
            }
            company.setLocation(filteredLocations.toArray(new Location[0]));

            return !filteredLocations.isEmpty();
        }).collect(Collectors.toList());
    }
}
