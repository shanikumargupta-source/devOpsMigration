package com.vf.cove.curve.internal.client;

import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.CurveConstant;
import org.apache.http.entity.ContentType;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.Response;
import java.util.Base64;
import java.util.Objects;

import static com.vf.cove.curve.internal.utils.CurveUtils.getSecret;

/**
 * Client class for sending REST requests
 */
@Component(
    configurationPid = CurveApiConfiguration.PID,
    service = CurveCiamClient.class
)
public class CurveCiamClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveCiamClient.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration config;

    @Reference(unbind = "-")
    ClientSSLConfiguration sslConfiguration;

    /**
     * Send POST request with authorization header and additional headers
     *
     * @param code - ciam access code
     * @return responseDTO - the Response of the POST request
     */
    public Response getCiamAccessToken(String code, String redirectUri, Boolean isExpired) throws ConfigurationException {
        LOGGER.debug("CurveCiamClient :: processPostRequest :: start");

        String basicAuth = getSecret(config.ciamUserName()) + ":" + getSecret(config.ciamPassword());
        String authorizationToken = CurveConstant.BASIC + Base64.getEncoder().encodeToString(basicAuth.getBytes());
        Client client = ClientBuilder.newClient().register(JacksonJaxbJsonProvider.class);

        Response response = null;
        try {
            response = client.target(config.ciamBaseURL()).path(config.accessTokenURIPath())
                    .request()
                    .accept(MediaType.APPLICATION_JSON)
                    .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_FORM_URLENCODED)
                    .header(CurveConstant.AUTHORIZATION, authorizationToken)
                    .post(Entity.form(getRequestBodyForm(code, redirectUri, isExpired)));
        } catch (Exception e) {
            LOGGER.error("Unable to make the DXL call", e);
            throw new BackendSystemException("DXL Call failed");
        }

        if(Objects.isNull(response)){
            throw new BackendSystemException("Ciam response is empty");
        }

        LOGGER.debug("CurveCiamClient :: processPostRequest :: end");
        return response;

    }

    public MultivaluedHashMap<String, String> getRequestBodyForm(String code, String redirectURI, Boolean isExpired){
        LOGGER.debug("CurveCiamClient :: getRequestBodyForm");

        MultivaluedHashMap <String, String> entity = new MultivaluedHashMap<>();
        entity.add(CurveConstant.REDIRECT_URI, redirectURI);

        if(isExpired){
            entity.add(CurveConstant.GRANT_TYPE, config.refreshTokenGrantType());
            entity.add(CurveConstant.REFRESH_TOKEN, code);

        }else{
            entity.add(CurveConstant.GRANT_TYPE, config.accessTokenGrantType());
            entity.add(CurveConstant.CODE, code);
        }

        return entity;
    }



}
