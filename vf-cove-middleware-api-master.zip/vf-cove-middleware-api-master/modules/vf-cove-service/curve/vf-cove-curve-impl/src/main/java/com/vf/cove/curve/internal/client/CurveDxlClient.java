package com.vf.cove.curve.internal.client;

import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.Response;

import static com.vf.cove.curve.internal.model.CurveConstant.DXL_APIGEE_SCOPE;
import static com.vf.cove.curve.internal.utils.CurveUtils.getSecret;

/**
 * Client class for sending REST requests to curve
 *
 * @author Omar Ismail
 */

@Component(immediate = true, service = CurveDxlClient.class)
public class CurveDxlClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveDxlClient.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    @Reference(unbind = "-")
    private ClientSSLConfiguration clientSSLConfiguration;

    private static String dxlErrorMessage = "Error in invoking DXL APIGEE: {}";

    /**
     * Send POST request with encoded parameters and additional headers
     *
     * @param requestDto - context object contains all headers, request and response objects
     * @return the Response to the POST request
     */
    public Response getDxlAccessToken(CurveHttpRequestDTO requestDto) {
        LOGGER.info("getDxlAccessToken :: start");

        Response response = null;
        try {
            Client client = clientSSLConfiguration.getClient();
            response = client.target(curveApiConfiguration.dxlOrchestratorBaseUrl())
                .path(curveApiConfiguration.dxlAccessTokenEndpoint())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .post(Entity.form(getRequestBodyForm()));

        } catch (Exception e) {
            throw new ServiceException(dxlErrorMessage.concat(e.getMessage()));
        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }

        LOGGER.info("getDxlAccessToken :: end");
        return response;
    }

    private MultivaluedHashMap<String, String> getRequestBodyForm() throws ConfigurationException {

        MultivaluedHashMap <String, String> entity = new MultivaluedHashMap<>();
        entity.add(CurveConstant.DXL_APIGEE_CLIENT_ID, getSecret(curveApiConfiguration.dxlClientId()));
        entity.add(CurveConstant.DXL_APIGEE_CLIENT_SECRET, getSecret(curveApiConfiguration.dxlClientSecret()));
        entity.add(DXL_APIGEE_SCOPE, curveApiConfiguration.dxlScope());
        entity.add(CurveConstant.DXL_APIGEE_GRANT_TYPE, curveApiConfiguration.dxlGrantType());

        return entity;
    }


}
