package com.vf.cove.curve.internal.client;

import com.vf.cove.curve.dto.v1_0.CurveCompany;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.DataNotFoundException;
import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveCompanyErrorResponse;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import static com.vf.cove.curve.internal.model.CurveConstant.*;

@Component(immediate = true, service = CurveSnowClient.class)
public class CurveSnowClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveSnowClient.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    @Reference(unbind = "-")
    private ClientSSLConfiguration clientSSLConfiguration;


    public List<CurveCompany> getCompanyListByGranterEmail(CurveHttpRequestDTO requestDto) {
        String targetHost = curveApiConfiguration.dxlOrchestratorBaseUrl();
        String path = curveApiConfiguration.snowCompanyEndpoint();

        Response response = callSnowClient(requestDto, targetHost, path);
        LOGGER.info("getCompanyByGranterEmail :: start");
        return mapToDto(response);

    }

    private Response callSnowClient(CurveHttpRequestDTO requestDto, String targetHost, String path) {

        LOGGER.info("targetHost={}", targetHost);
        LOGGER.info("path={}", path);
        Response response;

        try {
             response = clientSSLConfiguration.getClient().target(targetHost).path(path)
                .queryParam("userEmail", requestDto.getGranterEmail())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(AUTHORIZATION, requestDto.getHeaders().get(DXL_TOKEN))
                .header(CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(ACCEPT, ContentType.APPLICATION_JSON)
                .header(X_TRANSACTION_ID, UUID.randomUUID())
                .header(X_SOURCE_SYSTEM, CURVE)
                .header(X_DESTINATION_SYSTEM, SNOW)
                .header(X_ROUTE_INFO, PARTY_MANAGEMENT)
                .header(DATE, new Timestamp(new Date().getTime()))
                .get();

        } catch (SSLConnectivityException e) {
            throw new ServiceException(CurveConstant.GENERAL_ERROR, e);
        }

        if (Objects.isNull(response)) {
            throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
        }

        return response;
    }

    private List<CurveCompany> mapToDto(Response response){

        List<CurveCompany> companies;
        Integer statusCode = response.getStatus();
        LOGGER.info("statusCode :: " + statusCode);

        if (statusCode.intValue() == HttpStatus.SC_OK || statusCode.intValue() == HttpStatus.SC_ACCEPTED) {
            companies = response.readEntity(new GenericType<List<CurveCompany>>(){});
            LOGGER.info("company list :: " + companies);

        } else {
            CurveCompanyErrorResponse errorResponse = response.readEntity(CurveCompanyErrorResponse.class);
            LOGGER.error(String.valueOf(errorResponse));

            throw new ServiceException("Error getting companies :: " + errorResponse.getMessage());
        }

        return companies;
    }
}
