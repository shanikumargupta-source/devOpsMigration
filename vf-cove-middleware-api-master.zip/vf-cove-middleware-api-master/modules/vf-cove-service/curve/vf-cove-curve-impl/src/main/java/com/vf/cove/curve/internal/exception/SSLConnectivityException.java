package com.vf.cove.curve.internal.exception;

public class SSLConnectivityException extends Throwable {

    public SSLConnectivityException(String message) {
        super(message);
    }

    public SSLConnectivityException(String message, Throwable throwable) {
        super(message, throwable);
    }

}
