package com.vf.cove.curve.internal.model;

public class CurveConstant {

    public static final String CONTENT_TYPE = "content-type";

    public static final String AUTHORIZATION = "Authorization";
    public static final String ACCEPT = "accept";

    public static final String BASIC = "Basic ";

    public static final String GRANT_TYPE = "grant_type";

    public static final String CODE = "code";

    public static final String REDIRECT_URI = "redirect_uri";

    public static final String ACCESS_TOKEN = "access_token";

    public static final String REFRESH_TOKEN = "refresh_token";

    public static final String SCOPE = "scope";

    public static final String ID_TOKEN = "id_token";

    public static final String TOKEN_TYPE = "token_type";

    public static final String DXL_APIGEE_CLIENT_ID = "client_id";

    public static final String DXL_APIGEE_CLIENT_SECRET = "client_secret";

    public static final String DXL_APIGEE_SCOPE = "scope";

    public static final String DXL_APIGEE_GRANT_TYPE = "grant_type";

    public static final String X_TRANSACTION_ID = "x-transaction-id";

    public static final String X_SOURCE_SYSTEM = "x_source_system";

    public static final String X_ROUTE_INFO = "x-route-info";

    public static final String X_DESTINATION_SYSTEM = "x-destination-system";

    public static final String DXL_ACCESS_TOKEN_COOKIE = "dxl_access_token_cookie";

    public static final String DXL_TOKEN = "dxl-token";

    public static final String CIAM_ACCESS_TOKEN_COOKIE = "ciam_access_token_cookie";

    public static final String CIAM_REFRESH_TOKEN_COOKIE = "ciam_refresh_token_cookie";

    public static final String X_CIAM_TOKEN = "x-ciam-token";

    public static final String GRANTER_EMAIL = "granterEmail";

    public static final String SEARCH = "q";

    public static final String STATUS = "status";

    public static final String SORT = "sort";

    public static final String ASC = "asc";

    public static final String DESC = "desc";

    public static final String LEGAL_ORG_ID = "LegalOrgId";

    public static final String ID = "id";

    public static final String LEGAL_ORG_ID_FIELD = "legalOrgId";

    public static final String SELECTED_ORGANIZATION_ID = "selectedOrganisationId";

    public static final String ORGANIZATION_COUNTRY_CODE = "organizationCountryCode";

    public static final String ORGANIZATION_NAME = "organisationName";

    public static final String COUNTRY_CODE_FIELD = "countryCode";

    public static final String COUNTRY_NAME = "countryName";

    public static final String USER_GROUP_FIELD = "userGroup";

    public static final String PRODUCT_NAME = "productName";

    public static final String PRODUCT_ID = "productId";

    public static final String ROLE_NAME = "roleName";

    public static final String ORG_ID = "orgId";

    public static final String OFFSET = "offset";

    public static final String LIMIT = "limit";

    public static final String FIELDS = "fields";

    public static final String BAD_REQUEST = "Bad Request, error code : ";

    public static final String UNAUTHORIZED = "Unauthorized, error code : ";

    public static final String NOT_FOUND = "Not Found, error code : ";

    public static final String BAD_GATEWAY = "Bad gateway, error code : ";

    public static final String METHOD_NOT_ALLOWED ="Method not allowed, error code : ";

    public static final String SERVICE_UNAVAILABLE = "Backend System Unavailable, error code : ";

    public static final String GENERAL_ERROR = "Backend System Error, error code : ";

    public static final String BACKEND_SYSTEM_ERROR ="Curve backend system response is empty, error code : ";

    public static final String COVE = "COVE";

    public static final String CURVE = "CURVE";

    public static final String SNOW = "SNOW";

    public static final String PARTY_MANAGEMENT = "CURVE.PartyManagement";

    public static final String DATE = "Date";

    public static final String ERROR_MESSAGE = "Unable to find legalOrgId";

    public static final String EXCEL_FILE_NAME = "fileName";

    public static final String EXCEL_SHEET_NAME = "sheetName";

    public static final String FIRST_NAME_HEADER_KEY = "firstNameHeader";
    public static final String LAST_NAME_HEADER_KEY = "lastNameHeader";
    public static final String EMAIL_HEADER_KEY = "emailHeader";
    public static final String ACTIVATION_DATE_HEADER_KEY = "activationDateHeader";
    public static final String SEND_EMAIL_HEADER_KEY = "sendEmailHeader";
    public static final String ROLE_HEADER_KEY = "roleHeader";
    public static final String USER_GROUP_HEADER_KEY = "userGroupHeader";
    public static final String PHONE_NUMBER_HEADER_KEY = "phoneNumberHeader";
    public static final String TARIFF_HEADER_KEY = "tariffHeader";
    public static final String UPGRADE_DATE_HEADER_KEY = "upgradeDateHeader";

    public static final String SHEET_NAME = "Create User";
    public static final String FIRST_NAME = "First Name";
    public static final String LAST_NAME = "Last Name";
    public static final String EMAIL = "Email";
    public static final String ACTIVATION_DATE = "Activation Date";
    public static final String SEND_EMAIL = "Send email";
    public static final String ROLE = "Role";
    public static final String USER_GROUP = "User Group";
    public static final String PHONE_NUMBER = "Phone Number";
    public static final String TARIFF = "Tariff";

    public static final String TARIFF_VOICEDATA = "voiceData";
    public static final String TARIFF_DATA = "data";
    public static final String UPGRADE_DATE = "Upgrade Date";

    public static final String STRING_REGEX = "^[A-Za-z0-9 ]+$";

    public static final String EMAIL_REGEX = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

    public static final String DATE_REGEX = "^(((0[1-9]|[12]\\d|3[01])\\/(0[13578]|1[02])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|[12]\\d|30)\\/(0[13456789]|1[012])\\/((19|[2-9]\\d)\\d{2}))|((0[1-9]|1\\d|2[0-8])\\/02\\/((19|[2-9]\\d)\\d{2}))|(29\\/02\\/((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|(([1][26]|[2468][048]|[3579][26])00))))$";

    public static final String DATE_BODY_REGEX = "^(((19|[2-9]\\d)\\d{2})\\-(0[13578]|1[02])\\-(0[1-9]|[12]\\d|3[01])T[0-2][0-9]:[0-5][0-9]:[0-6][0-9]Z)|(((19|[2-9]\\d)\\d{2})\\-(0[13456789]|1[012])\\-(0[1-9]|[12]\\d|30)T[0-2][0-9]:[0-5][0-9]:[0-6][0-9]Z)|(((19|[2-9]\\d)\\d{2})\\-02\\-(0[1-9]|1\\d|2[0-8])T[0-2][0-9]:[0-5][0-9]:[0-6][0-9]Z)|(((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26]T[0-2][0-9]:[0-5][0-9]:[0-6][0-9]Z)|(([1][26]|[2468][048]|[3579][26])00))-02-29T[0-2][0-9]:[0-5][0-9]:[0-6][0-9]Z)$";

    public static final String PHONE_NUMBER_REGEX = "^\\+\\1?[1-9][0-9]{7,14}$";

    public static final String DEFAULT_ISO_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    public static final String SPREADSHEET_FORMAT = "dd/M/yyyy";

    public static final String SIMPLE_DATE_FORMAT = "dd/mm/yyyy";

    public static final String REQUEST_BODY_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    public static final String INVALID_TEXT_FORMAT = "Name cannot contain any special characters";

    public static final String INVALID_DATE_FORMAT = "Incorrect format. Needs to be in the format dd/mm/yyyy ";

    public static final String INVALID_POPULATION = " should only be provided when phone number is populated";

    public static final String FIELD_MUST_BE_POPULATED_WHEN_A_PHONE_NUMBER_IS_PROVIDED = " Field must be populated when a phone number is provided";

    public static final String INVALID_FILE = "Please provide a valid file";

    public static final String LEGAL_ORG_ID_NOT_MAPPED = "Company does not have a legalOrgId mapped";

    public static final String LEVEL_1_ORGANIZATION = "L1";
    public static final String LEVEL_3_ORGANIZATION = "L3";

    private CurveConstant() {}
}
