package com.vf.cove.curve.internal.model;

import com.vf.cove.curve.dto.v1_0.Error;
import lombok.Data;

import java.util.List;

@Data
public class BulkUserValidationDTO {

    List<UserDTO> userList;

    List<Error> errorList;

    List<String> csvHeaders;

}
