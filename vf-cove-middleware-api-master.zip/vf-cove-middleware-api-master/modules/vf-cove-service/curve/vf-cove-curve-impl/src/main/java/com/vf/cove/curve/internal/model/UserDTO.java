package com.vf.cove.curve.internal.model;

import com.opencsv.bean.CsvBindByName;
import lombok.Data;

@Data
public class UserDTO implements Comparable<UserDTO>{

    @CsvBindByName(column = "First Name")
    String  firstName;

    @CsvBindByName(column = "Last Name")
    String  lastName;

    @CsvBindByName(column = "Email")
    String  email;

    @CsvBindByName(column = "Activation Date")
    String  activationDate;

    @CsvBindByName(column = "Send Email")
    String  sendEmail;

    @CsvBindByName(column = "Role")
    String  role;

    @CsvBindByName(column = "User Group")
    String  userGroup;

    @CsvBindByName(column = "Phone Number")
    String  phoneNumber;

    @CsvBindByName(column = "Tariff")
    String tariff;

    @CsvBindByName(column = "Upgrade Date")
    String upgradeDate;

    Integer rowIndex;

    @Override
    public int compareTo(UserDTO o) {
        return this.rowIndex.compareTo(o.getRowIndex());
    }
}
