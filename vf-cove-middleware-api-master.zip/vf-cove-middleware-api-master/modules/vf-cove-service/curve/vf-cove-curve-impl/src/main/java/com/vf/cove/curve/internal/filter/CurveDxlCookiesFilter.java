package com.vf.cove.curve.internal.filter;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.CurveApigeeSuccessResponse;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.DxlAccessTokenService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.internal.utils.MutableHttpServletRequestWrapper;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;

@Component(
    immediate = true,
    service = Filter.class,
    property = {
        "servlet-context-name=",
        "servlet-filter-name=Curve Dxl Cookies Filter",
        "url-pattern=/o/vf-cove-curve/*"
    }
)
public class CurveDxlCookiesFilter extends BaseFilter {

    private static final Log logger = LogFactoryUtil.getLog(CurveDxlCookiesFilter.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    @Reference(unbind = "-")
    private DxlAccessTokenService dxlAccessTokenService;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        logger.info("dxl filter :: start" );
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        MutableHttpServletRequestWrapper mutableRequest = new MutableHttpServletRequestWrapper(request);
        final Cookie[] cookies = request.getCookies();
        if (curveApiConfiguration.isCurveDxlFilterEnabled()) {
            Optional<Cookie> dxlCookie = findCookieByName(cookies, CurveConstant.DXL_ACCESS_TOKEN_COOKIE);
            if(!dxlCookie.isPresent()){
                CurveHttpRequestDTO requestDto = new CurveHttpRequestDTO(CurveUtils.getHeadersAsMap(request), request, response);
                CurveApigeeSuccessResponse apigeeSuccessResponse = this.dxlAccessTokenService.getDxlAccessToken(requestDto);
                addCookieAsHeaderInRequest(CurveConstant.DXL_TOKEN, convertTokenToBearerToken(apigeeSuccessResponse.getAccessToken()), mutableRequest);

            }else {
                addCookieAsHeaderInRequest(CurveConstant.DXL_TOKEN, convertTokenToBearerToken(dxlCookie.get().getValue()), mutableRequest);
            }
        }
        logger.debug("DXL Filter :: DXL_TOKEN :: " + mutableRequest.getHeader(CurveConstant.DXL_TOKEN));
        logger.debug("dxl filter :: end" );

        super.doFilter(mutableRequest, servletResponse, filterChain);
    }

    private String convertTokenToBearerToken(String token){
        return "Bearer ".concat(token);
    }

    private void addCookieAsHeaderInRequest(String headerName, String headerValue, MutableHttpServletRequestWrapper request){
        request.addHeader(headerName, headerValue);
    }

    private Optional<Cookie> findCookieByName(Cookie [] cookies, String cookieName){
        if (cookies == null){cookies = new Cookie[0];}
         return Arrays.stream(cookies)
            .filter(cookie -> cookie.getName().equals(cookieName))
            .findFirst();
    }

    @Override
    protected Log getLog() {
        return logger;
    }
}
