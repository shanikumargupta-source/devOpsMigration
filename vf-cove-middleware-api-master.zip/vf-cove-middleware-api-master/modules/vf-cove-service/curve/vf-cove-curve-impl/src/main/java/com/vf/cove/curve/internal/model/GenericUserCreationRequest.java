package com.vf.cove.curve.internal.model;

import lombok.Data;

@Data
public class GenericUserCreationRequest {

    String  firstName;

    String  lastName;

    String  email;

    String  activationDate;

    String  sendEmail;

    String  role;

    String  userGroup;

    String  phoneNumber;

    String tariff;

    String upgradeDate;

}
