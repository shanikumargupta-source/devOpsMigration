package com.vf.cove.curve.internal.resource.v1_0;

import com.vf.cove.curve.dto.v1_0.DxlAccessToken;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.DxlAccessTokenService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.DxlAccessTokenResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author Omar Ismail
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/dxl-access-token.properties",
	scope = ServiceScope.PROTOTYPE, service = DxlAccessTokenResource.class
)
public class DxlAccessTokenResourceImpl extends BaseDxlAccessTokenResourceImpl {

    @Reference(unbind = "-")
    DxlAccessTokenService dxlAccessTokenService;

    @Override
    public DxlAccessToken getDxlAccessToken() throws Exception {
        CurveHttpRequestDTO requestDto = new CurveHttpRequestDTO(CurveUtils.getHeadersAsMap(contextHttpServletRequest), contextHttpServletRequest, contextHttpServletResponse);
        this.dxlAccessTokenService.getDxlAccessToken(requestDto);
        return new DxlAccessToken();
    }
}
