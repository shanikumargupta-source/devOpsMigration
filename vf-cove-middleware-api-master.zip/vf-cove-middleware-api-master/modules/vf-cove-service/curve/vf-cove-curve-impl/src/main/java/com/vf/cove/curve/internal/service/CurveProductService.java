package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.CurveProduct;
import com.vf.cove.curve.internal.client.CurveProductClient;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Component(service = CurveProductService.class)
public class CurveProductService {

    private static final Logger logger = LoggerFactory.getLogger(CurveProductService.class);

    @Reference(unbind = "-")
    CurveProductClient curveProductClient;

    public List<CurveProduct> getCurveProductList(CurveHttpRequestDTO curveHttpRequestDTO) {
        logger.info("CurveProductService :: getCurveProductList ");
        return  curveProductClient.getProductList(curveHttpRequestDTO);
    }

    public CurveProduct getCurveProductById(CurveHttpRequestDTO curveHttpRequestDTO) {
        logger.info("CurveProductService :: getCurveProductById ");
        return  curveProductClient.getProductById(curveHttpRequestDTO);
    }

}
