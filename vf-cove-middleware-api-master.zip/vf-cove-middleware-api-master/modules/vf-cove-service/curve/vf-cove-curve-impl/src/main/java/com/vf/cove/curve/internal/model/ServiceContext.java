package com.vf.cove.curve.internal.model;

import java.util.Map;

public class ServiceContext {
    private Map<String, String> headers;

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }
}
