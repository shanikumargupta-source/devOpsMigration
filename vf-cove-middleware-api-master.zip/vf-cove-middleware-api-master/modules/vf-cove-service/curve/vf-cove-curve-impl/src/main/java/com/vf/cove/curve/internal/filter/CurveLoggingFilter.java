package com.vf.cove.curve.internal.filter;

import org.slf4j.Logger;

import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import java.io.IOException;
import java.util.Objects;

public class CurveLoggingFilter implements ClientRequestFilter {

    private static Logger logger;

    private static String requestUriPrefix = "Request URI :: {} ";
    private static String requestBodyPrefix = "Request body :: {} ";

    public CurveLoggingFilter(Logger logger) {
        this.logger = logger;
    }

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {

        if(Objects.nonNull(requestContext)){
            if(Objects.nonNull(requestContext.getUri())){
                logger.info(requestUriPrefix, requestContext.getUri().toString());
            }

            if(Objects.nonNull(requestContext.getEntity())){
                logger.info(requestBodyPrefix, requestContext.getEntity().toString());
            }
        }

    }
}
