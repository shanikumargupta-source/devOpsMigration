package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.BulkUserValidationResponse;
import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.internal.client.CurveUserClient;
import com.vf.cove.curve.internal.model.*;
import com.vf.cove.curve.internal.utils.BulkUserValidationUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.vf.cove.curve.internal.model.CurveConstant.INVALID_FILE;
import static com.vf.cove.curve.internal.utils.BulkUserValidationUtil.getError;
import static java.util.stream.Collectors.toList;

@Component(service = BulkUserValidationService.class)
public class BulkUserValidationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BulkUserValidationService.class);

    @Reference(unbind = "-")
    CurveUserClient curveUserClient;
    @Reference(unbind = "-")
    BulkUserValidationUtil bulkUserValidationUtil;



    public BulkUserValidationResponse validaBulkUserSubmittedFile(InputStream inputStream, Map<String, String> paramsMap, CurveHttpRequestDTO request) {

        //data validation
        BulkUserValidationDTO validationDTO = bulkUserValidationUtil.validateBulkUserFile(inputStream, paramsMap);

        //create bulk user or return the file validation errors
        return getBulkUserResponse(validationDTO.getUserList(), validationDTO.getErrorList(), paramsMap, request);
    }

    BulkUserValidationResponse getBulkUserResponse(List<UserDTO> userDTOList, List<Error> errorList, Map<String, String> paramsMap, CurveHttpRequestDTO request) {
        LOGGER.debug("getBulkUserResponse :: start");
        BulkUserValidationResponse response = new BulkUserValidationResponse();
        List<Error> errors = new ArrayList<>();
        int invalidUserCount = 0;
        int totalUserCount = 0;
        boolean isValidFile = false;
        boolean isStructureError = false;

        if (CollectionUtils.isNotEmpty(userDTOList)) {

            invalidUserCount = getFailedUserCount(errorList);
            totalUserCount = userDTOList.size();

            if (CollectionUtils.isNotEmpty(errorList) && ObjectUtils.allNotNull(errorList)) {
                return getFileValidationResponse(response, totalUserCount, errorList);
            }

            //map userDTO to curveUser
            List<CurveUser> curveUsers = bulkUserValidationUtil.mapToCurveUser(userDTOList, paramsMap);
            //checks if user exists in curveDB
            List<String> existingUsers = getExistingUsers(curveUsers, request);

            //if users don't exist create them in ciam
            if (CollectionUtils.isEmpty(existingUsers)) {
                curveUserClient.createUser(curveUsers.stream().toArray(CurveUser[]::new), request);
                isValidFile = true;
            } else {
                invalidUserCount = existingUsers.size();

                List<UserDTO> existingUserList = userDTOList.stream()
                    .filter(userDTO -> existingUsers.stream()
                        .anyMatch(userEmail -> userEmail.equals(userDTO.getEmail())))
                    .collect(Collectors.toList());

                existingUserList.stream().filter(ObjectUtils::isNotEmpty).forEach(user ->
                    errors.add(getError(user.getEmail(), "user already exists", CurveConstant.EMAIL, ErrorTypeEnum.DUPLICATED, user.getRowIndex()))
                );
            }

        } else {
            errors.add(getError(INVALID_FILE, ErrorTypeEnum.FILE_STRUCTURE));
            isStructureError = true;
        }

        if(ObjectUtils.isNotEmpty(errors)){
            response.setErrors(errors.stream().filter(ObjectUtils::isNotEmpty).toArray(Error[]::new));
        }

        setBulkUserResponse(response, isValidFile, isStructureError, invalidUserCount, totalUserCount);

        LOGGER.debug("getBulkUserResponse :: end");
        return response;
    }

    BulkUserValidationResponse getFileValidationResponse(BulkUserValidationResponse response, int userListCount, List<Error> errorList) {
        LOGGER.debug("getFileValidationResponse :: start");
        response.setErrors(errorList.stream().toArray(Error[]::new));

        errorList.stream().findAny().map(Error::getErrorType).ifPresent(errorType -> {
            if (errorType.equals(ErrorTypeEnum.FILE_STRUCTURE)) {
                setBulkUserResponse(response,false, true, 0, 0);

            } else {
                setBulkUserResponse(response,false, false, getFailedUserCount(errorList), userListCount);

            }
        });

        LOGGER.debug("getFileValidationResponse :: end");
        return response;
    }

    void setBulkUserResponse(BulkUserValidationResponse response, boolean isValidFile, boolean isStructureError, int failedUserCount, int userListCount) {
        LOGGER.debug("setBulkUserResponse :: start");

        int validUserCount = userListCount - failedUserCount;
        response.setIsValid(isValidFile);
        response.setIsStructureError(isStructureError);
        response.setValidUserCount(validUserCount);
        response.setInvalidUserCount(failedUserCount);

        LOGGER.debug("isValid file :: {} ", isValidFile);
        LOGGER.debug("setBulkUserResponse :: end");
    }

    public List<String> getExistingUsers(List<CurveUser> userList, CurveHttpRequestDTO curveHttpRequestDTO) {
        List<String> userNameList = userList.stream().filter(user -> !user.getUserName().isEmpty()).map(CurveUser::getUserName).collect(toList());
        return curveUserClient.getUserByIdList(userNameList, curveHttpRequestDTO);
    }

    public int getFailedUserCount(List<Error> errors) {
        return (int) errors.stream().filter(Objects::nonNull).map(Error::getRow).filter(Objects::nonNull).distinct().count();
    }


}
