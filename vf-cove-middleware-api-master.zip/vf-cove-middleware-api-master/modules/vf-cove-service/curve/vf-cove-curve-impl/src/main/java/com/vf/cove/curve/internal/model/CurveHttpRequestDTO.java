package com.vf.cove.curve.internal.model;

import lombok.Data;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@Data
public class CurveHttpRequestDTO {

    private String userId;

    private String productId;

    private String orgId;

    private String legalOrgId;

    private Integer offset;

    private Integer limit;

    private String status;

    private String search;

    private String sort;

    private String dxlToken;

    private String ciamToken;

    private String granterEmail;

    private String sourceSystem;

    private String companyId;

    private String companyName;

    private Map<String, String> headers;

    private Map<String, String> params;

    private HttpServletRequest httpServletRequest;

    private HttpServletResponse httpServletResponse;

    private String ciamAccessCode;

    private Boolean isCiamTokenExpired;

    public CurveHttpRequestDTO() {
    }

    public CurveHttpRequestDTO(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, String ciamAccessCode, Boolean isCiamTokenExpired) {
        this.httpServletRequest = httpServletRequest;
        this.httpServletResponse = httpServletResponse;
        this.ciamAccessCode = ciamAccessCode;
        this.isCiamTokenExpired = isCiamTokenExpired;
    }

    public CurveHttpRequestDTO(Map<String, String> headers, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        this.headers = headers;
        this.httpServletRequest = httpServletRequest;
        this.httpServletResponse = httpServletResponse;
    }

    public CurveHttpRequestDTO(Integer offset, Integer limit, Map<String, String> headers, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        this.offset = offset;
        this.limit = limit;
        this.headers = headers;
        this.httpServletRequest = httpServletRequest;
        this.httpServletResponse = httpServletResponse;
    }

    public CurveHttpRequestDTO(String companyId, Map<String, String> headers, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        this.companyId = companyId;
        this.headers = headers;
        this.httpServletRequest = httpServletRequest;
        this.httpServletResponse = httpServletResponse;
    }
}
