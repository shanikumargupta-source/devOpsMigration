package com.vf.cove.curve.internal.exception;

public class ServiceException extends RuntimeException {

    public ServiceException(String errorMessage) {
        super(errorMessage);
    }

    public ServiceException(String errorMessage, Exception e) {
        super(errorMessage, e);
    }

    public ServiceException(String errorMessage, SSLConnectivityException e) {
        super(errorMessage, e);
    }
}
