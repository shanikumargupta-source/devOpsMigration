package com.vf.cove.curve.internal.model;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.type.ErrorType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.type.TypeVisitor;
import java.lang.annotation.Annotation;
import java.util.List;

public enum ErrorTypeEnum implements ErrorType {

    FORMAT("format"),
    REQUIRED("is-required"),
    DUPLICATED("duplicated"),
    FILE_STRUCTURE("file-structure"),
    OUT_OF_BOUNDS("out-of-bounds"),
    NOT_ALLOWED("not-allowed");

    public final String label;

    ErrorTypeEnum(String label) {
        this.label = label;
    }

    @Override
    public Element asElement() {
        return null;
    }

    @Override
    public TypeMirror getEnclosingType() {
        return null;
    }

    @Override
    public List<? extends TypeMirror> getTypeArguments() {
        return null;
    }

    @Override
    public TypeKind getKind() {
        return null;
    }

    @Override
    public <R, P> R accept(TypeVisitor<R, P> v, P p) {
        return null;
    }

    @Override
    public List<? extends AnnotationMirror> getAnnotationMirrors() {
        return null;
    }

    @Override
    public <A extends Annotation> A getAnnotation(Class<A> annotationType) {
        return null;
    }

    @Override
    public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
        return null;
    }
}
