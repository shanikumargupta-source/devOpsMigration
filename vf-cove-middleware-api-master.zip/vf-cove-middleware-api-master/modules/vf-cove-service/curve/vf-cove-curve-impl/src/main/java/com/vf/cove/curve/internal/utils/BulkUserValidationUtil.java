package com.vf.cove.curve.internal.utils;

import aQute.bnd.osgi.resource.FilterParser;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBeanBuilder;
import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.exception.CSVParserException;
import com.vf.cove.curve.internal.model.*;
import com.vf.cove.curve.internal.service.UserGroupsUploadFileService;
import org.apache.commons.codec.binary.Base64InputStream;
import org.apache.commons.lang3.ObjectUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.vf.cove.curve.internal.model.CurveConstant.*;
import static com.vf.cove.curve.internal.utils.ExcelUtils.CSV_PARSER_EXCEPTION_MESSAGE;
import static com.vf.cove.curve.internal.utils.ExcelUtils.isGhostUserList;
import static java.util.stream.Collectors.toList;

@Component(
    configurationPid = CurveApiConfiguration.PID,
    service = BulkUserValidationUtil.class
)
public class BulkUserValidationUtil {

    @Reference(unbind = "-")
    CurveApiConfiguration config;

    @Reference(unbind = "-")
    UserGroupsUploadFileService userGroupsUploadFileService;

    @Reference(unbind = "-")
    CurveUtils curveUtils;

    @Reference(unbind = "-")
    CommonUserDataValidationUtil commonUserDataValidationUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(BulkUserValidationUtil.class);

    public BulkUserValidationDTO validateBulkUserFile(InputStream inputStream, Map<String, String> paramsMap){
        BulkUserValidationDTO validationDTO = new BulkUserValidationDTO();
        BulkUserValidationDTO csvFileDTO;

        final CompanyLevel companyLevel = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(
            paramsMap.get(ORGANIZATION_NAME),
            paramsMap.get(COUNTRY_CODE_FIELD));

        try{
            csvFileDTO = createUserObject(companyLevel, inputStream);
            List<UserDTO>  userList = csvFileDTO.getUserList();
            validationDTO.setUserList(userList);

            //validate sheet structure
            List<Error> structureErrorList = validateSheetStructure(csvFileDTO);
            if(ObjectUtils.isNotEmpty(structureErrorList)){
                validationDTO.setErrorList(structureErrorList);
            } else {
                //validate sheet data
                validationDTO.setErrorList(validateSheetData(companyLevel, userList, paramsMap));
            }

        } catch (CSVParserException e){
            validationDTO.setErrorList(Collections.singletonList(getError(INVALID_FILE, ErrorTypeEnum.FILE_STRUCTURE)));
        }

        return validationDTO;

    }


    public static BulkUserValidationDTO createUserObject(CompanyLevel companyLevel, InputStream inputStream) {
        List<UserDTO> userList;
        String[] headers;

        final InputStream decodedInputStream = new Base64InputStream(inputStream);

        try (CSVReader csvReader = new CSVReader(new InputStreamReader(decodedInputStream, StandardCharsets.UTF_8))) {
            headers = csvReader.peek();
            userList = new CsvToBeanBuilder<UserDTO>(csvReader)
                //skip empty lines
                .withFilter(stringValues -> Arrays.stream(stringValues)
                    .anyMatch(value -> ObjectUtils.isNotEmpty(value) && value.length() > 0))
                .withIgnoreLeadingWhiteSpace(true)
                .withType(UserDTO.class)
                .build()
                .parse();


            if (isGhostUserList(userList)) {
                throw new CSVParserException(CSV_PARSER_EXCEPTION_MESSAGE);
            }

            enrichUserObject(companyLevel, userList);

        } catch (IOException | RuntimeException e ) {
            throw new CSVParserException(e.getMessage());
        }

        // sets bulkUserValidationDTO object
        BulkUserValidationDTO validationDTO = new BulkUserValidationDTO();
        validationDTO.setCsvHeaders(Arrays.stream(Optional.ofNullable(headers).get()).collect(toList()));
        validationDTO.setUserList(userList);

        return validationDTO;

    }

    private static void enrichUserObject(CompanyLevel companyLevel, List<UserDTO> userList) {

        if (ObjectUtils.isNotEmpty(userList)) {

            AtomicInteger index = new AtomicInteger(6);
            userList.stream().filter(ObjectUtils::isNotEmpty).forEach(user -> {
                int recordNum = index.getAndIncrement();
                user.setRowIndex(recordNum);

                if (companyLevel.isLevel1() && user.getTariff().isEmpty()) {
                    user.setTariff(TARIFF_VOICEDATA);
                }
            });

        }
    }

    public List<Error> validateSheetStructure(BulkUserValidationDTO validationDTO){
        List<String> actualCsvHeaders = validationDTO.getCsvHeaders();
        List<String> expectedHeaders = new ArrayList<>(getSheetHeaderQueue());

        //checks wrong headers
        AtomicInteger index = new AtomicInteger(0);
        List<Error> headerErrors = new ArrayList<>();

        actualCsvHeaders.forEach(actualHeader -> {
            int cellIndex = index.getAndIncrement();
            String expectedHeader = expectedHeaders.get(cellIndex);
            String actualCsvHeader = actualCsvHeaders.get(cellIndex);

            if (!expectedHeader.equals(actualCsvHeader)) {
                headerErrors.add(getError(actualCsvHeader, getHeaderErrorMessages(expectedHeader), expectedHeader, ErrorTypeEnum.FILE_STRUCTURE));
            }
        });

        //max users to be created per a request is 500 plus headers row
        if(validationDTO.getUserList().size() > 501){
            headerErrors.add(getError("Maximum number of employees that can be created in a single file is 500", ErrorTypeEnum.FILE_STRUCTURE));
        }

        return headerErrors;
    }

    List<Error> validateSheetData(CompanyLevel companyLevel, List<UserDTO> users, Map<String, String> paramsMap) {
        LOGGER.debug("validateSheetData :: start");

        List<Error> errorList = new ArrayList<>();
        users.stream().filter(ObjectUtils::isNotEmpty).forEach(user ->{

            GenericUserCreationRequest genericUserCreationRequest = new GenericUserCreationRequest();
            genericUserCreationRequest.setFirstName(user.getFirstName());
            genericUserCreationRequest.setLastName(user.getLastName());
            genericUserCreationRequest.setEmail(user.getEmail());
            genericUserCreationRequest.setSendEmail(user.getSendEmail());
            genericUserCreationRequest.setRole(user.getRole());
            genericUserCreationRequest.setUserGroup(user.getUserGroup());
            genericUserCreationRequest.setActivationDate(user.getActivationDate());
            genericUserCreationRequest.setPhoneNumber(user.getPhoneNumber());
            genericUserCreationRequest.setTariff(user.getTariff());
            genericUserCreationRequest.setUpgradeDate(user.getUpgradeDate());

            List<Error> mandatoryFields = commonUserDataValidationUtil.validateMandatoryFields(genericUserCreationRequest, companyLevel, user.getRowIndex());
            if(ObjectUtils.isNotEmpty(mandatoryFields)){
                errorList.addAll(mandatoryFields);
            }

            List<Error> optionalFields = commonUserDataValidationUtil.validateOptionalFields(genericUserCreationRequest, companyLevel, user.getRowIndex());
            if(ObjectUtils.isNotEmpty(optionalFields)){
                errorList.addAll(optionalFields);
            }

            List<Error> legalOrgIdValidation = validateLegalOrgId(paramsMap, user.getRowIndex());
            if(ObjectUtils.isNotEmpty(legalOrgIdValidation)){
                errorList.addAll(legalOrgIdValidation);
            }

        });

        //checks if there are duplicated data
        List<Error> emailTuples = findEmailTuples(users);
        if(ObjectUtils.isNotEmpty(emailTuples)){
            errorList.addAll(emailTuples);
        }

        List<Error> phoneNumberTuples = findPhoneNumberTuples(users);
        if(ObjectUtils.isNotEmpty(phoneNumberTuples)){
            errorList.addAll(phoneNumberTuples);
        }

        LOGGER.debug("validateSheetData :: end");
        return errorList;
    }

    List<Error> findEmailTuples(List<UserDTO> users) {
        List<Error> errorList = new ArrayList<>();
        TreeSet<String> emailTuples= new TreeSet <>();

        TreeSet<UserDTO> emailSet =  users.stream().filter(Objects::nonNull).filter(userDTO -> ObjectUtils.isNotEmpty(userDTO.getEmail())).filter(userDTO -> !emailTuples.add(userDTO.getEmail()))
            .collect(Collectors.toCollection(TreeSet::new));

        emailSet.stream().filter(Objects::nonNull).forEach(duplicateValue ->
            errorList.add(getError(duplicateValue.getEmail(), "This email appears more than once in the spreadsheet", EMAIL, ErrorTypeEnum.DUPLICATED, duplicateValue.getRowIndex()))
        );

        return errorList;
    }

    List<Error> findPhoneNumberTuples(List<UserDTO> users) {
        List<Error> errorList = new ArrayList<>();
        TreeSet<String> phoneNumberTuples = new TreeSet <>();

        TreeSet<UserDTO> phoneNumberSet =  users.stream().filter(Objects::nonNull).filter(userDTO -> ObjectUtils.isNotEmpty(userDTO.getPhoneNumber())).filter(userDTO -> !phoneNumberTuples.add(userDTO.getPhoneNumber()))
            .collect(Collectors.toCollection(TreeSet::new));

        phoneNumberSet.stream().filter(Objects::nonNull).forEach(duplicateValue ->
            errorList.add(getError(duplicateValue.getPhoneNumber(), "This phone number appears more than once in the spreadsheet", PHONE_NUMBER, ErrorTypeEnum.DUPLICATED, duplicateValue.getRowIndex()))
        );

        return errorList;
    }

    private Queue<String> getSheetHeaderQueue() {
        Queue<String> headerQueue = new LinkedList<>();

        headerQueue.add(config.firstNameHeader());
        headerQueue.add(config.lastNameHeader());
        headerQueue.add(config.emailHeader());
        headerQueue.add(config.activationDateHeader());
        headerQueue.add(config.sendEmailHeader());
        headerQueue.add(config.roleHeader());
        headerQueue.add(config.userGroupHeader());
        headerQueue.add(config.phoneNumberHeader());
        headerQueue.add(config.tariffHeader());
        headerQueue.add(config.upgradeDateHeader());

        return headerQueue;
    }

    public List<CurveUser> mapToCurveUser(List<UserDTO> users, Map<String, String> paramsMap){

        String countryCode = paramsMap.get(CurveConstant.COUNTRY_CODE_FIELD);
        String companyName = paramsMap.get(CurveConstant.ORGANIZATION_NAME);
        String legalOrgId = curveUtils.getLegalOrgId(countryCode, companyName);

        List<CurveUser> curveUserList = new ArrayList<>();
        users.stream().filter(ObjectUtils :: isNotEmpty).forEach(userDTO -> {
             CurveUser curveUser = CurveUserUtils.prepareCurveUser(userDTO, paramsMap, legalOrgId);
             curveUserList.add(curveUser);
        });

        return curveUserList;
    }

    private String getHeaderErrorMessages(String columnName) {
        return  String.format(" Column '%s' not found. Please ensure you are using the latest template", columnName);

    }

    public static Error getError(String formattedValue, String errorMessage, String columnName, int rowIndex) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);
        error.setValue(formattedValue);
        error.setColumn(columnName);
        error.setRow(rowIndex);
        error.setErrorType(getErrorType(formattedValue));

        return error;
    }

    public static Error getError(String formattedValue, String errorMessage, String columnName, ErrorTypeEnum errorType, int rowIndex) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);
        error.setValue(formattedValue);
        error.setColumn(columnName);
        error.setRow(rowIndex);
        error.setErrorType(errorType);

        return error;
    }

    public static Error getError(String formattedValue, String errorMessage, String columnName, ErrorTypeEnum errorType) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);
        error.setValue(formattedValue);
        error.setColumn(columnName);
        error.setErrorType(errorType);

        return error;
    }

    public static Error getError(String errorMessage, ErrorTypeEnum errorType) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);
        error.setErrorType(errorType);

        return error;
    }

    public static Error getError(String errorMessage) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);

        return error;
    }
    private static ErrorTypeEnum getErrorType(String fieldName) {
        return ObjectUtils.isEmpty(fieldName) ? ErrorTypeEnum.REQUIRED : ErrorTypeEnum.FORMAT;
    }

    private List<Error> validateLegalOrgId(Map<String, String> paramsMap, int rowIndex) {
        List<Error> errorList = new ArrayList<>();

        String organizationName = paramsMap.get(ORGANIZATION_NAME);
        String countryCode = paramsMap.get(COUNTRY_CODE_FIELD);

        try {
            curveUtils.getLegalOrgId(countryCode, organizationName);
        } catch (BackendSystemException exception) {
            Error error = getError("LegalOrgId must be mapped before creating user for this company", ErrorTypeEnum.NOT_ALLOWED);
            errorList.add(error);
        }

        return errorList;
    }

}
