package com.vf.cove.curve.internal.client;

import com.vf.cove.curve.dto.v1_0.CurveProduct;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.exception.DataNotFoundException;
import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Client class for sending REST requests
 */
@Component(
    configurationPid = CurveApiConfiguration.PID,
    service = CurveProductClient.class
)
public class CurveProductClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveProductClient.class);

    @Reference(unbind = "-")
    CurveApiConfiguration config;

    @Reference(unbind = "-")
    ClientSSLConfiguration sslConfiguration;

    @Reference(unbind = "-")
    CurveUtils curveUtils;

    /**
     * Send GET request
     *
     * @param curveHttpRequestDTO - contains request parameters and headers
     * @return CurveProduct list - the Response of the GET request
     */
    public List<CurveProduct> getProductList(CurveHttpRequestDTO curveHttpRequestDTO) {
        LOGGER.info("CurveProductClient :: getProductList :: start");
        List<CurveProduct> productList;
        Response response;

        LOGGER.info("curveHttpRequestDTO={}", curveHttpRequestDTO);
        LOGGER.info("dxlOrchestratorBaseUrl={}", config.dxlOrchestratorBaseUrl());
        LOGGER.info("curveProductURIPath={}", config.curveProductURIPath());

        try {
            response = sslConfiguration.getClient().target(config.dxlOrchestratorBaseUrl()).path(config.curveProductURIPath())
                .queryParam(CurveConstant.ORG_ID, curveHttpRequestDTO.getOrgId())
                .queryParam(CurveConstant.OFFSET, curveHttpRequestDTO.getOffset())
                .queryParam(CurveConstant.LIMIT, curveHttpRequestDTO.getLimit())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(CurveConstant.AUTHORIZATION, curveHttpRequestDTO.getDxlToken())
                .header(CurveConstant.X_TRANSACTION_ID, UUID.randomUUID())
                .header(CurveConstant.X_SOURCE_SYSTEM, curveHttpRequestDTO.getSourceSystem())
                .get();

            if (Objects.isNull(response)) {
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
            }

            int status = response.getStatus();
            LOGGER.info("CurveProductClient :: Response Status :: {}", status);

            if (status == HttpStatus.SC_OK || status == HttpStatus.SC_ACCEPTED) {
                productList = Arrays.asList(response.readEntity(CurveProduct[].class));
                LOGGER.info("CurveProductClient :: getProductList :: result {}", productList);
            }else{
                CurveProduct productError =response.readEntity(CurveProduct.class);
                throw new BackendSystemException(productError.getDescription());
            }

            LOGGER.info("CurveProductClient :: getProductList :: end");

        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }

        return productList;

    }

    /**
     * Send GET request
     *
     * @param curveHttpRequestDTO - contains request parameters and headers
     * @return CurveProduct - the Response of the GET request
     */
    public CurveProduct getProductById(CurveHttpRequestDTO curveHttpRequestDTO) {
        LOGGER.info("CurveProductClient :: getProductById :: start");
        CurveProduct curveProduct;
        Response response = null;

        try {
            response = sslConfiguration.getClient().target(config.dxlOrchestratorBaseUrl()).path(config.curveProductURIPath()).path(curveHttpRequestDTO.getProductId())
                .queryParam(CurveConstant.ORG_ID, curveHttpRequestDTO.getOrgId())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(CurveConstant.AUTHORIZATION, curveHttpRequestDTO.getDxlToken())
                .header(CurveConstant.X_TRANSACTION_ID, UUID.randomUUID())
                .header(CurveConstant.X_SOURCE_SYSTEM, curveHttpRequestDTO.getSourceSystem())
                .get();
            if (Objects.isNull(response)) {
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
            }

            int status = response.getStatus();
            LOGGER.info("CurveProductClient :: Response Status :: {}", status);

            if (status == HttpStatus.SC_OK || status == HttpStatus.SC_ACCEPTED) {
                curveProduct = response.readEntity(CurveProduct.class);
                if (Stream.of(curveProduct).anyMatch(Objects::isNull)) {
                    LOGGER.info("CurveProductClient :: getProductById :: result {}", curveProduct);
                }

            } else {
                throw new BackendSystemException(curveUtils.getStatusMessage(status));
            }

            LOGGER.info("CurveProductClient :: getProductById :: end");

        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }

        return curveProduct;

    }
}
