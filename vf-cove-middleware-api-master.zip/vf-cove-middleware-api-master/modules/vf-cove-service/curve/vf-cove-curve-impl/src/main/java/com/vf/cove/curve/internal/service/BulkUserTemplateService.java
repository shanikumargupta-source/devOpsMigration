package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.BulkUserDownloadResponse;
import com.vf.cove.curve.dto.v1_0.BulkUserUploadResponse;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.utils.ExcelUtils;
import org.apache.http.HttpStatus;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;


@Component(service = BulkUserTemplateService.class)
public class BulkUserTemplateService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BulkUserTemplateService.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    public BulkUserUploadResponse uploadFile(InputStream inputStream, String fileName) throws IOException {

        //checks if the inputStream is empty
        if (inputStream.available() == 0) {
            LOGGER.info("Empty inputStream :: ");
            return getUploadResponse(HttpStatus.SC_NOT_FOUND, "No file is selected");
        }

        String filePath = curveApiConfiguration.liferayDataVolumePath() + fileName;
        LOGGER.info("BulkUserTemplateService uploadFile filePath :: {}", filePath);
        return ExcelUtils.uploadBulkUserTemplate(inputStream, filePath) ?
            getUploadResponse(HttpStatus.SC_CREATED, "The File is uploaded successfully")
            : getUploadResponse(HttpStatus.SC_INTERNAL_SERVER_ERROR, "The system failed to upload the file");
    }

    public BulkUserUploadResponse getUploadResponse(int status, String message) {
        BulkUserUploadResponse response = new BulkUserUploadResponse();
        response.setStatus(status);
        response.setMessage(message);

        LOGGER.info("File upload response status :: {} ", response.getStatus());
        LOGGER.info("message :: {} ", response.getMessage());

        return response;
    }


    public BulkUserDownloadResponse downloadBulkUserTemplate() throws IOException {

        BulkUserDownloadResponse downloadResponse = new BulkUserDownloadResponse();
        String fileName = curveApiConfiguration.liferayDataVolumePath() + curveApiConfiguration.bulkUserFileName();
        downloadResponse.setFile(ExcelUtils.downloadTemplate(fileName));

        return downloadResponse;
    }


}
