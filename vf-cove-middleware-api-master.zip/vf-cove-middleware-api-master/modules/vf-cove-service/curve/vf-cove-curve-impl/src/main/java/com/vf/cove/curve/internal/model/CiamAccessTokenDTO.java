package com.vf.cove.curve.internal.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.servlet.http.Cookie;
import java.util.List;
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CiamAccessTokenDTO {

    @JsonProperty("access_token")
    protected String accessToken;

    @JsonProperty("refresh_token")
    protected String refreshToken;

    @JsonProperty
    protected String scope;

    @JsonProperty("id_token")
    protected String idToken;

    @JsonProperty("token_type")
    protected String tokenType;

    @JsonProperty("expires_in")
    protected int expiresIn;

    @JsonProperty
    protected String error;

    @JsonProperty("error_description")
    protected String errorDescription;

    protected Integer status;

    protected List<Cookie> cookieList;

    @Override
    public String toString() {
        return "{" +
            "accessToken='" + accessToken + '\'' +
            ", refreshToken='" + refreshToken + '\'' +
            ", scope='" + scope + '\'' +
            ", idToken='" + idToken + '\'' +
            ", tokenType='" + tokenType + '\'' +
            ", expiresIn=" + expiresIn +
            ", error='" + error + '\'' +
            ", errorDescription='" + errorDescription + '\'' +
            ", status=" + status +
            ", cookieList=" + cookieList +
            '}';
    }
}
