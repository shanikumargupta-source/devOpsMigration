package com.vf.cove.curve.internal.utils;

import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.util.Validator;
import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.dto.v1_0.RelatedParty;
import com.vf.cove.curve.dto.v1_0.UserCharacteristic;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.apache.http.HttpStatus;
import org.apache.poi.ss.usermodel.Workbook;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import static com.vf.cove.curve.internal.model.CurveConstant.*;
import static java.util.stream.Collectors.toList;

@Component(service = CurveUtils.class)
public class CurveUtils {

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveUtils.class);

    private static final String CURVE_HTTP_REQUEST_DTO = "CurveHttpRequestDTO :: {} ";

    private Map<String, Map<String, String>> inMemoryLegalOrgIdMap = new HashMap<>();

    @Activate
    @Modified
    private void activate() {
        String legalOrgIdMapFilePath = getFilePath();

        File file = new File(legalOrgIdMapFilePath);
        if (file.exists() && file.getTotalSpace() > 0) {
            try {
                createLegalOrgIdInMemoryMapFromExcelFile(legalOrgIdMapFilePath, curveApiConfiguration.legalOrgIdSheetName());
            } catch (Exception e) {
                LOGGER.error(e.toString());
            }
        }
    }

    public CurveHttpRequestDTO getUserRequestDto(HttpServletRequest httpRequest, String granterEmail, String search, String status, Sort[] sorts) {

        CurveHttpRequestDTO curveHttpRequestDTO = getUserRequestDto(httpRequest, granterEmail);
        Optional.ofNullable(search).ifPresent(curveHttpRequestDTO::setSearch);
        Optional.ofNullable(status).ifPresent(curveHttpRequestDTO::setStatus);
        Optional.ofNullable(sorts).ifPresent(value -> curveHttpRequestDTO.setSort(getSortQuery(sorts)));

        LOGGER.debug(CURVE_HTTP_REQUEST_DTO, curveHttpRequestDTO);
        return curveHttpRequestDTO;
    }

    public String getSortQuery(Sort[] sorts){

        String fieldName = ID;
        String sortValue = ASC;

        Optional<Sort> sort = Arrays.stream(sorts).findFirst();

        if (sort.isPresent()){
            fieldName = sort.get().getFieldName();
            sortValue = sort.get().isReverse()? DESC : sortValue;
        }


        //the sorting pattern should be like 'familyName:asc' as an example
       return fieldName + ":" + sortValue ;

    }

    public CurveHttpRequestDTO getUserRequestDto(HttpServletRequest httpRequest, String granterEmail) {
        CurveHttpRequestDTO curveHttpRequestDTO = getRequestHeaders(httpRequest);
        Optional.ofNullable(granterEmail).ifPresent(curveHttpRequestDTO::setGranterEmail);

        LOGGER.debug(CURVE_HTTP_REQUEST_DTO, curveHttpRequestDTO);
        return curveHttpRequestDTO;
    }

    public CurveHttpRequestDTO getProductRequestDto(HttpServletRequest httpRequest, String orgId, Integer offset, Integer limit) {

        CurveHttpRequestDTO curveHttpRequestDTO = getProductRequestDto(httpRequest, orgId);
        Optional.ofNullable(offset).ifPresent(curveHttpRequestDTO::setOffset);
        Optional.ofNullable(limit).ifPresent(curveHttpRequestDTO::setLimit);

        LOGGER.debug(CURVE_HTTP_REQUEST_DTO, curveHttpRequestDTO);
        return curveHttpRequestDTO;

    }

    public CurveHttpRequestDTO getProductRequestDto(HttpServletRequest httpRequest, String orgId) {
        CurveHttpRequestDTO curveHttpRequestDTO = getRequestHeaders(httpRequest);
        curveHttpRequestDTO.setOrgId(orgId);

        LOGGER.debug(CURVE_HTTP_REQUEST_DTO, curveHttpRequestDTO);
        return curveHttpRequestDTO;
    }

    public CurveHttpRequestDTO getRequestHeaders(HttpServletRequest httpRequest){
        CurveHttpRequestDTO curveHttpRequestDTO = new CurveHttpRequestDTO();
        Optional.ofNullable(httpRequest.getHeader(CurveConstant.X_CIAM_TOKEN)).ifPresent(curveHttpRequestDTO::setCiamToken);
        Optional.ofNullable(httpRequest.getHeader(CurveConstant.DXL_TOKEN)).ifPresent(curveHttpRequestDTO::setDxlToken);
        Optional.ofNullable(httpRequest.getHeader(CurveConstant.X_SOURCE_SYSTEM)).ifPresent(curveHttpRequestDTO::setSourceSystem);

        LOGGER.debug("CurveHttpRequestDTO :: getHeaders :: DTO :: {} ", curveHttpRequestDTO );
        return curveHttpRequestDTO;
    }

    public static CurveHttpRequestDTO getCompanyRequestDto(Integer offset, Integer limit, HttpServletRequest request, HttpServletResponse response){
        String granterEmail = request.getParameter("userContextEmail");
        LOGGER.info("CurveHttpRequestDTO :: granterEmail :: {} ", granterEmail);

        CurveHttpRequestDTO curveHttpRequestDTO = new CurveHttpRequestDTO(offset, limit, getHeadersAsMap(request), request, response);
        curveHttpRequestDTO.setGranterEmail(granterEmail);

        return curveHttpRequestDTO;
    }

    public static CurveHttpRequestDTO getCompanyRequestDto(String companyId, HttpServletRequest request, HttpServletResponse response){
       return new CurveHttpRequestDTO(companyId, CurveUtils.getHeadersAsMap(request), request, response);
    }

    public static CurveHttpRequestDTO getCiamAccessTokenRequestDto(HttpServletRequest httpRequest, HttpServletResponse httpResponse, String accessCode, Boolean isExpired){
        return new CurveHttpRequestDTO(httpRequest, httpResponse, accessCode, isExpired);
    }

    public String getStatusMessage(Integer status){
        LOGGER.debug("CurveHttpRequestDTO :: getStatusMessage : status {} ", status);
        String message ="";

        switch (status){
            case HttpStatus.SC_BAD_REQUEST :
                message = CurveConstant.BAD_REQUEST + status;
                break;

            case HttpStatus.SC_UNAUTHORIZED:
                message = CurveConstant.UNAUTHORIZED + status;
                break;

            case HttpStatus.SC_NOT_FOUND:
                message = CurveConstant.NOT_FOUND + status;
                break;

            case HttpStatus.SC_BAD_GATEWAY:
                message = CurveConstant.BAD_GATEWAY + status;
                break;

            case HttpStatus.SC_SERVICE_UNAVAILABLE:
                message = CurveConstant.SERVICE_UNAVAILABLE + status;
                break;

            case HttpStatus.SC_METHOD_NOT_ALLOWED:
                message =CurveConstant.METHOD_NOT_ALLOWED +  status ;
                break;

            default:
                message = CurveConstant.GENERAL_ERROR + status;

        }

        LOGGER.debug("CurveHttpRequestDTO :: getStatusMessage : message {} ", message);
        return message;
    }

    public static Map<String, String> getHeadersAsMap(HttpServletRequest request){
        Map<String, String> headers = new HashMap<>();
        Enumeration<String> headerNames = request.getHeaderNames();
        while(headerNames.hasMoreElements()){
            String key = headerNames.nextElement();
            headers.put(key, request.getHeader(key));
        }

        return headers;
    }

    public InputStream getResource(String path){
        LOGGER.info("path: {} :: getResourceAsStream: {}", path, getClass().getClassLoader().getResourceAsStream(path));
        return getClass().getClassLoader().getResourceAsStream(path);
    }

    public void createLegalOrgIdInMemoryMapFromExcelFile(String filePath, String sheetName) throws IOException {
        try {
            Workbook workbook = ExcelUtils.getWorkbookFromSavedFile(filePath);
            this.inMemoryLegalOrgIdMap = ExcelUtils.generateLegalOrgIdMapFromExcelFile(workbook, sheetName);

            workbook.close();

        } catch (IOException e) {
            throw e;
        }
    }

    public CurveUser[] addLegalOrgId(CurveUser[] curveUsers){
        List<CurveUser> curveUserList= Arrays.asList(curveUsers);

        curveUserList.forEach(curveUser -> {
            Optional<RelatedParty> relatedParty = Arrays.stream(curveUser.getRelatedParty()).findFirst();
            List<UserCharacteristic> userCharacteristics = Arrays.stream(curveUser.getUserCharacteristic()).collect(toList());
            Optional<UserCharacteristic> countryCodeCharacteristic =  userCharacteristics.stream().filter(userCharacteristic -> "organizationCountryCode".equalsIgnoreCase(userCharacteristic.getName())).findFirst();

            if(relatedParty.isPresent() && countryCodeCharacteristic.isPresent()) {
                userCharacteristics.add(getUserCharacteristic (relatedParty.get(),countryCodeCharacteristic.get()));
                curveUser.setUserCharacteristic(userCharacteristics.toArray(new UserCharacteristic[0]));
            }
        });

        return curveUserList.toArray(new CurveUser[0]);
    }

    private UserCharacteristic getUserCharacteristic (RelatedParty relatedParty, UserCharacteristic countryCodeCharacteristic){

        UserCharacteristic userCharacteristic = new UserCharacteristic();
        userCharacteristic.setName(LEGAL_ORG_ID_FIELD);

        String companyName = relatedParty.getName();
        String countryCode = countryCodeCharacteristic.getValue();
        String legalOrgId = getLegalOrgId(countryCode, companyName);
        userCharacteristic.setValue(legalOrgId);


        return userCharacteristic;
    }

    public String getLegalOrgId(String countryCode, String companyName) {
        try {
            String legalOrgId = inMemoryLegalOrgIdMap.get(countryCode).get(ExcelUtils.generateCompanyUniqueId(companyName, countryCode));

            validateLegalOrgId(legalOrgId);

            return legalOrgId;
        } catch (NullPointerException exception) {
            throw new BackendSystemException(CurveConstant.LEGAL_ORG_ID_NOT_MAPPED);
        }
    }

    private void validateLegalOrgId(String legalOrgId) {
        if ("".equals(legalOrgId) || legalOrgId == null) {
            throw new BackendSystemException(CurveConstant.LEGAL_ORG_ID_NOT_MAPPED);
        }
    }

    private String getFilePath(){
        return curveApiConfiguration.liferayDataVolumePath() + curveApiConfiguration.legalOrgIdFileName();
    }

    public static String getSecret(String key) throws ConfigurationException {
        LOGGER.debug("Accessing variable {}", key);
        final String envVar = System.getenv(key);

        if (Validator.isBlank(envVar)) {
            throw new ConfigurationException("Missing value for env variable " + key);
        }

        return envVar;
    }

    public boolean isInternalUser(String granterEmail){
        LOGGER.info("granterEmail :: {} ", granterEmail);

        boolean isInternalUser = granterEmail.contains("@vodafone.com") ? Boolean.TRUE : Boolean.FALSE;

        LOGGER.info("isInternalUser {}", isInternalUser);
        return isInternalUser;
    }

}
