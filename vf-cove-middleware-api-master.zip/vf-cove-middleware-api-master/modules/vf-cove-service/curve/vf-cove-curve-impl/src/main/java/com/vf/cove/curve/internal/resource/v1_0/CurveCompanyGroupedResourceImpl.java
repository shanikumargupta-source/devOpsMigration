package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.vulcan.pagination.Page;
import com.vf.cove.curve.dto.v1_0.CurveCompanyGrouped;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.CurveCompanyService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.CurveCompanyGroupedResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import javax.validation.constraints.Min;
import java.util.List;

/**
 * @author Hagar ElMasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/curve-company-grouped.properties",
	scope = ServiceScope.PROTOTYPE, service = CurveCompanyGroupedResource.class
)
public class CurveCompanyGroupedResourceImpl extends BaseCurveCompanyGroupedResourceImpl {
    @Reference(unbind = "-")
    private CurveCompanyService curveCompanyService;

    @Override
    public Page<CurveCompanyGrouped> getCompanyPage(@Min(value = 0, message = "The min value is zero") Integer limit, @Min(value = 0, message = "The min value is zero") Integer offset) throws Exception {
        CurveHttpRequestDTO requestDto = CurveUtils.getCompanyRequestDto(offset, limit, contextHttpServletRequest, contextHttpServletResponse);
        List<CurveCompanyGrouped> companies = curveCompanyService.getCompanyList(requestDto);
        return Page.of(companies);
    }
}
