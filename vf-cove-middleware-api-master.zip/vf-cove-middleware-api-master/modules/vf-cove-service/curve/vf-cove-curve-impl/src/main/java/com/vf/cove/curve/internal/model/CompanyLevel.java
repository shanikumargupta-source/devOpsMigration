package com.vf.cove.curve.internal.model;

import com.vf.cove.curve.dto.v1_0.CompanyLevelAndUserGroup;

import java.util.HashSet;
import java.util.Set;

import static com.vf.cove.curve.internal.model.CurveConstant.LEVEL_1_ORGANIZATION;
import static com.vf.cove.curve.internal.model.CurveConstant.LEVEL_3_ORGANIZATION;

public class CompanyLevel {
    private String companyName;
    private String country;
    private String level;
    private Set<String> userGroups = new HashSet<>();

    public String getCompanyName() {
        return this.companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLevel() {
        return this.level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Set<String> getUserGroups() {
        return userGroups;
    }

    public void setUserGroups(Set<String> userGroups) {
        this.userGroups = userGroups;
    }

    public boolean isLevel1() {
        return getLevel().equalsIgnoreCase(LEVEL_1_ORGANIZATION);
    }

    public boolean isLevel3() {
        return getLevel().equalsIgnoreCase(LEVEL_3_ORGANIZATION);
    }

    @Override
    public String toString() {
        return "CompanyLevel{" +
            "companyName='" + companyName + '\'' +
            ", country='" + country + '\'' +
            ", level='" + level + '\'' +
            ", userGroups=" + userGroups +
            '}';
    }

    public static CompanyLevelAndUserGroup getCompanyLevelAndUserGroupResponse(CompanyLevel companyLevel){
        CompanyLevelAndUserGroup temp = new CompanyLevelAndUserGroup();
        temp.setCompanyName(companyLevel.getCompanyName());
        temp.setCountry(companyLevel.getCountry());
        temp.setLevel(companyLevel.getLevel());
        if(!companyLevel.getUserGroups().isEmpty()) temp.setUserGroups(companyLevel.getUserGroups().toArray(new String[companyLevel.getUserGroups().size()]));
        return temp;
    }
}
