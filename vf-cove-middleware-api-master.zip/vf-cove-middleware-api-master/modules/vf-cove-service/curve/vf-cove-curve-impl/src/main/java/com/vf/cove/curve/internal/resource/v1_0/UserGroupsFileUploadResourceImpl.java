package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.vulcan.multipart.BinaryFile;
import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.vf.cove.curve.dto.v1_0.UserGroupsFileUpload;
import com.vf.cove.curve.internal.service.UserGroupsUploadFileService;
import com.vf.cove.curve.resource.v1_0.UserGroupsFileUploadResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

@Component(
    properties = {"OSGI-INF/liferay/rest/v1_0/user-groups-file-upload.properties"},
    scope = ServiceScope.PROTOTYPE,
    service = {UserGroupsFileUploadResource.class}
)
public class UserGroupsFileUploadResourceImpl extends BaseUserGroupsFileUploadResourceImpl {
    @Reference(unbind = "-")
    private UserGroupsUploadFileService userGroupsUploadFileService;

    private static final String EXCEL_FILE_NAME = "fileName";
    private static final String EXCEL_SHEET_NAME = "sheetName";

    @Override
    public UserGroupsFileUpload uploadUserGroups(MultipartBody multipartBody) throws Exception {
        BinaryFile binaryFile = multipartBody.getBinaryFile(EXCEL_FILE_NAME);
        String sheetName = multipartBody.getValueAsString(EXCEL_SHEET_NAME);
        this.userGroupsUploadFileService.createInMemoryMapFromExcelStream(binaryFile.getInputStream(), binaryFile.getFileName(), sheetName);

        UserGroupsFileUpload response = new UserGroupsFileUpload();
        response.setMessage("The File Uploaded Successfully");
        response.setStatusCode(200);
        return response;
    }
}
