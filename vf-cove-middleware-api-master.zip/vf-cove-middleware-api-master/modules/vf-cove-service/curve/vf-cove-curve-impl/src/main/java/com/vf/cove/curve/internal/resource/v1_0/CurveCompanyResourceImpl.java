package com.vf.cove.curve.internal.resource.v1_0;

import com.vf.cove.curve.dto.v1_0.CurveCompany;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.CurveCompanyService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.CurveCompanyResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author Hagar ElMasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/curve-company.properties",
	scope = ServiceScope.PROTOTYPE, service = CurveCompanyResource.class
)
public class CurveCompanyResourceImpl extends BaseCurveCompanyResourceImpl {

    @Reference(unbind = "-")
    private CurveCompanyService curveCompanyService;

    @Override
    public CurveCompany getCompanyId(String id){
        CurveHttpRequestDTO requestDto = CurveUtils.getCompanyRequestDto(id, contextHttpServletRequest, contextHttpServletResponse);
        return curveCompanyService.getCompanyById(requestDto);
    }
}
