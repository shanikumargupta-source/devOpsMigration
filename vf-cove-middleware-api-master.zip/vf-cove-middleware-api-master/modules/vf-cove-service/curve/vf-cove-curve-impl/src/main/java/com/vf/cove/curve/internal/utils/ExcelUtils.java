package com.vf.cove.curve.internal.utils;

import com.vf.cove.curve.internal.exception.TemplateNotFoundException;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.model.UserDTO;
import lombok.NonNull;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ooxml.POIXMLDocument;
import org.apache.poi.ooxml.POIXMLProperties;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.constraints.NotNull;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class ExcelUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelUtils.class);
    private static final String NOT_EXCEL_FILE_EXCEPTION_MESSAGE = "The specified file is not excel file";
    private static final String TEMPLATE_NOT_FOUND_EXCEPTION_MESSAGE = "The specified template file is not found";
    static final String CSV_PARSER_EXCEPTION_MESSAGE = "Uploaded file cannot be decoded";

    private ExcelUtils() {
    }

    public static Workbook getWorkbookFromUploadedFileStream(InputStream inputStream, String fileName) throws IOException {
        Workbook workbook = null;

        if (fileName.endsWith("xlsx")) {
            workbook = new XSSFWorkbook(inputStream);

        } else if (fileName.endsWith("xls")) {
            workbook = new HSSFWorkbook(inputStream);

        } else {
            throw new IllegalArgumentException(NOT_EXCEL_FILE_EXCEPTION_MESSAGE);
        }

        inputStream.close();
        return workbook;
    }

    public static Workbook getWorkbookFromSavedFile(String filePath) throws IOException {
        Workbook workbook = null;
        FileInputStream file = new FileInputStream(new File(filePath));
        if (filePath.endsWith("xlsx")) {
            workbook = new XSSFWorkbook(file);
        } else if (filePath.endsWith("xls")) {
            workbook = new HSSFWorkbook(file);
        } else {
            throw new IllegalArgumentException(NOT_EXCEL_FILE_EXCEPTION_MESSAGE);
        }
        file.close();
        return workbook;
    }

    public static void writeWorkbookInFileSystem(Workbook workbook, String filePath) throws IOException {
        FileOutputStream out = new FileOutputStream(filePath);
        workbook.write(out);
        out.close();
    }

    private static String getCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                return removeTrailers(String.valueOf(cell.getNumericCellValue()).trim());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue()).trim();
            default:
                return null;
        }
    }

    static String removeTrailers(String cellValue) {
        LOGGER.info("cell value :: {}", cellValue);
        return cellValue.contains(".") ? StringUtils.substringBefore(cellValue, ".") : cellValue;
    }

    public static Map<String, CompanyLevel> generateCompanyLevelsFromWorkbook(Workbook workbook, String sheetName) throws IOException {
        HashMap<String, CompanyLevel> inMemoryMap = new HashMap<>();
        Sheet sheet = workbook.getSheet(sheetName);
        if (Objects.isNull(sheet)) {
            throw new IllegalArgumentException("Sheet is not exist");
        }
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if(!isRowEmpty(row)){
                addRowToCompaniesMap(sheet.getRow(i), inMemoryMap);
            }
        }

        workbook.close();
        return inMemoryMap;
    }

    private static void addRowToCompaniesMap(Row row, HashMap<String, CompanyLevel> map) {
        CompanyLevel company = null;
        String companyId = generateCompanyUniqueId(getCellValue(row.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)), getCellValue(row.getCell(1, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)));
        if (!map.containsKey(companyId)) {
            company = new CompanyLevel();
            company.setCompanyName(getCellValue(row.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)));
            company.setCountry(getCellValue(row.getCell(1, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)));
            company.getUserGroups().add(getCellValue(row.getCell(2, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)));
            company.setLevel(getCellValue(row.getCell(3, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)));
            map.put(companyId, company);
        } else {
            company = map.get(companyId);
            company.getUserGroups().add(getCellValue(row.getCell(2)));
            map.put(companyId, company);
        }
    }

    public static String generateCompanyUniqueId(@NotNull String companyName, @NotNull String country) {
        return companyName.concat("_").concat(country).toLowerCase();
    }

    public static Workbook createBulkUserWorkbook(InputStream inputStream) throws IOException {
        return WorkbookFactory.create(inputStream);
    }

    public static boolean uploadBulkUserTemplate(InputStream inputStream, String uploadedFilePath) throws IOException {

        Workbook bulkUserWorkbook = ExcelUtils.createBulkUserWorkbook(inputStream);
        boolean isUploaded;

        try (FileOutputStream out = new FileOutputStream(uploadedFilePath)) {
            attachMetaData((XSSFWorkbook)bulkUserWorkbook, getCheckSum(inputStream)).write(out);
            isUploaded = Boolean.TRUE;

        } catch (IOException e) {
            isUploaded = Boolean.FALSE;
            LOGGER.info("IO Exception :: {} ", (Object) e.getStackTrace());

        }

        return isUploaded;

    }

    public static InputStream downloadBulkUserTemplate(String filePath) {
        return ExcelUtils.class.getClassLoader().getResourceAsStream(filePath);
    }

    public static String downloadTemplate(String templateFileName) throws IOException {

        Path path = Paths.get(templateFileName);

        byte[] arr;
        try {
            arr = Files.readAllBytes(path);
        } catch (NoSuchFileException e) {
            throw new TemplateNotFoundException(TEMPLATE_NOT_FOUND_EXCEPTION_MESSAGE);
        }


        return Base64.getEncoder().encodeToString(arr);
    }

    public static Map<String, Map<String, String>> generateLegalOrgIdMapFromExcelFile(Workbook workbook, String sheetName) throws IOException {
        Map<String, Map<String, String>> legalOrgIdMap = new HashMap<>();

        Sheet sheet = workbook.getSheet(sheetName);
        if (Objects.isNull(sheet)) {
            throw new IllegalArgumentException("Sheet is not exist");
        }
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if(!isRowEmpty(row)){
                String countryCode = getCellValue(row.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK));
                String legalOrgId = getCellValue(row.getCell(1, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK));
                String companyName = getCellValue(row.getCell(2, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK));
                String companyId = generateCompanyUniqueId(companyName, countryCode);

                if (legalOrgIdMap.containsKey(countryCode)) {
                    legalOrgIdMap.get(countryCode).put(companyId, legalOrgId);
                } else {
                    Map<String, String> orgIdLegalOrgId = new HashMap<>();
                    orgIdLegalOrgId.put(companyId, legalOrgId);

                    legalOrgIdMap.put(countryCode, orgIdLegalOrgId);
                }
            }
        }

        workbook.close();

        return legalOrgIdMap;
    }

    private static Optional<POIXMLProperties.CoreProperties> getPOIXMLProperties(Workbook workbook) {
        return Optional.ofNullable((XSSFWorkbook)workbook)
            .map(POIXMLDocument::getProperties)
            .map(POIXMLProperties::getCoreProperties);
    }

    private static String getCheckSum(InputStream inputStream) throws IOException {
        return DigestUtils.sha256Hex(inputStream);

    }

    public static XSSFWorkbook attachMetaData(XSSFWorkbook workbook, String checkSum) {
        getPOIXMLProperties(workbook).ifPresent(value -> value.setIdentifier(checkSum));
        return workbook;
    }

    private static String getMetadata(Workbook workbook) {
        return getPOIXMLProperties(workbook)
            .map(POIXMLProperties.CoreProperties::getIdentifier)
            .orElse("");
    }

    static boolean isRowEmpty(Row row) {
        boolean isEmpty = true;
        DataFormatter dataFormatter = new DataFormatter();
        if (row != null) {
            for (Cell cell : row) {
                if (dataFormatter.formatCellValue(cell).trim().length() > 0) {
                    isEmpty = false;
                    break;
                }
            }
        }
        return isEmpty;
    }


    static boolean isGhostUserList(List<UserDTO> users) {

        for (UserDTO user : users) {
            boolean ok =
                 ObjectUtils.isNotEmpty(user.getFirstName()) &&
                 ObjectUtils.isNotEmpty(user.getLastName()) &&
                 ObjectUtils.isNotEmpty(user.getEmail());

            if (!ok) return true;

        }

        return false;
    }


}
