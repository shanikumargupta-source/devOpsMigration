package com.vf.cove.curve.internal.connectivity;

import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.security.KeyStore;

public class KeyStoreLoader {

	public static final String STORE_TYPE = "jks";

	public static KeyStore getStore(String path, String password) throws SSLConnectivityException {
		KeyStore keyStore = null;
		if (StringUtils.isNotEmpty(path) && StringUtils.isNotEmpty(password)) {
			File file = new File(path);
			try (InputStream keyStoreStream = Files.newInputStream(file.toPath())) {
				keyStore = KeyStore.getInstance(STORE_TYPE);
				keyStore.load(keyStoreStream, password.toCharArray());
			} catch (Exception e) {
				throw new SSLConnectivityException(
						String.format("KeyStore %s failed to load. The exception is %s", path, e.getMessage()));
			}
		}
		return keyStore;
	}
}
