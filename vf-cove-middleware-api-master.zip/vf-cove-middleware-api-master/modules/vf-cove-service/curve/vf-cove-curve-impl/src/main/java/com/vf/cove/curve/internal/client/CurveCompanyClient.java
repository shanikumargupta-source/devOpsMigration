package com.vf.cove.curve.internal.client;

import com.vf.cove.curve.dto.v1_0.CurveCompany;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.DataNotFoundException;
import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveCompanyErrorResponse;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component(immediate = true, service = CurveCompanyClient.class)
public class CurveCompanyClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveCompanyClient.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    @Reference(unbind = "-")
    private ClientSSLConfiguration clientSSLConfiguration;

    public List<CurveCompany> getCompanyList(CurveHttpRequestDTO requestDto) throws ServiceException {
        String targetHost = curveApiConfiguration.dxlOrchestratorBaseUrl().concat(curveApiConfiguration.dxlOrchestratorCurveVersion());
        String path = curveApiConfiguration.companyEndpoint();
        Response response;

        LOGGER.info("getCompanyList :: start");
        LOGGER.info("targetHost={}", targetHost);
        LOGGER.info("path={}", path);

        try {

            LOGGER.info("company name={}", requestDto.getCompanyName());
            LOGGER.info("legalorg Id name={}", requestDto.getLegalOrgId());

            response = clientSSLConfiguration.getClient().target(targetHost).path(path)
                .queryParam(CurveConstant.FIELDS, requestDto.getLegalOrgId())
                .queryParam(CurveConstant.LIMIT, requestDto.getLimit())
                .queryParam(CurveConstant.OFFSET, requestDto.getOffset())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(CurveConstant.X_TRANSACTION_ID, UUID.randomUUID())
                .header(CurveConstant.X_SOURCE_SYSTEM, CurveConstant.COVE)
                .header(CurveConstant.AUTHORIZATION, requestDto.getHeaders().get(CurveConstant.DXL_TOKEN))
                .header(CurveConstant.X_CIAM_TOKEN, requestDto.getHeaders().get(CurveConstant.X_CIAM_TOKEN))
                .get();

            if (Objects.isNull(response)) {
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);

            }

            return mapToDto(response);

        } catch (SSLConnectivityException e) {
            throw new ServiceException(CurveConstant.GENERAL_ERROR, e);
        }
    }


    public Response getCompanyById(CurveHttpRequestDTO requestDto) {
        String targetHost = curveApiConfiguration.dxlOrchestratorBaseUrl().concat(curveApiConfiguration.dxlOrchestratorCurveVersion());
        String path = curveApiConfiguration.companyEndpoint().concat("/").concat(requestDto.getCompanyId());
        Response response;

        try {
            response = clientSSLConfiguration.getClient().target(targetHost).path(path)
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(CurveConstant.X_TRANSACTION_ID, UUID.randomUUID())
                .header(CurveConstant.X_SOURCE_SYSTEM, CurveConstant.COVE)
                .header(CurveConstant.AUTHORIZATION, requestDto.getHeaders().get(CurveConstant.DXL_TOKEN))
                .header(CurveConstant.X_CIAM_TOKEN, requestDto.getHeaders().get(CurveConstant.X_CIAM_TOKEN))
                .get();

            if (Objects.isNull(response)) {
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
            }

            return response;

        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }
    }

    private List<CurveCompany> mapToDto(Response response){

        List<CurveCompany> companies;
        Integer statusCode = response.getStatus();
        LOGGER.info("statusCode :: " + statusCode);

        if (statusCode.intValue() == HttpStatus.SC_OK || statusCode.intValue() == HttpStatus.SC_ACCEPTED) {
            companies = response.readEntity(new GenericType<List<CurveCompany>>(){});
            LOGGER.info("company list :: " + companies);

        } else {
            CurveCompanyErrorResponse errorResponse = response.readEntity(CurveCompanyErrorResponse.class);
            LOGGER.error(String.valueOf(errorResponse));

            throw new ServiceException("Error getting companies :: " + errorResponse.getMessage());
        }

        return companies;
    }

}
