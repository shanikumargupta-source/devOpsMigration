package com.vf.cove.curve.internal.configuration;

import aQute.bnd.annotation.metatype.Meta;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

@ExtendedObjectClassDefinition(category = "vodafone")
@Meta.OCD(id = "com.vf.cove.curve.internal.configuration.CurveApiConfiguration", localization = "content/Language", name = "Curve configuration")
public interface CurveApiConfiguration {

	String PID = "com.vf.cove.curve.internal.configuration.CurveApiConfiguration";

    @Meta.AD(deflt = "https://ciamsso.sit1.ciam.vodafone.com", required = false, description = "Ciam End point url")
    String ciamBaseURL();

    @Meta.AD(deflt = "/oauth2/token", required = false, description = "Ciam End point url")
    String accessTokenURIPath();

    @Meta.AD(deflt = "/keepsessionalive", required = false, description = "Ciam keep session alive url")
    String redirectURIPath();

    @Meta.AD(deflt = "authorization_code", required = false, description = "Ciam access token grant type")
    String accessTokenGrantType();

    @Meta.AD(deflt = "refresh_token", required = false, description = "Ciam refresh token grant type")
    String refreshTokenGrantType();

    @Meta.AD(deflt = "https%3A%2F%2Fwebserver-cove-st5.lfr.cloud%2Fo%2Fvf-cove-curve%2F1.0%2FaccessToken%2Fkeepsessionalive%3F", required = false, description = "Cove redirect uri")
    String redirectCoveUri();

    //New ciam client id and secret
    @Meta.AD(deflt = "CIAM_USERNAME", required = false, description = "Ciam encoded username")
    String ciamUserName();

    @Meta.AD(deflt = "CIAM_PASSWORD", required = false, description = "Ciam encoded passowrd")
    String ciamPassword();

    @Meta.AD(deflt = "https://fit-epns-eu1.api.vodafone.com", required = false, description = "Dxl Orchestrator Hostname")
    String dxlOrchestratorBaseUrl();

    @Meta.AD(deflt = "/curve-api/v1", required = false, description = "Curve path with api version")
    String dxlOrchestratorCurveVersion();

    @Meta.AD(deflt = "/vbpsoauth2/token", required = false, description = "Get dxl access token")
    String dxlAccessTokenEndpoint();

    @Meta.AD(deflt = "DXL_CLIENT_ID", required = false, description = "Dxl client id for authenticate with apigee")
    String dxlClientId();

    @Meta.AD(deflt = "DXL_CLIENT_SECRET", required = false, description = "Dxl client secret for the client id")
    String dxlClientSecret();

    @Meta.AD(deflt = "CURVE_USER_SEARCH CURVE_USER_CREATE CURVE_COMPANY_SEARCH CURVE_SNOW_COMPANY_SEARCH CURVE_PRODUCT_SEARCH", required = false, description = "Dxl token scope")
    String dxlScope();

    @Meta.AD(deflt = "client_credentials", required = false, description = "Dxl grant type")
    String dxlGrantType();

    @Meta.AD(deflt = "/company", required = false, description = "Company Endpoint")
    String companyEndpoint();

    @Meta.AD(deflt = "/curve-api/v1/snow/company", required = false, description = "Snow company endpoint")
    String snowCompanyEndpoint();

    @Meta.AD(deflt = "jks-bkp/dev-dxl.jks", required = false, description = "SSL Certificate for establishing the connection with apigee, It exist in resources folder")
    String dxlApigeeKeystorePath();

    @Meta.AD(deflt = "DXL_APIGEE_JKS_KEYSTORE_PASSWORD", required = false, description = "Password for JKS Store")
    String dxlApigeeJKSKeystorePassword();

    @Meta.AD(deflt = "DXL_APIGEE_PKCS12_KEYSTORE_PASSWORD", required = false, description = "Password for PKCS12 Store")
    String dxlApigeePKCS12Keystore();

    @Meta.AD(deflt = "/curve-api/v1/user", required = false, description = "Dxl curve user end point uri")
    String curveUserURIPath();

    @Meta.AD(deflt = "/curve-api/v1/user/exists", required = false, description = "Dxl curve user end point uri")
    String curveDBURIPath();

    @Meta.AD(deflt = "/curve-api/v1/product", required = false, description = "Dxl curve product end point uri")
    String curveProductURIPath();

    @Meta.AD(deflt = "Red Flex Bulk User-v0.1.xlsm", name = "Red Flex Bulk User File", required = false, description = "Red flex bulk user uploaded file name")
    String bulkUserFileName();

    @Meta.AD(deflt = "Create User", name = "Create User Sheet", required = false, description = "Create bulk user uploaded sheet name")
    String bulkUserSheetName();

    @Meta.AD(deflt = "/template/", name = "Template Path", required = false, description = "Bulk user uploaded sheet name")
    String templatePath();

    @Meta.AD(deflt = "true", name = "Curve Dxl Cookies Filter", required = false, description = "vf-cove-curve-filter-enabled")
    boolean isCurveDxlFilterEnabled();

    @Meta.AD(deflt = "true", name = "Curve Ciam Cookies Filter", required = false, description = "vf-cove-curve-filter-enabled")
    boolean isCurveCiamFilterEnabled();

    @Meta.AD(deflt = "red_flex_user_groups.xlsx", name = "User Groups File", required = false, description = "Saved user groups uploaded file name")
    String userGroupsFileName();

    @Meta.AD(deflt = "user_groups", name = "User Groups Sheet", required = false, description = "Saved user groups uploaded sheet name")
    String userGroupsSheetName();

    @Meta.AD(deflt = "data/uploads/", name = "liferay data volume path", required = false, description = "Files storage location")
    String liferayDataVolumePath();

    // Bulk user headers validation
    @Meta.AD(deflt = "Create User", required = false, description = "bulk user sheet name")
    String sheetName();

    @Meta.AD(deflt = "First Name", required = false, description = "first name header")
    String firstNameHeader();

    @Meta.AD(deflt = "Last Name", required = false, description = "last name header")
    String lastNameHeader();

    @Meta.AD(deflt = "Email", required = false, description = "email header")
    String emailHeader();

    @Meta.AD(deflt = "Activation Date", required = false, description = "activation date header")
    String activationDateHeader();

    @Meta.AD(deflt = "Send email", required = false, description = "send email header")
    String sendEmailHeader();

    @Meta.AD(deflt = "Role", required = false, description = "role header")
    String roleHeader();

    @Meta.AD(deflt = "User Group", required = false, description = "user group header")
    String userGroupHeader();

    @Meta.AD(deflt = "Phone Number", required = false, description = "phone number header")
    String phoneNumberHeader();

    @Meta.AD(deflt = "Tariff", required = false, description = "tariff header")
    String tariffHeader();

    @Meta.AD(deflt = "Upgrade Date", required = false, description = "upgrade date header")
    String upgradeDateHeader();

    @Meta.AD(deflt = "red_flex_legal_org_id.xlsx", name = "LegalOrgId Mapping File", required = false, description = "LegalOrgId mapping")
    String legalOrgIdFileName();

    @Meta.AD(deflt = "Sheet1", name = "LegalOrgId Mapping File", required = false, description = "LegalOrgId mapping")
    String legalOrgIdSheetName();

    @Meta.AD(deflt = "/opt/liferay/data/identityKeystore.jks", required = false, description = "the identity store holding the certs for comms with DXL")
    String identityStorePath();

    @Meta.AD(deflt = "/opt/liferay/data/dxlcerttrustStore.jks", required = false, description = "the trust sto`re holding the certs for comms with DXL")
    String trustStorePath();

    @Meta.AD(deflt = "DXLTRUSTSTORE_SECRET_VALUE", required = false, description = "secret of the trust store")
    String trustStoreSecret();

    @Meta.AD(deflt = "IDENTITYSTORE_SECRET_VALUE", required = false, description = "secret of the identity store")
    String identityStoreSecret();

    @Meta.AD(deflt = "client-cove-sit-name.crt", required = false, description = "the cert alias used to look up the cert from the key store")
    String certAlias();

}
