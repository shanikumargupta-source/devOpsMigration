package com.vf.cove.curve.internal.filter;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.CiamAccessTokenDTO;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.CiamAccessTokenService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.internal.utils.MutableHttpServletRequestWrapper;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;

@Component(
    immediate = true,
    service = Filter.class,
    property = {
        "servlet-context-name=",
        "servlet-filter-name=Curve Ciam Cookies Filter",
        "url-pattern=/o/vf-cove-curve/*"
    }
)
public class CurveCiamCookiesFilter extends BaseFilter {
    private static final Log LOGGER = LogFactoryUtil.getLog(CurveCiamCookiesFilter.class);

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    @Reference(unbind = "-")
    private CiamAccessTokenService ciamAccessTokenService;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        LOGGER.info("doFilter :: start");

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        MutableHttpServletRequestWrapper mutableRequest = new MutableHttpServletRequestWrapper(request);
        final Cookie[] cookies = request.getCookies();

        if (curveApiConfiguration.isCurveCiamFilterEnabled()) {
            Optional<Cookie> ciamRefreshToken = findCookieByName(cookies, CurveConstant.CIAM_REFRESH_TOKEN_COOKIE);
            Optional<Cookie> ciamAccessToken = findCookieByName(cookies, CurveConstant.CIAM_ACCESS_TOKEN_COOKIE);

            if(ciamRefreshToken.isPresent() && !ciamAccessToken.isPresent()){
                CurveHttpRequestDTO requestDTO = CurveUtils.getCiamAccessTokenRequestDto(request, response, ciamRefreshToken.get().getValue(), true);
                requestDTO.setIsCiamTokenExpired(true);
                CiamAccessTokenDTO ciamResponse = null;

                try {
                    ciamResponse = ciamAccessTokenService.getAccessToken(requestDTO);
                } catch (ConfigurationException e) {
                    throw new RuntimeException(e);
                }

                addCookieAsHeaderInRequest(CurveConstant.X_CIAM_TOKEN, convertTokenToBearerToken(ciamResponse.getAccessToken()), mutableRequest);
            }

            if(ciamRefreshToken.isPresent() && ciamAccessToken.isPresent()){
                addCookieAsHeaderInRequest(CurveConstant.X_CIAM_TOKEN, convertTokenToBearerToken(ciamAccessToken.get().getValue()), mutableRequest);
            }
        }

        LOGGER.debug("CIAM Filter :: X_CIAM_TOKEN :: " + mutableRequest.getHeader(CurveConstant.X_CIAM_TOKEN));
        LOGGER.debug("doFilter :: end");

        super.doFilter(mutableRequest, servletResponse, filterChain);
    }

    private String convertTokenToBearerToken(String token){
        return "Bearer ".concat(token);
    }

    private void addCookieAsHeaderInRequest(String headerName, String headerValue, MutableHttpServletRequestWrapper request){
        request.addHeader(headerName, headerValue);
    }

    private Optional<Cookie> findCookieByName(Cookie [] cookies, String cookieName){
        if (cookies == null){cookies = new Cookie[0];}
        return Arrays.stream(cookies)
            .filter(cookie -> cookie.getName().equals(cookieName))
            .findFirst();
    }

    @Override
    protected Log getLog() {
        return LOGGER;
    }
}
