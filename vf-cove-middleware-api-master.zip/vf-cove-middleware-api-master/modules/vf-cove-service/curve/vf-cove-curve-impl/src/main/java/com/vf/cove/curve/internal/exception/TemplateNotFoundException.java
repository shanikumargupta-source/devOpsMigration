/**
 *
 */
package com.vf.cove.curve.internal.exception;

import javax.ws.rs.core.Response;

public class TemplateNotFoundException extends RuntimeException {

    final int errorCode;

    public TemplateNotFoundException(String errorMessage) {
		super(errorMessage);
        this.errorCode = Response.Status.NOT_FOUND.getStatusCode();
	}


}
