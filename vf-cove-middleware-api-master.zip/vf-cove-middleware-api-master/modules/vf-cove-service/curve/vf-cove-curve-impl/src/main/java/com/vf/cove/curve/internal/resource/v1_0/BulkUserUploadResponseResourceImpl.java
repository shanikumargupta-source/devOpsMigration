package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.vf.cove.curve.dto.v1_0.BulkUserUploadResponse;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.service.BulkUserTemplateService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.BulkUserUploadResponseResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import static com.vf.cove.curve.internal.model.CurveConstant.EXCEL_FILE_NAME;

/**
 * @author Hagar ElMasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/bulk-user-upload-response.properties",
	scope = ServiceScope.PROTOTYPE,
	service = BulkUserUploadResponseResource.class
)
public class BulkUserUploadResponseResourceImpl
	extends BaseBulkUserUploadResponseResourceImpl {

    @Reference(unbind = "-")
    private BulkUserTemplateService bulkUserTemplateService;

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    @Reference(unbind = "-")
    private CurveUtils curveUtils;

    @Override
    public BulkUserUploadResponse postBulkUserTemplate(MultipartBody multipartBody) throws Exception {
        BulkUserUploadResponse bulkUserUploadResponse = bulkUserTemplateService.uploadFile(multipartBody.getBinaryFile(EXCEL_FILE_NAME).getInputStream(), curveApiConfiguration.bulkUserFileName());

        return bulkUserUploadResponse;
    }

    @Override
    public BulkUserUploadResponse postLegalOrgIdMapFile(MultipartBody multipartBody) throws Exception {
        BulkUserUploadResponse bulkUserUploadResponse =  bulkUserTemplateService.uploadFile(multipartBody.getBinaryFile(EXCEL_FILE_NAME).getInputStream(), curveApiConfiguration.legalOrgIdFileName());
        curveUtils.createLegalOrgIdInMemoryMapFromExcelFile(curveApiConfiguration.liferayDataVolumePath() + curveApiConfiguration.legalOrgIdFileName(), curveApiConfiguration.legalOrgIdSheetName());

        return bulkUserUploadResponse;
    }
}
