package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.vf.cove.curve.dto.v1_0.BulkUserValidationResponse;
import com.vf.cove.curve.internal.service.BulkUserValidationService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.BulkUserValidationResponseResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author Hagar ElMasry
 */
@Component(
    properties = "OSGI-INF/liferay/rest/v1_0/bulk-user-validation-response.properties",
    scope = ServiceScope.PROTOTYPE,
    service = BulkUserValidationResponseResource.class
)
public class BulkUserValidationResponseResourceImpl
    extends BaseBulkUserValidationResponseResourceImpl {

    private static final String FILE_KEY = "fileName";

    @Reference(unbind = "-")
    BulkUserValidationService bulkUserValidationService;

    @Reference(unbind = "-")
    CurveUtils curveUtils;

    @Override
    public BulkUserValidationResponse postBulkUser(MultipartBody multipartBody) throws Exception {
        return bulkUserValidationService.validaBulkUserSubmittedFile(
            multipartBody.getBinaryFile(FILE_KEY).getInputStream(),
            multipartBody.getValues(),
            curveUtils.getUserRequestDto(contextHttpServletRequest, null)
        );
    }
}
