package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.internal.client.CurveDxlClient;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CurveApigeeErrorResponse;
import com.vf.cove.curve.internal.model.CurveApigeeSuccessResponse;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.Cookie;
import javax.ws.rs.core.Response;

@Component(
    service = {DxlAccessTokenService.class}
)
public class DxlAccessTokenService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DxlAccessTokenService.class);

    @Reference(unbind = "-")
    private CurveDxlClient curveDxlClient;

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;

    /**
     * Method for getting dxl orchestrator access token
     *
     * @@param requestDto - context object contains all headers, request and response objects
     * @return Curve response JSON in string format & header data.
     * @throws Exception
     */
    public CurveApigeeSuccessResponse getDxlAccessToken(CurveHttpRequestDTO requestDto) {
        CurveApigeeSuccessResponse curveApigeeSuccessResponse = null;
        Response response = curveDxlClient.getDxlAccessToken(requestDto);

        LOGGER.trace(" DXLAccessToken response:: {}",  response);
        Integer statusCode = response.getStatus();

        if(statusCode.intValue() == 200){
            curveApigeeSuccessResponse = response.readEntity(CurveApigeeSuccessResponse.class);
            LOGGER.info(curveApigeeSuccessResponse.toString());
        }else {
            CurveApigeeErrorResponse errorResponse = response.readEntity(CurveApigeeErrorResponse.class);
            throw new ServiceException("Curve error description: ".concat(errorResponse.getErrorDescription()));
        }

        Cookie cookie = new Cookie(CurveConstant.DXL_ACCESS_TOKEN_COOKIE, curveApigeeSuccessResponse.getAccessToken());
        cookie.setHttpOnly(true);
        cookie.setMaxAge(Integer.valueOf(curveApigeeSuccessResponse.getExpiresIn()));
        requestDto.getHttpServletResponse().addCookie(cookie);
        return curveApigeeSuccessResponse;
    }
}

