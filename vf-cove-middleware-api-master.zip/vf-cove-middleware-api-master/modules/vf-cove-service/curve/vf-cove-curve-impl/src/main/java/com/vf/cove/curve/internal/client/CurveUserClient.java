package com.vf.cove.curve.internal.client;

import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.dto.v1_0.Location;
import com.vf.cove.curve.dto.v1_0.RelatedParty;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.exception.DataNotFoundException;
import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.UserGroupsUploadFileService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.vf.cove.curve.internal.utils.CurveUserUtils.transformCurveUserRequest;

/**
 * Client class for sending REST requests
 */
@Component(
    configurationPid = CurveApiConfiguration.PID,
    service = CurveUserClient.class
)
public class CurveUserClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveUserClient.class);
    private static final String CURVE_USER_CLIENT_RESPONSE_STATUS = "CurveUserClient :: Response Status :: {}";

    @Reference(unbind = "-")
    CurveApiConfiguration config;

    @Reference(unbind = "-")
    ClientSSLConfiguration sslConfiguration;

    @Reference(unbind = "-")
    CurveUtils curveUtils;

    @Reference(unbind = "-")
    UserGroupsUploadFileService userGroupsUploadFileService;

    /**
     * Send GET request
     *
     * @param curveHttpRequestDTO - contains request parameters and headers
     * @return CurveUser list - the Response of the GET request
     */
    public List<CurveUser> getUserList(CurveHttpRequestDTO curveHttpRequestDTO) {
        LOGGER.debug("getUserList :: start");
        List<CurveUser> userList;
        Response response;

        try {
            response = sslConfiguration.getClient().target(config.dxlOrchestratorBaseUrl()).path(config.curveUserURIPath())
                .queryParam(CurveConstant.GRANTER_EMAIL, curveHttpRequestDTO.getGranterEmail())
                .queryParam(CurveConstant.SEARCH, curveHttpRequestDTO.getSearch())
                .queryParam(CurveConstant.STATUS, curveHttpRequestDTO.getStatus())
                .queryParam(CurveConstant.SORT, curveHttpRequestDTO.getSort())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(CurveConstant.AUTHORIZATION, curveHttpRequestDTO.getDxlToken())
                .header(CurveConstant.X_SOURCE_SYSTEM, curveHttpRequestDTO.getSourceSystem())
                .get();

            if(Objects.isNull(response)){
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
            }

            int status = response.getStatus();
            LOGGER.debug(CURVE_USER_CLIENT_RESPONSE_STATUS, status);

            if(status == HttpStatus.SC_OK || status == HttpStatus.SC_ACCEPTED){
               userList =Arrays.asList(response.readEntity(CurveUser[].class));
               LOGGER.debug("result {}", userList);

            }else{
                CurveUser userError =response.readEntity(CurveUser.class);
                throw new BackendSystemException(userError.getDescription());
            }

            LOGGER.debug("getUserList :: end");

        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }

        return userList;

    }

    /**
     * Send GET request
     *
     * @param curveHttpRequestDTO - contains request parameters and headers
     * @return CurveUser - the Response of the GET request
     */
    public CurveUser getUserById(CurveHttpRequestDTO curveHttpRequestDTO) {

        LOGGER.debug("getUserById :: start");
        CurveUser curveUser;
        try {
            Response response = sslConfiguration.getClient().target(config.dxlOrchestratorBaseUrl()).path(config.curveUserURIPath()).path(curveHttpRequestDTO.getUserId())
                .queryParam(CurveConstant.GRANTER_EMAIL,curveHttpRequestDTO.getGranterEmail())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.CONTENT_TYPE, ContentType.APPLICATION_JSON)
                .header(CurveConstant.AUTHORIZATION, curveHttpRequestDTO.getDxlToken())
                .header(CurveConstant.X_SOURCE_SYSTEM, curveHttpRequestDTO.getSourceSystem())
                .get();

            if(Objects.isNull(response)){
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
            }

            int status = response.getStatus();
            LOGGER.debug(CURVE_USER_CLIENT_RESPONSE_STATUS, status);

            if(status == HttpStatus.SC_OK || status == HttpStatus.SC_ACCEPTED){
                curveUser =response.readEntity(CurveUser.class);
                LOGGER.debug("getUserById :: result {}", curveUser);

            }else{
                throw new BackendSystemException(curveUtils.getStatusMessage(status));
            }

            LOGGER.debug("getUserById :: end");

        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }

        return curveUser;

    }

    /**
     * Send POST request
     *
     * @param curveHttpRequestDTO - contains request parameters and headers
     * @return CurveUser list - the Response of the POST request
     */
    public List<CurveUser> createUser(CurveUser[] curveUserRequest, CurveHttpRequestDTO curveHttpRequestDTO) {
        LOGGER.debug("createUser :: start");

        CurveUser curveUser;
        RelatedParty relatedParty = null;
        Location location = null;

        if (curveUserRequest != null && curveUserRequest.length > 0) {
            curveUser = curveUserRequest[0];
            if (curveUser.getRelatedParty().length > 0) {
                relatedParty = curveUser.getRelatedParty()[0];
                if (relatedParty.getLocation().length > 0) {
                    location = relatedParty.getLocation()[0];
                }
            }
        }

        assert relatedParty != null;
        assert location != null;
        final CompanyLevel companyLevel = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(
            relatedParty.getName(),
            location.getCountryCode());
        LOGGER.trace("companyLevel={}", companyLevel);

        transformCurveUserRequest(companyLevel, curveUserRequest);

        String payload = Arrays.stream(curveUserRequest).map(Object::toString)
            .collect(Collectors.joining(", "));
        payload = "[" + payload + "]";

        LOGGER.trace("getDxlToken={}", curveHttpRequestDTO.getDxlToken());
        LOGGER.trace("getSourceSystem={}", curveHttpRequestDTO.getSourceSystem());
        LOGGER.trace("dxlOrchestratorBaseUrl={}", config.dxlOrchestratorBaseUrl());
        LOGGER.trace("curveUserURIPath={}", config.curveUserURIPath());
        LOGGER.trace("curveUserRequest={}", payload);

        try {
            Response response = null;
            try {
                response = sslConfiguration.getClient().target(config.dxlOrchestratorBaseUrl()).path(config.curveUserURIPath())
                    .request()
                    .accept(MediaType.APPLICATION_JSON)
                    .header(CurveConstant.AUTHORIZATION, curveHttpRequestDTO.getDxlToken())
                    .header(CurveConstant.X_SOURCE_SYSTEM, curveHttpRequestDTO.getSourceSystem())
                    .post(Entity.entity(payload,MediaType.APPLICATION_JSON));
            } catch (Exception e) {
                LOGGER.error("Unable to make the DXL call", e);
                throw new BackendSystemException("DXL Call failed");
            }

            LOGGER.debug("response={}", response);


            if(Objects.isNull(response)){
                throw new DataNotFoundException(CurveConstant.BACKEND_SYSTEM_ERROR);
            }

            int status = response.getStatus();
            LOGGER.debug("Status", status);
            LOGGER.debug(CURVE_USER_CLIENT_RESPONSE_STATUS, status);
            if(status == HttpStatus.SC_OK || status == HttpStatus.SC_ACCEPTED){
                List<CurveUser> userList = Arrays.asList(response.readEntity(CurveUser[].class));
                LOGGER.debug("createUser :: result {}", userList);
                LOGGER.debug("createUser :: end");
                return userList;
           }

           CurveUser userError = response.readEntity(CurveUser.class);
           LOGGER.info("BackendSystemException :: {} ", userError.getReason());
           throw new BackendSystemException(userError.getReason());

        }
        catch (SSLConnectivityException e) {
            LOGGER.error("SSLConnectivityException ", e);
            throw new BackendSystemException("User creation failed");
        }
    }



    public List<String> getUserByIdList(List<String> curveUserRequest, CurveHttpRequestDTO curveHttpRequestDTO){
        LOGGER.debug("getUserByIdList :: start");
        List<String> userIdList = new ArrayList<>();
        Response response;

        try {
            response = sslConfiguration.getClient().target(config.dxlOrchestratorBaseUrl()).path(config.curveDBURIPath())
                .request()
                .accept(MediaType.APPLICATION_JSON)
                .header(CurveConstant.AUTHORIZATION, curveHttpRequestDTO.getDxlToken())
                .header(CurveConstant.X_SOURCE_SYSTEM, curveHttpRequestDTO.getSourceSystem())
                .post(Entity.entity(curveUserRequest, MediaType.APPLICATION_JSON));


            int status = response.getStatus();
            LOGGER.debug(CURVE_USER_CLIENT_RESPONSE_STATUS, status);

            if(status == HttpStatus.SC_OK || status == HttpStatus.SC_ACCEPTED){
                userIdList = Arrays.asList(response.readEntity(String[].class));
            }

            LOGGER.debug("getUserByIdList :: end");
            return userIdList;

        } catch (SSLConnectivityException e) {
            throw new RuntimeException(e);
        }

    }

}
