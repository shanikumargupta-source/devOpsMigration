package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.vulcan.pagination.Page;
import com.vf.cove.curve.dto.v1_0.CurveProduct;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.CurveProductService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.CurveProductResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author Hagar ElMasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/curve-product.properties",
	scope = ServiceScope.PROTOTYPE, service = CurveProductResource.class
)
public class CurveProductResourceImpl extends BaseCurveProductResourceImpl {

    @Reference(unbind = "-")
    private CurveProductService curveProductService;

    @Reference(unbind = "-")
    CurveUtils curveUtils;

    private static final Logger logger = LoggerFactory.getLogger(CurveProductResourceImpl.class);

    @Override
    public Page<CurveProduct> getProductList(String orgId, Integer offset, Integer limit) throws Exception {
        CurveHttpRequestDTO curveHttpRequestDTO = curveUtils.getProductRequestDto(contextHttpServletRequest, orgId, offset, limit);
        List<CurveProduct> productList = curveProductService.getCurveProductList(curveHttpRequestDTO);

        logger.info("ProductList :: {} ", productList);
        return Page.of(productList);
    }

    @Override
    public CurveProduct getProductById(String id, String orgId) throws Exception {
        CurveHttpRequestDTO curveHttpRequestDTO = curveUtils.getProductRequestDto(contextHttpServletRequest, orgId);
        curveHttpRequestDTO.setProductId(id);

        return curveProductService.getCurveProductById(curveHttpRequestDTO);
    }
}
