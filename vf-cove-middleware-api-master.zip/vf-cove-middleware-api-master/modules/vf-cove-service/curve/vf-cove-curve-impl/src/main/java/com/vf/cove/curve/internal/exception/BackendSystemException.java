/**
 *
 */
package com.vf.cove.curve.internal.exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class BackendSystemException extends RuntimeException {

    public BackendSystemException(String errorMessage ) {
        super(errorMessage);
    }

}
