package com.vf.cove.curve.internal.configuration.impl;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Component(
    configurationPid = CurveApiConfiguration.PID,
    configurationPolicy = ConfigurationPolicy.OPTIONAL
)
public class CurveApiConfigurationImpl implements CurveApiConfiguration {

    private CurveApiConfiguration curveApiConfiguration;

    @Activate
    @Modified
    protected void activate(Map<Object, Object> properties) {
        curveApiConfiguration = ConfigurableUtil.createConfigurable(CurveApiConfiguration.class, properties);
    }

    @Override
    public String ciamBaseURL() {
        return curveApiConfiguration.ciamBaseURL();
    }

    @Override
    public String accessTokenURIPath() {
        return curveApiConfiguration.accessTokenURIPath();
    }

    @Override
    public String redirectURIPath() {
        return curveApiConfiguration.redirectURIPath();
    }

    @Override
    public String accessTokenGrantType() {
        return curveApiConfiguration.accessTokenGrantType();
    }

    @Override
    public String refreshTokenGrantType() {
        return curveApiConfiguration.refreshTokenGrantType();
    }

    @Override
    public String redirectCoveUri() {
        return curveApiConfiguration.redirectCoveUri();
    }

    @Override
    public String ciamUserName() {
        return curveApiConfiguration.ciamUserName();
    }

    @Override
    public String ciamPassword() {
        return curveApiConfiguration.ciamPassword();
    }

    @Override
    public String dxlOrchestratorBaseUrl() {
        return curveApiConfiguration.dxlOrchestratorBaseUrl();
    }

    @Override
    public String dxlOrchestratorCurveVersion() {
        return curveApiConfiguration.dxlOrchestratorCurveVersion();
    }

    @Override
    public String companyEndpoint() {
        return curveApiConfiguration.companyEndpoint();
    }

    @Override
    public String snowCompanyEndpoint() {
        return curveApiConfiguration.snowCompanyEndpoint();
    }

    @Override
    public String dxlAccessTokenEndpoint() {
        return curveApiConfiguration.dxlAccessTokenEndpoint();
    }

    @Override
    public String dxlClientId() {
        return curveApiConfiguration.dxlClientId();
    }

    @Override
    public String dxlClientSecret() {
        return curveApiConfiguration.dxlClientSecret();
    }

    @Override
    public String dxlScope() {
        return curveApiConfiguration.dxlScope();
    }

    @Override
    public String dxlGrantType() {
        return curveApiConfiguration.dxlGrantType();
    }

    @Override
    public String dxlApigeeKeystorePath() {
        return curveApiConfiguration.dxlApigeeKeystorePath();
    }

    @Override
    public String dxlApigeeJKSKeystorePassword() {
        return curveApiConfiguration.dxlApigeeJKSKeystorePassword();
    }

    @Override
    public String dxlApigeePKCS12Keystore() {
        return curveApiConfiguration.dxlApigeePKCS12Keystore();
    }

    @Override
    public String curveUserURIPath() {
        return curveApiConfiguration.curveUserURIPath();
    }

    @Override
    public String curveDBURIPath() { return curveApiConfiguration.curveDBURIPath(); }

    @Override
    public String curveProductURIPath() {
        return curveApiConfiguration.curveProductURIPath();
    }

    @Override
    public String bulkUserFileName() {
        return curveApiConfiguration.bulkUserFileName();
    }

    @Override
    public String bulkUserSheetName() {
        return curveApiConfiguration.bulkUserSheetName();
    }

    @Override
    public String templatePath() {
        return curveApiConfiguration.templatePath();
    }

    @Override
    public boolean isCurveDxlFilterEnabled() {
        return curveApiConfiguration.isCurveDxlFilterEnabled();
    }

    @Override
    public boolean isCurveCiamFilterEnabled() {
        return curveApiConfiguration.isCurveCiamFilterEnabled();
    }

    @Override
    public String userGroupsFileName() {
        return curveApiConfiguration.userGroupsFileName();
    }

    @Override
    public String userGroupsSheetName() {
        return curveApiConfiguration.userGroupsSheetName();
    }

    @Override
    public String liferayDataVolumePath() {return curveApiConfiguration.liferayDataVolumePath();}

    @Override
    public String sheetName() {return curveApiConfiguration.sheetName();}

    // Bulk user headers validation
    @Override
    public String firstNameHeader() {return curveApiConfiguration.firstNameHeader();}

    @Override
    public String lastNameHeader() {return curveApiConfiguration.lastNameHeader();}

    @Override
    public String emailHeader() {return curveApiConfiguration.emailHeader();}

    @Override
    public String activationDateHeader() { return curveApiConfiguration.activationDateHeader();}

    @Override
    public String sendEmailHeader() {return curveApiConfiguration.sendEmailHeader();}

    @Override
    public String roleHeader() {return curveApiConfiguration.roleHeader();}

    @Override
    public String userGroupHeader() {return curveApiConfiguration.userGroupHeader();}

    @Override
    public String phoneNumberHeader() {return curveApiConfiguration.phoneNumberHeader();}

    @Override
    public String tariffHeader() {return curveApiConfiguration.tariffHeader();}

    @Override
    public String upgradeDateHeader() {return curveApiConfiguration.upgradeDateHeader(); }

    @Override
    public String legalOrgIdFileName() {
        return curveApiConfiguration.legalOrgIdFileName();
    }

    public String legalOrgIdSheetName() {
        return curveApiConfiguration.legalOrgIdSheetName();
    }

    @Override
    public String identityStorePath() {
        return curveApiConfiguration.identityStorePath();
    }

    @Override
    public String trustStorePath() {
        return curveApiConfiguration.trustStorePath();
    }

    @Override
    public String trustStoreSecret() {
        return curveApiConfiguration.trustStoreSecret();
    }

    @Override
    public String identityStoreSecret() {
        return curveApiConfiguration.identityStoreSecret();
    }

    @Override
    public String certAlias() {
        return curveApiConfiguration.certAlias();
    }

}
