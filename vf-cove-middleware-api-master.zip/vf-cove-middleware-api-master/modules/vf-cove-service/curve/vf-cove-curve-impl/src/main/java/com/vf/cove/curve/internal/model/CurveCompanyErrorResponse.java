package com.vf.cove.curve.internal.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CurveCompanyErrorResponse {
    @JsonProperty("code")
    private String code;

    @JsonProperty("status")
    private String status;

    @JsonProperty("reason")
    private String reason;

    @JsonProperty("message")
    private String message;


    @Override
    public String toString() {
        return "CurveCompanyBusinessErrorResponse{" +
            "code='" + code + '\'' +
            ", status='" + status + '\'' +
            ", reason='" + reason + '\'' +
            ", message='" + message + '\'' +
            '}';
    }
}
