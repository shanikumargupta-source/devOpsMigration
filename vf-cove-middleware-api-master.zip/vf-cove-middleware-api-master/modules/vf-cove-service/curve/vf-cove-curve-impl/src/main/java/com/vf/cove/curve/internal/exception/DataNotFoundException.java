/**
 *
 */
package com.vf.cove.curve.internal.exception;

import javax.ws.rs.core.Response;

public class DataNotFoundException extends RuntimeException {

    final int errorCode;


    //Constructors
    public DataNotFoundException() {
        this.errorCode = Response.Status.NOT_FOUND.getStatusCode();
    }

    public DataNotFoundException(String errorMessage) {
		super(errorMessage);
        this.errorCode = Response.Status.NOT_FOUND.getStatusCode();
	}


}
