package com.vf.cove.curve.internal.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CurveCompanyDTO implements Serializable {

    @JsonProperty("id")
    private String id;

    @JsonProperty("href")
    private String href;

    @JsonProperty("name")
    private String name;

    @JsonProperty("linkedUserId")
    private String linkedUserId;

    @JsonProperty("displayName")
    private String displayName;

    @JsonProperty("location")
    private List<LocationDTO> locations;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLinkedUserId() {
        return linkedUserId;
    }

    public void setLinkedUserId(String linkedUserId) {
        this.linkedUserId = linkedUserId;
    }

    public List<LocationDTO> getLocations() {
        return locations;
    }

    public void setLocations(List<LocationDTO> locations) {
        this.locations = locations;
    }

    @Override
    public String toString() {
        return "CurveCompanyDTO{" +
            "id='" + id + '\'' +
            ", href='" + href + '\'' +
            ", name='" + name + '\'' +
            ", displayName='" + displayName + '\'' +
            ", linkedUserId='" + linkedUserId + '\'' +
            ", locations=" + locations +
            '}';
    }
}
