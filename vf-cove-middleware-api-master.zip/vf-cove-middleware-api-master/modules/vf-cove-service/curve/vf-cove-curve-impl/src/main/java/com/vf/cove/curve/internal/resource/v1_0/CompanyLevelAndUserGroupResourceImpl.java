package com.vf.cove.curve.internal.resource.v1_0;

import com.vf.cove.curve.dto.v1_0.CompanyLevelAndUserGroup;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.service.UserGroupsUploadFileService;
import com.vf.cove.curve.resource.v1_0.CompanyLevelAndUserGroupResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author Hagar ElMasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/company-level-and-user-group.properties",
	scope = ServiceScope.PROTOTYPE,
	service = CompanyLevelAndUserGroupResource.class
)
public class CompanyLevelAndUserGroupResourceImpl extends BaseCompanyLevelAndUserGroupResourceImpl {

    @Reference(unbind = "-")
    UserGroupsUploadFileService userGroupsUploadFileService;

    @Override
    public CompanyLevelAndUserGroup getUserGroups(String companyName, String country){
        CompanyLevel company = this.userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(companyName, country);
        return CompanyLevel.getCompanyLevelAndUserGroupResponse(company);
    }
}
