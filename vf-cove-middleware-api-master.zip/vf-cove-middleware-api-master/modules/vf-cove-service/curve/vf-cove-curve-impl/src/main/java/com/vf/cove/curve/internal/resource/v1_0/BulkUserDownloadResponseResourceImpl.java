package com.vf.cove.curve.internal.resource.v1_0;

import com.vf.cove.curve.dto.v1_0.BulkUserDownloadResponse;
import com.vf.cove.curve.internal.service.BulkUserTemplateService;
import com.vf.cove.curve.resource.v1_0.BulkUserDownloadResponseResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author Hagar ElMasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/bulk-user-download-response.properties",
	scope = ServiceScope.PROTOTYPE,
	service = BulkUserDownloadResponseResource.class
)
public class BulkUserDownloadResponseResourceImpl
	extends BaseBulkUserDownloadResponseResourceImpl {

    @Reference(unbind = "-")
    private BulkUserTemplateService bulkUserTemplateService;

    @Override
    public BulkUserDownloadResponse getBulkUserTemplate() throws Exception {
        return bulkUserTemplateService.downloadBulkUserTemplate();
    }
}
