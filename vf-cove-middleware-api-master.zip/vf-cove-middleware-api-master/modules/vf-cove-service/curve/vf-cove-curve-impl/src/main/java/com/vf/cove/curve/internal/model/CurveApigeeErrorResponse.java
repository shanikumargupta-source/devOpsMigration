package com.vf.cove.curve.internal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class CurveApigeeErrorResponse implements Serializable {

    @JsonProperty("error")
    private String error;
    @JsonProperty("error_description")
    private String errorDescription;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
}
