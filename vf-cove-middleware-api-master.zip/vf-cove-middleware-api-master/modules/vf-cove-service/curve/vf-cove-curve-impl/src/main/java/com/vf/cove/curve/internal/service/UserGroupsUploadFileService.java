package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.utils.ExcelUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.osgi.service.component.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Objects;

@Component(
    service = {UserGroupsUploadFileService.class}, scope = ServiceScope.SINGLETON
)
public class UserGroupsUploadFileService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserGroupsUploadFileService.class);

    private Map<String, CompanyLevel> inMemoryMap;

    @Reference(unbind = "-")
    private CurveApiConfiguration curveApiConfiguration;


    @Activate
    @Modified
    protected void activate() {
        String  userGroupsFilePath = getFilePath();

        File file = new File(userGroupsFilePath);
        if (file.exists() && file.getTotalSpace() > 0) {
            try {
                LOGGER.info("UserGroupsUploadFileService :: activate");
                createInMemoryMapFromExcelFile(userGroupsFilePath , curveApiConfiguration.userGroupsSheetName());
                LOGGER.info("In Memory User Groups map Size :: " + inMemoryMap.size());

            } catch (Exception e) {
                LOGGER.error("Unable to createInMemoryMapFromExcelFile",e);
            }
        }
    }

    public CompanyLevel getCompanyUserGroupsByCompanyNameAndCountry(String companyName, String country) {
        String companyId = ExcelUtils.generateCompanyUniqueId(companyName, country);

        if (!Objects.isNull(this.inMemoryMap) && !this.inMemoryMap.isEmpty() && this.inMemoryMap.containsKey(companyId)) {
            return this.inMemoryMap.get(companyId);
        }

        return new CompanyLevel();
    }

    public void createInMemoryMapFromExcelStream(InputStream inputStream, String fileName, String sheetName) throws IOException {
        try {
            Workbook workbook = ExcelUtils.getWorkbookFromUploadedFileStream(inputStream, fileName);
            ExcelUtils.writeWorkbookInFileSystem(workbook, getFilePath());
            this.inMemoryMap = ExcelUtils.generateCompanyLevelsFromWorkbook(workbook, sheetName);
        } catch (IOException e) {
            throw e;
        }
    }

    public void createInMemoryMapFromExcelFile(String filePath, String sheetName) throws IOException {
        try {
            Workbook workbook = ExcelUtils.getWorkbookFromSavedFile(filePath);
            this.inMemoryMap = ExcelUtils.generateCompanyLevelsFromWorkbook(workbook, sheetName);
        } catch (IOException e) {
            throw e;
        }
    }

    public Map<String, CompanyLevel> getInMemoryMap() {
        return inMemoryMap;
    }

    public void setInMemoryMap(Map<String, CompanyLevel> inMemoryMap) {
        this.inMemoryMap = inMemoryMap;
    }

    public String getFilePath(){
        return curveApiConfiguration.liferayDataVolumePath() + curveApiConfiguration.userGroupsFileName();
    }
}
