package com.vf.cove.curve.internal.client;

import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import com.vf.cove.curve.internal.configuration.CurveApiConfiguration;
import com.vf.cove.curve.internal.connectivity.KeyStoreLoader;
import com.vf.cove.curve.internal.exception.SSLConnectivityException;
import com.vf.cove.curve.internal.filter.CurveLoggingFilter;
import org.apache.http.ssl.SSLContexts;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.security.KeyStore;

import static com.vf.cove.curve.internal.utils.CurveUtils.getSecret;


@Component(
    configurationPid = CurveApiConfiguration.PID,
    service = ClientSSLConfiguration.class)
public class ClientSSLConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClientSSLConfiguration.class);

    private static final String FILE_SEPARATOR = "file.separator";

    @Reference(unbind = "-")
    CurveApiConfiguration curveApiConfiguration;

    public Client getClient() throws SSLConnectivityException {

        SSLContext sslContext = createContext(curveApiConfiguration);

        return ClientBuilder.newBuilder()
            .register(JacksonJaxbJsonProvider.class)
            .register(new CurveLoggingFilter(LoggerFactory.getLogger(CurveLoggingFilter.class)))
            .sslContext(sslContext).build();
    }

    private static SSLContext createContext(CurveApiConfiguration curveConfig) throws SSLConnectivityException {
        LOGGER.info("ClientSSLConfiguration :: createContext :: start");

        try {
            KeyStore identityStore = KeyStoreLoader.getStore(curveConfig.identityStorePath(), getSecret(curveConfig.identityStoreSecret()));
            String fullPath = curveConfig.trustStorePath();

            LOGGER.info("identityStore={}", identityStore);
            LOGGER.info("fullPath={}", fullPath);

            int index = fullPath.lastIndexOf(System.getProperty(FILE_SEPARATOR));
            String storeFileName = fullPath.substring(index + 1);
            LOGGER.info("storeFileName={}", storeFileName);

            KeyStore trustStore = KeyStoreLoader.getStore(curveConfig.trustStorePath(), getSecret(curveConfig.trustStoreSecret()));
            LOGGER.info("trustStore={}", trustStore);

            LOGGER.info("ClientSSLConfiguration :: createContext :: end");

            return SSLContexts.custom()
                .loadKeyMaterial(identityStore, getSecret(curveConfig.identityStoreSecret()).toCharArray(), (aliases, socket) -> curveConfig.certAlias())
                .loadTrustMaterial(trustStore, null)
                .build();

        } catch (Exception e) {
            throw new SSLConnectivityException("SSLContext failed to load. The exception is " + e);
        }
    }

}
