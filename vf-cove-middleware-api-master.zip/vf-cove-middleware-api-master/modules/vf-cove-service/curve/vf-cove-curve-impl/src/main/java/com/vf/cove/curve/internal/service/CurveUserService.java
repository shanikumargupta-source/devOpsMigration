package com.vf.cove.curve.internal.service;

import com.vf.cove.curve.dto.v1_0.CurveUser;
import com.vf.cove.curve.internal.client.CurveUserClient;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Component(service = CurveUserService.class)
public class CurveUserService {

    private static final Logger logger = LoggerFactory.getLogger(CurveUserService.class);

    @Reference(unbind = "-")
    CurveUserClient curveUserClient;

    public List<CurveUser> getCurveUserList(CurveHttpRequestDTO curveHttpRequestDTO) {
        logger.debug("CurveUserService :: getCurveUserList ");
        return  curveUserClient.getUserList(curveHttpRequestDTO);
    }

    public CurveUser getCurveUserById(CurveHttpRequestDTO curveHttpRequestDTO) {
        logger.debug("CurveUserService :: getCurveUserById ");
        return  curveUserClient.getUserById(curveHttpRequestDTO);
    }

    public List<CurveUser> createCurveUser(CurveUser[] curveUsers, CurveHttpRequestDTO curveHttpRequestDTO) {
        logger.debug("CurveUserService :: createCurveUser ");
        return  curveUserClient.createUser(curveUsers, curveHttpRequestDTO);
    }
}
