package com.vf.cove.curve.internal.service;

import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.vf.cove.curve.internal.client.CurveCiamClient;
import com.vf.cove.curve.internal.exception.ServiceException;
import com.vf.cove.curve.internal.model.CiamAccessTokenDTO;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component(service = CiamAccessTokenService.class)
public class CiamAccessTokenService {

    private static final Logger logger = LoggerFactory.getLogger(CiamAccessTokenService.class);

    @Reference(unbind = "-")
    CurveCiamClient curveCiamClient;

    public CiamAccessTokenDTO getAccessToken(CurveHttpRequestDTO requestDTO) throws ConfigurationException {
        logger.debug("CiamAccessTokenService :: getAccessToken ");

        HttpServletRequest contextRequest = requestDTO.getHttpServletRequest();
        HttpServletResponse contextResponse = requestDTO.getHttpServletResponse();
        String redirectUri = getRedirectUriWithQueryParams(contextRequest);

        Response response = curveCiamClient.getCiamAccessToken(requestDTO.getCiamAccessCode(), redirectUri, requestDTO.getIsCiamTokenExpired());
        logger.debug(" CiamAccessToken response:: " +  response);
        CiamAccessTokenDTO accessTokenDTO = null;

        try {
            accessTokenDTO = response.readEntity(CiamAccessTokenDTO.class);
            List<Cookie> cookieList = getCookies(accessTokenDTO);

            logger.trace("getAccessToken {}", accessTokenDTO);

            if(!cookieList.isEmpty()){
                cookieList.forEach(contextResponse::addCookie);
                logger.debug("getAccessToken::Success:: end" );
            }

            logger.debug("getAccessToken::Error:: end" );
            return accessTokenDTO;


        }catch (ProcessingException | IllegalStateException e){
            throw new ServiceException("Error reading ciam response", e);

        }
    }

    List<Cookie> getCookies(CiamAccessTokenDTO response ){

        logger.debug("CiamAccessTokenService :: getCookies :: start");
        List<Cookie> cookieList = new ArrayList<>();

        if(Objects.nonNull(response.getAccessToken())){
            Cookie cookie = new Cookie(CurveConstant.CIAM_ACCESS_TOKEN_COOKIE, response.getAccessToken());
            cookie.setMaxAge(response.getExpiresIn());
            cookieList.add(cookie);
        }

        if(Objects.nonNull(response.getRefreshToken())){
            cookieList.add(new Cookie(CurveConstant.CIAM_REFRESH_TOKEN_COOKIE, response.getRefreshToken()));
        }

        if(Objects.nonNull(response.getScope())){
            cookieList.add(new Cookie(CurveConstant.SCOPE,response.getScope()));
        }

        if(Objects.nonNull(response.getIdToken())){
            cookieList.add(new Cookie(CurveConstant.ID_TOKEN,response.getIdToken()));
        }

        if(Objects.nonNull(response.getTokenType())){
            cookieList.add(new Cookie(CurveConstant.TOKEN_TYPE,response.getTokenType()));
        }

        logger.debug("CiamAccessTokenService :: getCookies ::{}", cookieList);

        return cookieList ;

    }

    private String getRedirectUriWithQueryParams(HttpServletRequest request){
        StringBuffer redirectUri = request.getRequestURL();
        if(request.getQueryString() != null){
            String[] queryParams = request.getQueryString().split("&");
            String isExpired = queryParameterByName(queryParams, "isExpired");
            String userContextEmail = queryParameterByName(queryParams, "userContextEmail");
            String pAuth = queryParameterByName(queryParams, "p_auth");
            redirectUri.append("?").append(isExpired).append("&").append(userContextEmail).append("&").append(pAuth);
            return redirectUri.toString();
        } else {
            return "";
        }
    }

    private String queryParameterByName(String[] queryParams, String paramName){
        for (String queryParam : queryParams) {
            if(queryParam.contains(paramName)){return queryParam;}
        }
        return null;
    }
}
