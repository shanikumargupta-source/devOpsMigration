package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.vulcan.pagination.Page;
import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.dto.v1_0.*;
import com.vf.cove.curve.internal.exception.BackendSystemException;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.model.GenericUserCreationRequest;
import com.vf.cove.curve.internal.service.CurveUserService;
import com.vf.cove.curve.internal.service.UserGroupsUploadFileService;
import com.vf.cove.curve.internal.utils.CommonUserDataValidationUtil;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.CurveUserResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * @author Hagar Elmasry
 */
@Component(
    properties = "OSGI-INF/liferay/rest/v1_0/curve-user.properties",
    scope = ServiceScope.PROTOTYPE, service = CurveUserResource.class
)
public class CurveUserResourceImpl extends BaseCurveUserResourceImpl {

    @Reference(unbind = "-")
    private CurveUserService curveUserService;

    @Reference(unbind = "-")
    private CurveUtils curveUtils;

    @Reference(unbind = "-")
    private CommonUserDataValidationUtil commonUserDataValidationUtil;

    @Reference(unbind = "-")
    private UserGroupsUploadFileService userGroupsUploadFileService;

    private static final Logger logger = LoggerFactory.getLogger(CurveUserResourceImpl.class);

    @Override
    public Page<CurveUser> getUserList(String granterEmail, String search, String status, Sort[] sorts) throws Exception {
        CurveHttpRequestDTO curveHttpRequestDTO = curveUtils.getUserRequestDto(contextHttpServletRequest, granterEmail, search, status, sorts);
        List<CurveUser> userList = curveUserService.getCurveUserList(curveHttpRequestDTO);

        logger.debug("UserList :: {} ", userList);
        return Page.of(userList);
    }


    @Override
    public CurveUser getUserById(String id, String granterEmail) throws Exception {
        CurveHttpRequestDTO curveHttpRequestDTO = curveUtils.getUserRequestDto(contextHttpServletRequest, granterEmail);
        curveHttpRequestDTO.setUserId(id);

        return curveUserService.getCurveUserById(curveHttpRequestDTO);
    }

    @Override
    public Page<CurveUser> createUser(CurveUser[] curveUsers) throws Exception {
        curveUsers = curveUtils.addLegalOrgId(curveUsers);
        logger.info("curveUsers :: {} ", Arrays.asList(curveUsers));

        List<Error> validationErrors = new ArrayList<>();
        for (CurveUser curveUser : curveUsers) {
            GenericUserCreationRequest genericUserCreationRequest = new GenericUserCreationRequest();
            genericUserCreationRequest.setFirstName(curveUser.getGivenName());
            genericUserCreationRequest.setLastName(curveUser.getFamilyName());
            genericUserCreationRequest.setEmail(curveUser.getUserName());
            genericUserCreationRequest.setSendEmail(Boolean.FALSE.equals(curveUser.getIsEmailOtpDisabled()) ? "No" : "Yes");
            genericUserCreationRequest.setRole("User");

            Optional<@Valid UserCharacteristic> userGroupUserCharacteristic = Arrays.stream(curveUser.getUserCharacteristic()).filter(characteristic -> "userGroup".equalsIgnoreCase(characteristic.getName())).findFirst();
            userGroupUserCharacteristic.ifPresent(characteristic -> genericUserCreationRequest.setUserGroup(characteristic.getValue()));
            genericUserCreationRequest.setActivationDate(curveUser.getActivationDate());

            Optional<@Valid ServiceInventory> serviceInventory = Arrays.stream(curveUser.getServiceInventory()).findFirst();
            if (serviceInventory.isPresent()) {
                genericUserCreationRequest.setPhoneNumber(serviceInventory.get().getMsisdn());
                genericUserCreationRequest.setTariff(serviceInventory.get().getTarrif());
                genericUserCreationRequest.setUpgradeDate(serviceInventory.get().getUpgradeDate());
            }

            RelatedParty relatedParty = Arrays.stream(curveUser.getRelatedParty()).findFirst().get();
            String companyName = relatedParty.getName();

            Optional<UserCharacteristic> userCharacteristicCountryCodeOptional =  Arrays.stream(curveUser.getUserCharacteristic()).filter(userCharacteristic -> "organizationCountryCode".equalsIgnoreCase(userCharacteristic.getName())).findFirst();
            String countryCode = userCharacteristicCountryCodeOptional.get().getValue();
            final CompanyLevel companyLevel = userGroupsUploadFileService.getCompanyUserGroupsByCompanyNameAndCountry(
                companyName,
                countryCode);

            List<Error> mandatoryFieldsError = commonUserDataValidationUtil.validateMandatoryFields(genericUserCreationRequest, companyLevel, 0);
            List<Error> optionalFieldsError = commonUserDataValidationUtil.validateOptionalFields(genericUserCreationRequest, companyLevel, 0);

            validationErrors.addAll(mandatoryFieldsError);
            validationErrors.addAll(optionalFieldsError);
        }

        logger.info("createUser validationErrors :: {} ", validationErrors);
        if (!validationErrors.isEmpty()) {
            throw new BackendSystemException(validationErrors.toString());
        }

        List<CurveUser> userList = curveUserService.createCurveUser(curveUsers, curveUtils.getUserRequestDto(contextHttpServletRequest, null));

        logger.info("Created Users :: {} ", userList);
        return Page.of(userList);
    }

}
