package com.vf.cove.curve.internal.utils;

import com.vf.cove.curve.dto.v1_0.Error;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.model.ErrorTypeEnum;
import com.vf.cove.curve.internal.model.GenericUserCreationRequest;
import org.apache.commons.lang3.ObjectUtils;
import org.osgi.service.component.annotations.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import static com.vf.cove.curve.internal.model.CurveConstant.*;

@Component(
    service = CommonUserDataValidationUtil.class
)
public class CommonUserDataValidationUtil {


    public List<Error> validateMandatoryFields(GenericUserCreationRequest user, CompanyLevel companyLevel, int rowIndex) {
        List<Error> errors = new ArrayList<>();

        validateFirstName(errors, user.getFirstName(), rowIndex);
        validateLastName(errors, user.getLastName(), rowIndex);
        validateEmail(errors, user.getEmail(), rowIndex);
        validateSendEmail(errors, user.getSendEmail(), rowIndex);
        validateRole(errors, user.getRole(), rowIndex);
        validateUserGroup(errors, user.getUserGroup(), companyLevel, rowIndex);

        return errors;
    }

    public List<Error> validateOptionalFields(GenericUserCreationRequest user, CompanyLevel companyLevel, int rowIndex) {
        List<Error> errors = new ArrayList<>();

        validateActivationDate(errors, user.getActivationDate(), rowIndex);
        validatePhoneNumber(errors, user.getPhoneNumber(), user.getUpgradeDate(), user.getTariff(), companyLevel, rowIndex);
        validateTariff(errors, user.getTariff(), user.getPhoneNumber(), companyLevel, rowIndex);
        validateUpgradeDate(errors, user.getUpgradeDate(), user.getPhoneNumber(), companyLevel, rowIndex);

        return errors;
    }

    private void validateFirstName(List<Error> errors, String firstName, int rowIndex) {
        if(!isValidTextFormat(firstName, STRING_REGEX)){
            String errorMessage =  ObjectUtils.isEmpty(firstName)? getEmptyFieldErrorMessage(FIRST_NAME) : INVALID_TEXT_FORMAT;
            errors.add(getError(firstName, errorMessage, FIRST_NAME, rowIndex ));
        }
    }

    private void validateLastName(List<Error> errors, String lastName, int rowIndex) {
        if(!isValidTextFormat(lastName, STRING_REGEX)){
            String errorMessage = ObjectUtils.isEmpty(lastName)? getEmptyFieldErrorMessage(LAST_NAME) : INVALID_TEXT_FORMAT;
            errors.add(getError(lastName, errorMessage, LAST_NAME, rowIndex));
        }
    }

    private void validateEmail(List<Error> errors, String email, int rowIndex) {
        if(!isValidTextFormat(email, EMAIL_REGEX)){
            String errorMessage = ObjectUtils.isEmpty(email)? getEmptyFieldErrorMessage(EMAIL) : "Invalid email format";
            errors.add(getError(email, errorMessage, EMAIL, rowIndex));
        }
    }

    private void validateSendEmail(List<Error> errors, String sendEmail, int rowIndex) {
        if (ObjectUtils.isEmpty(sendEmail)) {
            errors.add(getError(sendEmail, SEND_EMAIL + " Field needs to be populated with Yes or No", SEND_EMAIL, rowIndex));
        } else if (ObjectUtils.isNotEmpty(sendEmail) && !sendEmail.equalsIgnoreCase("Yes") && !sendEmail.equalsIgnoreCase("No")) {
            errors.add(getError(sendEmail, "Value must be Yes or No", SEND_EMAIL, rowIndex));
        }
    }

    private void validateRole(List<Error> errors, String role, int rowIndex) {
        if (ObjectUtils.isEmpty(role)) {
            errors.add(getError(role, getEmptyFieldErrorMessage(ROLE), ROLE, rowIndex));

        } else if (!role.equalsIgnoreCase("User")) {
            errors.add(getError(role, "Role must be set to User", ROLE, rowIndex));
        }
    }

    private void validateUserGroup(List<Error> errors, String userGroup, CompanyLevel companyLevel, int rowIndex) {
        if(ObjectUtils.isEmpty(userGroup)){
            errors.add(getError(userGroup, getEmptyFieldErrorMessage(USER_GROUP), USER_GROUP, rowIndex));
        }

        if(companyLevel.getUserGroups().stream().noneMatch(userGroup::equalsIgnoreCase)) {
            errors.add(getError(userGroup, getNonExistingUserGroupFieldErrorMessage(userGroup, companyLevel), USER_GROUP, ErrorTypeEnum.NOT_ALLOWED, rowIndex));
        }
    }

    private void validateActivationDate(List<Error> errors, String activationDate, int rowIndex) {
        if (ObjectUtils.isNotEmpty(activationDate)) {
            try{
                if (isValidFormat(activationDate, DATE_REGEX)) {
                    LocalDate activationLocalDate = LocalDate.parse(activationDate, DateTimeFormatter.ofPattern(SPREADSHEET_FORMAT));
                    LocalDate currentDate = LocalDate.now();

                    if (!activationLocalDate.isAfter(currentDate)) {
                        errors.add(getError(activationDate, "Activation date must be in the future", ACTIVATION_DATE, rowIndex));
                    }

                } else if (isValidFormat(activationDate, DATE_BODY_REGEX)) {
                    LocalDate activationLocalDate = LocalDate.parse(activationDate, DateTimeFormatter.ofPattern(REQUEST_BODY_DATE_FORMAT));
                    LocalDate currentDate = LocalDate.now();

                    if (!activationLocalDate.isAfter(currentDate)) {
                        errors.add(getError(activationDate, "Activation date must be in the future", ACTIVATION_DATE, rowIndex));
                    }
                } else {
                    errors.add(getError(activationDate, "Incorrect format. Needs to be in the format dd/mm/yyyy", ACTIVATION_DATE, rowIndex));
                }

            }catch(DateTimeParseException e){
                errors.add(getError(activationDate, "Incorrect format. Needs to be in the format dd/mm/yyyy", ACTIVATION_DATE, rowIndex));
            }
        }
    }

    private void  validatePhoneNumber(List<Error> errors, String phoneNumber, String upgradeDate, String tariff, CompanyLevel companyLevel, int rowIndex) {
        if (companyLevel.isLevel3()) {
            if (ObjectUtils.isNotEmpty(phoneNumber)) {
                if (!isValidFormat(phoneNumber, PHONE_NUMBER_REGEX)) {
                    errors.add(getError(phoneNumber, "Phone number is in an incorrect format", PHONE_NUMBER, rowIndex));
                }

                if (ObjectUtils.isEmpty(tariff)) {
                    errors.add(getError(tariff, FIELD_MUST_BE_POPULATED_WHEN_A_PHONE_NUMBER_IS_PROVIDED, TARIFF, rowIndex));
                }

                if (ObjectUtils.isEmpty(upgradeDate)) {
                    errors.add(getError(upgradeDate, FIELD_MUST_BE_POPULATED_WHEN_A_PHONE_NUMBER_IS_PROVIDED, UPGRADE_DATE, rowIndex));
                }
            }
        }

        if (companyLevel.isLevel1()) {
            if (ObjectUtils.isEmpty(phoneNumber)) {
                errors.add(getError(phoneNumber, getEmptyFieldErrorMessage(PHONE_NUMBER), PHONE_NUMBER, rowIndex));
            }
        }
    }

    private void validateTariff(List<Error> errors, String tariff, String phoneNumber, CompanyLevel companyLevel, int rowIndex) {
        if (companyLevel.isLevel3()) {
            if (ObjectUtils.isNotEmpty(tariff)) {
                if (ObjectUtils.isEmpty(phoneNumber)) {
                    errors.add(getError(tariff, TARIFF + INVALID_POPULATION, TARIFF, rowIndex));
                }

                if (!Arrays.asList(TARIFF_VOICEDATA, TARIFF_DATA).contains(tariff)) {
                    errors.add(getError(tariff, "Tariff must be either " + TARIFF_VOICEDATA + " or " + TARIFF_DATA, TARIFF, rowIndex));
                }
            }
        }
    }

    private void validateUpgradeDate(List<Error> errors, String upgradeDate, String phoneNumber, CompanyLevel companyLevel, int rowIndex) {
        if (companyLevel.isLevel3()) {
            if (ObjectUtils.isNotEmpty(upgradeDate)) {
                if (ObjectUtils.isEmpty(phoneNumber)) {
                    errors.add(getError(upgradeDate, UPGRADE_DATE + INVALID_POPULATION, UPGRADE_DATE, rowIndex));
                }

                if (!isValidFormat(upgradeDate, DATE_REGEX) && !isValidFormat(upgradeDate, DATE_BODY_REGEX)) {
                    errors.add(getError(upgradeDate, INVALID_DATE_FORMAT, UPGRADE_DATE, rowIndex));
                }
            }
        }
    }

    public boolean isValidTextFormat(String value, String regex) {
        return value.matches(regex);
    }

    public boolean isValidFormat(String value, String regex) {
        return Pattern.compile(regex).matcher(value).matches();
    }

    private String getEmptyFieldErrorMessage(String columnName) {
        return columnName + " needs to be populated as it is a mandatory field";
    }

    private String getNonExistingUserGroupFieldErrorMessage(String userGroup, CompanyLevel companyLevel) {
        return String.format("User group not found for your organisation");
    }

    private static Error getError(String formattedValue, String errorMessage, String columnName, int rowIndex) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);
        error.setValue(formattedValue);
        error.setColumn(columnName);
        error.setRow(rowIndex);
        final ErrorTypeEnum errorType = getErrorType(formattedValue);
        error.setErrorType(errorType);

        return error;
    }

    public static Error getError(String formattedValue, String errorMessage, String columnName, ErrorTypeEnum errorType, int rowIndex) {
        Error error = new Error();
        error.setErrorMessage(errorMessage);
        error.setValue(formattedValue);
        error.setColumn(columnName);
        error.setRow(rowIndex);
        error.setErrorType(errorType);

        return error;
    }

    private static ErrorTypeEnum getErrorType(String fieldName) {
        return ObjectUtils.isEmpty(fieldName) ? ErrorTypeEnum.REQUIRED : ErrorTypeEnum.FORMAT;
    }
}
