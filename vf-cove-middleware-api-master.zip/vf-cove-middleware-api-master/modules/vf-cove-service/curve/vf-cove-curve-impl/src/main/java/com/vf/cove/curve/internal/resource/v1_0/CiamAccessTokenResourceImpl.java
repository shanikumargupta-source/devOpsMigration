package com.vf.cove.curve.internal.resource.v1_0;

import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.vf.cove.curve.dto.v1_0.CiamAccessToken;
import com.vf.cove.curve.internal.model.CiamAccessTokenDTO;
import com.vf.cove.curve.internal.model.CurveHttpRequestDTO;
import com.vf.cove.curve.internal.service.CiamAccessTokenService;
import com.vf.cove.curve.internal.utils.CurveUtils;
import com.vf.cove.curve.resource.v1_0.CiamAccessTokenResource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

/**
 * @author Hagar Elmasry
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/ciam-access-token.properties",
	scope = ServiceScope.PROTOTYPE, service = CiamAccessTokenResource.class
)
public class CiamAccessTokenResourceImpl extends BaseCiamAccessTokenResourceImpl {

    @Reference(unbind = "-")
    private CiamAccessTokenService accessTokenService;

    private static final Logger logger = LoggerFactory.getLogger(CiamAccessTokenResourceImpl.class);

    @Override
    public CiamAccessToken getAccessToken(String accessCode, Boolean isExpired) throws ConfigurationException {
        logger.debug("getAccessToken:: start :: Access Code {}", accessCode );
        CurveHttpRequestDTO requestDTO = CurveUtils.getCiamAccessTokenRequestDto(contextHttpServletRequest, contextHttpServletResponse, accessCode, isExpired);
        //if the access code is expired, curve request filter will set isExpired to true to can get the new access code
        CiamAccessTokenDTO accessTokenDTO = accessTokenService.getAccessToken(requestDTO);

        CiamAccessToken accessToken = new CiamAccessToken();
        accessToken.setError(Optional.ofNullable(accessTokenDTO.getError()).orElse(accessTokenDTO.getError()));
        accessToken.setErrorDescription(Optional.ofNullable(accessTokenDTO.getErrorDescription()).orElse(accessTokenDTO.getErrorDescription()));
        logger.trace("getAccessToken:: end :: Access token {}", accessToken );
        return accessToken;
    }

}
