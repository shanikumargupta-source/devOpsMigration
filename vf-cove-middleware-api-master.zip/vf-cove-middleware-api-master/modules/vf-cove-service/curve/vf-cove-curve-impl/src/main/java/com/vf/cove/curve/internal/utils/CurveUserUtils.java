package com.vf.cove.curve.internal.utils;

import com.vf.cove.curve.dto.v1_0.*;
import com.vf.cove.curve.internal.model.CompanyLevel;
import com.vf.cove.curve.internal.model.CurveConstant;
import com.vf.cove.curve.internal.model.UserDTO;
import org.apache.commons.lang3.ObjectUtils;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import static com.vf.cove.curve.internal.model.CurveConstant.*;
import static java.time.format.DateTimeFormatter.ofPattern;


@Component(service = CurveUserUtils.class)
public class CurveUserUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(CurveUserUtils.class);

    public static CurveUser prepareCurveUser(UserDTO userDTO, Map<String, String> paramsMap, String legalOrgId) {
        CurveUser curveUser = new CurveUser();

        prepareRootData(curveUser, userDTO, paramsMap);
        curveUser.setServiceInventory(prepareServiceInventory(userDTO));
        curveUser.setUserCharacteristic(prepareUserCharacteristic(userDTO, paramsMap, legalOrgId));
        curveUser.setProduct(prepareProduct(userDTO, paramsMap));
        curveUser.setRelatedParty(prepareRelatedParty(paramsMap));

        return curveUser;
    }

    public static void prepareRootData(CurveUser curveUser, UserDTO userDTO, Map<String, String> paramsMap) {
        curveUser.setDisplayName(userDTO.getFirstName() + " " + userDTO.getLastName());
        curveUser.setFullName(curveUser.getDisplayName());
        curveUser.setUserName(userDTO.getEmail());
        curveUser.setGranterEmail(paramsMap.get(CurveConstant.GRANTER_EMAIL));
        curveUser.setFamilyName(userDTO.getLastName());
        curveUser.setGivenName(userDTO.getFirstName());
        curveUser.setIsEmailOtpDisabled(Optional.ofNullable(userDTO.getSendEmail()).get().equals("No"));

        LOGGER.debug("prepareRootData : user : {}", userDTO.getEmail());
    }

    public static ServiceInventory[] prepareServiceInventory(UserDTO userDTO) {
        List<ServiceInventory> serviceInventoryList = new ArrayList<>();

        if (isNotNullOrEmpty(userDTO.getTariff()) && isNotNullOrEmpty(userDTO.getPhoneNumber())) {
            ServiceInventory serviceInventory = new ServiceInventory();
            serviceInventory.setTarrif(userDTO.getTariff());
            serviceInventory.setMsisdn(userDTO.getPhoneNumber());
            serviceInventory.setUpgradeDate(convertToISODate(userDTO.getUpgradeDate()));
            serviceInventory.setActivationDate(convertToISODate(userDTO.getActivationDate()));
            serviceInventoryList.add(serviceInventory);
        }

        return serviceInventoryList.toArray(new ServiceInventory[0]);
    }

    public static UserCharacteristic[] prepareUserCharacteristic(UserDTO userDTO, Map<String, String> paramsMap, String legalOrgId) {
        List<UserCharacteristic> userCharacteristicList = new ArrayList<>();

        String countryCode = paramsMap.get(CurveConstant.COUNTRY_CODE_FIELD);
        UserCharacteristic userCharacteristic1 = new UserCharacteristic();
        userCharacteristic1.setName(CurveConstant.ORGANIZATION_COUNTRY_CODE);
        userCharacteristic1.setValue(countryCode);

        UserCharacteristic userCharacteristic2 = new UserCharacteristic();
        userCharacteristic2.setName(CurveConstant.USER_GROUP_FIELD);
        userCharacteristic2.setValue(userDTO.getUserGroup());

        UserCharacteristic userCharacteristic3 = new UserCharacteristic();
        userCharacteristic3.setName(CurveConstant.LEGAL_ORG_ID_FIELD);
        userCharacteristic3.setValue(legalOrgId);

        userCharacteristicList.add(userCharacteristic1);
        userCharacteristicList.add(userCharacteristic2);
        userCharacteristicList.add(userCharacteristic3);

        return userCharacteristicList.toArray(new UserCharacteristic[0]);
    }

    public static UserProduct[] prepareProduct(UserDTO userDTO, Map<String, String> paramsMap) {
        List<UserProduct> userProductList = new ArrayList<>();
        UserProduct userProduct = new UserProduct();
        userProduct.setId(paramsMap.get(CurveConstant.PRODUCT_ID));
        userProduct.setName(paramsMap.get(CurveConstant.PRODUCT_NAME));

        UserRole userRole = new UserRole();
        userRole.setName(paramsMap.get(CurveConstant.ROLE_NAME));
        userProduct.setRole(new UserRole[]{userRole});

        userProductList.add(userProduct);

        return userProductList.toArray(new UserProduct[0]);
    }

    public static RelatedParty[] prepareRelatedParty(Map<String, String> paramsMap) {
        List<RelatedParty> relatedParties = new ArrayList<>();
        RelatedParty relatedParty = new RelatedParty();
        relatedParty.setName(paramsMap.get(CurveConstant.ORGANIZATION_NAME));

        List<Location> locations = new ArrayList<>();
        Location location = new Location();
        location.setCountryCode(paramsMap.get(CurveConstant.COUNTRY_CODE_FIELD));
        location.setCountryName(paramsMap.get(CurveConstant.COUNTRY_NAME));
        locations.add(location);

        relatedParty.setLocation(locations.toArray(new Location[0]));
        relatedParties.add(relatedParty);

        return relatedParties.toArray(new RelatedParty[0]);
    }

    public static String convertToISODate(String date) {
        String formattedDate = null;
        if (Objects.nonNull(date) && ObjectUtils.isNotEmpty(date)) {
            try {
                //a placeholder to help conversion to ISO dateTime
                LocalTime time = LocalTime.parse("00:00:00");
                LocalDate parsedDate = LocalDate.parse(date.trim(), ofPattern(SPREADSHEET_FORMAT));
                formattedDate = parsedDate.atTime(time).format(DateTimeFormatter.ofPattern(DEFAULT_ISO_DATE_FORMAT));

            } catch (DateTimeParseException e) {
                throw new IllegalArgumentException("Incorrect format. Needs to be in the format dd/mm/yyyy");
            }
        }

        return formattedDate;
    }

    private static boolean isNotNullOrEmpty(String value) {
        return value != null && !value.isEmpty();
    }

    public static void transformCurveUserRequest(CompanyLevel companyLevel, CurveUser[] curveUserRequest) {
        LOGGER.debug("transformCurveUserRequest :: start");
        Arrays.stream(curveUserRequest).filter(ObjectUtils::isNotEmpty).forEach(curveUser -> {
            transformCurveUser(companyLevel, curveUser);
        });
        LOGGER.debug("transformCurveUserRequest :: end");
    }

    public static void transformCurveUser(CompanyLevel companyLevel, CurveUser curveUserRequest) {
        transformTariff(companyLevel, curveUserRequest);
    }

    private static void transformTariff(CompanyLevel companyLevel, CurveUser curveUserRequest) {
        LOGGER.debug("transformCurveUserRequest :: defaultTariff :: start");

        if (companyLevel.isLevel1()) {
            if (curveUserRequest.getServiceInventory().length > 0) {
                Arrays.stream(curveUserRequest.getServiceInventory()).filter(ObjectUtils::isNotEmpty).forEach(si -> {
                    if (si.getTarrif().isEmpty()) {
                        si.setTarrif(TARIFF_VOICEDATA);
                    }
                });
            }
        }

        LOGGER.debug("transformCurveUserRequest :: defaultTariff :: end");
    }


}
