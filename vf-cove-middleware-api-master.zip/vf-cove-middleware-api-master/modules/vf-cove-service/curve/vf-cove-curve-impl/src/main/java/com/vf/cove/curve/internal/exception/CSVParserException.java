package com.vf.cove.curve.internal.exception;

public class CSVParserException extends RuntimeException {

    public CSVParserException(String errorMessage) {
        super(errorMessage);
    }

    public CSVParserException(String errorMessage, Exception e) {
        super(errorMessage, e);
    }
}
