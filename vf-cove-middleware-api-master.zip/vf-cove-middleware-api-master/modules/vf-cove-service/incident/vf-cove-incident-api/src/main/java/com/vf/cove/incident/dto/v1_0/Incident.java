package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("Incident")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Incident")
public class Incident implements Serializable {

	public static Incident toDTO(String json) {
		return ObjectMapperUtil.readValue(Incident.class, json);
	}

	public static Incident unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Incident.class, json);
	}

	@Schema(example = "ACME Refrigerator Support")
	public String getAssignedTo() {
		if (_assignedToSupplier != null) {
			assignedTo = _assignedToSupplier.get();

			_assignedToSupplier = null;
		}

		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;

		_assignedToSupplier = null;
	}

	@JsonIgnore
	public void setAssignedTo(
		UnsafeSupplier<String, Exception> assignedToUnsafeSupplier) {

		_assignedToSupplier = () -> {
			try {
				return assignedToUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String assignedTo;

	@JsonIgnore
	private Supplier<String> _assignedToSupplier;

	@Schema(example = "Internet Of Things")
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema(example = "Alert Monitoring - Network")
	public String getCategory() {
		if (_categorySupplier != null) {
			category = _categorySupplier.get();

			_categorySupplier = null;
		}

		return category;
	}

	public void setCategory(String category) {
		this.category = category;

		_categorySupplier = null;
	}

	@JsonIgnore
	public void setCategory(
		UnsafeSupplier<String, Exception> categoryUnsafeSupplier) {

		_categorySupplier = () -> {
			try {
				return categoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String category;

	@JsonIgnore
	private Supplier<String> _categorySupplier;

	@Schema(example = "")
	public String getCountryCode() {
		if (_countryCodeSupplier != null) {
			countryCode = _countryCodeSupplier.get();

			_countryCodeSupplier = null;
		}

		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;

		_countryCodeSupplier = null;
	}

	@JsonIgnore
	public void setCountryCode(
		UnsafeSupplier<String, Exception> countryCodeUnsafeSupplier) {

		_countryCodeSupplier = () -> {
			try {
				return countryCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String countryCode;

	@JsonIgnore
	private Supplier<String> _countryCodeSupplier;

	@Schema(example = "-")
	public String getCustomerRef() {
		if (_customerRefSupplier != null) {
			customerRef = _customerRefSupplier.get();

			_customerRefSupplier = null;
		}

		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;

		_customerRefSupplier = null;
	}

	@JsonIgnore
	public void setCustomerRef(
		UnsafeSupplier<String, Exception> customerRefUnsafeSupplier) {

		_customerRefSupplier = () -> {
			try {
				return customerRefUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerRef;

	@JsonIgnore
	private Supplier<String> _customerRefSupplier;

	@Schema(example = "2019-06-26T10:43:13")
	public String getDateRaised() {
		if (_dateRaisedSupplier != null) {
			dateRaised = _dateRaisedSupplier.get();

			_dateRaisedSupplier = null;
		}

		return dateRaised;
	}

	public void setDateRaised(String dateRaised) {
		this.dateRaised = dateRaised;

		_dateRaisedSupplier = null;
	}

	@JsonIgnore
	public void setDateRaised(
		UnsafeSupplier<String, Exception> dateRaisedUnsafeSupplier) {

		_dateRaisedSupplier = () -> {
			try {
				return dateRaisedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dateRaised;

	@JsonIgnore
	private Supplier<String> _dateRaisedSupplier;

	@Schema(example = "Not escalated")
	public String getEscalationLevel() {
		if (_escalationLevelSupplier != null) {
			escalationLevel = _escalationLevelSupplier.get();

			_escalationLevelSupplier = null;
		}

		return escalationLevel;
	}

	public void setEscalationLevel(String escalationLevel) {
		this.escalationLevel = escalationLevel;

		_escalationLevelSupplier = null;
	}

	@JsonIgnore
	public void setEscalationLevel(
		UnsafeSupplier<String, Exception> escalationLevelUnsafeSupplier) {

		_escalationLevelSupplier = () -> {
			try {
				return escalationLevelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String escalationLevel;

	@JsonIgnore
	private Supplier<String> _escalationLevelSupplier;

	@Schema(example = "")
	public String getEscalationTeam() {
		if (_escalationTeamSupplier != null) {
			escalationTeam = _escalationTeamSupplier.get();

			_escalationTeamSupplier = null;
		}

		return escalationTeam;
	}

	public void setEscalationTeam(String escalationTeam) {
		this.escalationTeam = escalationTeam;

		_escalationTeamSupplier = null;
	}

	@JsonIgnore
	public void setEscalationTeam(
		UnsafeSupplier<String, Exception> escalationTeamUnsafeSupplier) {

		_escalationTeamSupplier = () -> {
			try {
				return escalationTeamUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String escalationTeam;

	@JsonIgnore
	private Supplier<String> _escalationTeamSupplier;

	@Schema(example = "Major")
	public String getImpact() {
		if (_impactSupplier != null) {
			impact = _impactSupplier.get();

			_impactSupplier = null;
		}

		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;

		_impactSupplier = null;
	}

	@JsonIgnore
	public void setImpact(
		UnsafeSupplier<String, Exception> impactUnsafeSupplier) {

		_impactSupplier = () -> {
			try {
				return impactUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String impact;

	@JsonIgnore
	private Supplier<String> _impactSupplier;

	@Schema(example = "80955")
	public String getIncidentIdInt() {
		if (_incidentIdIntSupplier != null) {
			incidentIdInt = _incidentIdIntSupplier.get();

			_incidentIdIntSupplier = null;
		}

		return incidentIdInt;
	}

	public void setIncidentIdInt(String incidentIdInt) {
		this.incidentIdInt = incidentIdInt;

		_incidentIdIntSupplier = null;
	}

	@JsonIgnore
	public void setIncidentIdInt(
		UnsafeSupplier<String, Exception> incidentIdIntUnsafeSupplier) {

		_incidentIdIntSupplier = () -> {
			try {
				return incidentIdIntUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String incidentIdInt;

	@JsonIgnore
	private Supplier<String> _incidentIdIntSupplier;

	@Schema(example = "INCV00080955")
	public String getIncidentRef() {
		if (_incidentRefSupplier != null) {
			incidentRef = _incidentRefSupplier.get();

			_incidentRefSupplier = null;
		}

		return incidentRef;
	}

	public void setIncidentRef(String incidentRef) {
		this.incidentRef = incidentRef;

		_incidentRefSupplier = null;
	}

	@JsonIgnore
	public void setIncidentRef(
		UnsafeSupplier<String, Exception> incidentRefUnsafeSupplier) {

		_incidentRefSupplier = () -> {
			try {
				return incidentRefUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String incidentRef;

	@JsonIgnore
	private Supplier<String> _incidentRefSupplier;

	@Schema(example = "")
	public String getInventoryItem() {
		if (_inventoryItemSupplier != null) {
			inventoryItem = _inventoryItemSupplier.get();

			_inventoryItemSupplier = null;
		}

		return inventoryItem;
	}

	public void setInventoryItem(String inventoryItem) {
		this.inventoryItem = inventoryItem;

		_inventoryItemSupplier = null;
	}

	@JsonIgnore
	public void setInventoryItem(
		UnsafeSupplier<String, Exception> inventoryItemUnsafeSupplier) {

		_inventoryItemSupplier = () -> {
			try {
				return inventoryItemUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String inventoryItem;

	@JsonIgnore
	private Supplier<String> _inventoryItemSupplier;

	@Schema(example = "2019-07-03T05:19:32")
	public String getLastUpdatedOn() {
		if (_lastUpdatedOnSupplier != null) {
			lastUpdatedOn = _lastUpdatedOnSupplier.get();

			_lastUpdatedOnSupplier = null;
		}

		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;

		_lastUpdatedOnSupplier = null;
	}

	@JsonIgnore
	public void setLastUpdatedOn(
		UnsafeSupplier<String, Exception> lastUpdatedOnUnsafeSupplier) {

		_lastUpdatedOnSupplier = () -> {
			try {
				return lastUpdatedOnUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lastUpdatedOn;

	@JsonIgnore
	private Supplier<String> _lastUpdatedOnSupplier;

	@Schema
	public String getNextCommunication() {
		if (_nextCommunicationSupplier != null) {
			nextCommunication = _nextCommunicationSupplier.get();

			_nextCommunicationSupplier = null;
		}

		return nextCommunication;
	}

	public void setNextCommunication(String nextCommunication) {
		this.nextCommunication = nextCommunication;

		_nextCommunicationSupplier = null;
	}

	@JsonIgnore
	public void setNextCommunication(
		UnsafeSupplier<String, Exception> nextCommunicationUnsafeSupplier) {

		_nextCommunicationSupplier = () -> {
			try {
				return nextCommunicationUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String nextCommunication;

	@JsonIgnore
	private Supplier<String> _nextCommunicationSupplier;

	@Schema(example = "Medium")
	public String getPriority() {
		if (_prioritySupplier != null) {
			priority = _prioritySupplier.get();

			_prioritySupplier = null;
		}

		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;

		_prioritySupplier = null;
	}

	@JsonIgnore
	public void setPriority(
		UnsafeSupplier<String, Exception> priorityUnsafeSupplier) {

		_prioritySupplier = () -> {
			try {
				return priorityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priority;

	@JsonIgnore
	private Supplier<String> _prioritySupplier;

	@Schema(example = "P3")
	public String getPriorityLabel() {
		if (_priorityLabelSupplier != null) {
			priorityLabel = _priorityLabelSupplier.get();

			_priorityLabelSupplier = null;
		}

		return priorityLabel;
	}

	public void setPriorityLabel(String priorityLabel) {
		this.priorityLabel = priorityLabel;

		_priorityLabelSupplier = null;
	}

	@JsonIgnore
	public void setPriorityLabel(
		UnsafeSupplier<String, Exception> priorityLabelUnsafeSupplier) {

		_priorityLabelSupplier = () -> {
			try {
				return priorityLabelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priorityLabel;

	@JsonIgnore
	private Supplier<String> _priorityLabelSupplier;

	@Schema(example = "NaN")
	public String getSladueIn() {
		if (_sladueInSupplier != null) {
			sladueIn = _sladueInSupplier.get();

			_sladueInSupplier = null;
		}

		return sladueIn;
	}

	public void setSladueIn(String sladueIn) {
		this.sladueIn = sladueIn;

		_sladueInSupplier = null;
	}

	@JsonIgnore
	public void setSladueIn(
		UnsafeSupplier<String, Exception> sladueInUnsafeSupplier) {

		_sladueInSupplier = () -> {
			try {
				return sladueInUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String sladueIn;

	@JsonIgnore
	private Supplier<String> _sladueInSupplier;

	@Schema(example = "New")
	public String getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@JsonIgnore
	private Supplier<String> _statusSupplier;

	@Schema(example = "N/A")
	public String getSubCategory() {
		if (_subCategorySupplier != null) {
			subCategory = _subCategorySupplier.get();

			_subCategorySupplier = null;
		}

		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;

		_subCategorySupplier = null;
	}

	@JsonIgnore
	public void setSubCategory(
		UnsafeSupplier<String, Exception> subCategoryUnsafeSupplier) {

		_subCategorySupplier = () -> {
			try {
				return subCategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String subCategory;

	@JsonIgnore
	private Supplier<String> _subCategorySupplier;

	@Schema(example = "test")
	public String getSummary() {
		if (_summarySupplier != null) {
			summary = _summarySupplier.get();

			_summarySupplier = null;
		}

		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;

		_summarySupplier = null;
	}

	@JsonIgnore
	public void setSummary(
		UnsafeSupplier<String, Exception> summaryUnsafeSupplier) {

		_summarySupplier = () -> {
			try {
				return summaryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String summary;

	@JsonIgnore
	private Supplier<String> _summarySupplier;

	@Schema(example = "")
	public String getTimeToClose() {
		if (_timeToCloseSupplier != null) {
			timeToClose = _timeToCloseSupplier.get();

			_timeToCloseSupplier = null;
		}

		return timeToClose;
	}

	public void setTimeToClose(String timeToClose) {
		this.timeToClose = timeToClose;

		_timeToCloseSupplier = null;
	}

	@JsonIgnore
	public void setTimeToClose(
		UnsafeSupplier<String, Exception> timeToCloseUnsafeSupplier) {

		_timeToCloseSupplier = () -> {
			try {
				return timeToCloseUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String timeToClose;

	@JsonIgnore
	private Supplier<String> _timeToCloseSupplier;

	@Schema(example = "Medium")
	public String getUrgency() {
		if (_urgencySupplier != null) {
			urgency = _urgencySupplier.get();

			_urgencySupplier = null;
		}

		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;

		_urgencySupplier = null;
	}

	@JsonIgnore
	public void setUrgency(
		UnsafeSupplier<String, Exception> urgencyUnsafeSupplier) {

		_urgencySupplier = () -> {
			try {
				return urgencyUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String urgency;

	@JsonIgnore
	private Supplier<String> _urgencySupplier;

	@Schema(example = "")
	public String getWatchFlag() {
		if (_watchFlagSupplier != null) {
			watchFlag = _watchFlagSupplier.get();

			_watchFlagSupplier = null;
		}

		return watchFlag;
	}

	public void setWatchFlag(String watchFlag) {
		this.watchFlag = watchFlag;

		_watchFlagSupplier = null;
	}

	@JsonIgnore
	public void setWatchFlag(
		UnsafeSupplier<String, Exception> watchFlagUnsafeSupplier) {

		_watchFlagSupplier = () -> {
			try {
				return watchFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String watchFlag;

	@JsonIgnore
	private Supplier<String> _watchFlagSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Incident)) {
			return false;
		}

		Incident incident = (Incident)object;

		return Objects.equals(toString(), incident.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String assignedTo = getAssignedTo();

		if (assignedTo != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"assignedTo\": ");

			sb.append("\"");

			sb.append(_escape(assignedTo));

			sb.append("\"");
		}

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String category = getCategory();

		if (category != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"category\": ");

			sb.append("\"");

			sb.append(_escape(category));

			sb.append("\"");
		}

		String countryCode = getCountryCode();

		if (countryCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryCode\": ");

			sb.append("\"");

			sb.append(_escape(countryCode));

			sb.append("\"");
		}

		String customerRef = getCustomerRef();

		if (customerRef != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerRef\": ");

			sb.append("\"");

			sb.append(_escape(customerRef));

			sb.append("\"");
		}

		String dateRaised = getDateRaised();

		if (dateRaised != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateRaised\": ");

			sb.append("\"");

			sb.append(_escape(dateRaised));

			sb.append("\"");
		}

		String escalationLevel = getEscalationLevel();

		if (escalationLevel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationLevel\": ");

			sb.append("\"");

			sb.append(_escape(escalationLevel));

			sb.append("\"");
		}

		String escalationTeam = getEscalationTeam();

		if (escalationTeam != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationTeam\": ");

			sb.append("\"");

			sb.append(_escape(escalationTeam));

			sb.append("\"");
		}

		String impact = getImpact();

		if (impact != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"impact\": ");

			sb.append("\"");

			sb.append(_escape(impact));

			sb.append("\"");
		}

		String incidentIdInt = getIncidentIdInt();

		if (incidentIdInt != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"incidentIdInt\": ");

			sb.append("\"");

			sb.append(_escape(incidentIdInt));

			sb.append("\"");
		}

		String incidentRef = getIncidentRef();

		if (incidentRef != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"incidentRef\": ");

			sb.append("\"");

			sb.append(_escape(incidentRef));

			sb.append("\"");
		}

		String inventoryItem = getInventoryItem();

		if (inventoryItem != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"inventoryItem\": ");

			sb.append("\"");

			sb.append(_escape(inventoryItem));

			sb.append("\"");
		}

		String lastUpdatedOn = getLastUpdatedOn();

		if (lastUpdatedOn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lastUpdatedOn\": ");

			sb.append("\"");

			sb.append(_escape(lastUpdatedOn));

			sb.append("\"");
		}

		String nextCommunication = getNextCommunication();

		if (nextCommunication != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"nextCommunication\": ");

			sb.append("\"");

			sb.append(_escape(nextCommunication));

			sb.append("\"");
		}

		String priority = getPriority();

		if (priority != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priority\": ");

			sb.append("\"");

			sb.append(_escape(priority));

			sb.append("\"");
		}

		String priorityLabel = getPriorityLabel();

		if (priorityLabel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priorityLabel\": ");

			sb.append("\"");

			sb.append(_escape(priorityLabel));

			sb.append("\"");
		}

		String sladueIn = getSladueIn();

		if (sladueIn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sladueIn\": ");

			sb.append("\"");

			sb.append(_escape(sladueIn));

			sb.append("\"");
		}

		String status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		String subCategory = getSubCategory();

		if (subCategory != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"subCategory\": ");

			sb.append("\"");

			sb.append(_escape(subCategory));

			sb.append("\"");
		}

		String summary = getSummary();

		if (summary != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"summary\": ");

			sb.append("\"");

			sb.append(_escape(summary));

			sb.append("\"");
		}

		String timeToClose = getTimeToClose();

		if (timeToClose != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"timeToClose\": ");

			sb.append("\"");

			sb.append(_escape(timeToClose));

			sb.append("\"");
		}

		String urgency = getUrgency();

		if (urgency != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"urgency\": ");

			sb.append("\"");

			sb.append(_escape(urgency));

			sb.append("\"");
		}

		String watchFlag = getWatchFlag();

		if (watchFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"watchFlag\": ");

			sb.append("\"");

			sb.append(_escape(watchFlag));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.Incident",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}