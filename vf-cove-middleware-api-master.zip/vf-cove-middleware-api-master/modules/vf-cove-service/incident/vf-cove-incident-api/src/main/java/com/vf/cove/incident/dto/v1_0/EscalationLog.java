package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("EscalationLog")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "EscalationLog")
public class EscalationLog implements Serializable {

	public static EscalationLog toDTO(String json) {
		return ObjectMapperUtil.readValue(EscalationLog.class, json);
	}

	public static EscalationLog unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(EscalationLog.class, json);
	}

	@Schema
	public String getEffectiveDateTime() {
		if (_effectiveDateTimeSupplier != null) {
			effectiveDateTime = _effectiveDateTimeSupplier.get();

			_effectiveDateTimeSupplier = null;
		}

		return effectiveDateTime;
	}

	public void setEffectiveDateTime(String effectiveDateTime) {
		this.effectiveDateTime = effectiveDateTime;

		_effectiveDateTimeSupplier = null;
	}

	@JsonIgnore
	public void setEffectiveDateTime(
		UnsafeSupplier<String, Exception> effectiveDateTimeUnsafeSupplier) {

		_effectiveDateTimeSupplier = () -> {
			try {
				return effectiveDateTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String effectiveDateTime;

	@JsonIgnore
	private Supplier<String> _effectiveDateTimeSupplier;

	@Schema
	public String getEscalationIndicator() {
		if (_escalationIndicatorSupplier != null) {
			escalationIndicator = _escalationIndicatorSupplier.get();

			_escalationIndicatorSupplier = null;
		}

		return escalationIndicator;
	}

	public void setEscalationIndicator(String escalationIndicator) {
		this.escalationIndicator = escalationIndicator;

		_escalationIndicatorSupplier = null;
	}

	@JsonIgnore
	public void setEscalationIndicator(
		UnsafeSupplier<String, Exception> escalationIndicatorUnsafeSupplier) {

		_escalationIndicatorSupplier = () -> {
			try {
				return escalationIndicatorUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String escalationIndicator;

	@JsonIgnore
	private Supplier<String> _escalationIndicatorSupplier;

	@Schema
	public String getReasonCode() {
		if (_reasonCodeSupplier != null) {
			reasonCode = _reasonCodeSupplier.get();

			_reasonCodeSupplier = null;
		}

		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;

		_reasonCodeSupplier = null;
	}

	@JsonIgnore
	public void setReasonCode(
		UnsafeSupplier<String, Exception> reasonCodeUnsafeSupplier) {

		_reasonCodeSupplier = () -> {
			try {
				return reasonCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String reasonCode;

	@JsonIgnore
	private Supplier<String> _reasonCodeSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EscalationLog)) {
			return false;
		}

		EscalationLog escalationLog = (EscalationLog)object;

		return Objects.equals(toString(), escalationLog.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String effectiveDateTime = getEffectiveDateTime();

		if (effectiveDateTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"effectiveDateTime\": ");

			sb.append("\"");

			sb.append(_escape(effectiveDateTime));

			sb.append("\"");
		}

		String escalationIndicator = getEscalationIndicator();

		if (escalationIndicator != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationIndicator\": ");

			sb.append("\"");

			sb.append(_escape(escalationIndicator));

			sb.append("\"");
		}

		String reasonCode = getReasonCode();

		if (reasonCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"reasonCode\": ");

			sb.append("\"");

			sb.append(_escape(reasonCode));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.EscalationLog",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}