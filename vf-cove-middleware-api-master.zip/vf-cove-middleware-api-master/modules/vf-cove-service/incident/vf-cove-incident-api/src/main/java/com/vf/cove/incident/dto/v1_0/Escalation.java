package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("Escalation")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Escalation")
public class Escalation implements Serializable {

	public static Escalation toDTO(String json) {
		return ObjectMapperUtil.readValue(Escalation.class, json);
	}

	public static Escalation unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Escalation.class, json);
	}

	@Schema
	@Valid
	public EscalationLog[] getEscalationLog() {
		if (_escalationLogSupplier != null) {
			escalationLog = _escalationLogSupplier.get();

			_escalationLogSupplier = null;
		}

		return escalationLog;
	}

	public void setEscalationLog(EscalationLog[] escalationLog) {
		this.escalationLog = escalationLog;

		_escalationLogSupplier = null;
	}

	@JsonIgnore
	public void setEscalationLog(
		UnsafeSupplier<EscalationLog[], Exception>
			escalationLogUnsafeSupplier) {

		_escalationLogSupplier = () -> {
			try {
				return escalationLogUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected EscalationLog[] escalationLog;

	@JsonIgnore
	private Supplier<EscalationLog[]> _escalationLogSupplier;

	@Schema
	public String getLevel() {
		if (_levelSupplier != null) {
			level = _levelSupplier.get();

			_levelSupplier = null;
		}

		return level;
	}

	public void setLevel(String level) {
		this.level = level;

		_levelSupplier = null;
	}

	@JsonIgnore
	public void setLevel(
		UnsafeSupplier<String, Exception> levelUnsafeSupplier) {

		_levelSupplier = () -> {
			try {
				return levelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String level;

	@JsonIgnore
	private Supplier<String> _levelSupplier;

	@Schema
	public String getTeam() {
		if (_teamSupplier != null) {
			team = _teamSupplier.get();

			_teamSupplier = null;
		}

		return team;
	}

	public void setTeam(String team) {
		this.team = team;

		_teamSupplier = null;
	}

	@JsonIgnore
	public void setTeam(UnsafeSupplier<String, Exception> teamUnsafeSupplier) {
		_teamSupplier = () -> {
			try {
				return teamUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String team;

	@JsonIgnore
	private Supplier<String> _teamSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Escalation)) {
			return false;
		}

		Escalation escalation = (Escalation)object;

		return Objects.equals(toString(), escalation.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		EscalationLog[] escalationLog = getEscalationLog();

		if (escalationLog != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationLog\": ");

			sb.append("[");

			for (int i = 0; i < escalationLog.length; i++) {
				sb.append(String.valueOf(escalationLog[i]));

				if ((i + 1) < escalationLog.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String level = getLevel();

		if (level != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"level\": ");

			sb.append("\"");

			sb.append(_escape(level));

			sb.append("\"");
		}

		String team = getTeam();

		if (team != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"team\": ");

			sb.append("\"");

			sb.append(_escape(team));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.Escalation",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}