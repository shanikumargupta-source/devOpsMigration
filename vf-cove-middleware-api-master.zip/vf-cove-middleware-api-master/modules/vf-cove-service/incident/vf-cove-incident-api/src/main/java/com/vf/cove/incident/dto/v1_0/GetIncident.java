package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("GetIncident")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetIncident")
public class GetIncident implements Serializable {

	public static GetIncident toDTO(String json) {
		return ObjectMapperUtil.readValue(GetIncident.class, json);
	}

	public static GetIncident unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(GetIncident.class, json);
	}

	@Schema(example = "")
	public String getAttachmentCount() {
		if (_attachmentCountSupplier != null) {
			attachmentCount = _attachmentCountSupplier.get();

			_attachmentCountSupplier = null;
		}

		return attachmentCount;
	}

	public void setAttachmentCount(String attachmentCount) {
		this.attachmentCount = attachmentCount;

		_attachmentCountSupplier = null;
	}

	@JsonIgnore
	public void setAttachmentCount(
		UnsafeSupplier<String, Exception> attachmentCountUnsafeSupplier) {

		_attachmentCountSupplier = () -> {
			try {
				return attachmentCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String attachmentCount;

	@JsonIgnore
	private Supplier<String> _attachmentCountSupplier;

	@Schema
	@Valid
	public Attachments getAttachments() {
		if (_attachmentsSupplier != null) {
			attachments = _attachmentsSupplier.get();

			_attachmentsSupplier = null;
		}

		return attachments;
	}

	public void setAttachments(Attachments attachments) {
		this.attachments = attachments;

		_attachmentsSupplier = null;
	}

	@JsonIgnore
	public void setAttachments(
		UnsafeSupplier<Attachments, Exception> attachmentsUnsafeSupplier) {

		_attachmentsSupplier = () -> {
			try {
				return attachmentsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Attachments attachments;

	@JsonIgnore
	private Supplier<Attachments> _attachmentsSupplier;

	@Schema(example = "")
	public String getBreachDateTime() {
		if (_breachDateTimeSupplier != null) {
			breachDateTime = _breachDateTimeSupplier.get();

			_breachDateTimeSupplier = null;
		}

		return breachDateTime;
	}

	public void setBreachDateTime(String breachDateTime) {
		this.breachDateTime = breachDateTime;

		_breachDateTimeSupplier = null;
	}

	@JsonIgnore
	public void setBreachDateTime(
		UnsafeSupplier<String, Exception> breachDateTimeUnsafeSupplier) {

		_breachDateTimeSupplier = () -> {
			try {
				return breachDateTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String breachDateTime;

	@JsonIgnore
	private Supplier<String> _breachDateTimeSupplier;

	@Schema(example = "")
	public String getBusinessElapsedTime() {
		if (_businessElapsedTimeSupplier != null) {
			businessElapsedTime = _businessElapsedTimeSupplier.get();

			_businessElapsedTimeSupplier = null;
		}

		return businessElapsedTime;
	}

	public void setBusinessElapsedTime(String businessElapsedTime) {
		this.businessElapsedTime = businessElapsedTime;

		_businessElapsedTimeSupplier = null;
	}

	@JsonIgnore
	public void setBusinessElapsedTime(
		UnsafeSupplier<String, Exception> businessElapsedTimeUnsafeSupplier) {

		_businessElapsedTimeSupplier = () -> {
			try {
				return businessElapsedTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessElapsedTime;

	@JsonIgnore
	private Supplier<String> _businessElapsedTimeSupplier;

	@Schema(example = "")
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema(example = "")
	public String getCategory() {
		if (_categorySupplier != null) {
			category = _categorySupplier.get();

			_categorySupplier = null;
		}

		return category;
	}

	public void setCategory(String category) {
		this.category = category;

		_categorySupplier = null;
	}

	@JsonIgnore
	public void setCategory(
		UnsafeSupplier<String, Exception> categoryUnsafeSupplier) {

		_categorySupplier = () -> {
			try {
				return categoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String category;

	@JsonIgnore
	private Supplier<String> _categorySupplier;

	@Schema(example = "internal/external")
	public String getChannel() {
		if (_channelSupplier != null) {
			channel = _channelSupplier.get();

			_channelSupplier = null;
		}

		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;

		_channelSupplier = null;
	}

	@JsonIgnore
	public void setChannel(
		UnsafeSupplier<String, Exception> channelUnsafeSupplier) {

		_channelSupplier = () -> {
			try {
				return channelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String channel;

	@JsonIgnore
	private Supplier<String> _channelSupplier;

	@Schema(example = "")
	public String getCompanyName() {
		if (_companyNameSupplier != null) {
			companyName = _companyNameSupplier.get();

			_companyNameSupplier = null;
		}

		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;

		_companyNameSupplier = null;
	}

	@JsonIgnore
	public void setCompanyName(
		UnsafeSupplier<String, Exception> companyNameUnsafeSupplier) {

		_companyNameSupplier = () -> {
			try {
				return companyNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String companyName;

	@JsonIgnore
	private Supplier<String> _companyNameSupplier;

	@Schema(example = "")
	public String getCountryCode() {
		if (_countryCodeSupplier != null) {
			countryCode = _countryCodeSupplier.get();

			_countryCodeSupplier = null;
		}

		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;

		_countryCodeSupplier = null;
	}

	@JsonIgnore
	public void setCountryCode(
		UnsafeSupplier<String, Exception> countryCodeUnsafeSupplier) {

		_countryCodeSupplier = () -> {
			try {
				return countryCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String countryCode;

	@JsonIgnore
	private Supplier<String> _countryCodeSupplier;

	@Schema(example = "")
	public String getCustomerOutageStartDate() {
		if (_customerOutageStartDateSupplier != null) {
			customerOutageStartDate = _customerOutageStartDateSupplier.get();

			_customerOutageStartDateSupplier = null;
		}

		return customerOutageStartDate;
	}

	public void setCustomerOutageStartDate(String customerOutageStartDate) {
		this.customerOutageStartDate = customerOutageStartDate;

		_customerOutageStartDateSupplier = null;
	}

	@JsonIgnore
	public void setCustomerOutageStartDate(
		UnsafeSupplier<String, Exception>
			customerOutageStartDateUnsafeSupplier) {

		_customerOutageStartDateSupplier = () -> {
			try {
				return customerOutageStartDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerOutageStartDate;

	@JsonIgnore
	private Supplier<String> _customerOutageStartDateSupplier;

	@Schema(example = "")
	public String getCustomerRef() {
		if (_customerRefSupplier != null) {
			customerRef = _customerRefSupplier.get();

			_customerRefSupplier = null;
		}

		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;

		_customerRefSupplier = null;
	}

	@JsonIgnore
	public void setCustomerRef(
		UnsafeSupplier<String, Exception> customerRefUnsafeSupplier) {

		_customerRefSupplier = () -> {
			try {
				return customerRefUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerRef;

	@JsonIgnore
	private Supplier<String> _customerRefSupplier;

	@Schema(example = "")
	public String getDateRaised() {
		if (_dateRaisedSupplier != null) {
			dateRaised = _dateRaisedSupplier.get();

			_dateRaisedSupplier = null;
		}

		return dateRaised;
	}

	public void setDateRaised(String dateRaised) {
		this.dateRaised = dateRaised;

		_dateRaisedSupplier = null;
	}

	@JsonIgnore
	public void setDateRaised(
		UnsafeSupplier<String, Exception> dateRaisedUnsafeSupplier) {

		_dateRaisedSupplier = () -> {
			try {
				return dateRaisedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dateRaised;

	@JsonIgnore
	private Supplier<String> _dateRaisedSupplier;

	@Schema(example = "")
	public String getDescription() {
		if (_descriptionSupplier != null) {
			description = _descriptionSupplier.get();

			_descriptionSupplier = null;
		}

		return description;
	}

	public void setDescription(String description) {
		this.description = description;

		_descriptionSupplier = null;
	}

	@JsonIgnore
	public void setDescription(
		UnsafeSupplier<String, Exception> descriptionUnsafeSupplier) {

		_descriptionSupplier = () -> {
			try {
				return descriptionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String description;

	@JsonIgnore
	private Supplier<String> _descriptionSupplier;

	@Schema
	@Valid
	public EscalationDetail[] getEscalationDetails() {
		if (_escalationDetailsSupplier != null) {
			escalationDetails = _escalationDetailsSupplier.get();

			_escalationDetailsSupplier = null;
		}

		return escalationDetails;
	}

	public void setEscalationDetails(EscalationDetail[] escalationDetails) {
		this.escalationDetails = escalationDetails;

		_escalationDetailsSupplier = null;
	}

	@JsonIgnore
	public void setEscalationDetails(
		UnsafeSupplier<EscalationDetail[], Exception>
			escalationDetailsUnsafeSupplier) {

		_escalationDetailsSupplier = () -> {
			try {
				return escalationDetailsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected EscalationDetail[] escalationDetails;

	@JsonIgnore
	private Supplier<EscalationDetail[]> _escalationDetailsSupplier;

	@Schema(example = "test value")
	public String getEscalationStatus() {
		if (_escalationStatusSupplier != null) {
			escalationStatus = _escalationStatusSupplier.get();

			_escalationStatusSupplier = null;
		}

		return escalationStatus;
	}

	public void setEscalationStatus(String escalationStatus) {
		this.escalationStatus = escalationStatus;

		_escalationStatusSupplier = null;
	}

	@JsonIgnore
	public void setEscalationStatus(
		UnsafeSupplier<String, Exception> escalationStatusUnsafeSupplier) {

		_escalationStatusSupplier = () -> {
			try {
				return escalationStatusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String escalationStatus;

	@JsonIgnore
	private Supplier<String> _escalationStatusSupplier;

	@Schema
	@Valid
	public Escalation[] getEscalations() {
		if (_escalationsSupplier != null) {
			escalations = _escalationsSupplier.get();

			_escalationsSupplier = null;
		}

		return escalations;
	}

	public void setEscalations(Escalation[] escalations) {
		this.escalations = escalations;

		_escalationsSupplier = null;
	}

	@JsonIgnore
	public void setEscalations(
		UnsafeSupplier<Escalation[], Exception> escalationsUnsafeSupplier) {

		_escalationsSupplier = () -> {
			try {
				return escalationsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Escalation[] escalations;

	@JsonIgnore
	private Supplier<Escalation[]> _escalationsSupplier;

	@Schema(example = "")
	public String getHasBreached() {
		if (_hasBreachedSupplier != null) {
			hasBreached = _hasBreachedSupplier.get();

			_hasBreachedSupplier = null;
		}

		return hasBreached;
	}

	public void setHasBreached(String hasBreached) {
		this.hasBreached = hasBreached;

		_hasBreachedSupplier = null;
	}

	@JsonIgnore
	public void setHasBreached(
		UnsafeSupplier<String, Exception> hasBreachedUnsafeSupplier) {

		_hasBreachedSupplier = () -> {
			try {
				return hasBreachedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String hasBreached;

	@JsonIgnore
	private Supplier<String> _hasBreachedSupplier;

	@Schema(example = "")
	public String getImpact() {
		if (_impactSupplier != null) {
			impact = _impactSupplier.get();

			_impactSupplier = null;
		}

		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;

		_impactSupplier = null;
	}

	@JsonIgnore
	public void setImpact(
		UnsafeSupplier<String, Exception> impactUnsafeSupplier) {

		_impactSupplier = () -> {
			try {
				return impactUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String impact;

	@JsonIgnore
	private Supplier<String> _impactSupplier;

	@Schema(example = "")
	public String getInvVariableCount() {
		if (_invVariableCountSupplier != null) {
			invVariableCount = _invVariableCountSupplier.get();

			_invVariableCountSupplier = null;
		}

		return invVariableCount;
	}

	public void setInvVariableCount(String invVariableCount) {
		this.invVariableCount = invVariableCount;

		_invVariableCountSupplier = null;
	}

	@JsonIgnore
	public void setInvVariableCount(
		UnsafeSupplier<String, Exception> invVariableCountUnsafeSupplier) {

		_invVariableCountSupplier = () -> {
			try {
				return invVariableCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String invVariableCount;

	@JsonIgnore
	private Supplier<String> _invVariableCountSupplier;

	@Schema
	@Valid
	public InventoryDetails getInventoryDetails() {
		if (_inventoryDetailsSupplier != null) {
			inventoryDetails = _inventoryDetailsSupplier.get();

			_inventoryDetailsSupplier = null;
		}

		return inventoryDetails;
	}

	public void setInventoryDetails(InventoryDetails inventoryDetails) {
		this.inventoryDetails = inventoryDetails;

		_inventoryDetailsSupplier = null;
	}

	@JsonIgnore
	public void setInventoryDetails(
		UnsafeSupplier<InventoryDetails, Exception>
			inventoryDetailsUnsafeSupplier) {

		_inventoryDetailsSupplier = () -> {
			try {
				return inventoryDetailsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected InventoryDetails inventoryDetails;

	@JsonIgnore
	private Supplier<InventoryDetails> _inventoryDetailsSupplier;

	@Schema(example = "")
	public String getInventoryItem() {
		if (_inventoryItemSupplier != null) {
			inventoryItem = _inventoryItemSupplier.get();

			_inventoryItemSupplier = null;
		}

		return inventoryItem;
	}

	public void setInventoryItem(String inventoryItem) {
		this.inventoryItem = inventoryItem;

		_inventoryItemSupplier = null;
	}

	@JsonIgnore
	public void setInventoryItem(
		UnsafeSupplier<String, Exception> inventoryItemUnsafeSupplier) {

		_inventoryItemSupplier = () -> {
			try {
				return inventoryItemUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String inventoryItem;

	@JsonIgnore
	private Supplier<String> _inventoryItemSupplier;

	@Schema(example = "")
	public String getLastUpdatedOn() {
		if (_lastUpdatedOnSupplier != null) {
			lastUpdatedOn = _lastUpdatedOnSupplier.get();

			_lastUpdatedOnSupplier = null;
		}

		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;

		_lastUpdatedOnSupplier = null;
	}

	@JsonIgnore
	public void setLastUpdatedOn(
		UnsafeSupplier<String, Exception> lastUpdatedOnUnsafeSupplier) {

		_lastUpdatedOnSupplier = () -> {
			try {
				return lastUpdatedOnUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lastUpdatedOn;

	@JsonIgnore
	private Supplier<String> _lastUpdatedOnSupplier;

	@Schema(example = "")
	public String getLongDesc() {
		if (_longDescSupplier != null) {
			longDesc = _longDescSupplier.get();

			_longDescSupplier = null;
		}

		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;

		_longDescSupplier = null;
	}

	@JsonIgnore
	public void setLongDesc(
		UnsafeSupplier<String, Exception> longDescUnsafeSupplier) {

		_longDescSupplier = () -> {
			try {
				return longDescUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String longDesc;

	@JsonIgnore
	private Supplier<String> _longDescSupplier;

	@Schema(example = "")
	public String getNextCommunication() {
		if (_nextCommunicationSupplier != null) {
			nextCommunication = _nextCommunicationSupplier.get();

			_nextCommunicationSupplier = null;
		}

		return nextCommunication;
	}

	public void setNextCommunication(String nextCommunication) {
		this.nextCommunication = nextCommunication;

		_nextCommunicationSupplier = null;
	}

	@JsonIgnore
	public void setNextCommunication(
		UnsafeSupplier<String, Exception> nextCommunicationUnsafeSupplier) {

		_nextCommunicationSupplier = () -> {
			try {
				return nextCommunicationUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String nextCommunication;

	@JsonIgnore
	private Supplier<String> _nextCommunicationSupplier;

	@Schema(example = "")
	public String getNextUpdate() {
		if (_nextUpdateSupplier != null) {
			nextUpdate = _nextUpdateSupplier.get();

			_nextUpdateSupplier = null;
		}

		return nextUpdate;
	}

	public void setNextUpdate(String nextUpdate) {
		this.nextUpdate = nextUpdate;

		_nextUpdateSupplier = null;
	}

	@JsonIgnore
	public void setNextUpdate(
		UnsafeSupplier<String, Exception> nextUpdateUnsafeSupplier) {

		_nextUpdateSupplier = () -> {
			try {
				return nextUpdateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String nextUpdate;

	@JsonIgnore
	private Supplier<String> _nextUpdateSupplier;

	@Schema(example = "")
	public String getNoteCount() {
		if (_noteCountSupplier != null) {
			noteCount = _noteCountSupplier.get();

			_noteCountSupplier = null;
		}

		return noteCount;
	}

	public void setNoteCount(String noteCount) {
		this.noteCount = noteCount;

		_noteCountSupplier = null;
	}

	@JsonIgnore
	public void setNoteCount(
		UnsafeSupplier<String, Exception> noteCountUnsafeSupplier) {

		_noteCountSupplier = () -> {
			try {
				return noteCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String noteCount;

	@JsonIgnore
	private Supplier<String> _noteCountSupplier;

	@Schema
	@Valid
	public Notes getNotes() {
		if (_notesSupplier != null) {
			notes = _notesSupplier.get();

			_notesSupplier = null;
		}

		return notes;
	}

	public void setNotes(Notes notes) {
		this.notes = notes;

		_notesSupplier = null;
	}

	@JsonIgnore
	public void setNotes(UnsafeSupplier<Notes, Exception> notesUnsafeSupplier) {
		_notesSupplier = () -> {
			try {
				return notesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Notes notes;

	@JsonIgnore
	private Supplier<Notes> _notesSupplier;

	@Schema(example = "")
	public String getParentIncident() {
		if (_parentIncidentSupplier != null) {
			parentIncident = _parentIncidentSupplier.get();

			_parentIncidentSupplier = null;
		}

		return parentIncident;
	}

	public void setParentIncident(String parentIncident) {
		this.parentIncident = parentIncident;

		_parentIncidentSupplier = null;
	}

	@JsonIgnore
	public void setParentIncident(
		UnsafeSupplier<String, Exception> parentIncidentUnsafeSupplier) {

		_parentIncidentSupplier = () -> {
			try {
				return parentIncidentUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String parentIncident;

	@JsonIgnore
	private Supplier<String> _parentIncidentSupplier;

	@Schema(example = "")
	public String getPriority() {
		if (_prioritySupplier != null) {
			priority = _prioritySupplier.get();

			_prioritySupplier = null;
		}

		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;

		_prioritySupplier = null;
	}

	@JsonIgnore
	public void setPriority(
		UnsafeSupplier<String, Exception> priorityUnsafeSupplier) {

		_prioritySupplier = () -> {
			try {
				return priorityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priority;

	@JsonIgnore
	private Supplier<String> _prioritySupplier;

	@Schema(example = "")
	public String getPriorityLabel() {
		if (_priorityLabelSupplier != null) {
			priorityLabel = _priorityLabelSupplier.get();

			_priorityLabelSupplier = null;
		}

		return priorityLabel;
	}

	public void setPriorityLabel(String priorityLabel) {
		this.priorityLabel = priorityLabel;

		_priorityLabelSupplier = null;
	}

	@JsonIgnore
	public void setPriorityLabel(
		UnsafeSupplier<String, Exception> priorityLabelUnsafeSupplier) {

		_priorityLabelSupplier = () -> {
			try {
				return priorityLabelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priorityLabel;

	@JsonIgnore
	private Supplier<String> _priorityLabelSupplier;

	@Schema(example = "")
	public String getRaisedBy() {
		if (_raisedBySupplier != null) {
			raisedBy = _raisedBySupplier.get();

			_raisedBySupplier = null;
		}

		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;

		_raisedBySupplier = null;
	}

	@JsonIgnore
	public void setRaisedBy(
		UnsafeSupplier<String, Exception> raisedByUnsafeSupplier) {

		_raisedBySupplier = () -> {
			try {
				return raisedByUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String raisedBy;

	@JsonIgnore
	private Supplier<String> _raisedBySupplier;

	@Schema(example = "")
	public String getReference() {
		if (_referenceSupplier != null) {
			reference = _referenceSupplier.get();

			_referenceSupplier = null;
		}

		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;

		_referenceSupplier = null;
	}

	@JsonIgnore
	public void setReference(
		UnsafeSupplier<String, Exception> referenceUnsafeSupplier) {

		_referenceSupplier = () -> {
			try {
				return referenceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String reference;

	@JsonIgnore
	private Supplier<String> _referenceSupplier;

	@Schema(example = "")
	public String getSlaDueIn() {
		if (_slaDueInSupplier != null) {
			slaDueIn = _slaDueInSupplier.get();

			_slaDueInSupplier = null;
		}

		return slaDueIn;
	}

	public void setSlaDueIn(String slaDueIn) {
		this.slaDueIn = slaDueIn;

		_slaDueInSupplier = null;
	}

	@JsonIgnore
	public void setSlaDueIn(
		UnsafeSupplier<String, Exception> slaDueInUnsafeSupplier) {

		_slaDueInSupplier = () -> {
			try {
				return slaDueInUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String slaDueIn;

	@JsonIgnore
	private Supplier<String> _slaDueInSupplier;

	@Schema(example = "")
	public String getSlaPercentage() {
		if (_slaPercentageSupplier != null) {
			slaPercentage = _slaPercentageSupplier.get();

			_slaPercentageSupplier = null;
		}

		return slaPercentage;
	}

	public void setSlaPercentage(String slaPercentage) {
		this.slaPercentage = slaPercentage;

		_slaPercentageSupplier = null;
	}

	@JsonIgnore
	public void setSlaPercentage(
		UnsafeSupplier<String, Exception> slaPercentageUnsafeSupplier) {

		_slaPercentageSupplier = () -> {
			try {
				return slaPercentageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String slaPercentage;

	@JsonIgnore
	private Supplier<String> _slaPercentageSupplier;

	@Schema(example = "")
	public String getSlaRemaining() {
		if (_slaRemainingSupplier != null) {
			slaRemaining = _slaRemainingSupplier.get();

			_slaRemainingSupplier = null;
		}

		return slaRemaining;
	}

	public void setSlaRemaining(String slaRemaining) {
		this.slaRemaining = slaRemaining;

		_slaRemainingSupplier = null;
	}

	@JsonIgnore
	public void setSlaRemaining(
		UnsafeSupplier<String, Exception> slaRemainingUnsafeSupplier) {

		_slaRemainingSupplier = () -> {
			try {
				return slaRemainingUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String slaRemaining;

	@JsonIgnore
	private Supplier<String> _slaRemainingSupplier;

	@Schema(example = "")
	public String getSlaStartDateTime() {
		if (_slaStartDateTimeSupplier != null) {
			slaStartDateTime = _slaStartDateTimeSupplier.get();

			_slaStartDateTimeSupplier = null;
		}

		return slaStartDateTime;
	}

	public void setSlaStartDateTime(String slaStartDateTime) {
		this.slaStartDateTime = slaStartDateTime;

		_slaStartDateTimeSupplier = null;
	}

	@JsonIgnore
	public void setSlaStartDateTime(
		UnsafeSupplier<String, Exception> slaStartDateTimeUnsafeSupplier) {

		_slaStartDateTimeSupplier = () -> {
			try {
				return slaStartDateTimeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String slaStartDateTime;

	@JsonIgnore
	private Supplier<String> _slaStartDateTimeSupplier;

	@Schema(example = "")
	public String getSlaStatus() {
		if (_slaStatusSupplier != null) {
			slaStatus = _slaStatusSupplier.get();

			_slaStatusSupplier = null;
		}

		return slaStatus;
	}

	public void setSlaStatus(String slaStatus) {
		this.slaStatus = slaStatus;

		_slaStatusSupplier = null;
	}

	@JsonIgnore
	public void setSlaStatus(
		UnsafeSupplier<String, Exception> slaStatusUnsafeSupplier) {

		_slaStatusSupplier = () -> {
			try {
				return slaStatusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String slaStatus;

	@JsonIgnore
	private Supplier<String> _slaStatusSupplier;

	@Schema(example = "")
	public String getState() {
		if (_stateSupplier != null) {
			state = _stateSupplier.get();

			_stateSupplier = null;
		}

		return state;
	}

	public void setState(String state) {
		this.state = state;

		_stateSupplier = null;
	}

	@JsonIgnore
	public void setState(
		UnsafeSupplier<String, Exception> stateUnsafeSupplier) {

		_stateSupplier = () -> {
			try {
				return stateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String state;

	@JsonIgnore
	private Supplier<String> _stateSupplier;

	@Schema(example = "")
	public String getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@JsonIgnore
	private Supplier<String> _statusSupplier;

	@Schema(example = "")
	public String getSubCategory() {
		if (_subCategorySupplier != null) {
			subCategory = _subCategorySupplier.get();

			_subCategorySupplier = null;
		}

		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;

		_subCategorySupplier = null;
	}

	@JsonIgnore
	public void setSubCategory(
		UnsafeSupplier<String, Exception> subCategoryUnsafeSupplier) {

		_subCategorySupplier = () -> {
			try {
				return subCategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String subCategory;

	@JsonIgnore
	private Supplier<String> _subCategorySupplier;

	@Schema(example = "")
	public String getSystemId() {
		if (_systemIdSupplier != null) {
			systemId = _systemIdSupplier.get();

			_systemIdSupplier = null;
		}

		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;

		_systemIdSupplier = null;
	}

	@JsonIgnore
	public void setSystemId(
		UnsafeSupplier<String, Exception> systemIdUnsafeSupplier) {

		_systemIdSupplier = () -> {
			try {
				return systemIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String systemId;

	@JsonIgnore
	private Supplier<String> _systemIdSupplier;

	@Schema(example = "")
	public String getTeamName() {
		if (_teamNameSupplier != null) {
			teamName = _teamNameSupplier.get();

			_teamNameSupplier = null;
		}

		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;

		_teamNameSupplier = null;
	}

	@JsonIgnore
	public void setTeamName(
		UnsafeSupplier<String, Exception> teamNameUnsafeSupplier) {

		_teamNameSupplier = () -> {
			try {
				return teamNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String teamName;

	@JsonIgnore
	private Supplier<String> _teamNameSupplier;

	@Schema(example = "")
	public String getTotalCount() {
		if (_totalCountSupplier != null) {
			totalCount = _totalCountSupplier.get();

			_totalCountSupplier = null;
		}

		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;

		_totalCountSupplier = null;
	}

	@JsonIgnore
	public void setTotalCount(
		UnsafeSupplier<String, Exception> totalCountUnsafeSupplier) {

		_totalCountSupplier = () -> {
			try {
				return totalCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String totalCount;

	@JsonIgnore
	private Supplier<String> _totalCountSupplier;

	@Schema(example = "")
	public String getUrgency() {
		if (_urgencySupplier != null) {
			urgency = _urgencySupplier.get();

			_urgencySupplier = null;
		}

		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;

		_urgencySupplier = null;
	}

	@JsonIgnore
	public void setUrgency(
		UnsafeSupplier<String, Exception> urgencyUnsafeSupplier) {

		_urgencySupplier = () -> {
			try {
				return urgencyUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String urgency;

	@JsonIgnore
	private Supplier<String> _urgencySupplier;

	@Schema(example = "")
	public String getVariableCount() {
		if (_variableCountSupplier != null) {
			variableCount = _variableCountSupplier.get();

			_variableCountSupplier = null;
		}

		return variableCount;
	}

	public void setVariableCount(String variableCount) {
		this.variableCount = variableCount;

		_variableCountSupplier = null;
	}

	@JsonIgnore
	public void setVariableCount(
		UnsafeSupplier<String, Exception> variableCountUnsafeSupplier) {

		_variableCountSupplier = () -> {
			try {
				return variableCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String variableCount;

	@JsonIgnore
	private Supplier<String> _variableCountSupplier;

	@Schema
	@Valid
	public Variable[] getVariables() {
		if (_variablesSupplier != null) {
			variables = _variablesSupplier.get();

			_variablesSupplier = null;
		}

		return variables;
	}

	public void setVariables(Variable[] variables) {
		this.variables = variables;

		_variablesSupplier = null;
	}

	@JsonIgnore
	public void setVariables(
		UnsafeSupplier<Variable[], Exception> variablesUnsafeSupplier) {

		_variablesSupplier = () -> {
			try {
				return variablesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Variable[] variables;

	@JsonIgnore
	private Supplier<Variable[]> _variablesSupplier;

	@Schema(example = "")
	public String getWatchFlag() {
		if (_watchFlagSupplier != null) {
			watchFlag = _watchFlagSupplier.get();

			_watchFlagSupplier = null;
		}

		return watchFlag;
	}

	public void setWatchFlag(String watchFlag) {
		this.watchFlag = watchFlag;

		_watchFlagSupplier = null;
	}

	@JsonIgnore
	public void setWatchFlag(
		UnsafeSupplier<String, Exception> watchFlagUnsafeSupplier) {

		_watchFlagSupplier = () -> {
			try {
				return watchFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String watchFlag;

	@JsonIgnore
	private Supplier<String> _watchFlagSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetIncident)) {
			return false;
		}

		GetIncident getIncident = (GetIncident)object;

		return Objects.equals(toString(), getIncident.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String attachmentCount = getAttachmentCount();

		if (attachmentCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"attachmentCount\": ");

			sb.append("\"");

			sb.append(_escape(attachmentCount));

			sb.append("\"");
		}

		Attachments attachments = getAttachments();

		if (attachments != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"attachments\": ");

			sb.append(String.valueOf(attachments));
		}

		String breachDateTime = getBreachDateTime();

		if (breachDateTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"breachDateTime\": ");

			sb.append("\"");

			sb.append(_escape(breachDateTime));

			sb.append("\"");
		}

		String businessElapsedTime = getBusinessElapsedTime();

		if (businessElapsedTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessElapsedTime\": ");

			sb.append("\"");

			sb.append(_escape(businessElapsedTime));

			sb.append("\"");
		}

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String category = getCategory();

		if (category != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"category\": ");

			sb.append("\"");

			sb.append(_escape(category));

			sb.append("\"");
		}

		String channel = getChannel();

		if (channel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"channel\": ");

			sb.append("\"");

			sb.append(_escape(channel));

			sb.append("\"");
		}

		String companyName = getCompanyName();

		if (companyName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"companyName\": ");

			sb.append("\"");

			sb.append(_escape(companyName));

			sb.append("\"");
		}

		String countryCode = getCountryCode();

		if (countryCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryCode\": ");

			sb.append("\"");

			sb.append(_escape(countryCode));

			sb.append("\"");
		}

		String customerOutageStartDate = getCustomerOutageStartDate();

		if (customerOutageStartDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerOutageStartDate\": ");

			sb.append("\"");

			sb.append(_escape(customerOutageStartDate));

			sb.append("\"");
		}

		String customerRef = getCustomerRef();

		if (customerRef != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerRef\": ");

			sb.append("\"");

			sb.append(_escape(customerRef));

			sb.append("\"");
		}

		String dateRaised = getDateRaised();

		if (dateRaised != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateRaised\": ");

			sb.append("\"");

			sb.append(_escape(dateRaised));

			sb.append("\"");
		}

		String description = getDescription();

		if (description != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(description));

			sb.append("\"");
		}

		EscalationDetail[] escalationDetails = getEscalationDetails();

		if (escalationDetails != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationDetails\": ");

			sb.append("[");

			for (int i = 0; i < escalationDetails.length; i++) {
				sb.append(String.valueOf(escalationDetails[i]));

				if ((i + 1) < escalationDetails.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String escalationStatus = getEscalationStatus();

		if (escalationStatus != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalationStatus\": ");

			sb.append("\"");

			sb.append(_escape(escalationStatus));

			sb.append("\"");
		}

		Escalation[] escalations = getEscalations();

		if (escalations != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalations\": ");

			sb.append("[");

			for (int i = 0; i < escalations.length; i++) {
				sb.append(String.valueOf(escalations[i]));

				if ((i + 1) < escalations.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String hasBreached = getHasBreached();

		if (hasBreached != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"hasBreached\": ");

			sb.append("\"");

			sb.append(_escape(hasBreached));

			sb.append("\"");
		}

		String impact = getImpact();

		if (impact != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"impact\": ");

			sb.append("\"");

			sb.append(_escape(impact));

			sb.append("\"");
		}

		String invVariableCount = getInvVariableCount();

		if (invVariableCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"invVariableCount\": ");

			sb.append("\"");

			sb.append(_escape(invVariableCount));

			sb.append("\"");
		}

		InventoryDetails inventoryDetails = getInventoryDetails();

		if (inventoryDetails != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"inventoryDetails\": ");

			sb.append(String.valueOf(inventoryDetails));
		}

		String inventoryItem = getInventoryItem();

		if (inventoryItem != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"inventoryItem\": ");

			sb.append("\"");

			sb.append(_escape(inventoryItem));

			sb.append("\"");
		}

		String lastUpdatedOn = getLastUpdatedOn();

		if (lastUpdatedOn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lastUpdatedOn\": ");

			sb.append("\"");

			sb.append(_escape(lastUpdatedOn));

			sb.append("\"");
		}

		String longDesc = getLongDesc();

		if (longDesc != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"longDesc\": ");

			sb.append("\"");

			sb.append(_escape(longDesc));

			sb.append("\"");
		}

		String nextCommunication = getNextCommunication();

		if (nextCommunication != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"nextCommunication\": ");

			sb.append("\"");

			sb.append(_escape(nextCommunication));

			sb.append("\"");
		}

		String nextUpdate = getNextUpdate();

		if (nextUpdate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"nextUpdate\": ");

			sb.append("\"");

			sb.append(_escape(nextUpdate));

			sb.append("\"");
		}

		String noteCount = getNoteCount();

		if (noteCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"noteCount\": ");

			sb.append("\"");

			sb.append(_escape(noteCount));

			sb.append("\"");
		}

		Notes notes = getNotes();

		if (notes != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"notes\": ");

			sb.append(String.valueOf(notes));
		}

		String parentIncident = getParentIncident();

		if (parentIncident != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"parentIncident\": ");

			sb.append("\"");

			sb.append(_escape(parentIncident));

			sb.append("\"");
		}

		String priority = getPriority();

		if (priority != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priority\": ");

			sb.append("\"");

			sb.append(_escape(priority));

			sb.append("\"");
		}

		String priorityLabel = getPriorityLabel();

		if (priorityLabel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priorityLabel\": ");

			sb.append("\"");

			sb.append(_escape(priorityLabel));

			sb.append("\"");
		}

		String raisedBy = getRaisedBy();

		if (raisedBy != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"raisedBy\": ");

			sb.append("\"");

			sb.append(_escape(raisedBy));

			sb.append("\"");
		}

		String reference = getReference();

		if (reference != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"reference\": ");

			sb.append("\"");

			sb.append(_escape(reference));

			sb.append("\"");
		}

		String slaDueIn = getSlaDueIn();

		if (slaDueIn != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"slaDueIn\": ");

			sb.append("\"");

			sb.append(_escape(slaDueIn));

			sb.append("\"");
		}

		String slaPercentage = getSlaPercentage();

		if (slaPercentage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"slaPercentage\": ");

			sb.append("\"");

			sb.append(_escape(slaPercentage));

			sb.append("\"");
		}

		String slaRemaining = getSlaRemaining();

		if (slaRemaining != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"slaRemaining\": ");

			sb.append("\"");

			sb.append(_escape(slaRemaining));

			sb.append("\"");
		}

		String slaStartDateTime = getSlaStartDateTime();

		if (slaStartDateTime != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"slaStartDateTime\": ");

			sb.append("\"");

			sb.append(_escape(slaStartDateTime));

			sb.append("\"");
		}

		String slaStatus = getSlaStatus();

		if (slaStatus != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"slaStatus\": ");

			sb.append("\"");

			sb.append(_escape(slaStatus));

			sb.append("\"");
		}

		String state = getState();

		if (state != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"state\": ");

			sb.append("\"");

			sb.append(_escape(state));

			sb.append("\"");
		}

		String status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		String subCategory = getSubCategory();

		if (subCategory != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"subCategory\": ");

			sb.append("\"");

			sb.append(_escape(subCategory));

			sb.append("\"");
		}

		String systemId = getSystemId();

		if (systemId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"systemId\": ");

			sb.append("\"");

			sb.append(_escape(systemId));

			sb.append("\"");
		}

		String teamName = getTeamName();

		if (teamName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"teamName\": ");

			sb.append("\"");

			sb.append(_escape(teamName));

			sb.append("\"");
		}

		String totalCount = getTotalCount();

		if (totalCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"totalCount\": ");

			sb.append("\"");

			sb.append(_escape(totalCount));

			sb.append("\"");
		}

		String urgency = getUrgency();

		if (urgency != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"urgency\": ");

			sb.append("\"");

			sb.append(_escape(urgency));

			sb.append("\"");
		}

		String variableCount = getVariableCount();

		if (variableCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"variableCount\": ");

			sb.append("\"");

			sb.append(_escape(variableCount));

			sb.append("\"");
		}

		Variable[] variables = getVariables();

		if (variables != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"variables\": ");

			sb.append("[");

			for (int i = 0; i < variables.length; i++) {
				sb.append(String.valueOf(variables[i]));

				if ((i + 1) < variables.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String watchFlag = getWatchFlag();

		if (watchFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"watchFlag\": ");

			sb.append("\"");

			sb.append(_escape(watchFlag));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.GetIncident",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}