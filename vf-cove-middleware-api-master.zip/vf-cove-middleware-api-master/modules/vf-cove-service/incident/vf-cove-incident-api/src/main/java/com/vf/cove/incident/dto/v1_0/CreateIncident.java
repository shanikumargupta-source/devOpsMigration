package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("CreateIncident")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CreateIncident")
public class CreateIncident implements Serializable {

	public static CreateIncident toDTO(String json) {
		return ObjectMapperUtil.readValue(CreateIncident.class, json);
	}

	public static CreateIncident unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CreateIncident.class, json);
	}

	@Schema(example = "INC0011473")
	public String getIncidentId() {
		if (_incidentIdSupplier != null) {
			incidentId = _incidentIdSupplier.get();

			_incidentIdSupplier = null;
		}

		return incidentId;
	}

	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;

		_incidentIdSupplier = null;
	}

	@JsonIgnore
	public void setIncidentId(
		UnsafeSupplier<String, Exception> incidentIdUnsafeSupplier) {

		_incidentIdSupplier = () -> {
			try {
				return incidentIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String incidentId;

	@JsonIgnore
	private Supplier<String> _incidentIdSupplier;

	@Schema(example = "82cbfb5ddbb85054d158325c7c9619e7")
	public String getIncidentSystemId() {
		if (_incidentSystemIdSupplier != null) {
			incidentSystemId = _incidentSystemIdSupplier.get();

			_incidentSystemIdSupplier = null;
		}

		return incidentSystemId;
	}

	public void setIncidentSystemId(String incidentSystemId) {
		this.incidentSystemId = incidentSystemId;

		_incidentSystemIdSupplier = null;
	}

	@JsonIgnore
	public void setIncidentSystemId(
		UnsafeSupplier<String, Exception> incidentSystemIdUnsafeSupplier) {

		_incidentSystemIdSupplier = () -> {
			try {
				return incidentSystemIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String incidentSystemId;

	@JsonIgnore
	private Supplier<String> _incidentSystemIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CreateIncident)) {
			return false;
		}

		CreateIncident createIncident = (CreateIncident)object;

		return Objects.equals(toString(), createIncident.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String incidentId = getIncidentId();

		if (incidentId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"incidentId\": ");

			sb.append("\"");

			sb.append(_escape(incidentId));

			sb.append("\"");
		}

		String incidentSystemId = getIncidentSystemId();

		if (incidentSystemId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"incidentSystemId\": ");

			sb.append("\"");

			sb.append(_escape(incidentSystemId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.CreateIncident",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}