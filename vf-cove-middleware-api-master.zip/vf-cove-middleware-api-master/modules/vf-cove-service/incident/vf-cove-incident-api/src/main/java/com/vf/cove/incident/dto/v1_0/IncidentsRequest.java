package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("IncidentsRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "IncidentsRequest")
public class IncidentsRequest implements Serializable {

	public static IncidentsRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(IncidentsRequest.class, json);
	}

	public static IncidentsRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(IncidentsRequest.class, json);
	}

	@Schema(example = "2019-07-03T06:52:31.289Z")
	public String getCurrentDate() {
		if (_currentDateSupplier != null) {
			currentDate = _currentDateSupplier.get();

			_currentDateSupplier = null;
		}

		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;

		_currentDateSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDate(
		UnsafeSupplier<String, Exception> currentDateUnsafeSupplier) {

		_currentDateSupplier = () -> {
			try {
				return currentDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentDate;

	@JsonIgnore
	private Supplier<String> _currentDateSupplier;

	@Schema(example = "42487")
	public String getCustomerId() {
		if (_customerIdSupplier != null) {
			customerId = _customerIdSupplier.get();

			_customerIdSupplier = null;
		}

		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;

		_customerIdSupplier = null;
	}

	@JsonIgnore
	public void setCustomerId(
		UnsafeSupplier<String, Exception> customerIdUnsafeSupplier) {

		_customerIdSupplier = () -> {
			try {
				return customerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerId;

	@JsonIgnore
	private Supplier<String> _customerIdSupplier;

	@Schema
	public String[] getEscalation() {
		if (_escalationSupplier != null) {
			escalation = _escalationSupplier.get();

			_escalationSupplier = null;
		}

		return escalation;
	}

	public void setEscalation(String[] escalation) {
		this.escalation = escalation;

		_escalationSupplier = null;
	}

	@JsonIgnore
	public void setEscalation(
		UnsafeSupplier<String[], Exception> escalationUnsafeSupplier) {

		_escalationSupplier = () -> {
			try {
				return escalationUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] escalation;

	@JsonIgnore
	private Supplier<String[]> _escalationSupplier;

	@Schema(example = "2019-06-03T06:52:32.184Z")
	public String getFromDate() {
		if (_fromDateSupplier != null) {
			fromDate = _fromDateSupplier.get();

			_fromDateSupplier = null;
		}

		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;

		_fromDateSupplier = null;
	}

	@JsonIgnore
	public void setFromDate(
		UnsafeSupplier<String, Exception> fromDateUnsafeSupplier) {

		_fromDateSupplier = () -> {
			try {
				return fromDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fromDate;

	@JsonIgnore
	private Supplier<String> _fromDateSupplier;

	@Schema(example = "3b0d49b8-6c31-4f8c-98e1-baf1c9a039afb")
	public String getMessageId() {
		if (_messageIdSupplier != null) {
			messageId = _messageIdSupplier.get();

			_messageIdSupplier = null;
		}

		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;

		_messageIdSupplier = null;
	}

	@JsonIgnore
	public void setMessageId(
		UnsafeSupplier<String, Exception> messageIdUnsafeSupplier) {

		_messageIdSupplier = () -> {
			try {
				return messageIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String messageId;

	@JsonIgnore
	private Supplier<String> _messageIdSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getOamuserId() {
		if (_oamuserIdSupplier != null) {
			oamuserId = _oamuserIdSupplier.get();

			_oamuserIdSupplier = null;
		}

		return oamuserId;
	}

	public void setOamuserId(String oamuserId) {
		this.oamuserId = oamuserId;

		_oamuserIdSupplier = null;
	}

	@JsonIgnore
	public void setOamuserId(
		UnsafeSupplier<String, Exception> oamuserIdUnsafeSupplier) {

		_oamuserIdSupplier = () -> {
			try {
				return oamuserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String oamuserId;

	@JsonIgnore
	private Supplier<String> _oamuserIdSupplier;

	@Schema(example = "0")
	public Integer getPageIndex() {
		if (_pageIndexSupplier != null) {
			pageIndex = _pageIndexSupplier.get();

			_pageIndexSupplier = null;
		}

		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;

		_pageIndexSupplier = null;
	}

	@JsonIgnore
	public void setPageIndex(
		UnsafeSupplier<Integer, Exception> pageIndexUnsafeSupplier) {

		_pageIndexSupplier = () -> {
			try {
				return pageIndexUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer pageIndex;

	@JsonIgnore
	private Supplier<Integer> _pageIndexSupplier;

	@Schema
	public String[] getPriority() {
		if (_prioritySupplier != null) {
			priority = _prioritySupplier.get();

			_prioritySupplier = null;
		}

		return priority;
	}

	public void setPriority(String[] priority) {
		this.priority = priority;

		_prioritySupplier = null;
	}

	@JsonIgnore
	public void setPriority(
		UnsafeSupplier<String[], Exception> priorityUnsafeSupplier) {

		_prioritySupplier = () -> {
			try {
				return priorityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] priority;

	@JsonIgnore
	private Supplier<String[]> _prioritySupplier;

	@Schema(example = "20")
	public Integer getRecordsPerPage() {
		if (_recordsPerPageSupplier != null) {
			recordsPerPage = _recordsPerPageSupplier.get();

			_recordsPerPageSupplier = null;
		}

		return recordsPerPage;
	}

	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;

		_recordsPerPageSupplier = null;
	}

	@JsonIgnore
	public void setRecordsPerPage(
		UnsafeSupplier<Integer, Exception> recordsPerPageUnsafeSupplier) {

		_recordsPerPageSupplier = () -> {
			try {
				return recordsPerPageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer recordsPerPage;

	@JsonIgnore
	private Supplier<Integer> _recordsPerPageSupplier;

	@Schema
	public String getRequestType() {
		if (_requestTypeSupplier != null) {
			requestType = _requestTypeSupplier.get();

			_requestTypeSupplier = null;
		}

		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;

		_requestTypeSupplier = null;
	}

	@JsonIgnore
	public void setRequestType(
		UnsafeSupplier<String, Exception> requestTypeUnsafeSupplier) {

		_requestTypeSupplier = () -> {
			try {
				return requestTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String requestType;

	@JsonIgnore
	private Supplier<String> _requestTypeSupplier;

	@Schema(example = "")
	public String getSearchType() {
		if (_searchTypeSupplier != null) {
			searchType = _searchTypeSupplier.get();

			_searchTypeSupplier = null;
		}

		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;

		_searchTypeSupplier = null;
	}

	@JsonIgnore
	public void setSearchType(
		UnsafeSupplier<String, Exception> searchTypeUnsafeSupplier) {

		_searchTypeSupplier = () -> {
			try {
				return searchTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchType;

	@JsonIgnore
	private Supplier<String> _searchTypeSupplier;

	@Schema(example = "")
	public String getSearchValue() {
		if (_searchValueSupplier != null) {
			searchValue = _searchValueSupplier.get();

			_searchValueSupplier = null;
		}

		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;

		_searchValueSupplier = null;
	}

	@JsonIgnore
	public void setSearchValue(
		UnsafeSupplier<String, Exception> searchValueUnsafeSupplier) {

		_searchValueSupplier = () -> {
			try {
				return searchValueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchValue;

	@JsonIgnore
	private Supplier<String> _searchValueSupplier;

	@Schema
	@Valid
	public SortOrder[] getSortOrder() {
		if (_sortOrderSupplier != null) {
			sortOrder = _sortOrderSupplier.get();

			_sortOrderSupplier = null;
		}

		return sortOrder;
	}

	public void setSortOrder(SortOrder[] sortOrder) {
		this.sortOrder = sortOrder;

		_sortOrderSupplier = null;
	}

	@JsonIgnore
	public void setSortOrder(
		UnsafeSupplier<SortOrder[], Exception> sortOrderUnsafeSupplier) {

		_sortOrderSupplier = () -> {
			try {
				return sortOrderUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected SortOrder[] sortOrder;

	@JsonIgnore
	private Supplier<SortOrder[]> _sortOrderSupplier;

	@Schema
	public String[] getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String[] status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String[], Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] status;

	@JsonIgnore
	private Supplier<String[]> _statusSupplier;

	@Schema(example = "2019-07-03T06:52:32.184Z")
	public String getToDate() {
		if (_toDateSupplier != null) {
			toDate = _toDateSupplier.get();

			_toDateSupplier = null;
		}

		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;

		_toDateSupplier = null;
	}

	@JsonIgnore
	public void setToDate(
		UnsafeSupplier<String, Exception> toDateUnsafeSupplier) {

		_toDateSupplier = () -> {
			try {
				return toDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String toDate;

	@JsonIgnore
	private Supplier<String> _toDateSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof IncidentsRequest)) {
			return false;
		}

		IncidentsRequest incidentsRequest = (IncidentsRequest)object;

		return Objects.equals(toString(), incidentsRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String currentDate = getCurrentDate();

		if (currentDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDate\": ");

			sb.append("\"");

			sb.append(_escape(currentDate));

			sb.append("\"");
		}

		String customerId = getCustomerId();

		if (customerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerId\": ");

			sb.append("\"");

			sb.append(_escape(customerId));

			sb.append("\"");
		}

		String[] escalation = getEscalation();

		if (escalation != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"escalation\": ");

			sb.append("[");

			for (int i = 0; i < escalation.length; i++) {
				sb.append("\"");

				sb.append(_escape(escalation[i]));

				sb.append("\"");

				if ((i + 1) < escalation.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String fromDate = getFromDate();

		if (fromDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fromDate\": ");

			sb.append("\"");

			sb.append(_escape(fromDate));

			sb.append("\"");
		}

		String messageId = getMessageId();

		if (messageId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"messageId\": ");

			sb.append("\"");

			sb.append(_escape(messageId));

			sb.append("\"");
		}

		String oamuserId = getOamuserId();

		if (oamuserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"oamuserId\": ");

			sb.append("\"");

			sb.append(_escape(oamuserId));

			sb.append("\"");
		}

		Integer pageIndex = getPageIndex();

		if (pageIndex != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"pageIndex\": ");

			sb.append(pageIndex);
		}

		String[] priority = getPriority();

		if (priority != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priority\": ");

			sb.append("[");

			for (int i = 0; i < priority.length; i++) {
				sb.append("\"");

				sb.append(_escape(priority[i]));

				sb.append("\"");

				if ((i + 1) < priority.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		Integer recordsPerPage = getRecordsPerPage();

		if (recordsPerPage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"recordsPerPage\": ");

			sb.append(recordsPerPage);
		}

		String requestType = getRequestType();

		if (requestType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"requestType\": ");

			sb.append("\"");

			sb.append(_escape(requestType));

			sb.append("\"");
		}

		String searchType = getSearchType();

		if (searchType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchType\": ");

			sb.append("\"");

			sb.append(_escape(searchType));

			sb.append("\"");
		}

		String searchValue = getSearchValue();

		if (searchValue != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchValue\": ");

			sb.append("\"");

			sb.append(_escape(searchValue));

			sb.append("\"");
		}

		SortOrder[] sortOrder = getSortOrder();

		if (sortOrder != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sortOrder\": ");

			sb.append("[");

			for (int i = 0; i < sortOrder.length; i++) {
				sb.append(String.valueOf(sortOrder[i]));

				if ((i + 1) < sortOrder.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("[");

			for (int i = 0; i < status.length; i++) {
				sb.append("\"");

				sb.append(_escape(status[i]));

				sb.append("\"");

				if ((i + 1) < status.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String toDate = getToDate();

		if (toDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"toDate\": ");

			sb.append("\"");

			sb.append(_escape(toDate));

			sb.append("\"");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.IncidentsRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}