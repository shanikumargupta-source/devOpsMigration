package com.vf.cove.incident.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("CreateIncidentRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CreateIncidentRequest")
public class CreateIncidentRequest implements Serializable {

	public static CreateIncidentRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(CreateIncidentRequest.class, json);
	}

	public static CreateIncidentRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			CreateIncidentRequest.class, json);
	}

	@Schema(example = "82d1974fdb334744bfe97d5a8c96191f")
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema(example = "fbba576cdb0fc780557c5259dc9619ae")
	public String getCategory() {
		if (_categorySupplier != null) {
			category = _categorySupplier.get();

			_categorySupplier = null;
		}

		return category;
	}

	public void setCategory(String category) {
		this.category = category;

		_categorySupplier = null;
	}

	@JsonIgnore
	public void setCategory(
		UnsafeSupplier<String, Exception> categoryUnsafeSupplier) {

		_categorySupplier = () -> {
			try {
				return categoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String category;

	@JsonIgnore
	private Supplier<String> _categorySupplier;

	@Schema(example = "1234234")
	public String getChildCustomerId() {
		if (_childCustomerIdSupplier != null) {
			childCustomerId = _childCustomerIdSupplier.get();

			_childCustomerIdSupplier = null;
		}

		return childCustomerId;
	}

	public void setChildCustomerId(String childCustomerId) {
		this.childCustomerId = childCustomerId;

		_childCustomerIdSupplier = null;
	}

	@JsonIgnore
	public void setChildCustomerId(
		UnsafeSupplier<String, Exception> childCustomerIdUnsafeSupplier) {

		_childCustomerIdSupplier = () -> {
			try {
				return childCustomerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childCustomerId;

	@JsonIgnore
	private Supplier<String> _childCustomerIdSupplier;

	@Schema(example = "<![CDATA[[code]<p>Test Comments</p>[/code]]]>")
	public String getComments() {
		if (_commentsSupplier != null) {
			comments = _commentsSupplier.get();

			_commentsSupplier = null;
		}

		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;

		_commentsSupplier = null;
	}

	@JsonIgnore
	public void setComments(
		UnsafeSupplier<String, Exception> commentsUnsafeSupplier) {

		_commentsSupplier = () -> {
			try {
				return commentsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String comments;

	@JsonIgnore
	private Supplier<String> _commentsSupplier;

	@Schema
	public String getConfigurationItemId() {
		if (_configurationItemIdSupplier != null) {
			configurationItemId = _configurationItemIdSupplier.get();

			_configurationItemIdSupplier = null;
		}

		return configurationItemId;
	}

	public void setConfigurationItemId(String configurationItemId) {
		this.configurationItemId = configurationItemId;

		_configurationItemIdSupplier = null;
	}

	@JsonIgnore
	public void setConfigurationItemId(
		UnsafeSupplier<String, Exception> configurationItemIdUnsafeSupplier) {

		_configurationItemIdSupplier = () -> {
			try {
				return configurationItemIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String configurationItemId;

	@JsonIgnore
	private Supplier<String> _configurationItemIdSupplier;

	@Schema(example = "2019-11-28T07:31:21.168Z")
	public String getCurrentDate() {
		if (_currentDateSupplier != null) {
			currentDate = _currentDateSupplier.get();

			_currentDateSupplier = null;
		}

		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;

		_currentDateSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDate(
		UnsafeSupplier<String, Exception> currentDateUnsafeSupplier) {

		_currentDateSupplier = () -> {
			try {
				return currentDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentDate;

	@JsonIgnore
	private Supplier<String> _currentDateSupplier;

	@Schema(example = "42487")
	public String getCustomerId() {
		if (_customerIdSupplier != null) {
			customerId = _customerIdSupplier.get();

			_customerIdSupplier = null;
		}

		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;

		_customerIdSupplier = null;
	}

	@JsonIgnore
	public void setCustomerId(
		UnsafeSupplier<String, Exception> customerIdUnsafeSupplier) {

		_customerIdSupplier = () -> {
			try {
				return customerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerId;

	@JsonIgnore
	private Supplier<String> _customerIdSupplier;

	@Schema(example = "234234")
	public String getCustomerReference() {
		if (_customerReferenceSupplier != null) {
			customerReference = _customerReferenceSupplier.get();

			_customerReferenceSupplier = null;
		}

		return customerReference;
	}

	public void setCustomerReference(String customerReference) {
		this.customerReference = customerReference;

		_customerReferenceSupplier = null;
	}

	@JsonIgnore
	public void setCustomerReference(
		UnsafeSupplier<String, Exception> customerReferenceUnsafeSupplier) {

		_customerReferenceSupplier = () -> {
			try {
				return customerReferenceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerReference;

	@JsonIgnore
	private Supplier<String> _customerReferenceSupplier;

	@Schema(example = "description about incident")
	public String getDescription() {
		if (_descriptionSupplier != null) {
			description = _descriptionSupplier.get();

			_descriptionSupplier = null;
		}

		return description;
	}

	public void setDescription(String description) {
		this.description = description;

		_descriptionSupplier = null;
	}

	@JsonIgnore
	public void setDescription(
		UnsafeSupplier<String, Exception> descriptionUnsafeSupplier) {

		_descriptionSupplier = () -> {
			try {
				return descriptionUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String description;

	@JsonIgnore
	private Supplier<String> _descriptionSupplier;

	@Schema(example = "Low")
	public String getImpactCode() {
		if (_impactCodeSupplier != null) {
			impactCode = _impactCodeSupplier.get();

			_impactCodeSupplier = null;
		}

		return impactCode;
	}

	public void setImpactCode(String impactCode) {
		this.impactCode = impactCode;

		_impactCodeSupplier = null;
	}

	@JsonIgnore
	public void setImpactCode(
		UnsafeSupplier<String, Exception> impactCodeUnsafeSupplier) {

		_impactCodeSupplier = () -> {
			try {
				return impactCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String impactCode;

	@JsonIgnore
	private Supplier<String> _impactCodeSupplier;

	@Schema(example = "6f19bf9b-4ac4-476e-a1cc-96fe334b8e9")
	public String getMessageId() {
		if (_messageIdSupplier != null) {
			messageId = _messageIdSupplier.get();

			_messageIdSupplier = null;
		}

		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;

		_messageIdSupplier = null;
	}

	@JsonIgnore
	public void setMessageId(
		UnsafeSupplier<String, Exception> messageIdUnsafeSupplier) {

		_messageIdSupplier = () -> {
			try {
				return messageIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String messageId;

	@JsonIgnore
	private Supplier<String> _messageIdSupplier;

	@Schema
	public String getSlaTrigger() {
		if (_slaTriggerSupplier != null) {
			slaTrigger = _slaTriggerSupplier.get();

			_slaTriggerSupplier = null;
		}

		return slaTrigger;
	}

	public void setSlaTrigger(String slaTrigger) {
		this.slaTrigger = slaTrigger;

		_slaTriggerSupplier = null;
	}

	@JsonIgnore
	public void setSlaTrigger(
		UnsafeSupplier<String, Exception> slaTriggerUnsafeSupplier) {

		_slaTriggerSupplier = () -> {
			try {
				return slaTriggerUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String slaTrigger;

	@JsonIgnore
	private Supplier<String> _slaTriggerSupplier;

	@Schema(example = "e422ed08dbed9b04b3bd5c48dc961964")
	public String getSubCategory() {
		if (_subCategorySupplier != null) {
			subCategory = _subCategorySupplier.get();

			_subCategorySupplier = null;
		}

		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;

		_subCategorySupplier = null;
	}

	@JsonIgnore
	public void setSubCategory(
		UnsafeSupplier<String, Exception> subCategoryUnsafeSupplier) {

		_subCategorySupplier = () -> {
			try {
				return subCategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String subCategory;

	@JsonIgnore
	private Supplier<String> _subCategorySupplier;

	@Schema(example = "summary about incident")
	public String getSummary() {
		if (_summarySupplier != null) {
			summary = _summarySupplier.get();

			_summarySupplier = null;
		}

		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;

		_summarySupplier = null;
	}

	@JsonIgnore
	public void setSummary(
		UnsafeSupplier<String, Exception> summaryUnsafeSupplier) {

		_summarySupplier = () -> {
			try {
				return summaryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String summary;

	@JsonIgnore
	private Supplier<String> _summarySupplier;

	@Schema(example = "Low")
	public String getUrgencyCode() {
		if (_urgencyCodeSupplier != null) {
			urgencyCode = _urgencyCodeSupplier.get();

			_urgencyCodeSupplier = null;
		}

		return urgencyCode;
	}

	public void setUrgencyCode(String urgencyCode) {
		this.urgencyCode = urgencyCode;

		_urgencyCodeSupplier = null;
	}

	@JsonIgnore
	public void setUrgencyCode(
		UnsafeSupplier<String, Exception> urgencyCodeUnsafeSupplier) {

		_urgencyCodeSupplier = () -> {
			try {
				return urgencyCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String urgencyCode;

	@JsonIgnore
	private Supplier<String> _urgencyCodeSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CreateIncidentRequest)) {
			return false;
		}

		CreateIncidentRequest createIncidentRequest =
			(CreateIncidentRequest)object;

		return Objects.equals(toString(), createIncidentRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String category = getCategory();

		if (category != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"category\": ");

			sb.append("\"");

			sb.append(_escape(category));

			sb.append("\"");
		}

		String childCustomerId = getChildCustomerId();

		if (childCustomerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childCustomerId\": ");

			sb.append("\"");

			sb.append(_escape(childCustomerId));

			sb.append("\"");
		}

		String comments = getComments();

		if (comments != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"comments\": ");

			sb.append("\"");

			sb.append(_escape(comments));

			sb.append("\"");
		}

		String configurationItemId = getConfigurationItemId();

		if (configurationItemId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"configurationItemId\": ");

			sb.append("\"");

			sb.append(_escape(configurationItemId));

			sb.append("\"");
		}

		String currentDate = getCurrentDate();

		if (currentDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDate\": ");

			sb.append("\"");

			sb.append(_escape(currentDate));

			sb.append("\"");
		}

		String customerId = getCustomerId();

		if (customerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerId\": ");

			sb.append("\"");

			sb.append(_escape(customerId));

			sb.append("\"");
		}

		String customerReference = getCustomerReference();

		if (customerReference != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerReference\": ");

			sb.append("\"");

			sb.append(_escape(customerReference));

			sb.append("\"");
		}

		String description = getDescription();

		if (description != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(description));

			sb.append("\"");
		}

		String impactCode = getImpactCode();

		if (impactCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"impactCode\": ");

			sb.append("\"");

			sb.append(_escape(impactCode));

			sb.append("\"");
		}

		String messageId = getMessageId();

		if (messageId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"messageId\": ");

			sb.append("\"");

			sb.append(_escape(messageId));

			sb.append("\"");
		}

		String slaTrigger = getSlaTrigger();

		if (slaTrigger != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"slaTrigger\": ");

			sb.append("\"");

			sb.append(_escape(slaTrigger));

			sb.append("\"");
		}

		String subCategory = getSubCategory();

		if (subCategory != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"subCategory\": ");

			sb.append("\"");

			sb.append(_escape(subCategory));

			sb.append("\"");
		}

		String summary = getSummary();

		if (summary != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"summary\": ");

			sb.append("\"");

			sb.append(_escape(summary));

			sb.append("\"");
		}

		String urgencyCode = getUrgencyCode();

		if (urgencyCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"urgencyCode\": ");

			sb.append("\"");

			sb.append(_escape(urgencyCode));

			sb.append("\"");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.incident.dto.v1_0.CreateIncidentRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}