package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("CodeListRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CodeListRequest")
public class CodeListRequest implements Serializable {

	public static CodeListRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(CodeListRequest.class, json);
	}

	public static CodeListRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CodeListRequest.class, json);
	}

	@Schema
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema
	public String getCatalogueItemSysID() {
		if (_catalogueItemSysIDSupplier != null) {
			catalogueItemSysID = _catalogueItemSysIDSupplier.get();

			_catalogueItemSysIDSupplier = null;
		}

		return catalogueItemSysID;
	}

	public void setCatalogueItemSysID(String catalogueItemSysID) {
		this.catalogueItemSysID = catalogueItemSysID;

		_catalogueItemSysIDSupplier = null;
	}

	@JsonIgnore
	public void setCatalogueItemSysID(
		UnsafeSupplier<String, Exception> catalogueItemSysIDUnsafeSupplier) {

		_catalogueItemSysIDSupplier = () -> {
			try {
				return catalogueItemSysIDUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String catalogueItemSysID;

	@JsonIgnore
	private Supplier<String> _catalogueItemSysIDSupplier;

	@Schema(example = "2019-11-28T07:31:21.168Z")
	public String getCurrentDate() {
		if (_currentDateSupplier != null) {
			currentDate = _currentDateSupplier.get();

			_currentDateSupplier = null;
		}

		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;

		_currentDateSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDate(
		UnsafeSupplier<String, Exception> currentDateUnsafeSupplier) {

		_currentDateSupplier = () -> {
			try {
				return currentDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentDate;

	@JsonIgnore
	private Supplier<String> _currentDateSupplier;

	@Schema(example = "42487")
	public String getCustomerId() {
		if (_customerIdSupplier != null) {
			customerId = _customerIdSupplier.get();

			_customerIdSupplier = null;
		}

		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;

		_customerIdSupplier = null;
	}

	@JsonIgnore
	public void setCustomerId(
		UnsafeSupplier<String, Exception> customerIdUnsafeSupplier) {

		_customerIdSupplier = () -> {
			try {
				return customerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerId;

	@JsonIgnore
	private Supplier<String> _customerIdSupplier;

	@Schema(example = "D17287288")
	public String getDlmId() {
		if (_dlmIdSupplier != null) {
			dlmId = _dlmIdSupplier.get();

			_dlmIdSupplier = null;
		}

		return dlmId;
	}

	public void setDlmId(String dlmId) {
		this.dlmId = dlmId;

		_dlmIdSupplier = null;
	}

	@JsonIgnore
	public void setDlmId(
		UnsafeSupplier<String, Exception> dlmIdUnsafeSupplier) {

		_dlmIdSupplier = () -> {
			try {
				return dlmIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dlmId;

	@JsonIgnore
	private Supplier<String> _dlmIdSupplier;

	@Schema(example = "6f19bf9b-4ac4-476e-a1cc-96fe334b8e9")
	public String getMessageId() {
		if (_messageIdSupplier != null) {
			messageId = _messageIdSupplier.get();

			_messageIdSupplier = null;
		}

		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;

		_messageIdSupplier = null;
	}

	@JsonIgnore
	public void setMessageId(
		UnsafeSupplier<String, Exception> messageIdUnsafeSupplier) {

		_messageIdSupplier = () -> {
			try {
				return messageIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String messageId;

	@JsonIgnore
	private Supplier<String> _messageIdSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getOamuserId() {
		if (_oamuserIdSupplier != null) {
			oamuserId = _oamuserIdSupplier.get();

			_oamuserIdSupplier = null;
		}

		return oamuserId;
	}

	public void setOamuserId(String oamuserId) {
		this.oamuserId = oamuserId;

		_oamuserIdSupplier = null;
	}

	@JsonIgnore
	public void setOamuserId(
		UnsafeSupplier<String, Exception> oamuserIdUnsafeSupplier) {

		_oamuserIdSupplier = () -> {
			try {
				return oamuserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String oamuserId;

	@JsonIgnore
	private Supplier<String> _oamuserIdSupplier;

	@Schema
	public String getType() {
		if (_typeSupplier != null) {
			type = _typeSupplier.get();

			_typeSupplier = null;
		}

		return type;
	}

	public void setType(String type) {
		this.type = type;

		_typeSupplier = null;
	}

	@JsonIgnore
	public void setType(UnsafeSupplier<String, Exception> typeUnsafeSupplier) {
		_typeSupplier = () -> {
			try {
				return typeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String type;

	@JsonIgnore
	private Supplier<String> _typeSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CodeListRequest)) {
			return false;
		}

		CodeListRequest codeListRequest = (CodeListRequest)object;

		return Objects.equals(toString(), codeListRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String catalogueItemSysID = getCatalogueItemSysID();

		if (catalogueItemSysID != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"catalogueItemSysID\": ");

			sb.append("\"");

			sb.append(_escape(catalogueItemSysID));

			sb.append("\"");
		}

		String currentDate = getCurrentDate();

		if (currentDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDate\": ");

			sb.append("\"");

			sb.append(_escape(currentDate));

			sb.append("\"");
		}

		String customerId = getCustomerId();

		if (customerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerId\": ");

			sb.append("\"");

			sb.append(_escape(customerId));

			sb.append("\"");
		}

		String dlmId = getDlmId();

		if (dlmId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dlmId\": ");

			sb.append("\"");

			sb.append(_escape(dlmId));

			sb.append("\"");
		}

		String messageId = getMessageId();

		if (messageId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"messageId\": ");

			sb.append("\"");

			sb.append(_escape(messageId));

			sb.append("\"");
		}

		String oamuserId = getOamuserId();

		if (oamuserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"oamuserId\": ");

			sb.append("\"");

			sb.append(_escape(oamuserId));

			sb.append("\"");
		}

		String type = getType();

		if (type != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"type\": ");

			sb.append("\"");

			sb.append(_escape(type));

			sb.append("\"");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.CodeListRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}