package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("Attachment")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "Attachment")
public class Attachment implements Serializable {

	public static Attachment toDTO(String json) {
		return ObjectMapperUtil.readValue(Attachment.class, json);
	}

	public static Attachment unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(Attachment.class, json);
	}

	@Schema
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema
	public String getCapability() {
		if (_capabilitySupplier != null) {
			capability = _capabilitySupplier.get();

			_capabilitySupplier = null;
		}

		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;

		_capabilitySupplier = null;
	}

	@JsonIgnore
	public void setCapability(
		UnsafeSupplier<String, Exception> capabilityUnsafeSupplier) {

		_capabilitySupplier = () -> {
			try {
				return capabilityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String capability;

	@JsonIgnore
	private Supplier<String> _capabilitySupplier;

	@Schema
	public String getName() {
		if (_nameSupplier != null) {
			name = _nameSupplier.get();

			_nameSupplier = null;
		}

		return name;
	}

	public void setName(String name) {
		this.name = name;

		_nameSupplier = null;
	}

	@JsonIgnore
	public void setName(UnsafeSupplier<String, Exception> nameUnsafeSupplier) {
		_nameSupplier = () -> {
			try {
				return nameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String name;

	@JsonIgnore
	private Supplier<String> _nameSupplier;

	@Schema
	public String getStatus() {
		if (_statusSupplier != null) {
			status = _statusSupplier.get();

			_statusSupplier = null;
		}

		return status;
	}

	public void setStatus(String status) {
		this.status = status;

		_statusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		_statusSupplier = () -> {
			try {
				return statusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@JsonIgnore
	private Supplier<String> _statusSupplier;

	@Schema
	public String getSysId() {
		if (_sysIdSupplier != null) {
			sysId = _sysIdSupplier.get();

			_sysIdSupplier = null;
		}

		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;

		_sysIdSupplier = null;
	}

	@JsonIgnore
	public void setSysId(
		UnsafeSupplier<String, Exception> sysIdUnsafeSupplier) {

		_sysIdSupplier = () -> {
			try {
				return sysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String sysId;

	@JsonIgnore
	private Supplier<String> _sysIdSupplier;

	@Schema
	public String getTicketId() {
		if (_ticketIdSupplier != null) {
			ticketId = _ticketIdSupplier.get();

			_ticketIdSupplier = null;
		}

		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;

		_ticketIdSupplier = null;
	}

	@JsonIgnore
	public void setTicketId(
		UnsafeSupplier<String, Exception> ticketIdUnsafeSupplier) {

		_ticketIdSupplier = () -> {
			try {
				return ticketIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ticketId;

	@JsonIgnore
	private Supplier<String> _ticketIdSupplier;

	@Schema
	public String getVariableSysId() {
		if (_variableSysIdSupplier != null) {
			variableSysId = _variableSysIdSupplier.get();

			_variableSysIdSupplier = null;
		}

		return variableSysId;
	}

	public void setVariableSysId(String variableSysId) {
		this.variableSysId = variableSysId;

		_variableSysIdSupplier = null;
	}

	@JsonIgnore
	public void setVariableSysId(
		UnsafeSupplier<String, Exception> variableSysIdUnsafeSupplier) {

		_variableSysIdSupplier = () -> {
			try {
				return variableSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String variableSysId;

	@JsonIgnore
	private Supplier<String> _variableSysIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Attachment)) {
			return false;
		}

		Attachment attachment = (Attachment)object;

		return Objects.equals(toString(), attachment.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String capability = getCapability();

		if (capability != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"capability\": ");

			sb.append("\"");

			sb.append(_escape(capability));

			sb.append("\"");
		}

		String name = getName();

		if (name != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"name\": ");

			sb.append("\"");

			sb.append(_escape(name));

			sb.append("\"");
		}

		String status = getStatus();

		if (status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"status\": ");

			sb.append("\"");

			sb.append(_escape(status));

			sb.append("\"");
		}

		String sysId = getSysId();

		if (sysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sysId\": ");

			sb.append("\"");

			sb.append(_escape(sysId));

			sb.append("\"");
		}

		String ticketId = getTicketId();

		if (ticketId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ticketId\": ");

			sb.append("\"");

			sb.append(_escape(ticketId));

			sb.append("\"");
		}

		String variableSysId = getVariableSysId();

		if (variableSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"variableSysId\": ");

			sb.append("\"");

			sb.append(_escape(variableSysId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.Attachment",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}