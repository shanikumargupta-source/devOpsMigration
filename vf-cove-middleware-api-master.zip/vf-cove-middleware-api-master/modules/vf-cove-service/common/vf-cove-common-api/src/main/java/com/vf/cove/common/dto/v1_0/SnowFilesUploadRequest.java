package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("SnowFilesUploadRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "SnowFilesUploadRequest")
public class SnowFilesUploadRequest implements Serializable {

	public static SnowFilesUploadRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(SnowFilesUploadRequest.class, json);
	}

	public static SnowFilesUploadRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			SnowFilesUploadRequest.class, json);
	}

	@Schema
	public String getBusinessService() {
		if (_businessServiceSupplier != null) {
			businessService = _businessServiceSupplier.get();

			_businessServiceSupplier = null;
		}

		return businessService;
	}

	public void setBusinessService(String businessService) {
		this.businessService = businessService;

		_businessServiceSupplier = null;
	}

	@JsonIgnore
	public void setBusinessService(
		UnsafeSupplier<String, Exception> businessServiceUnsafeSupplier) {

		_businessServiceSupplier = () -> {
			try {
				return businessServiceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String businessService;

	@JsonIgnore
	private Supplier<String> _businessServiceSupplier;

	@Schema
	public String getCapability() {
		if (_capabilitySupplier != null) {
			capability = _capabilitySupplier.get();

			_capabilitySupplier = null;
		}

		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;

		_capabilitySupplier = null;
	}

	@JsonIgnore
	public void setCapability(
		UnsafeSupplier<String, Exception> capabilityUnsafeSupplier) {

		_capabilitySupplier = () -> {
			try {
				return capabilityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String capability;

	@JsonIgnore
	private Supplier<String> _capabilitySupplier;

	@Schema
	public String getLegalOrgId() {
		if (_legalOrgIdSupplier != null) {
			legalOrgId = _legalOrgIdSupplier.get();

			_legalOrgIdSupplier = null;
		}

		return legalOrgId;
	}

	public void setLegalOrgId(String legalOrgId) {
		this.legalOrgId = legalOrgId;

		_legalOrgIdSupplier = null;
	}

	@JsonIgnore
	public void setLegalOrgId(
		UnsafeSupplier<String, Exception> legalOrgIdUnsafeSupplier) {

		_legalOrgIdSupplier = () -> {
			try {
				return legalOrgIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String legalOrgId;

	@JsonIgnore
	private Supplier<String> _legalOrgIdSupplier;

	@Schema
	public String getTicketId() {
		if (_ticketIdSupplier != null) {
			ticketId = _ticketIdSupplier.get();

			_ticketIdSupplier = null;
		}

		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;

		_ticketIdSupplier = null;
	}

	@JsonIgnore
	public void setTicketId(
		UnsafeSupplier<String, Exception> ticketIdUnsafeSupplier) {

		_ticketIdSupplier = () -> {
			try {
				return ticketIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ticketId;

	@JsonIgnore
	private Supplier<String> _ticketIdSupplier;

	@Schema
	public String getUserEmail() {
		if (_userEmailSupplier != null) {
			userEmail = _userEmailSupplier.get();

			_userEmailSupplier = null;
		}

		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;

		_userEmailSupplier = null;
	}

	@JsonIgnore
	public void setUserEmail(
		UnsafeSupplier<String, Exception> userEmailUnsafeSupplier) {

		_userEmailSupplier = () -> {
			try {
				return userEmailUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userEmail;

	@JsonIgnore
	private Supplier<String> _userEmailSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof SnowFilesUploadRequest)) {
			return false;
		}

		SnowFilesUploadRequest snowFilesUploadRequest =
			(SnowFilesUploadRequest)object;

		return Objects.equals(toString(), snowFilesUploadRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String businessService = getBusinessService();

		if (businessService != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessService\": ");

			sb.append("\"");

			sb.append(_escape(businessService));

			sb.append("\"");
		}

		String capability = getCapability();

		if (capability != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"capability\": ");

			sb.append("\"");

			sb.append(_escape(capability));

			sb.append("\"");
		}

		String legalOrgId = getLegalOrgId();

		if (legalOrgId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"legalOrgId\": ");

			sb.append("\"");

			sb.append(_escape(legalOrgId));

			sb.append("\"");
		}

		String ticketId = getTicketId();

		if (ticketId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ticketId\": ");

			sb.append("\"");

			sb.append(_escape(ticketId));

			sb.append("\"");
		}

		String userEmail = getUserEmail();

		if (userEmail != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userEmail\": ");

			sb.append("\"");

			sb.append(_escape(userEmail));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.SnowFilesUploadRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}