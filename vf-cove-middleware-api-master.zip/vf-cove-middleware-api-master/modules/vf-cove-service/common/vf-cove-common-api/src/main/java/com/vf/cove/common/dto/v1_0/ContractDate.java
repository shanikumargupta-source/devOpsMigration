package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("ContractDate")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ContractDate")
public class ContractDate implements Serializable {

	public static ContractDate toDTO(String json) {
		return ObjectMapperUtil.readValue(ContractDate.class, json);
	}

	public static ContractDate unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(ContractDate.class, json);
	}

	@Schema
	public String getFromDate() {
		if (_fromDateSupplier != null) {
			fromDate = _fromDateSupplier.get();

			_fromDateSupplier = null;
		}

		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;

		_fromDateSupplier = null;
	}

	@JsonIgnore
	public void setFromDate(
		UnsafeSupplier<String, Exception> fromDateUnsafeSupplier) {

		_fromDateSupplier = () -> {
			try {
				return fromDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fromDate;

	@JsonIgnore
	private Supplier<String> _fromDateSupplier;

	@Schema
	public String getOperator() {
		if (_operatorSupplier != null) {
			operator = _operatorSupplier.get();

			_operatorSupplier = null;
		}

		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;

		_operatorSupplier = null;
	}

	@JsonIgnore
	public void setOperator(
		UnsafeSupplier<String, Exception> operatorUnsafeSupplier) {

		_operatorSupplier = () -> {
			try {
				return operatorUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String operator;

	@JsonIgnore
	private Supplier<String> _operatorSupplier;

	@Schema
	public String getToDate() {
		if (_toDateSupplier != null) {
			toDate = _toDateSupplier.get();

			_toDateSupplier = null;
		}

		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;

		_toDateSupplier = null;
	}

	@JsonIgnore
	public void setToDate(
		UnsafeSupplier<String, Exception> toDateUnsafeSupplier) {

		_toDateSupplier = () -> {
			try {
				return toDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String toDate;

	@JsonIgnore
	private Supplier<String> _toDateSupplier;

	@Schema
	public String getValue() {
		if (_valueSupplier != null) {
			value = _valueSupplier.get();

			_valueSupplier = null;
		}

		return value;
	}

	public void setValue(String value) {
		this.value = value;

		_valueSupplier = null;
	}

	@JsonIgnore
	public void setValue(
		UnsafeSupplier<String, Exception> valueUnsafeSupplier) {

		_valueSupplier = () -> {
			try {
				return valueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String value;

	@JsonIgnore
	private Supplier<String> _valueSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ContractDate)) {
			return false;
		}

		ContractDate contractDate = (ContractDate)object;

		return Objects.equals(toString(), contractDate.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String fromDate = getFromDate();

		if (fromDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fromDate\": ");

			sb.append("\"");

			sb.append(_escape(fromDate));

			sb.append("\"");
		}

		String operator = getOperator();

		if (operator != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"operator\": ");

			sb.append("\"");

			sb.append(_escape(operator));

			sb.append("\"");
		}

		String toDate = getToDate();

		if (toDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"toDate\": ");

			sb.append("\"");

			sb.append(_escape(toDate));

			sb.append("\"");
		}

		String value = getValue();

		if (value != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"value\": ");

			sb.append("\"");

			sb.append(_escape(value));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.ContractDate",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}