package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("BusinessService")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "BusinessService")
public class BusinessService implements Serializable {

	public static BusinessService toDTO(String json) {
		return ObjectMapperUtil.readValue(BusinessService.class, json);
	}

	public static BusinessService unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(BusinessService.class, json);
	}

	@Schema(example = "true")
	public String getCiAvailableFlag() {
		if (_ciAvailableFlagSupplier != null) {
			ciAvailableFlag = _ciAvailableFlagSupplier.get();

			_ciAvailableFlagSupplier = null;
		}

		return ciAvailableFlag;
	}

	public void setCiAvailableFlag(String ciAvailableFlag) {
		this.ciAvailableFlag = ciAvailableFlag;

		_ciAvailableFlagSupplier = null;
	}

	@JsonIgnore
	public void setCiAvailableFlag(
		UnsafeSupplier<String, Exception> ciAvailableFlagUnsafeSupplier) {

		_ciAvailableFlagSupplier = () -> {
			try {
				return ciAvailableFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciAvailableFlag;

	@JsonIgnore
	private Supplier<String> _ciAvailableFlagSupplier;

	@Schema(example = "GB")
	public String getCountryCode() {
		if (_countryCodeSupplier != null) {
			countryCode = _countryCodeSupplier.get();

			_countryCodeSupplier = null;
		}

		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;

		_countryCodeSupplier = null;
	}

	@JsonIgnore
	public void setCountryCode(
		UnsafeSupplier<String, Exception> countryCodeUnsafeSupplier) {

		_countryCodeSupplier = () -> {
			try {
				return countryCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String countryCode;

	@JsonIgnore
	private Supplier<String> _countryCodeSupplier;

	@Schema(example = "United Kingdom")
	public String getCountryName() {
		if (_countryNameSupplier != null) {
			countryName = _countryNameSupplier.get();

			_countryNameSupplier = null;
		}

		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;

		_countryNameSupplier = null;
	}

	@JsonIgnore
	public void setCountryName(
		UnsafeSupplier<String, Exception> countryNameUnsafeSupplier) {

		_countryNameSupplier = () -> {
			try {
				return countryNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String countryName;

	@JsonIgnore
	private Supplier<String> _countryNameSupplier;

	@Schema(example = "URL")
	public String getDynamicAppLinkURL() {
		if (_dynamicAppLinkURLSupplier != null) {
			dynamicAppLinkURL = _dynamicAppLinkURLSupplier.get();

			_dynamicAppLinkURLSupplier = null;
		}

		return dynamicAppLinkURL;
	}

	public void setDynamicAppLinkURL(String dynamicAppLinkURL) {
		this.dynamicAppLinkURL = dynamicAppLinkURL;

		_dynamicAppLinkURLSupplier = null;
	}

	@JsonIgnore
	public void setDynamicAppLinkURL(
		UnsafeSupplier<String, Exception> dynamicAppLinkURLUnsafeSupplier) {

		_dynamicAppLinkURLSupplier = () -> {
			try {
				return dynamicAppLinkURLUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dynamicAppLinkURL;

	@JsonIgnore
	private Supplier<String> _dynamicAppLinkURLSupplier;

	@Schema
	@Valid
	public FilterDefaultDropDownData getFilterDefaultDropDownData() {
		if (_filterDefaultDropDownDataSupplier != null) {
			filterDefaultDropDownData =
				_filterDefaultDropDownDataSupplier.get();

			_filterDefaultDropDownDataSupplier = null;
		}

		return filterDefaultDropDownData;
	}

	public void setFilterDefaultDropDownData(
		FilterDefaultDropDownData filterDefaultDropDownData) {

		this.filterDefaultDropDownData = filterDefaultDropDownData;

		_filterDefaultDropDownDataSupplier = null;
	}

	@JsonIgnore
	public void setFilterDefaultDropDownData(
		UnsafeSupplier<FilterDefaultDropDownData, Exception>
			filterDefaultDropDownDataUnsafeSupplier) {

		_filterDefaultDropDownDataSupplier = () -> {
			try {
				return filterDefaultDropDownDataUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected FilterDefaultDropDownData filterDefaultDropDownData;

	@JsonIgnore
	private Supplier<FilterDefaultDropDownData>
		_filterDefaultDropDownDataSupplier;

	@Schema(example = "true")
	public String getLeaversFlag() {
		if (_leaversFlagSupplier != null) {
			leaversFlag = _leaversFlagSupplier.get();

			_leaversFlagSupplier = null;
		}

		return leaversFlag;
	}

	public void setLeaversFlag(String leaversFlag) {
		this.leaversFlag = leaversFlag;

		_leaversFlagSupplier = null;
	}

	@JsonIgnore
	public void setLeaversFlag(
		UnsafeSupplier<String, Exception> leaversFlagUnsafeSupplier) {

		_leaversFlagSupplier = () -> {
			try {
				return leaversFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String leaversFlag;

	@JsonIgnore
	private Supplier<String> _leaversFlagSupplier;

	@Schema(example = "true")
	public String getMultiCountryFlag() {
		if (_multiCountryFlagSupplier != null) {
			multiCountryFlag = _multiCountryFlagSupplier.get();

			_multiCountryFlagSupplier = null;
		}

		return multiCountryFlag;
	}

	public void setMultiCountryFlag(String multiCountryFlag) {
		this.multiCountryFlag = multiCountryFlag;

		_multiCountryFlagSupplier = null;
	}

	@JsonIgnore
	public void setMultiCountryFlag(
		UnsafeSupplier<String, Exception> multiCountryFlagUnsafeSupplier) {

		_multiCountryFlagSupplier = () -> {
			try {
				return multiCountryFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String multiCountryFlag;

	@JsonIgnore
	private Supplier<String> _multiCountryFlagSupplier;

	@Schema(example = "Internet Of Things")
	public String getName() {
		if (_nameSupplier != null) {
			name = _nameSupplier.get();

			_nameSupplier = null;
		}

		return name;
	}

	public void setName(String name) {
		this.name = name;

		_nameSupplier = null;
	}

	@JsonIgnore
	public void setName(UnsafeSupplier<String, Exception> nameUnsafeSupplier) {
		_nameSupplier = () -> {
			try {
				return nameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String name;

	@JsonIgnore
	private Supplier<String> _nameSupplier;

	@Schema
	@Valid
	public SearchGridConfig getSearchGridConfig() {
		if (_searchGridConfigSupplier != null) {
			searchGridConfig = _searchGridConfigSupplier.get();

			_searchGridConfigSupplier = null;
		}

		return searchGridConfig;
	}

	public void setSearchGridConfig(SearchGridConfig searchGridConfig) {
		this.searchGridConfig = searchGridConfig;

		_searchGridConfigSupplier = null;
	}

	@JsonIgnore
	public void setSearchGridConfig(
		UnsafeSupplier<SearchGridConfig, Exception>
			searchGridConfigUnsafeSupplier) {

		_searchGridConfigSupplier = () -> {
			try {
				return searchGridConfigUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected SearchGridConfig searchGridConfig;

	@JsonIgnore
	private Supplier<SearchGridConfig> _searchGridConfigSupplier;

	@Schema
	@Valid
	public Selected getSelected() {
		if (_selectedSupplier != null) {
			selected = _selectedSupplier.get();

			_selectedSupplier = null;
		}

		return selected;
	}

	public void setSelected(Selected selected) {
		this.selected = selected;

		_selectedSupplier = null;
	}

	@JsonIgnore
	public void setSelected(
		UnsafeSupplier<Selected, Exception> selectedUnsafeSupplier) {

		_selectedSupplier = () -> {
			try {
				return selectedUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Selected selected;

	@JsonIgnore
	private Supplier<Selected> _selectedSupplier;

	@Schema(example = "true")
	public String getSwapStockFlag() {
		if (_swapStockFlagSupplier != null) {
			swapStockFlag = _swapStockFlagSupplier.get();

			_swapStockFlagSupplier = null;
		}

		return swapStockFlag;
	}

	public void setSwapStockFlag(String swapStockFlag) {
		this.swapStockFlag = swapStockFlag;

		_swapStockFlagSupplier = null;
	}

	@JsonIgnore
	public void setSwapStockFlag(
		UnsafeSupplier<String, Exception> swapStockFlagUnsafeSupplier) {

		_swapStockFlagSupplier = () -> {
			try {
				return swapStockFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String swapStockFlag;

	@JsonIgnore
	private Supplier<String> _swapStockFlagSupplier;

	@Schema(example = "2f093051db1f97c4bfe97d5a8c961932")
	public String getSystemId() {
		if (_systemIdSupplier != null) {
			systemId = _systemIdSupplier.get();

			_systemIdSupplier = null;
		}

		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;

		_systemIdSupplier = null;
	}

	@JsonIgnore
	public void setSystemId(
		UnsafeSupplier<String, Exception> systemIdUnsafeSupplier) {

		_systemIdSupplier = () -> {
			try {
				return systemIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String systemId;

	@JsonIgnore
	private Supplier<String> _systemIdSupplier;

	@Schema(example = "Contracts before 1st of April 2023")
	public String getTier_1() {
		if (_tier_1Supplier != null) {
			tier_1 = _tier_1Supplier.get();

			_tier_1Supplier = null;
		}

		return tier_1;
	}

	public void setTier_1(String tier_1) {
		this.tier_1 = tier_1;

		_tier_1Supplier = null;
	}

	@JsonIgnore
	public void setTier_1(
		UnsafeSupplier<String, Exception> tier_1UnsafeSupplier) {

		_tier_1Supplier = () -> {
			try {
				return tier_1UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String tier_1;

	@JsonIgnore
	private Supplier<String> _tier_1Supplier;

	@Schema(example = "Contracts before 1st of April 2023")
	public String getTier_2() {
		if (_tier_2Supplier != null) {
			tier_2 = _tier_2Supplier.get();

			_tier_2Supplier = null;
		}

		return tier_2;
	}

	public void setTier_2(String tier_2) {
		this.tier_2 = tier_2;

		_tier_2Supplier = null;
	}

	@JsonIgnore
	public void setTier_2(
		UnsafeSupplier<String, Exception> tier_2UnsafeSupplier) {

		_tier_2Supplier = () -> {
			try {
				return tier_2UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String tier_2;

	@JsonIgnore
	private Supplier<String> _tier_2Supplier;

	@Schema
	public String getType() {
		if (_typeSupplier != null) {
			type = _typeSupplier.get();

			_typeSupplier = null;
		}

		return type;
	}

	public void setType(String type) {
		this.type = type;

		_typeSupplier = null;
	}

	@JsonIgnore
	public void setType(UnsafeSupplier<String, Exception> typeUnsafeSupplier) {
		_typeSupplier = () -> {
			try {
				return typeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String type;

	@JsonIgnore
	private Supplier<String> _typeSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof BusinessService)) {
			return false;
		}

		BusinessService businessService = (BusinessService)object;

		return Objects.equals(toString(), businessService.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String ciAvailableFlag = getCiAvailableFlag();

		if (ciAvailableFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciAvailableFlag\": ");

			sb.append("\"");

			sb.append(_escape(ciAvailableFlag));

			sb.append("\"");
		}

		String countryCode = getCountryCode();

		if (countryCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryCode\": ");

			sb.append("\"");

			sb.append(_escape(countryCode));

			sb.append("\"");
		}

		String countryName = getCountryName();

		if (countryName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryName\": ");

			sb.append("\"");

			sb.append(_escape(countryName));

			sb.append("\"");
		}

		String dynamicAppLinkURL = getDynamicAppLinkURL();

		if (dynamicAppLinkURL != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dynamicAppLinkURL\": ");

			sb.append("\"");

			sb.append(_escape(dynamicAppLinkURL));

			sb.append("\"");
		}

		FilterDefaultDropDownData filterDefaultDropDownData =
			getFilterDefaultDropDownData();

		if (filterDefaultDropDownData != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"filterDefaultDropDownData\": ");

			sb.append(String.valueOf(filterDefaultDropDownData));
		}

		String leaversFlag = getLeaversFlag();

		if (leaversFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"leaversFlag\": ");

			sb.append("\"");

			sb.append(_escape(leaversFlag));

			sb.append("\"");
		}

		String multiCountryFlag = getMultiCountryFlag();

		if (multiCountryFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"multiCountryFlag\": ");

			sb.append("\"");

			sb.append(_escape(multiCountryFlag));

			sb.append("\"");
		}

		String name = getName();

		if (name != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"name\": ");

			sb.append("\"");

			sb.append(_escape(name));

			sb.append("\"");
		}

		SearchGridConfig searchGridConfig = getSearchGridConfig();

		if (searchGridConfig != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchGridConfig\": ");

			sb.append(String.valueOf(searchGridConfig));
		}

		Selected selected = getSelected();

		if (selected != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"selected\": ");

			sb.append(String.valueOf(selected));
		}

		String swapStockFlag = getSwapStockFlag();

		if (swapStockFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"swapStockFlag\": ");

			sb.append("\"");

			sb.append(_escape(swapStockFlag));

			sb.append("\"");
		}

		String systemId = getSystemId();

		if (systemId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"systemId\": ");

			sb.append("\"");

			sb.append(_escape(systemId));

			sb.append("\"");
		}

		String tier_1 = getTier_1();

		if (tier_1 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tier_1\": ");

			sb.append("\"");

			sb.append(_escape(tier_1));

			sb.append("\"");
		}

		String tier_2 = getTier_2();

		if (tier_2 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tier_2\": ");

			sb.append("\"");

			sb.append(_escape(tier_2));

			sb.append("\"");
		}

		String type = getType();

		if (type != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"type\": ");

			sb.append("\"");

			sb.append(_escape(type));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.BusinessService",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}