package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("CatalogueService")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CatalogueService")
public class CatalogueService implements Serializable {

	public static CatalogueService toDTO(String json) {
		return ObjectMapperUtil.readValue(CatalogueService.class, json);
	}

	public static CatalogueService unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CatalogueService.class, json);
	}

	@Schema
	public String getCatalogueItemCount() {
		if (_catalogueItemCountSupplier != null) {
			catalogueItemCount = _catalogueItemCountSupplier.get();

			_catalogueItemCountSupplier = null;
		}

		return catalogueItemCount;
	}

	public void setCatalogueItemCount(String catalogueItemCount) {
		this.catalogueItemCount = catalogueItemCount;

		_catalogueItemCountSupplier = null;
	}

	@JsonIgnore
	public void setCatalogueItemCount(
		UnsafeSupplier<String, Exception> catalogueItemCountUnsafeSupplier) {

		_catalogueItemCountSupplier = () -> {
			try {
				return catalogueItemCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String catalogueItemCount;

	@JsonIgnore
	private Supplier<String> _catalogueItemCountSupplier;

	@Schema
	@Valid
	public CatalogueItem[] getCatalogueItems() {
		if (_catalogueItemsSupplier != null) {
			catalogueItems = _catalogueItemsSupplier.get();

			_catalogueItemsSupplier = null;
		}

		return catalogueItems;
	}

	public void setCatalogueItems(CatalogueItem[] catalogueItems) {
		this.catalogueItems = catalogueItems;

		_catalogueItemsSupplier = null;
	}

	@JsonIgnore
	public void setCatalogueItems(
		UnsafeSupplier<CatalogueItem[], Exception>
			catalogueItemsUnsafeSupplier) {

		_catalogueItemsSupplier = () -> {
			try {
				return catalogueItemsUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected CatalogueItem[] catalogueItems;

	@JsonIgnore
	private Supplier<CatalogueItem[]> _catalogueItemsSupplier;

	@Schema
	public String getCiAvailableFlag() {
		if (_ciAvailableFlagSupplier != null) {
			ciAvailableFlag = _ciAvailableFlagSupplier.get();

			_ciAvailableFlagSupplier = null;
		}

		return ciAvailableFlag;
	}

	public void setCiAvailableFlag(String ciAvailableFlag) {
		this.ciAvailableFlag = ciAvailableFlag;

		_ciAvailableFlagSupplier = null;
	}

	@JsonIgnore
	public void setCiAvailableFlag(
		UnsafeSupplier<String, Exception> ciAvailableFlagUnsafeSupplier) {

		_ciAvailableFlagSupplier = () -> {
			try {
				return ciAvailableFlagUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ciAvailableFlag;

	@JsonIgnore
	private Supplier<String> _ciAvailableFlagSupplier;

	@Schema
	public String getCountryCode() {
		if (_countryCodeSupplier != null) {
			countryCode = _countryCodeSupplier.get();

			_countryCodeSupplier = null;
		}

		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;

		_countryCodeSupplier = null;
	}

	@JsonIgnore
	public void setCountryCode(
		UnsafeSupplier<String, Exception> countryCodeUnsafeSupplier) {

		_countryCodeSupplier = () -> {
			try {
				return countryCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String countryCode;

	@JsonIgnore
	private Supplier<String> _countryCodeSupplier;

	@Schema
	public String getCountryName() {
		if (_countryNameSupplier != null) {
			countryName = _countryNameSupplier.get();

			_countryNameSupplier = null;
		}

		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;

		_countryNameSupplier = null;
	}

	@JsonIgnore
	public void setCountryName(
		UnsafeSupplier<String, Exception> countryNameUnsafeSupplier) {

		_countryNameSupplier = () -> {
			try {
				return countryNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String countryName;

	@JsonIgnore
	private Supplier<String> _countryNameSupplier;

	@Schema
	public String getName() {
		if (_nameSupplier != null) {
			name = _nameSupplier.get();

			_nameSupplier = null;
		}

		return name;
	}

	public void setName(String name) {
		this.name = name;

		_nameSupplier = null;
	}

	@JsonIgnore
	public void setName(UnsafeSupplier<String, Exception> nameUnsafeSupplier) {
		_nameSupplier = () -> {
			try {
				return nameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String name;

	@JsonIgnore
	private Supplier<String> _nameSupplier;

	@Schema
	public String getSystemId() {
		if (_systemIdSupplier != null) {
			systemId = _systemIdSupplier.get();

			_systemIdSupplier = null;
		}

		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;

		_systemIdSupplier = null;
	}

	@JsonIgnore
	public void setSystemId(
		UnsafeSupplier<String, Exception> systemIdUnsafeSupplier) {

		_systemIdSupplier = () -> {
			try {
				return systemIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String systemId;

	@JsonIgnore
	private Supplier<String> _systemIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CatalogueService)) {
			return false;
		}

		CatalogueService catalogueService = (CatalogueService)object;

		return Objects.equals(toString(), catalogueService.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String catalogueItemCount = getCatalogueItemCount();

		if (catalogueItemCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"catalogueItemCount\": ");

			sb.append("\"");

			sb.append(_escape(catalogueItemCount));

			sb.append("\"");
		}

		CatalogueItem[] catalogueItems = getCatalogueItems();

		if (catalogueItems != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"catalogueItems\": ");

			sb.append("[");

			for (int i = 0; i < catalogueItems.length; i++) {
				sb.append(String.valueOf(catalogueItems[i]));

				if ((i + 1) < catalogueItems.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String ciAvailableFlag = getCiAvailableFlag();

		if (ciAvailableFlag != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ciAvailableFlag\": ");

			sb.append("\"");

			sb.append(_escape(ciAvailableFlag));

			sb.append("\"");
		}

		String countryCode = getCountryCode();

		if (countryCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryCode\": ");

			sb.append("\"");

			sb.append(_escape(countryCode));

			sb.append("\"");
		}

		String countryName = getCountryName();

		if (countryName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryName\": ");

			sb.append("\"");

			sb.append(_escape(countryName));

			sb.append("\"");
		}

		String name = getName();

		if (name != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"name\": ");

			sb.append("\"");

			sb.append(_escape(name));

			sb.append("\"");
		}

		String systemId = getSystemId();

		if (systemId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"systemId\": ");

			sb.append("\"");

			sb.append(_escape(systemId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.CatalogueService",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}