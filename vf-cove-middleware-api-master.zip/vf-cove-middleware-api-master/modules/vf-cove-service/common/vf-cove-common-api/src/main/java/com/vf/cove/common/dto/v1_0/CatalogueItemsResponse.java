package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("CatalogueItemsResponse")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CatalogueItemsResponse")
public class CatalogueItemsResponse implements Serializable {

	public static CatalogueItemsResponse toDTO(String json) {
		return ObjectMapperUtil.readValue(CatalogueItemsResponse.class, json);
	}

	public static CatalogueItemsResponse unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			CatalogueItemsResponse.class, json);
	}

	@Schema
	@Valid
	public CatalogueService[] getCatalogueServices() {
		if (_catalogueServicesSupplier != null) {
			catalogueServices = _catalogueServicesSupplier.get();

			_catalogueServicesSupplier = null;
		}

		return catalogueServices;
	}

	public void setCatalogueServices(CatalogueService[] catalogueServices) {
		this.catalogueServices = catalogueServices;

		_catalogueServicesSupplier = null;
	}

	@JsonIgnore
	public void setCatalogueServices(
		UnsafeSupplier<CatalogueService[], Exception>
			catalogueServicesUnsafeSupplier) {

		_catalogueServicesSupplier = () -> {
			try {
				return catalogueServicesUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected CatalogueService[] catalogueServices;

	@JsonIgnore
	private Supplier<CatalogueService[]> _catalogueServicesSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CatalogueItemsResponse)) {
			return false;
		}

		CatalogueItemsResponse catalogueItemsResponse =
			(CatalogueItemsResponse)object;

		return Objects.equals(toString(), catalogueItemsResponse.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		CatalogueService[] catalogueServices = getCatalogueServices();

		if (catalogueServices != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"catalogueServices\": ");

			sb.append("[");

			for (int i = 0; i < catalogueServices.length; i++) {
				sb.append(String.valueOf(catalogueServices[i]));

				if ((i + 1) < catalogueServices.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.CatalogueItemsResponse",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}