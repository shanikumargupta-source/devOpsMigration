package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("ExportPDFRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "ExportPDFRequest")
public class ExportPDFRequest implements Serializable {

	public static ExportPDFRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(ExportPDFRequest.class, json);
	}

	public static ExportPDFRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(ExportPDFRequest.class, json);
	}

	@Schema(example = "incident")
	public String getReferenceNumber() {
		if (_ReferenceNumberSupplier != null) {
			ReferenceNumber = _ReferenceNumberSupplier.get();

			_ReferenceNumberSupplier = null;
		}

		return ReferenceNumber;
	}

	public void setReferenceNumber(String ReferenceNumber) {
		this.ReferenceNumber = ReferenceNumber;

		_ReferenceNumberSupplier = null;
	}

	@JsonIgnore
	public void setReferenceNumber(
		UnsafeSupplier<String, Exception> ReferenceNumberUnsafeSupplier) {

		_ReferenceNumberSupplier = () -> {
			try {
				return ReferenceNumberUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ReferenceNumber;

	@JsonIgnore
	private Supplier<String> _ReferenceNumberSupplier;

	@Schema(example = "Internet of Things")
	public String getRequestBody() {
		if (_RequestBodySupplier != null) {
			RequestBody = _RequestBodySupplier.get();

			_RequestBodySupplier = null;
		}

		return RequestBody;
	}

	public void setRequestBody(String RequestBody) {
		this.RequestBody = RequestBody;

		_RequestBodySupplier = null;
	}

	@JsonIgnore
	public void setRequestBody(
		UnsafeSupplier<String, Exception> RequestBodyUnsafeSupplier) {

		_RequestBodySupplier = () -> {
			try {
				return RequestBodyUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String RequestBody;

	@JsonIgnore
	private Supplier<String> _RequestBodySupplier;

	@Schema(example = "Internet of Things")
	public String getRequestType() {
		if (_RequestTypeSupplier != null) {
			RequestType = _RequestTypeSupplier.get();

			_RequestTypeSupplier = null;
		}

		return RequestType;
	}

	public void setRequestType(String RequestType) {
		this.RequestType = RequestType;

		_RequestTypeSupplier = null;
	}

	@JsonIgnore
	public void setRequestType(
		UnsafeSupplier<String, Exception> RequestTypeUnsafeSupplier) {

		_RequestTypeSupplier = () -> {
			try {
				return RequestTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String RequestType;

	@JsonIgnore
	private Supplier<String> _RequestTypeSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ExportPDFRequest)) {
			return false;
		}

		ExportPDFRequest exportPDFRequest = (ExportPDFRequest)object;

		return Objects.equals(toString(), exportPDFRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String ReferenceNumber = getReferenceNumber();

		if (ReferenceNumber != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ReferenceNumber\": ");

			sb.append("\"");

			sb.append(_escape(ReferenceNumber));

			sb.append("\"");
		}

		String RequestBody = getRequestBody();

		if (RequestBody != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"RequestBody\": ");

			sb.append("\"");

			sb.append(_escape(RequestBody));

			sb.append("\"");
		}

		String RequestType = getRequestType();

		if (RequestType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"RequestType\": ");

			sb.append("\"");

			sb.append(_escape(RequestType));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.ExportPDFRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}