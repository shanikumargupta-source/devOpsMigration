package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("DLMStreamDataRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "DLMStreamDataRequest")
public class DLMStreamDataRequest implements Serializable {

	public static DLMStreamDataRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(DLMStreamDataRequest.class, json);
	}

	public static DLMStreamDataRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			DLMStreamDataRequest.class, json);
	}

	@Schema
	public String[] getEquipmenttype() {
		if (_EquipmenttypeSupplier != null) {
			Equipmenttype = _EquipmenttypeSupplier.get();

			_EquipmenttypeSupplier = null;
		}

		return Equipmenttype;
	}

	public void setEquipmenttype(String[] Equipmenttype) {
		this.Equipmenttype = Equipmenttype;

		_EquipmenttypeSupplier = null;
	}

	@JsonIgnore
	public void setEquipmenttype(
		UnsafeSupplier<String[], Exception> EquipmenttypeUnsafeSupplier) {

		_EquipmenttypeSupplier = () -> {
			try {
				return EquipmenttypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] Equipmenttype;

	@JsonIgnore
	private Supplier<String[]> _EquipmenttypeSupplier;

	@Schema
	public String[] getServiceSubStatus() {
		if (_ServiceSubStatusSupplier != null) {
			ServiceSubStatus = _ServiceSubStatusSupplier.get();

			_ServiceSubStatusSupplier = null;
		}

		return ServiceSubStatus;
	}

	public void setServiceSubStatus(String[] ServiceSubStatus) {
		this.ServiceSubStatus = ServiceSubStatus;

		_ServiceSubStatusSupplier = null;
	}

	@JsonIgnore
	public void setServiceSubStatus(
		UnsafeSupplier<String[], Exception> ServiceSubStatusUnsafeSupplier) {

		_ServiceSubStatusSupplier = () -> {
			try {
				return ServiceSubStatusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] ServiceSubStatus;

	@JsonIgnore
	private Supplier<String[]> _ServiceSubStatusSupplier;

	@Schema
	public String[] getBusinessUnit() {
		if (_businessUnitSupplier != null) {
			businessUnit = _businessUnitSupplier.get();

			_businessUnitSupplier = null;
		}

		return businessUnit;
	}

	public void setBusinessUnit(String[] businessUnit) {
		this.businessUnit = businessUnit;

		_businessUnitSupplier = null;
	}

	@JsonIgnore
	public void setBusinessUnit(
		UnsafeSupplier<String[], Exception> businessUnitUnsafeSupplier) {

		_businessUnitSupplier = () -> {
			try {
				return businessUnitUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] businessUnit;

	@JsonIgnore
	private Supplier<String[]> _businessUnitSupplier;

	@Schema
	@Valid
	public ContractDate getContractEndDate() {
		if (_contractEndDateSupplier != null) {
			contractEndDate = _contractEndDateSupplier.get();

			_contractEndDateSupplier = null;
		}

		return contractEndDate;
	}

	public void setContractEndDate(ContractDate contractEndDate) {
		this.contractEndDate = contractEndDate;

		_contractEndDateSupplier = null;
	}

	@JsonIgnore
	public void setContractEndDate(
		UnsafeSupplier<ContractDate, Exception> contractEndDateUnsafeSupplier) {

		_contractEndDateSupplier = () -> {
			try {
				return contractEndDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ContractDate contractEndDate;

	@JsonIgnore
	private Supplier<ContractDate> _contractEndDateSupplier;

	@Schema
	@Valid
	public ContractDate getContractStartDate() {
		if (_contractStartDateSupplier != null) {
			contractStartDate = _contractStartDateSupplier.get();

			_contractStartDateSupplier = null;
		}

		return contractStartDate;
	}

	public void setContractStartDate(ContractDate contractStartDate) {
		this.contractStartDate = contractStartDate;

		_contractStartDateSupplier = null;
	}

	@JsonIgnore
	public void setContractStartDate(
		UnsafeSupplier<ContractDate, Exception>
			contractStartDateUnsafeSupplier) {

		_contractStartDateSupplier = () -> {
			try {
				return contractStartDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected ContractDate contractStartDate;

	@JsonIgnore
	private Supplier<ContractDate> _contractStartDateSupplier;

	@Schema
	public String[] getCountryCode() {
		if (_countryCodeSupplier != null) {
			countryCode = _countryCodeSupplier.get();

			_countryCodeSupplier = null;
		}

		return countryCode;
	}

	public void setCountryCode(String[] countryCode) {
		this.countryCode = countryCode;

		_countryCodeSupplier = null;
	}

	@JsonIgnore
	public void setCountryCode(
		UnsafeSupplier<String[], Exception> countryCodeUnsafeSupplier) {

		_countryCodeSupplier = () -> {
			try {
				return countryCodeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String[] countryCode;

	@JsonIgnore
	private Supplier<String[]> _countryCodeSupplier;

	@Schema
	public Boolean getEorReport() {
		if (_eorReportSupplier != null) {
			eorReport = _eorReportSupplier.get();

			_eorReportSupplier = null;
		}

		return eorReport;
	}

	public void setEorReport(Boolean eorReport) {
		this.eorReport = eorReport;

		_eorReportSupplier = null;
	}

	@JsonIgnore
	public void setEorReport(
		UnsafeSupplier<Boolean, Exception> eorReportUnsafeSupplier) {

		_eorReportSupplier = () -> {
			try {
				return eorReportUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean eorReport;

	@JsonIgnore
	private Supplier<Boolean> _eorReportSupplier;

	@Schema
	public String getLegalOrgId() {
		if (_legalOrgIdSupplier != null) {
			legalOrgId = _legalOrgIdSupplier.get();

			_legalOrgIdSupplier = null;
		}

		return legalOrgId;
	}

	public void setLegalOrgId(String legalOrgId) {
		this.legalOrgId = legalOrgId;

		_legalOrgIdSupplier = null;
	}

	@JsonIgnore
	public void setLegalOrgId(
		UnsafeSupplier<String, Exception> legalOrgIdUnsafeSupplier) {

		_legalOrgIdSupplier = () -> {
			try {
				return legalOrgIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String legalOrgId;

	@JsonIgnore
	private Supplier<String> _legalOrgIdSupplier;

	@Schema
	public String getSearchType() {
		if (_searchTypeSupplier != null) {
			searchType = _searchTypeSupplier.get();

			_searchTypeSupplier = null;
		}

		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;

		_searchTypeSupplier = null;
	}

	@JsonIgnore
	public void setSearchType(
		UnsafeSupplier<String, Exception> searchTypeUnsafeSupplier) {

		_searchTypeSupplier = () -> {
			try {
				return searchTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchType;

	@JsonIgnore
	private Supplier<String> _searchTypeSupplier;

	@Schema
	public String getSearchValue() {
		if (_searchValueSupplier != null) {
			searchValue = _searchValueSupplier.get();

			_searchValueSupplier = null;
		}

		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;

		_searchValueSupplier = null;
	}

	@JsonIgnore
	public void setSearchValue(
		UnsafeSupplier<String, Exception> searchValueUnsafeSupplier) {

		_searchValueSupplier = () -> {
			try {
				return searchValueUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String searchValue;

	@JsonIgnore
	private Supplier<String> _searchValueSupplier;

	@Schema
	public Boolean getStreamApiDLMUS() {
		if (_streamApiDLMUSSupplier != null) {
			streamApiDLMUS = _streamApiDLMUSSupplier.get();

			_streamApiDLMUSSupplier = null;
		}

		return streamApiDLMUS;
	}

	public void setStreamApiDLMUS(Boolean streamApiDLMUS) {
		this.streamApiDLMUS = streamApiDLMUS;

		_streamApiDLMUSSupplier = null;
	}

	@JsonIgnore
	public void setStreamApiDLMUS(
		UnsafeSupplier<Boolean, Exception> streamApiDLMUSUnsafeSupplier) {

		_streamApiDLMUSSupplier = () -> {
			try {
				return streamApiDLMUSUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean streamApiDLMUS;

	@JsonIgnore
	private Supplier<Boolean> _streamApiDLMUSSupplier;

	@Schema
	public String getUserEmail() {
		if (_userEmailSupplier != null) {
			userEmail = _userEmailSupplier.get();

			_userEmailSupplier = null;
		}

		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;

		_userEmailSupplier = null;
	}

	@JsonIgnore
	public void setUserEmail(
		UnsafeSupplier<String, Exception> userEmailUnsafeSupplier) {

		_userEmailSupplier = () -> {
			try {
				return userEmailUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userEmail;

	@JsonIgnore
	private Supplier<String> _userEmailSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof DLMStreamDataRequest)) {
			return false;
		}

		DLMStreamDataRequest dlmStreamDataRequest =
			(DLMStreamDataRequest)object;

		return Objects.equals(toString(), dlmStreamDataRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String[] Equipmenttype = getEquipmenttype();

		if (Equipmenttype != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Equipmenttype\": ");

			sb.append("[");

			for (int i = 0; i < Equipmenttype.length; i++) {
				sb.append("\"");

				sb.append(_escape(Equipmenttype[i]));

				sb.append("\"");

				if ((i + 1) < Equipmenttype.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] ServiceSubStatus = getServiceSubStatus();

		if (ServiceSubStatus != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ServiceSubStatus\": ");

			sb.append("[");

			for (int i = 0; i < ServiceSubStatus.length; i++) {
				sb.append("\"");

				sb.append(_escape(ServiceSubStatus[i]));

				sb.append("\"");

				if ((i + 1) < ServiceSubStatus.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String[] businessUnit = getBusinessUnit();

		if (businessUnit != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"businessUnit\": ");

			sb.append("[");

			for (int i = 0; i < businessUnit.length; i++) {
				sb.append("\"");

				sb.append(_escape(businessUnit[i]));

				sb.append("\"");

				if ((i + 1) < businessUnit.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		ContractDate contractEndDate = getContractEndDate();

		if (contractEndDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractEndDate\": ");

			sb.append(String.valueOf(contractEndDate));
		}

		ContractDate contractStartDate = getContractStartDate();

		if (contractStartDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"contractStartDate\": ");

			sb.append(String.valueOf(contractStartDate));
		}

		String[] countryCode = getCountryCode();

		if (countryCode != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"countryCode\": ");

			sb.append("[");

			for (int i = 0; i < countryCode.length; i++) {
				sb.append("\"");

				sb.append(_escape(countryCode[i]));

				sb.append("\"");

				if ((i + 1) < countryCode.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		Boolean eorReport = getEorReport();

		if (eorReport != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"eorReport\": ");

			sb.append(eorReport);
		}

		String legalOrgId = getLegalOrgId();

		if (legalOrgId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"legalOrgId\": ");

			sb.append("\"");

			sb.append(_escape(legalOrgId));

			sb.append("\"");
		}

		String searchType = getSearchType();

		if (searchType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchType\": ");

			sb.append("\"");

			sb.append(_escape(searchType));

			sb.append("\"");
		}

		String searchValue = getSearchValue();

		if (searchValue != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"searchValue\": ");

			sb.append("\"");

			sb.append(_escape(searchValue));

			sb.append("\"");
		}

		Boolean streamApiDLMUS = getStreamApiDLMUS();

		if (streamApiDLMUS != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"streamApiDLMUS\": ");

			sb.append(streamApiDLMUS);
		}

		String userEmail = getUserEmail();

		if (userEmail != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userEmail\": ");

			sb.append("\"");

			sb.append(_escape(userEmail));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.DLMStreamDataRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}