package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("CatalogueItemsRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CatalogueItemsRequest")
public class CatalogueItemsRequest implements Serializable {

	public static CatalogueItemsRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(CatalogueItemsRequest.class, json);
	}

	public static CatalogueItemsRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			CatalogueItemsRequest.class, json);
	}

	@Schema(example = "catalogueItems")
	public String getCategory() {
		if (_CategorySupplier != null) {
			Category = _CategorySupplier.get();

			_CategorySupplier = null;
		}

		return Category;
	}

	public void setCategory(String Category) {
		this.Category = Category;

		_CategorySupplier = null;
	}

	@JsonIgnore
	public void setCategory(
		UnsafeSupplier<String, Exception> CategoryUnsafeSupplier) {

		_CategorySupplier = () -> {
			try {
				return CategoryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String Category;

	@JsonIgnore
	private Supplier<String> _CategorySupplier;

	@Schema(example = "Internet of Things")
	public String getAddUserCatalogueItemSysId() {
		if (_addUserCatalogueItemSysIdSupplier != null) {
			addUserCatalogueItemSysId =
				_addUserCatalogueItemSysIdSupplier.get();

			_addUserCatalogueItemSysIdSupplier = null;
		}

		return addUserCatalogueItemSysId;
	}

	public void setAddUserCatalogueItemSysId(String addUserCatalogueItemSysId) {
		this.addUserCatalogueItemSysId = addUserCatalogueItemSysId;

		_addUserCatalogueItemSysIdSupplier = null;
	}

	@JsonIgnore
	public void setAddUserCatalogueItemSysId(
		UnsafeSupplier<String, Exception>
			addUserCatalogueItemSysIdUnsafeSupplier) {

		_addUserCatalogueItemSysIdSupplier = () -> {
			try {
				return addUserCatalogueItemSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String addUserCatalogueItemSysId;

	@JsonIgnore
	private Supplier<String> _addUserCatalogueItemSysIdSupplier;

	@Schema(example = "Internet of Things")
	public String getAddUsersNavigationURL() {
		if (_addUsersNavigationURLSupplier != null) {
			addUsersNavigationURL = _addUsersNavigationURLSupplier.get();

			_addUsersNavigationURLSupplier = null;
		}

		return addUsersNavigationURL;
	}

	public void setAddUsersNavigationURL(String addUsersNavigationURL) {
		this.addUsersNavigationURL = addUsersNavigationURL;

		_addUsersNavigationURLSupplier = null;
	}

	@JsonIgnore
	public void setAddUsersNavigationURL(
		UnsafeSupplier<String, Exception> addUsersNavigationURLUnsafeSupplier) {

		_addUsersNavigationURLSupplier = () -> {
			try {
				return addUsersNavigationURLUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String addUsersNavigationURL;

	@JsonIgnore
	private Supplier<String> _addUsersNavigationURLSupplier;

	@Schema(example = "142487")
	public String getChildCustomerId() {
		if (_childCustomerIdSupplier != null) {
			childCustomerId = _childCustomerIdSupplier.get();

			_childCustomerIdSupplier = null;
		}

		return childCustomerId;
	}

	public void setChildCustomerId(String childCustomerId) {
		this.childCustomerId = childCustomerId;

		_childCustomerIdSupplier = null;
	}

	@JsonIgnore
	public void setChildCustomerId(
		UnsafeSupplier<String, Exception> childCustomerIdUnsafeSupplier) {

		_childCustomerIdSupplier = () -> {
			try {
				return childCustomerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String childCustomerId;

	@JsonIgnore
	private Supplier<String> _childCustomerIdSupplier;

	@Schema(example = "Internet of Things")
	public String getContext() {
		if (_contextSupplier != null) {
			context = _contextSupplier.get();

			_contextSupplier = null;
		}

		return context;
	}

	public void setContext(String context) {
		this.context = context;

		_contextSupplier = null;
	}

	@JsonIgnore
	public void setContext(
		UnsafeSupplier<String, Exception> contextUnsafeSupplier) {

		_contextSupplier = () -> {
			try {
				return contextUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String context;

	@JsonIgnore
	private Supplier<String> _contextSupplier;

	@Schema(example = "2019-11-28T07:31:21.168Z")
	public String getCurrentDate() {
		if (_currentDateSupplier != null) {
			currentDate = _currentDateSupplier.get();

			_currentDateSupplier = null;
		}

		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;

		_currentDateSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDate(
		UnsafeSupplier<String, Exception> currentDateUnsafeSupplier) {

		_currentDateSupplier = () -> {
			try {
				return currentDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentDate;

	@JsonIgnore
	private Supplier<String> _currentDateSupplier;

	@Schema(example = "42487")
	public String getCustomerId() {
		if (_customerIdSupplier != null) {
			customerId = _customerIdSupplier.get();

			_customerIdSupplier = null;
		}

		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;

		_customerIdSupplier = null;
	}

	@JsonIgnore
	public void setCustomerId(
		UnsafeSupplier<String, Exception> customerIdUnsafeSupplier) {

		_customerIdSupplier = () -> {
			try {
				return customerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerId;

	@JsonIgnore
	private Supplier<String> _customerIdSupplier;

	@Schema(example = "Internet of Things")
	public String getDlmSysId() {
		if (_dlmSysIdSupplier != null) {
			dlmSysId = _dlmSysIdSupplier.get();

			_dlmSysIdSupplier = null;
		}

		return dlmSysId;
	}

	public void setDlmSysId(String dlmSysId) {
		this.dlmSysId = dlmSysId;

		_dlmSysIdSupplier = null;
	}

	@JsonIgnore
	public void setDlmSysId(
		UnsafeSupplier<String, Exception> dlmSysIdUnsafeSupplier) {

		_dlmSysIdSupplier = () -> {
			try {
				return dlmSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dlmSysId;

	@JsonIgnore
	private Supplier<String> _dlmSysIdSupplier;

	@Schema(example = "8drfsf5b-5dcc4-43ee-dfdc-but6434b8e9")
	public String getGlobalSub() {
		if (_globalSubSupplier != null) {
			globalSub = _globalSubSupplier.get();

			_globalSubSupplier = null;
		}

		return globalSub;
	}

	public void setGlobalSub(String globalSub) {
		this.globalSub = globalSub;

		_globalSubSupplier = null;
	}

	@JsonIgnore
	public void setGlobalSub(
		UnsafeSupplier<String, Exception> globalSubUnsafeSupplier) {

		_globalSubSupplier = () -> {
			try {
				return globalSubUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String globalSub;

	@JsonIgnore
	private Supplier<String> _globalSubSupplier;

	@Schema(example = "false")
	public Boolean getIsBulkOrderUser() {
		if (_isBulkOrderUserSupplier != null) {
			isBulkOrderUser = _isBulkOrderUserSupplier.get();

			_isBulkOrderUserSupplier = null;
		}

		return isBulkOrderUser;
	}

	public void setIsBulkOrderUser(Boolean isBulkOrderUser) {
		this.isBulkOrderUser = isBulkOrderUser;

		_isBulkOrderUserSupplier = null;
	}

	@JsonIgnore
	public void setIsBulkOrderUser(
		UnsafeSupplier<Boolean, Exception> isBulkOrderUserUnsafeSupplier) {

		_isBulkOrderUserSupplier = () -> {
			try {
				return isBulkOrderUserUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isBulkOrderUser;

	@JsonIgnore
	private Supplier<Boolean> _isBulkOrderUserSupplier;

	@Schema(example = "false")
	public Boolean getIsCatalogueUser() {
		if (_isCatalogueUserSupplier != null) {
			isCatalogueUser = _isCatalogueUserSupplier.get();

			_isCatalogueUserSupplier = null;
		}

		return isCatalogueUser;
	}

	public void setIsCatalogueUser(Boolean isCatalogueUser) {
		this.isCatalogueUser = isCatalogueUser;

		_isCatalogueUserSupplier = null;
	}

	@JsonIgnore
	public void setIsCatalogueUser(
		UnsafeSupplier<Boolean, Exception> isCatalogueUserUnsafeSupplier) {

		_isCatalogueUserSupplier = () -> {
			try {
				return isCatalogueUserUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isCatalogueUser;

	@JsonIgnore
	private Supplier<Boolean> _isCatalogueUserSupplier;

	@Schema(example = "Internet of Things")
	public String getJourneyType() {
		if (_journeyTypeSupplier != null) {
			journeyType = _journeyTypeSupplier.get();

			_journeyTypeSupplier = null;
		}

		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;

		_journeyTypeSupplier = null;
	}

	@JsonIgnore
	public void setJourneyType(
		UnsafeSupplier<String, Exception> journeyTypeUnsafeSupplier) {

		_journeyTypeSupplier = () -> {
			try {
				return journeyTypeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String journeyType;

	@JsonIgnore
	private Supplier<String> _journeyTypeSupplier;

	@Schema(example = "6f1fsf5b-5ac4-4gte-afdc-gt56434b8e9")
	public String getLocalSub() {
		if (_localSubSupplier != null) {
			localSub = _localSubSupplier.get();

			_localSubSupplier = null;
		}

		return localSub;
	}

	public void setLocalSub(String localSub) {
		this.localSub = localSub;

		_localSubSupplier = null;
	}

	@JsonIgnore
	public void setLocalSub(
		UnsafeSupplier<String, Exception> localSubUnsafeSupplier) {

		_localSubSupplier = () -> {
			try {
				return localSubUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String localSub;

	@JsonIgnore
	private Supplier<String> _localSubSupplier;

	@Schema(example = "Internet of Things")
	public String getManageUsersSysId() {
		if (_manageUsersSysIdSupplier != null) {
			manageUsersSysId = _manageUsersSysIdSupplier.get();

			_manageUsersSysIdSupplier = null;
		}

		return manageUsersSysId;
	}

	public void setManageUsersSysId(String manageUsersSysId) {
		this.manageUsersSysId = manageUsersSysId;

		_manageUsersSysIdSupplier = null;
	}

	@JsonIgnore
	public void setManageUsersSysId(
		UnsafeSupplier<String, Exception> manageUsersSysIdUnsafeSupplier) {

		_manageUsersSysIdSupplier = () -> {
			try {
				return manageUsersSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String manageUsersSysId;

	@JsonIgnore
	private Supplier<String> _manageUsersSysIdSupplier;

	@Schema(example = "6f19bf9b-4ac4-476e-a1cc-96fe334b8e9")
	public String getMessageId() {
		if (_messageIdSupplier != null) {
			messageId = _messageIdSupplier.get();

			_messageIdSupplier = null;
		}

		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;

		_messageIdSupplier = null;
	}

	@JsonIgnore
	public void setMessageId(
		UnsafeSupplier<String, Exception> messageIdUnsafeSupplier) {

		_messageIdSupplier = () -> {
			try {
				return messageIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String messageId;

	@JsonIgnore
	private Supplier<String> _messageIdSupplier;

	@Schema(example = "Internet of Things")
	public String getNavigationURL() {
		if (_navigationURLSupplier != null) {
			navigationURL = _navigationURLSupplier.get();

			_navigationURLSupplier = null;
		}

		return navigationURL;
	}

	public void setNavigationURL(String navigationURL) {
		this.navigationURL = navigationURL;

		_navigationURLSupplier = null;
	}

	@JsonIgnore
	public void setNavigationURL(
		UnsafeSupplier<String, Exception> navigationURLUnsafeSupplier) {

		_navigationURLSupplier = () -> {
			try {
				return navigationURLUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String navigationURL;

	@JsonIgnore
	private Supplier<String> _navigationURLSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getOamuserId() {
		if (_oamuserIdSupplier != null) {
			oamuserId = _oamuserIdSupplier.get();

			_oamuserIdSupplier = null;
		}

		return oamuserId;
	}

	public void setOamuserId(String oamuserId) {
		this.oamuserId = oamuserId;

		_oamuserIdSupplier = null;
	}

	@JsonIgnore
	public void setOamuserId(
		UnsafeSupplier<String, Exception> oamuserIdUnsafeSupplier) {

		_oamuserIdSupplier = () -> {
			try {
				return oamuserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String oamuserId;

	@JsonIgnore
	private Supplier<String> _oamuserIdSupplier;

	@Schema(example = "Internet of Things")
	public String getUpdateUsersCatalogueSysId() {
		if (_updateUsersCatalogueSysIdSupplier != null) {
			updateUsersCatalogueSysId =
				_updateUsersCatalogueSysIdSupplier.get();

			_updateUsersCatalogueSysIdSupplier = null;
		}

		return updateUsersCatalogueSysId;
	}

	public void setUpdateUsersCatalogueSysId(String updateUsersCatalogueSysId) {
		this.updateUsersCatalogueSysId = updateUsersCatalogueSysId;

		_updateUsersCatalogueSysIdSupplier = null;
	}

	@JsonIgnore
	public void setUpdateUsersCatalogueSysId(
		UnsafeSupplier<String, Exception>
			updateUsersCatalogueSysIdUnsafeSupplier) {

		_updateUsersCatalogueSysIdSupplier = () -> {
			try {
				return updateUsersCatalogueSysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String updateUsersCatalogueSysId;

	@JsonIgnore
	private Supplier<String> _updateUsersCatalogueSysIdSupplier;

	@Schema(example = "Internet of Things")
	public String getUpdateUsersNavigationURL() {
		if (_updateUsersNavigationURLSupplier != null) {
			updateUsersNavigationURL = _updateUsersNavigationURLSupplier.get();

			_updateUsersNavigationURLSupplier = null;
		}

		return updateUsersNavigationURL;
	}

	public void setUpdateUsersNavigationURL(String updateUsersNavigationURL) {
		this.updateUsersNavigationURL = updateUsersNavigationURL;

		_updateUsersNavigationURLSupplier = null;
	}

	@JsonIgnore
	public void setUpdateUsersNavigationURL(
		UnsafeSupplier<String, Exception>
			updateUsersNavigationURLUnsafeSupplier) {

		_updateUsersNavigationURLSupplier = () -> {
			try {
				return updateUsersNavigationURLUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String updateUsersNavigationURL;

	@JsonIgnore
	private Supplier<String> _updateUsersNavigationURLSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CatalogueItemsRequest)) {
			return false;
		}

		CatalogueItemsRequest catalogueItemsRequest =
			(CatalogueItemsRequest)object;

		return Objects.equals(toString(), catalogueItemsRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String Category = getCategory();

		if (Category != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Category\": ");

			sb.append("\"");

			sb.append(_escape(Category));

			sb.append("\"");
		}

		String addUserCatalogueItemSysId = getAddUserCatalogueItemSysId();

		if (addUserCatalogueItemSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"addUserCatalogueItemSysId\": ");

			sb.append("\"");

			sb.append(_escape(addUserCatalogueItemSysId));

			sb.append("\"");
		}

		String addUsersNavigationURL = getAddUsersNavigationURL();

		if (addUsersNavigationURL != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"addUsersNavigationURL\": ");

			sb.append("\"");

			sb.append(_escape(addUsersNavigationURL));

			sb.append("\"");
		}

		String childCustomerId = getChildCustomerId();

		if (childCustomerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"childCustomerId\": ");

			sb.append("\"");

			sb.append(_escape(childCustomerId));

			sb.append("\"");
		}

		String context = getContext();

		if (context != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"context\": ");

			sb.append("\"");

			sb.append(_escape(context));

			sb.append("\"");
		}

		String currentDate = getCurrentDate();

		if (currentDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDate\": ");

			sb.append("\"");

			sb.append(_escape(currentDate));

			sb.append("\"");
		}

		String customerId = getCustomerId();

		if (customerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerId\": ");

			sb.append("\"");

			sb.append(_escape(customerId));

			sb.append("\"");
		}

		String dlmSysId = getDlmSysId();

		if (dlmSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dlmSysId\": ");

			sb.append("\"");

			sb.append(_escape(dlmSysId));

			sb.append("\"");
		}

		String globalSub = getGlobalSub();

		if (globalSub != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"globalSub\": ");

			sb.append("\"");

			sb.append(_escape(globalSub));

			sb.append("\"");
		}

		Boolean isBulkOrderUser = getIsBulkOrderUser();

		if (isBulkOrderUser != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isBulkOrderUser\": ");

			sb.append(isBulkOrderUser);
		}

		Boolean isCatalogueUser = getIsCatalogueUser();

		if (isCatalogueUser != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isCatalogueUser\": ");

			sb.append(isCatalogueUser);
		}

		String journeyType = getJourneyType();

		if (journeyType != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"journeyType\": ");

			sb.append("\"");

			sb.append(_escape(journeyType));

			sb.append("\"");
		}

		String localSub = getLocalSub();

		if (localSub != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"localSub\": ");

			sb.append("\"");

			sb.append(_escape(localSub));

			sb.append("\"");
		}

		String manageUsersSysId = getManageUsersSysId();

		if (manageUsersSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"manageUsersSysId\": ");

			sb.append("\"");

			sb.append(_escape(manageUsersSysId));

			sb.append("\"");
		}

		String messageId = getMessageId();

		if (messageId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"messageId\": ");

			sb.append("\"");

			sb.append(_escape(messageId));

			sb.append("\"");
		}

		String navigationURL = getNavigationURL();

		if (navigationURL != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"navigationURL\": ");

			sb.append("\"");

			sb.append(_escape(navigationURL));

			sb.append("\"");
		}

		String oamuserId = getOamuserId();

		if (oamuserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"oamuserId\": ");

			sb.append("\"");

			sb.append(_escape(oamuserId));

			sb.append("\"");
		}

		String updateUsersCatalogueSysId = getUpdateUsersCatalogueSysId();

		if (updateUsersCatalogueSysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"updateUsersCatalogueSysId\": ");

			sb.append("\"");

			sb.append(_escape(updateUsersCatalogueSysId));

			sb.append("\"");
		}

		String updateUsersNavigationURL = getUpdateUsersNavigationURL();

		if (updateUsersNavigationURL != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"updateUsersNavigationURL\": ");

			sb.append("\"");

			sb.append(_escape(updateUsersNavigationURL));

			sb.append("\"");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.CatalogueItemsRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}