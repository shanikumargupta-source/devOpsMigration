package com.vf.cove.common.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author GhousPasha
 * @generated
 */
@Generated("")
@GraphQLName("CatalogueItem")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "CatalogueItem")
public class CatalogueItem implements Serializable {

	public static CatalogueItem toDTO(String json) {
		return ObjectMapperUtil.readValue(CatalogueItem.class, json);
	}

	public static CatalogueItem unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(CatalogueItem.class, json);
	}

	@Schema
	public String getCapability() {
		if (_capabilitySupplier != null) {
			capability = _capabilitySupplier.get();

			_capabilitySupplier = null;
		}

		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;

		_capabilitySupplier = null;
	}

	@JsonIgnore
	public void setCapability(
		UnsafeSupplier<String, Exception> capabilityUnsafeSupplier) {

		_capabilitySupplier = () -> {
			try {
				return capabilityUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String capability;

	@JsonIgnore
	private Supplier<String> _capabilitySupplier;

	@Schema
	public String getIsStaticURL() {
		if (_isStaticURLSupplier != null) {
			isStaticURL = _isStaticURLSupplier.get();

			_isStaticURLSupplier = null;
		}

		return isStaticURL;
	}

	public void setIsStaticURL(String isStaticURL) {
		this.isStaticURL = isStaticURL;

		_isStaticURLSupplier = null;
	}

	@JsonIgnore
	public void setIsStaticURL(
		UnsafeSupplier<String, Exception> isStaticURLUnsafeSupplier) {

		_isStaticURLSupplier = () -> {
			try {
				return isStaticURLUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String isStaticURL;

	@JsonIgnore
	private Supplier<String> _isStaticURLSupplier;

	@Schema
	public String getName() {
		if (_nameSupplier != null) {
			name = _nameSupplier.get();

			_nameSupplier = null;
		}

		return name;
	}

	public void setName(String name) {
		this.name = name;

		_nameSupplier = null;
	}

	@JsonIgnore
	public void setName(UnsafeSupplier<String, Exception> nameUnsafeSupplier) {
		_nameSupplier = () -> {
			try {
				return nameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String name;

	@JsonIgnore
	private Supplier<String> _nameSupplier;

	@Schema
	public String getNextRenewalDate() {
		if (_nextRenewalDateSupplier != null) {
			nextRenewalDate = _nextRenewalDateSupplier.get();

			_nextRenewalDateSupplier = null;
		}

		return nextRenewalDate;
	}

	public void setNextRenewalDate(String nextRenewalDate) {
		this.nextRenewalDate = nextRenewalDate;

		_nextRenewalDateSupplier = null;
	}

	@JsonIgnore
	public void setNextRenewalDate(
		UnsafeSupplier<String, Exception> nextRenewalDateUnsafeSupplier) {

		_nextRenewalDateSupplier = () -> {
			try {
				return nextRenewalDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String nextRenewalDate;

	@JsonIgnore
	private Supplier<String> _nextRenewalDateSupplier;

	@Schema
	public String getPrice() {
		if (_priceSupplier != null) {
			price = _priceSupplier.get();

			_priceSupplier = null;
		}

		return price;
	}

	public void setPrice(String price) {
		this.price = price;

		_priceSupplier = null;
	}

	@JsonIgnore
	public void setPrice(
		UnsafeSupplier<String, Exception> priceUnsafeSupplier) {

		_priceSupplier = () -> {
			try {
				return priceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String price;

	@JsonIgnore
	private Supplier<String> _priceSupplier;

@Schema
	public String getPriorityOverrideCount() {
		if (_priorityOverrideCountSupplier != null) {
			priorityOverrideCount = _priorityOverrideCountSupplier.get();

			_priorityOverrideCountSupplier = null;
		}

		return priorityOverrideCount;
	}

	public void setPriorityOverrideCount(String priorityOverrideCount) {
		this.priorityOverrideCount = priorityOverrideCount;

		_priorityOverrideCountSupplier = null;
	}

	@JsonIgnore
	public void setPriorityOverrideCount(
		UnsafeSupplier<String, Exception> priorityOverrideCountUnsafeSupplier) {

		_priorityOverrideCountSupplier = () -> {
			try {
				return priorityOverrideCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priorityOverrideCount;

	@JsonIgnore
	private Supplier<String> _priorityOverrideCountSupplier;

	@Schema
	public String getPriorityOverrideRemaining() {
		if (_priorityOverrideRemainingSupplier != null) {
			priorityOverrideRemaining = _priorityOverrideRemainingSupplier.get();

			_priorityOverrideRemainingSupplier = null;
		}

		return priorityOverrideRemaining;
	}

	public void setPriorityOverrideRemaining(String priorityOverrideRemaining) {
		this.priorityOverrideRemaining = priorityOverrideRemaining;

		_priorityOverrideRemainingSupplier = null;
	}

	@JsonIgnore
	public void setPriorityOverrideRemaining(
		UnsafeSupplier<String, Exception> priorityOverrideRemainingUnsafeSupplier) {

		_priorityOverrideRemainingSupplier = () -> {
			try {
				return priorityOverrideRemainingUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String priorityOverrideRemaining;

	@JsonIgnore
	private Supplier<String> _priorityOverrideRemainingSupplier;

	@Schema
	public String getRequestBespokeRemaining() {
		if (_requestBespokeRemainingSupplier != null) {
			requestBespokeRemaining = _requestBespokeRemainingSupplier.get();

			_requestBespokeRemainingSupplier = null;
		}

		return requestBespokeRemaining;
	}

	public void setRequestBespokeRemaining(String requestBespokeRemaining) {
		this.requestBespokeRemaining = requestBespokeRemaining;

		_requestBespokeRemainingSupplier = null;
	}

	@JsonIgnore
	public void setRequestBespokeRemaining(
		UnsafeSupplier<String, Exception> requestBespokeRemainingUnsafeSupplier) {

		_requestBespokeRemainingSupplier = () -> {
			try {
				return requestBespokeRemainingUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String requestBespokeRemaining;

	@JsonIgnore
	private Supplier<String> _requestBespokeRemainingSupplier;

	@Schema
	public String getRequestBespokeCount() {
		if (_requestBespokeCountSupplier != null) {
			requestBespokeCount = _requestBespokeCountSupplier.get();

			_requestBespokeCountSupplier = null;
		}

		return requestBespokeCount;
	}

	public void setRequestBespokeCount(String requestBespokeCount) {
		this.requestBespokeCount = requestBespokeCount;

		_requestBespokeCountSupplier = null;
	}

	@JsonIgnore
	public void setRequestBespokeCount(
		UnsafeSupplier<String, Exception> requestBespokeCountUnsafeSupplier) {

		_requestBespokeCountSupplier = () -> {
			try {
				return requestBespokeCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String requestBespokeCount;

	@JsonIgnore
	private Supplier<String> _requestBespokeCountSupplier;

	@Schema
	public String getRequestDirectAccessCount() {
		if (_requestDirectAccessCountSupplier != null) {
			requestDirectAccessCount = _requestDirectAccessCountSupplier.get();

			_requestDirectAccessCountSupplier = null;
		}

		return requestDirectAccessCount;
	}

	public void setRequestDirectAccessCount(String requestDirectAccessCount) {
		this.requestDirectAccessCount = requestDirectAccessCount;

		_requestDirectAccessCountSupplier = null;
	}

	@JsonIgnore
	public void setRequestDirectAccessCount(
		UnsafeSupplier<String, Exception> requestDirectAccessCountUnsafeSupplier) {

		_requestDirectAccessCountSupplier = () -> {
			try {
				return requestDirectAccessCountUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String requestDirectAccessCount;

	@JsonIgnore
	private Supplier<String> _requestDirectAccessCountSupplier;

	@Schema
	public String getRequestDirectAccessRemaining() {
		if (_requestDirectAccessRemainingSupplier != null) {
			requestDirectAccessRemaining = _requestDirectAccessRemainingSupplier.get();

			_requestDirectAccessRemainingSupplier = null;
		}

		return requestDirectAccessRemaining;
	}

	public void setRequestDirectAccessRemaining(String requestDirectAccessRemaining) {
		this.requestDirectAccessRemaining = requestDirectAccessRemaining;

		_requestDirectAccessRemainingSupplier = null;
	}

	@JsonIgnore
	public void setRequestDirectAccessRemaining(
		UnsafeSupplier<String, Exception> requestDirectAccessRemainingUnsafeSupplier) {

		_requestDirectAccessRemainingSupplier = () -> {
			try {
				return requestDirectAccessRemainingUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String requestDirectAccessRemaining;

	@JsonIgnore
	private Supplier<String> _requestDirectAccessRemainingSupplier;

	@Schema
	public String getStaticURL() {
		if (_staticURLSupplier != null) {
			staticURL = _staticURLSupplier.get();

			_staticURLSupplier = null;
		}

		return staticURL;
	}

	public void setStaticURL(String staticURL) {
		this.staticURL = staticURL;

		_staticURLSupplier = null;
	}

	@JsonIgnore
	public void setStaticURL(
		UnsafeSupplier<String, Exception> staticURLUnsafeSupplier) {

		_staticURLSupplier = () -> {
			try {
				return staticURLUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String staticURL;

	@JsonIgnore
	private Supplier<String> _staticURLSupplier;

	@Schema
	public String getSummary() {
		if (_summarySupplier != null) {
			summary = _summarySupplier.get();

			_summarySupplier = null;
		}

		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;

		_summarySupplier = null;
	}

	@JsonIgnore
	public void setSummary(
		UnsafeSupplier<String, Exception> summaryUnsafeSupplier) {

		_summarySupplier = () -> {
			try {
				return summaryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String summary;

	@JsonIgnore
	private Supplier<String> _summarySupplier;

	@Schema
	public String getSysId() {
		if (_sysIdSupplier != null) {
			sysId = _sysIdSupplier.get();

			_sysIdSupplier = null;
		}

		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;

		_sysIdSupplier = null;
	}

	@JsonIgnore
	public void setSysId(
		UnsafeSupplier<String, Exception> sysIdUnsafeSupplier) {

		_sysIdSupplier = () -> {
			try {
				return sysIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String sysId;

	@JsonIgnore
	private Supplier<String> _sysIdSupplier;

	@Schema
	public String getTier_1() {
		if (_tier_1Supplier != null) {
			tier_1 = _tier_1Supplier.get();

			_tier_1Supplier = null;
		}

		return tier_1;
	}

	public void setTier_1(String tier_1) {
		this.tier_1 = tier_1;

		_tier_1Supplier = null;
	}

	@JsonIgnore
	public void setTier_1(
		UnsafeSupplier<String, Exception> tier_1UnsafeSupplier) {

		_tier_1Supplier = () -> {
			try {
				return tier_1UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String tier_1;

	@JsonIgnore
	private Supplier<String> _tier_1Supplier;

	@Schema
	public String getTier_2() {
		if (_tier_2Supplier != null) {
			tier_2 = _tier_2Supplier.get();

			_tier_2Supplier = null;
		}

		return tier_2;
	}

	public void setTier_2(String tier_2) {
		this.tier_2 = tier_2;

		_tier_2Supplier = null;
	}

	@JsonIgnore
	public void setTier_2(
		UnsafeSupplier<String, Exception> tier_2UnsafeSupplier) {

		_tier_2Supplier = () -> {
			try {
				return tier_2UnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String tier_2;

	@JsonIgnore
	private Supplier<String> _tier_2Supplier;

	@Schema
	public String getType() {
		if (_typeSupplier != null) {
			type = _typeSupplier.get();

			_typeSupplier = null;
		}

		return type;
	}

	public void setType(String type) {
		this.type = type;

		_typeSupplier = null;
	}

	@JsonIgnore
	public void setType(UnsafeSupplier<String, Exception> typeUnsafeSupplier) {
		_typeSupplier = () -> {
			try {
				return typeUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String type;

	@JsonIgnore
	private Supplier<String> _typeSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof CatalogueItem)) {
			return false;
		}

		CatalogueItem catalogueItem = (CatalogueItem)object;

		return Objects.equals(toString(), catalogueItem.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String capability = getCapability();

		if (capability != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"capability\": ");

			sb.append("\"");

			sb.append(_escape(capability));

			sb.append("\"");
		}

		String isStaticURL = getIsStaticURL();

		if (isStaticURL != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isStaticURL\": ");

			sb.append("\"");

			sb.append(_escape(isStaticURL));

			sb.append("\"");
		}

		String name = getName();

		if (name != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"name\": ");

			sb.append("\"");

			sb.append(_escape(name));

			sb.append("\"");
		}
		String nextRenewalDate = getNextRenewalDate();

		if (nextRenewalDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"nextRenewalDate\": ");

			sb.append("\"");

			sb.append(_escape(nextRenewalDate));

			sb.append("\"");
		}

		String price = getPrice();

		if (price != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"price\": ");

			sb.append("\"");

			sb.append(_escape(price));

			sb.append("\"");
		}

		String priorityOverrideCount = getPriorityOverrideCount();

		if (priorityOverrideCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priorityOverrideCount\": ");

			sb.append("\"");

			sb.append(_escape(priorityOverrideCount));

			sb.append("\"");
		}

        String priorityOverrideRemaining = getPriorityOverrideRemaining();

		if (priorityOverrideRemaining != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"priorityOverrideRemaining\": ");

			sb.append("\"");

			sb.append(_escape(priorityOverrideRemaining));

			sb.append("\"");
		}

		String requestBespokeRemaining = getRequestBespokeRemaining();

		if (requestBespokeRemaining != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"requestBespokeRemaining\": ");

			sb.append("\"");

			sb.append(_escape(requestBespokeRemaining));

			sb.append("\"");
		}

		String requestBespokeCount = getRequestBespokeCount();

		if (requestBespokeCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"requestBespokeCount\": ");

			sb.append("\"");

			sb.append(_escape(requestBespokeCount));

			sb.append("\"");
		}

		String requestDirectAccessCount = getRequestDirectAccessCount();

		if (requestDirectAccessCount != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"requestDirectAccessCount\": ");

			sb.append("\"");

			sb.append(_escape(requestDirectAccessCount));

			sb.append("\"");
		}

		String requestDirectAccessRemaining = getRequestDirectAccessRemaining();

		if (requestDirectAccessRemaining != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"requestDirectAccessRemaining\": ");

			sb.append("\"");

			sb.append(_escape(requestDirectAccessRemaining));

			sb.append("\"");
		}

		String staticURL = getStaticURL();

		if (staticURL != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"staticURL\": ");

			sb.append("\"");

			sb.append(_escape(staticURL));

			sb.append("\"");
		}

		String summary = getSummary();

		if (summary != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"summary\": ");

			sb.append("\"");

			sb.append(_escape(summary));

			sb.append("\"");
		}

		String sysId = getSysId();

		if (sysId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sysId\": ");

			sb.append("\"");

			sb.append(_escape(sysId));

			sb.append("\"");
		}

		String tier_1 = getTier_1();

		if (tier_1 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tier_1\": ");

			sb.append("\"");

			sb.append(_escape(tier_1));

			sb.append("\"");
		}

		String tier_2 = getTier_2();

		if (tier_2 != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tier_2\": ");

			sb.append("\"");

			sb.append(_escape(tier_2));

			sb.append("\"");
		}

		String type = getType();

		if (type != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"type\": ");

			sb.append("\"");

			sb.append(_escape(type));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.common.dto.v1_0.CatalogueItem",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}