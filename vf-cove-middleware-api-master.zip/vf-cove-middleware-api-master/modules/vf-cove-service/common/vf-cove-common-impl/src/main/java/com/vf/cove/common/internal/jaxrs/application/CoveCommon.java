package com.vf.cove.common.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author GhousPasha
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false", "osgi.jaxrs.application.base=/vf-cove-common",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=vf-cove-common",
        "auth.verifier.guest.allowed=false"
	},
	service = Application.class
)
@Generated("")
public class CoveCommon extends Application {
}
