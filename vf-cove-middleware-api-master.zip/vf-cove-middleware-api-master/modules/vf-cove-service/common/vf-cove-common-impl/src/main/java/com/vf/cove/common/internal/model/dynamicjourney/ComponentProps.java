package com.vf.cove.common.internal.model.dynamicjourney;

public class ComponentProps {

	private String inputLabel;
	private String isRequired;
	private String maxLength;
	private String model;
	private String selectIpLabel;
	private String inputLabel_label;
	private String inputLabel_id;
	private SelectDropDown selectFieldValues;

	public String getInputLabel_label() {
		return inputLabel_label;
	}

	public void setInputLabel_label(String inputLabel_label) {
		this.inputLabel_label = inputLabel_label;
	}

	public String getInputLabel_id() {
		return inputLabel_id;
	}

	public void setInputLabel_id(String inputLabel_id) {
		this.inputLabel_id = inputLabel_id;
	}

	public String getInputLabel() {
		return inputLabel;
	}

	public void setInputLabel(String inputLabel) {
		this.inputLabel = inputLabel;
	}

	public String getIsRequired() {
		return isRequired;
	}

	public void setIsRequired(String isRequired) {
		this.isRequired = isRequired;
	}

	public String getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(String maxLength) {
		this.maxLength = maxLength;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getSelectIpLabel() {
		return selectIpLabel;
	}

	public void setSelectIpLabel(String selectIpLabel) {
		this.selectIpLabel = selectIpLabel;
	}

	public SelectDropDown getSelectFieldValues() {
		return selectFieldValues;
	}

	public void setSelectFieldValues(SelectDropDown selectFieldValues) {
		this.selectFieldValues = selectFieldValues;
	}

}
