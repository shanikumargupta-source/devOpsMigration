package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.CommonLogger;
import com.vf.cove.common.dto.v1_0.CommonLoggerResponse;
import com.vf.cove.common.internal.resource.service.CommonLoggerService;
import com.vf.cove.common.resource.v1_0.CommonLoggerResponseResource;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author GhousPasha
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/common-logger-response.properties",
	scope = ServiceScope.PROTOTYPE, service = CommonLoggerResponseResource.class
)
public class CommonLoggerResponseResourceImpl
	extends BaseCommonLoggerResponseResourceImpl {


		@Reference(unbind = "-")
		private CommonLoggerService commonLoggerService;
		
		@Override
		public CommonLoggerResponse postCommonLogger(CommonLogger commonLogger) throws Exception {
	
			String currentTime = RequestUtils.getUTCDate();
			return commonLoggerService.saveCommonLogger(commonLogger, contextUser, currentTime);
	
		}
	}