package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.common.dto.v1_0.CodeList;
import com.vf.cove.common.dto.v1_0.CodeListRequest;
import com.vf.cove.common.dto.v1_0.CodeListResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Component(service = CodeListService.class)
public class CodeListService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CodeListService.class);

	private static final String CODE_LIST_URI = "/cove/codeList/getCodeList";

	@Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	public CodeListResponse postCodeList(CodeListRequest codeListRequest, String messageId) throws Exception {
		LOGGER.info(" CodeList service");
		CodeListResponse coveResponse = new CodeListResponse();

		final String request = codeListRequest.toString();
        String relativeUrl = CODE_LIST_URI ;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);

        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            restAPIRequest.addHeader(CommonConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
        LOGGER.info("Request Headers.. {}", restAPIRequest.getHeaders());

        CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);


		if (StringUtils.isEmpty(dxlResponse.getData())) {
			throw new ServiceException(CommonConstants.ERROR_CODE_500, CommonConstants.INTERNAL_SERVER_ERROR);
		} else {
			try {
				InputStream in = BusinessServices.class
						.getResourceAsStream(CommonConstants.CODE_LIST_RESPONSE_DEFINITION);
				String decodedResponse = dxlResponse.getData();
				LOGGER.info("Get Code List DXL Response UTF-8 ...{}", decodedResponse);

				JsonNode transformedJsonNode = responseParser.parse(in, decodedResponse);
				LOGGER.debug("Transformed Response {} ", transformedJsonNode.toString());

				List<CodeList> codeListArray = new ArrayList<>();
				transformedJsonNode.forEach(node -> {
					CodeList codeList = null;
					try {
						codeList = responseParser.getCoveMapper().readValue(node.toString(), CodeList.class);
					} catch (Exception e) {
						LOGGER.error("Exception {} ", e);
					}
					if (codeList != null) {
						codeListArray.add(codeList);
					}
				});
				coveResponse.setCodeList(codeListArray.toArray(new CodeList[codeListArray.size()]));
			} catch (Exception ex) {
				LOGGER.error("Exception {} ", ex);
			}
		}
		return coveResponse;
	}

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }
}
