package com.vf.cove.common.internal.model.dynamicjourney;

public class NextAndPreviousStepNames {

	private String nextStepName;
	private String prevStepName;

	public NextAndPreviousStepNames(String nextStepName, String prevStepName) {
		this.nextStepName = nextStepName;
		this.prevStepName = prevStepName;
	}

	public String getNextStepName() {
		return nextStepName;
	}

	public void setNextStepName(String nextStepName) {
		this.nextStepName = nextStepName;
	}

	public String getPrevStepName() {
		return prevStepName;
	}

	public void setPrevStepName(String prevStepName) {
		this.prevStepName = prevStepName;
	}
}
