package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "componentType", "props", "alignmentClass", "validateForm" })
public class FooterField {

	@JsonProperty("componentType")
	private String componentType;
	@JsonProperty("props")
	private Props_ props;
	@JsonProperty("alignmentClass")
	private String alignmentClass;
	@JsonProperty("validateForm")
	private boolean validateForm;

	@JsonProperty("componentType")
	public String getComponentType() {
		return componentType;
	}

	@JsonProperty("componentType")
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

	@JsonProperty("props")
	public Props_ getProps() {
		return props;
	}

	@JsonProperty("props")
	public void setProps(Props_ props) {
		this.props = props;
	}

	@JsonProperty("alignmentClass")
	public String getAlignmentClass() {
		return alignmentClass;
	}

	@JsonProperty("alignmentClass")
	public void setAlignmentClass(String alignmentClass) {
		this.alignmentClass = alignmentClass;
	}

	@JsonProperty("validateForm")
	public boolean isValidateForm() {
		return validateForm;
	}

	@JsonProperty("validateForm")
	public void setValidateForm(boolean validateForm) {
		this.validateForm = validateForm;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("componentType", componentType).append("props", props)
				.append("alignmentClass", alignmentClass).append("validateForm", validateForm).toString();
	}

}
