<@compress single_line=true>
{
  "sectionSysId": "${sysId}",
  "stepSequenceNum": "${stepSequenceNum}",
  "currentStepName": "${currentStepName}",
  "id": "${id}",
  "nextStepName": "${nextStepName}",
  "prevStepName": "${prevStepName}",
  "containerClass": "dj-raise-incident-wrapper dj--catalogue--wrapper",
  "listOfFields": [
    {
      "componentType": "Label",
      "customClass": "summaryLabel",
      "props": {
        "data": {
          "id": "SelectedCatBusinessService_label",
          "htmlFor": "SelectedCatBusinessService",
          "type": "labelHeadingNBCenter",
          "labelname": "",
          "apiData": "@FormData.labelname|generalInfo.businessService"
        }
      }
    },
    {
      "componentType": "Accordion",
      "customClass": "custom__accordion__wrapper",
      "props": {
        "data": {
          "displayAccordion": true,
          "id": "detailsForm",
          "name": "detailsForm",
          "alwaysExpanded": true,
          "header": {
            "type": "Title",
            "headerData": {
              "title": "${headerData}"
            }
          },
          "content": {
            "type": "FormContent",
            "contentData": []
          }
        }
      }
    }
  ],
  "footerFields": [
    {
      "componentType": "Button",
      "props": {
        "data": {
          "buttonType": "button",
          "isIcon": true,
          "name": "${footerNext}",
          "location": "right",
          "id": "nextButton",
          "type": "primary",
          "CreateHandler": "incidentNextClickHandler|onClick"
        }
      },
      "alignmentClass": "pull_right",
      "validateForm": true
    },
    {
      "componentType": "Button",
      "props": {
        "data": {
          "location": "left",
          "isIcon": true,
          "id": "previousButton",
          "name": "${footerPrevious}",
          "type": "secondary",
          "buttonType": "button",
          "CreateHandler": "backClickHandler|onClick"
        }
      },
      "alignmentClass": "pull_right",
      "validateForm": false
    },
    {
      "componentType": "Button",
      "props": {
        "data": {
          "id": "backToTickets",
          "name": "Back to catalogue",
          "type": "tertiary",
          "buttonType": "button",
          "CreateHandler": "redirectToCatalog|onClick"
        }
      },
      "alignmentClass": "pull_left",
      "validateForm": false
    }
  ],
  "validationRules": {
    "rules": [
      {
        "ruleName": "REQUIRED",
        "applicableFields": [],
        "message": "This is mandatory field"
      }
    ],
    "messageProps": {
      "type": "warning",
      "name": "warning",
      "id": "validationError",
      "lightBackground": true,
      "arrowRequired": true,
      "messageTitle": "Sorry, there were @count errors in the following fields",
      "messageBody": ""
    }
  }
}
</@compress>