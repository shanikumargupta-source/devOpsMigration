package com.vf.cove.common.internal.model.dynamicjourney;

public class GroupBy {

	private String[] listOfFieldIds;

	public String[] getListOfFieldIds() {
		return listOfFieldIds;
	}

	public void setListOfFieldIds(String[] listOfFieldIds) {
		this.listOfFieldIds = listOfFieldIds;
	}
}
