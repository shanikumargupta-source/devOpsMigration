package com.vf.cove.common.internal.resource.service;

import com.vf.cove.common.dto.v1_0.ExportPDF;
import com.vf.cove.common.dto.v1_0.ExportPDFRequest;
import com.vf.cove.common.dto.v1_0.ExportPDFResponse;
import com.vf.cove.common.internal.util.CommonUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.jsoup.parser.Parser;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Base64;
import java.util.Map;
import java.util.Set;

@Component(service = ExportPDFService.class)
public class ExportPDFService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExportPDFService.class);
	private static final String PDF_EXTENSION = ".pdf";
	private static final String UTF_8 = "UTF-8";

    @Reference
    private CommonUtils commonUtils;
	public ExportPDFResponse exportPDF(Map<String, Object> inputParams, ExportPDFRequest exportPDFRequest)
			throws Exception {

		ExportPDFResponse coveResponse = new ExportPDFResponse();
		ExportPDF exportPDF = new ExportPDF();
		coveResponse.setExportPDF(exportPDF);

		String referenceNumber = exportPDFRequest.getReferenceNumber();
		String templatePath = getTemplatePath(exportPDFRequest.getRequestType());

		if (ObjectUtils.isNotEmpty(inputParams) && ObjectUtils.isNotEmpty(referenceNumber)
				&& ObjectUtils.isNotEmpty(templatePath)) {

			if (ObjectUtils.isNotEmpty(inputParams)) {
				String htmlString = commonUtils.getDXLRequest(inputParams, inputParams, templatePath);

				if (StringUtils.isNotEmpty(htmlString) && StringUtils.isNotEmpty(referenceNumber)) {
					File pdfFile = createPDFFile(referenceNumber, htmlString);
					String base64String = convertFiletoBase64String(pdfFile);
					exportPDF.setFileName(referenceNumber + PDF_EXTENSION);
					exportPDF.setFileContent(base64String);
					if (pdfFile != null) {
						boolean isRemoved = pdfFile.delete();
						LOGGER.debug("PDF file erased: {}", isRemoved);
					}
				}
			}
		}
		return coveResponse;
	}

	private File createPDFFile(String referenceNumber, String htmlContent) throws IOException {
		File pdfFile = null;
		OutputStream outputStream = null;

		try {
            pdfFile = File.createTempFile(referenceNumber, PDF_EXTENSION);

			LOGGER.debug("Get path of PDF {} ", pdfFile.getAbsolutePath());
			outputStream = new FileOutputStream(pdfFile.getAbsolutePath());

			LOGGER.debug("HTML content before parsing : {}", htmlContent);

			Document doc = Jsoup.parse(new ByteArrayInputStream(htmlContent.getBytes()), UTF_8, StringUtils.EMPTY,
					Parser.xmlParser());
			doc.outputSettings().charset(UTF_8);
			doc.outputSettings().escapeMode(Entities.EscapeMode.xhtml);

			ITextRenderer renderer = new ITextRenderer();
			renderer.setDocumentFromString(doc.toString());
			renderer.layout();
			renderer.createPDF(outputStream);
		} catch (Exception ex) {
            if (outputStream != null) {
                outputStream.close();
            }
			LOGGER.error("Exception in temp PDF file creation ", ex);
		}
		return pdfFile;
	}

	private String convertFiletoBase64String(File file) {
		try {
			byte[] pdf = FileUtils.readFileToByteArray(file);
			return Base64.getEncoder().encodeToString(pdf);
		} catch (Exception ex) {
			LOGGER.error("Exception in base64 file conversion {} ", ex);
		}
		return StringUtils.EMPTY;
	}

	private String getTemplatePath(String type) {
		if (!type.isEmpty()) {
			return String.format("/templates/%s.html", type);
		}
		return StringUtils.EMPTY;
	}
}
