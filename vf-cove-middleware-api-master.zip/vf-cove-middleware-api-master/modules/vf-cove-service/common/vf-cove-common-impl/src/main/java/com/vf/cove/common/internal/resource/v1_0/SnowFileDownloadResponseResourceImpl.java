package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.SnowFileDownloadRequest;
import com.vf.cove.common.dto.v1_0.SnowFileDownloadResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.SnowFileDownloadService;
import com.vf.cove.common.resource.v1_0.SnowFileDownloadResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/snow-file-download-response.properties", scope = ServiceScope.PROTOTYPE, service = SnowFileDownloadResponseResource.class)
public class SnowFileDownloadResponseResourceImpl extends BaseSnowFileDownloadResponseResourceImpl {

	@Reference(unbind = "-")
	private SnowFileDownloadService fileDownloadService;

	public SnowFileDownloadResponse postDownloadFileFromSNOW(SnowFileDownloadRequest snowFileDownloadRequest)
			throws Exception {
		requiredFieldValidation(snowFileDownloadRequest);
		snowFileDownloadRequest.setUserEmail(contextUser.getEmailAddress());
		snowFileDownloadRequest.setLegalOrgId(String.valueOf(
				contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
		return fileDownloadService.postDownloadFileFromSNow(snowFileDownloadRequest);
	}

	private void requiredFieldValidation(SnowFileDownloadRequest request) throws Exception {
		if (StringUtils.isEmpty(request.getCapability()) || StringUtils.isEmpty(request.getAttachmentId())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
	}
}
