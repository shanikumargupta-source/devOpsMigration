package com.vf.cove.common.internal.resource.v1_0;

import com.liferay.portal.vulcan.multipart.BinaryFile;
import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.vf.cove.common.dto.v1_0.Attachment;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.SnowFilesUploadService;
import com.vf.cove.common.resource.v1_0.AttachmentResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/attachment.properties", scope = ServiceScope.PROTOTYPE, service = AttachmentResource.class)
public class AttachmentResourceImpl extends BaseAttachmentResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(SnowFilesUploadResponseResourceImpl.class);

	@Reference(unbind = "-")
	private SnowFilesUploadService filesUploadService;

	@Override
	public Attachment postAttachment(MultipartBody multipartBody) throws Exception {
		LOGGER.info("Inside postAttachment");

		BinaryFile binaryFile = multipartBody.getBinaryFile("file");
		Attachment attachment = multipartBody.getValueAsInstance("attachment", Attachment.class);

		if (binaryFile == null || attachment == null || StringUtils.isBlank(binaryFile.getFileName())
				|| StringUtils.isBlank(attachment.getTicketId()) || StringUtils.isBlank(attachment.getCapability())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
		LOGGER.debug("File name {} Document data {}", binaryFile.getFileName(), attachment);
		attachment.setName(binaryFile.getFileName());
		String userId = contextUser.getEmailAddress();
		String customerId = String
				.valueOf(contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID));
		return filesUploadService.uploadFile(attachment, binaryFile.getInputStream(), userId, customerId);
	}

	@Override
	public Attachment postAttachmentDelete(Attachment attachment) throws Exception {
		LOGGER.debug("Inside delete attachment ");
		if (attachment == null || StringUtils.isBlank(attachment.getTicketId())
				|| StringUtils.isBlank(attachment.getSysId()) || StringUtils.isBlank(attachment.getCapability())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
		String userId = contextUser.getEmailAddress();
		String customerId = String
				.valueOf(contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID));
		return filesUploadService.deleteAttachment(attachment, userId, customerId);
	}

}
