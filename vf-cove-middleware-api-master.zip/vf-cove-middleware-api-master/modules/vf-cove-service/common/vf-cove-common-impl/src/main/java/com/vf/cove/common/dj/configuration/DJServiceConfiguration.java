package com.vf.cove.common.dj.configuration;

import aQute.bnd.annotation.metatype.Meta;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

@ExtendedObjectClassDefinition(category = "vodafone")
@Meta.OCD(id = "com.vf.cove.common.dj.configuration.DJServiceConfiguration", localization = "content/Language", name = "vf-dj-configuration")
public interface DJServiceConfiguration {

	String PID = "com.vf.cove.common.dj.configuration.DJServiceConfiguration";

	@Meta.AD(deflt = "", required = false, description = "vf-dj-vonec-description")
	public String vonecSysId();

	@Meta.AD(deflt = "{}", required = false, description = "vf-dj-validation-messages")
	public String validationMessages();

}
