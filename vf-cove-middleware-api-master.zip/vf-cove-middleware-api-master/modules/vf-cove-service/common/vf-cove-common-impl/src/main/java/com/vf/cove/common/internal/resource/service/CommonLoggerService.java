package com.vf.cove.common.internal.resource.service;

import com.liferay.portal.kernel.audit.AuditException;
import com.liferay.portal.kernel.audit.AuditMessage;
import com.liferay.portal.kernel.audit.AuditRouter;
import com.liferay.portal.kernel.json.JSONFactory;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.security.audit.event.generators.constants.EventTypes;
import com.vf.cove.common.dto.v1_0.CommonLogger;
import com.vf.cove.common.dto.v1_0.CommonLoggerResponse;
import com.vf.cove.common.internal.model.CommonLoggerConstants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component(service = CommonLoggerService.class)
public class CommonLoggerService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonLoggerService.class);
	
	@Reference
	private AuditRouter auditRouter;
	
	@Reference
	private JSONFactory jsonFactory;

	public CommonLoggerResponse saveCommonLogger(CommonLogger commonLoggerRequest, User user , String currentTime) throws Exception {
		LOGGER.info("coming inside the commonlogger for Save Excel");
		CommonLoggerResponse commonLoggerResponse = new CommonLoggerResponse();
		try {

			JSONObject additionalInfoJSONObject = jsonFactory.createJSONObject();

			additionalInfoJSONObject.put(CommonLoggerConstants.JOURNEY_NAME, commonLoggerRequest.getJourneyName());
			additionalInfoJSONObject.put(CommonLoggerConstants.CURRENT_TIME, currentTime);
			additionalInfoJSONObject.put(CommonLoggerConstants.USER_EMAIL, user.getEmailAddress());

			AuditMessage auditMessage = new AuditMessage(EventTypes.ADD, user.getCompanyId(), user.getUserId(),
					user.getFullName(), CommonLogger.class.getName(), String.valueOf(user.getPrimaryKey()), null,
					additionalInfoJSONObject);

			auditRouter.route(auditMessage);
			commonLoggerResponse.setStatus("Log Saved Successfully!");
			LOGGER.info(user.getEmailAddress() +" Saved Excel {}",additionalInfoJSONObject.toJSONString());
			return commonLoggerResponse;
		} catch (Exception e) {
			throw new AuditException();
		}
	}
}