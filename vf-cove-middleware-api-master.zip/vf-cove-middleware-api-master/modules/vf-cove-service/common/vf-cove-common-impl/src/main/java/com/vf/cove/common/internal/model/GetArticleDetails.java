package com.vf.cove.common.internal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "GetArticleDetails")
public class GetArticleDetails {

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleID;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleSysID;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String name;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String desc;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleType;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleViewCount;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleBody;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleRating;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleLikes;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String articleDislikes;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected List<ArticleAttachment> attachments;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected List<BusinessServices> businessService;

	public String getArticleID() {
		return articleID;
	}

	public void setArticleID(String articleID) {
		this.articleID = articleID;
	}

	public String getArticleSysID() {
		return articleSysID;
	}

	public void setArticleSysID(String articleSysID) {
		this.articleSysID = articleSysID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getArticleType() {
		return articleType;
	}

	public void setArticleType(String articleType) {
		this.articleType = articleType;
	}

	public String getArticleViewCount() {
		return articleViewCount;
	}

	public void setArticleViewCount(String articleViewCount) {
		this.articleViewCount = articleViewCount;
	}

	public String getArticleBody() {
		return articleBody;
	}

	public void setArticleBody(String articleBody) {
		this.articleBody = articleBody;
	}

	public String getArticleRating() {
		return articleRating;
	}

	public void setArticleRating(String articleRating) {
		this.articleRating = articleRating;
	}

	public String getArticleLikes() {
		return articleLikes;
	}

	public void setArticleLikes(String articleLikes) {
		this.articleLikes = articleLikes;
	}

	public String getArticleDislikes() {
		return articleDislikes;
	}

	public void setArticleDislikes(String articleDislikes) {
		this.articleDislikes = articleDislikes;
	}

	public List<ArticleAttachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<ArticleAttachment> attachments) {
		this.attachments = attachments;
	}

	public List<BusinessServices> getBusinessService() {
		return businessService;
	}

	public void setBusinessService(List<BusinessServices> businessService) {
		this.businessService = businessService;
	}
}
