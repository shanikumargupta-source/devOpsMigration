package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.BusinessServicesRequest;
import com.vf.cove.common.dto.v1_0.BusinessServicesResponse;
import com.vf.cove.common.internal.resource.service.BusinessServices;
import com.vf.cove.common.resource.v1_0.BusinessServicesResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/business-services-response.properties", scope = ServiceScope.PROTOTYPE, service = BusinessServicesResponseResource.class)
public class BusinessServicesResponseResourceImpl extends BaseBusinessServicesResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessServicesResponseResourceImpl.class);
	private static final String NOCONTEXT = "NOCONTEXT";

	@Reference(unbind = "-")
	private BusinessServices businessService;

	public BusinessServicesResponse postBusinessService(BusinessServicesRequest businessServicesRequest)
			throws Exception {
		String messageId = RequestUtils.getUUID();
		LOGGER.info("Invoking businessServices API for messageId {} " + messageId);
		if (ObjectUtils.isNotEmpty(businessServicesRequest) && ObjectUtils.isNotEmpty(contextUser)) {
			String emailId = contextUser.getEmailAddress();
			businessServicesRequest.setUserId(emailId);
			businessServicesRequest.setOamuserId(emailId);
			businessServicesRequest.setCustomerId(String.valueOf(
					contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
			businessServicesRequest.setCurrentDate(RequestUtils.getUTCDate());
			businessServicesRequest.setMessageId(messageId);

			if (businessServicesRequest.getContext() != null
					&& (businessServicesRequest.getContext().equalsIgnoreCase(Constants.INVENTORY) ||
							businessServicesRequest.getContext().equalsIgnoreCase(NOCONTEXT))) {
				businessServicesRequest.setJourneyType(Constants.BUSINESS_SERVICES);
			}
			return businessService.postBusinessService(businessServicesRequest, messageId);
		}
		return new BusinessServicesResponse();
	}
}
