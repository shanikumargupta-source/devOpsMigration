<@compress single_line=true>
{
        "componentType": "Button",
        "props": {
          "data": {
            "location": "left",
            "isIcon": true,
            "id": "previousButton",
            "name": "CI selection",
            "type": "secondary",
            "buttonType": "button",
            "CreateHandler": "backClickHandler|onClick"
          }
        },
        "alignmentClass": "pull_right",
        "validateForm": false
      }
</@compress>