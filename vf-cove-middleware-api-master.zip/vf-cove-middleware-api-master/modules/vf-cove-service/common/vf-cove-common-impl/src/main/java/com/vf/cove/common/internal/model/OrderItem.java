package com.vf.cove.common.internal.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 */
@XmlRootElement(name = "OrderItem")
public class OrderItem {

	@Schema
	public String getEquipmentType() {
		return equipmentType;
	}

	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String equipmentType;

	@Schema
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String productName;

	@Schema
	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String quantity;

	@Schema
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String type;
}
