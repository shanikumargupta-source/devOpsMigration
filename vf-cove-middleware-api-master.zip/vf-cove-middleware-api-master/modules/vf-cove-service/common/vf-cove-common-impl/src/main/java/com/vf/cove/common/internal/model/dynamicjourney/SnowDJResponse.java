package com.vf.cove.common.internal.model.dynamicjourney;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "responseData" })
public class SnowDJResponse {

	@JsonProperty("responseData")
	private DJResponseData responseData;

	@JsonProperty("responseData")
	public DJResponseData getResponseData() {
		return responseData;
	}

	@JsonProperty("responseData")
	public void setResponseData(DJResponseData responseData) {
		this.responseData = responseData;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("responseData", responseData).toString();
	}

}
