package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "rules", "messageProps" })
public class ValidationRules {

	@JsonProperty("rules")
	private List<Rule> rules = null;
	@JsonProperty("messageProps")
	private MessageProps messageProps;

	@JsonProperty("rules")
	public List<Rule> getRules() {
		return rules;
	}

	@JsonProperty("rules")
	public void setRules(List<Rule> rules) {
		this.rules = rules;
	}

	@JsonProperty("messageProps")
	public MessageProps getMessageProps() {
		return messageProps;
	}

	@JsonProperty("messageProps")
	public void setMessageProps(MessageProps messageProps) {
		this.messageProps = messageProps;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("rules", rules).append("messageProps", messageProps).toString();
	}

}
