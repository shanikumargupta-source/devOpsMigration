package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "componentType", "customClass", "props" })
public class ListOfField {

	@JsonProperty("componentType")
	private String componentType;
	@JsonProperty("customClass")
	private String customClass;
	@JsonProperty("props")
	private Props props;

	@JsonProperty("componentType")
	public String getComponentType() {
		return componentType;
	}

	@JsonProperty("componentType")
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

	@JsonProperty("customClass")
	public String getCustomClass() {
		return customClass;
	}

	@JsonProperty("customClass")
	public void setCustomClass(String customClass) {
		this.customClass = customClass;
	}

	@JsonProperty("props")
	public Props getProps() {
		return props;
	}

	@JsonProperty("props")
	public void setProps(Props props) {
		this.props = props;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("componentType", componentType).append("customClass", customClass)
				.append("props", props).toString();
	}

}
