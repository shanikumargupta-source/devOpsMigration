package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.SnowFilesUploadRequest;
import com.vf.cove.common.dto.v1_0.SnowFilesUploadResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.SnowFilesUploadService;
import com.vf.cove.common.resource.v1_0.SnowFilesUploadResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/snow-files-upload-response.properties", scope = ServiceScope.PROTOTYPE, service = SnowFilesUploadResponseResource.class)
public class SnowFilesUploadResponseResourceImpl extends BaseSnowFilesUploadResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(SnowFilesUploadResponseResourceImpl.class);

	@Reference(unbind = "-")
	private SnowFilesUploadService filesUploadService;

	@Override
	public SnowFilesUploadResponse postUploadFilesToSNOW(SnowFilesUploadRequest snowFileUploadRequest)
			throws Exception {
		requiredFieldValidation(snowFileUploadRequest);
		snowFileUploadRequest.setUserEmail(contextUser.getEmailAddress());
		snowFileUploadRequest.setLegalOrgId(String.valueOf(
				contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
		return filesUploadService.postUploadFilesToSNow(snowFileUploadRequest, contextUser, contextCompany);
	}

	private void requiredFieldValidation(SnowFilesUploadRequest request) throws Exception {
		LOGGER.debug("Inside SnowUploadFile - requiredFieldValidation()");
		if (StringUtils.isEmpty(request.getTicketId()) || StringUtils.isEmpty(request.getCapability())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
	}

}
