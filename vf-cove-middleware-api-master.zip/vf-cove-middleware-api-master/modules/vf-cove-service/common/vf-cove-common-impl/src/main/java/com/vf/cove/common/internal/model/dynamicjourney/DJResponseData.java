package com.vf.cove.common.internal.model.dynamicjourney;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "response", "status" })
public class DJResponseData {

	@JsonProperty("response")
	private DJResponse response;
	@JsonProperty("status")
	private String status;

	@JsonProperty("response")
	public DJResponse getResponse() {
		return response;
	}

	@JsonProperty("response")
	public void setResponse(DJResponse response) {
		this.response = response;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("response", response).append("status", status).toString();
	}

}
