package com.vf.cove.common.internal.model.dynamicjourney;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "stepsCount", "steps", "", "description" })
public class DJResponse {

	@JsonProperty("stepsCount")
	private String stepsCount;
	@JsonProperty("steps")
	private List<Step> steps = null;

	@JsonProperty("conditions")
	private List<Condition> conditions;

	@JsonProperty("conditions")
	public List<Condition> getConditions() {
		return conditions;
	}
	@JsonProperty("conditions")
	public void setConditions(List<Condition> conditions) {
		this.conditions = conditions;
	}

	@JsonProperty("description")
	private String description;

	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	@JsonProperty("stepsCount")
	public String getStepsCount() {
		return stepsCount;
	}

	@JsonProperty("stepsCount")
	public void setStepsCount(String stepsCount) {
		this.stepsCount = stepsCount;
	}

	@JsonProperty("steps")
	public List<Step> getSteps() {
		return steps;
	}

	@JsonProperty("steps")
	public void setSteps(List<Step> steps) {
		this.steps = steps;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("stepsCount", stepsCount).append("steps", steps)
				.append("description", description).append("conditions", conditions).toString();
	}

}
