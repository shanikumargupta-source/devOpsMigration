package com.vf.cove.common.internal.resource.v1_0;

import com.liferay.portal.kernel.model.Role;
import com.vf.cove.common.dto.v1_0.CatalogueItemsRequest;
import com.vf.cove.common.dto.v1_0.CatalogueItemsResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.CatalogueItemsService;
import com.vf.cove.common.resource.v1_0.CatalogueItemsResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/catalogue-items-response.properties", scope = ServiceScope.PROTOTYPE, service = CatalogueItemsResponseResource.class)
public class CatalogueItemsResponseResourceImpl extends BaseCatalogueItemsResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CatalogueItemsResponseResourceImpl.class);

    @Reference(unbind = "-")
    private CatalogueItemsService catalogueItemsService;

	public CatalogueItemsResponse postCatalogueItem(CatalogueItemsRequest catalogueItemsRequest) throws Exception {
		String messageId = RequestUtils.getUUID();
		LOGGER.info("Invoking catalogueItems API for messageId {} " + messageId);
		requiredFieldValidations(catalogueItemsRequest);
		if (ObjectUtils.isNotEmpty(catalogueItemsRequest) && ObjectUtils.isNotEmpty(contextUser)) {
			String emailId = contextUser.getEmailAddress();
	        catalogueItemsRequest.setUserId(emailId);
	        catalogueItemsRequest.setOamuserId(emailId);
	        catalogueItemsRequest.setCustomerId(String.valueOf(contextUser.getOrganizations()
	            .get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
	        catalogueItemsRequest.setCurrentDate(RequestUtils.getUTCDate());
	        catalogueItemsRequest.setMessageId(messageId);
	        catalogueItemsRequest.setDlmSysId(Constants.DLM_SYS_ID);
	        catalogueItemsRequest.setManageUsersSysId(Constants.MANAGE_USER_SYS_ID);
	        catalogueItemsRequest.setAddUserCatalogueItemSysId(Constants.ADD_USER_CATALOGUE_SYS_ID);
	        catalogueItemsRequest.setUpdateUsersCatalogueSysId(Constants.UPDATE_USER_CATALOGUE_SYS_ID);
	        catalogueItemsRequest.setAddUsersNavigationURL(Constants.ADD_USER_NAV_URL);
	        catalogueItemsRequest.setUpdateUsersNavigationURL(Constants.UPDATE_USER_NAV_URL);

	        List<String> userRoles = new ArrayList<>();
	        for (Role role : contextUser.getRoles()) {
	            userRoles.add(role.getName().trim());
	        }
	        if (userRoles.contains(Constants.BULK_ORDER_ROLE)) {
	            catalogueItemsRequest.setIsBulkOrderUser(true);
	        }
	        if (userRoles.contains(Constants.SR_CATALOGUE_ROLE)) {
	            catalogueItemsRequest.setIsCatalogueUser(true);
	        }
	       return catalogueItemsService.postCatalogueItem(catalogueItemsRequest, messageId);
		}
		return new CatalogueItemsResponse();
	}

	private void requiredFieldValidations(CatalogueItemsRequest getSRRequest) throws Exception {
        LOGGER.debug("Inside catalogueItems - requiredFieldValidations()");
        if(StringUtils.isEmpty(getSRRequest.getCategory()) ||
        		StringUtils.isEmpty(getSRRequest.getJourneyType())) {
            throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
        }
    }
}
