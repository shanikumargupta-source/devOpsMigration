package com.vf.cove.common.internal.resource.service;

import com.vf.cove.common.dto.v1_0.DownloadMultipleFileFromSNOW;
import com.vf.cove.common.dto.v1_0.DownloadMultipleFileFromSNOWRequest;
import com.vf.cove.common.dto.v1_0.DownloadMultipleFileFromSNOWResponse;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.service.SNowCallProcessor;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.vf.cove.common.internal.model.CommonConstants.*;

@Component(service = SnowMultipleFileDownloadService.class)
public class SnowMultipleFileDownloadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SnowMultipleFileDownloadService.class);

	@Reference(unbind = "-")
	private SNowCallProcessor snowCallProcessor;

	public DownloadMultipleFileFromSNOWResponse postDownloadMultipleFileFromSNow(DownloadMultipleFileFromSNOWRequest request) throws Exception {

		LOGGER.info("DownloadMultipleFilesFromSnow request object {}", request.toString());
		String token = generateSnowToken(request.getUserEmail() , request.getLegalOrgId());
		LOGGER.info("Token {}", token);

		if (StringUtils.isEmpty(token)) {
			throw new ServiceException(500, "Invalid token");
		}

		DownloadMultipleFileFromSNOWResponse downloadMultipleFileFromSNOWResponse = new DownloadMultipleFileFromSNOWResponse();
		List<DownloadMultipleFileFromSNOW> downloadMultipleFileFromSNOWList = new ArrayList<>();

		Map<String, String> headers = new HashMap<>();
		headers.put(CAPABILITY, request.getCapability());
		headers.put(TOKEN, token);

		String[] fileSysIDs = request.getFileSysIDs();

		for (String fileSysId : fileSysIDs) {
			Map<String, String> queryParams = populateQueryParams(request, fileSysId);
			String encodedString = snowCallProcessor.getAttachment(GET_ATTACHMENT, headers, queryParams);
			DownloadMultipleFileFromSNOW downloadFile = null;
			if (StringUtils.isNotEmpty(encodedString)) {
				downloadFile = new DownloadMultipleFileFromSNOW();
				downloadFile.setFileContent(encodedString);
				downloadFile.setFileSysID(fileSysId);
				LOGGER.info("File sysId {} ", fileSysId);
				if(StringUtils.isEmpty(encodedString)) {
					LOGGER.info("Encoded content received is empty");
				}
				downloadMultipleFileFromSNOWList.add(downloadFile);
			}
		}

		downloadMultipleFileFromSNOWResponse.setDownloadMultipleFileFromSNOW(downloadMultipleFileFromSNOWList
				.toArray(new DownloadMultipleFileFromSNOW[downloadMultipleFileFromSNOWList.size()]));

		return downloadMultipleFileFromSNOWResponse;
	}

	private String generateSnowToken(String userEmail ,String legalOrgId) throws Exception {
		return snowCallProcessor.getManageToken(userEmail, legalOrgId);
	}

	private Map<String, String> populateQueryParams(DownloadMultipleFileFromSNOWRequest request, String fileSysId){
		Map<String, String> queryParams = new HashMap<>();
		if(StringUtils.isNotEmpty(request.getBusinessService())) {
			queryParams.put(BUSINESS_SERVICE, request.getBusinessService());
		}
		if(StringUtils.isNotEmpty(request.getTicketId())) {
			queryParams.put(TICKET_ID, request.getTicketId());
		}
		queryParams.put(USER_EMAIL_ID, request.getUserEmail());
		queryParams.put(LEGAL_ORG_ID, request.getLegalOrgId());
		queryParams.put(ATTACHMENT_ID, fileSysId);
		return queryParams;
	}
}
