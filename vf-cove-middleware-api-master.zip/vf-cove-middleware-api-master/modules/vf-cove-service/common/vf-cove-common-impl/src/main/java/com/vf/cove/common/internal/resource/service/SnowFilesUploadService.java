package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.TempFileEntryUtil;
import com.vf.cove.common.dto.v1_0.Attachment;
import com.vf.cove.common.dto.v1_0.SnowFilesUploadRequest;
import com.vf.cove.common.dto.v1_0.SnowFilesUploadResponse;
import com.vf.cove.common.dto.v1_0.UploadFilesToSNOW;
import com.vf.cove.common.internal.util.CommonUtils;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.ServiceContext;
import com.vf.cove.core.restutils.service.SNowCallProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.*;
import java.util.stream.Stream;

import static com.vf.cove.common.internal.model.CommonConstants.*;

@Component(service = SnowFilesUploadService.class)
public class SnowFilesUploadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SnowFilesUploadService.class);

	@Reference
	private GroupLocalService groupLocalService;

	@Reference(unbind = "-")
	private SNowCallProcessor snowCallProcessor;

    @Reference(unbind = "-")
    private CoveResponseParser coveResponseParser;

    @Reference
    private CommonUtils commonUtils;
    private static final String OPERATION = "operation";
    private static final String RESULT = "result";

	public SnowFilesUploadResponse postUploadFilesToSNow(SnowFilesUploadRequest request, User user, Company company)
			throws Exception {
		LOGGER.info("UploadFileToSNOW request object {} ", request.toString());
		String token = generateSnowToken(request.getUserEmail(), request.getLegalOrgId());

		if (StringUtils.isEmpty(token)) {
			throw new ServiceException(500, "Invalid token");
		}

		SnowFilesUploadResponse snowFilesUploadResponse = new SnowFilesUploadResponse();
		List<UploadFilesToSNOW> filesUploadDetails = new ArrayList<>();

		try {
			Group group = groupLocalService.fetchUserGroup(company.getCompanyId(), user.getUserId());
			long groupId = group.getGroupId();
			String[] tempFileNames = TempFileEntryUtil.getTempFileNames(groupId, user.getUserId(),
					TEMP_FILE_FOLDER_NAME);
			for (String tempFileName : tempFileNames) {
				LOGGER.info("Read temp file {} for user {}", tempFileName, user.getUserId());
				FileEntry fileEntry = TempFileEntryUtil.getTempFileEntry(groupId, user.getUserId(),
						TEMP_FILE_FOLDER_NAME, tempFileName);
				try (InputStream inputStream = fileEntry.getContentStream()) {
					if (inputStream != null) {
						String fileContent = Base64.getEncoder().encodeToString(FileUtil.getBytes(inputStream));
						String fileName = Stream.of(tempFileName.split(StringPool.MINUS + StringPool.MINUS))
								.reduce((first, last) -> first).get();
						String originalFileName = fileName + StringPool.PERIOD + fileEntry.getExtension();
						LOGGER.info("Original file name {}", originalFileName);
						if (StringUtils.isEmpty(fileContent)) {
							LOGGER.info("File content is empty");
						}
						Map<String, Object> params = populateParams(request, originalFileName, fileContent, token);

						String response = execute(request, params);

						LOGGER.debug("Upload Attachment response {}", response);
						if (StringUtils.isNotEmpty(response)) {
							UploadFilesToSNOW filesUploadDetail = new UploadFilesToSNOW();
							filesUploadDetail.setFileName(originalFileName);
							filesUploadDetail.setStatus(coveResponseParser.getCoveMapper().readTree(response).path(RESULT).path(OPERATION).asText());
							filesUploadDetails.add(filesUploadDetail);
						}
					}
					TempFileEntryUtil.deleteTempFileEntry(groupId, user.getUserId(), TEMP_FILE_FOLDER_NAME,
							tempFileName);
				} catch (PortalException e) {
					LOGGER.error("Could not read file {} for user {} ", tempFileName, user.getUserId());
				}
			}
		} catch (PortalException e) {
			LOGGER.warn("Read file is failed {} ", e);
		}
		snowFilesUploadResponse
				.setUploadFilesToSNOW(filesUploadDetails.toArray(new UploadFilesToSNOW[filesUploadDetails.size()]));

		return snowFilesUploadResponse;
	}

	private String execute(Object request, Map<String, Object> params) throws Exception {
		String snowRequest = commonUtils.getDXLRequest(request, params, FILE_UPLOAD_REQUEST_DEFINITION);
		LOGGER.debug("Upload request to Snow {}", snowRequest);
		return snowCallProcessor.processPostRequest(UPLOAD_FILE_URL, snowRequest, new ServiceContext());
	}

	public Attachment uploadFile(Attachment attachment, InputStream inputStream, String userId, String legalOrgId)
			throws Exception {

		String token = generateSnowToken(userId, legalOrgId);
		String fileContent = Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream));

		Map<String, Object> params = new HashMap<>();
		params.put(CAPABILITY, attachment.getCapability());
		params.put(TOKEN, token);
		if (StringUtils.isNotEmpty(attachment.getBusinessService())) {
			params.put(BUSINESS_SERVICE, attachment.getBusinessService());
		}
		if (StringUtils.isNotEmpty(attachment.getTicketId())) {
			params.put(TICKET_ID, attachment.getTicketId());
		}
		if (StringUtils.isNotEmpty(attachment.getVariableSysId())) {
			params.put(VARIABLE_ID, attachment.getVariableSysId());
		}
		params.put(USER_EMAIL_ID, userId);
		params.put(LEGAL_ORG_ID, legalOrgId);
		params.put(ATTACHMENT_FILE_NAME, attachment.getName());
		params.put(ATTACHED_CONTENT, fileContent);

		String response = execute(attachment, params);
		JsonNode responseNode = coveResponseParser.getCoveMapper().readTree(response).path(RESULT);
		attachment.setStatus(responseNode.path(OPERATION).asText());
		attachment.setSysId(responseNode.path("attachment_id").asText());
		return attachment;
	}

	private String generateSnowToken(String userEmail, String legalOrgId) throws Exception {
		String token = snowCallProcessor.getManageToken(userEmail, legalOrgId);
		LOGGER.info("Token {} ", token);
		return token;
	}

	private Map<String, Object> populateParams(SnowFilesUploadRequest request, String fileName, String fileContent,
			String token) {
		Map<String, Object> params = new HashMap<>();
		params.put(CAPABILITY, request.getCapability());
		params.put(TOKEN, token);
		if (StringUtils.isNotEmpty(request.getBusinessService())) {
			params.put(BUSINESS_SERVICE, request.getBusinessService());
		}
		if (StringUtils.isNotEmpty(request.getTicketId())) {
			params.put(TICKET_ID, request.getTicketId());
		}
		params.put(USER_EMAIL_ID, request.getUserEmail());
		params.put(LEGAL_ORG_ID, request.getLegalOrgId());
		params.put(ATTACHMENT_FILE_NAME, fileName);
		params.put(ATTACHED_CONTENT, fileContent);
		return params;
	}

	public Attachment deleteAttachment(Attachment attachment, String userId, String customerId) throws Exception {
		LOGGER.info("deleteAttachment sysId {} ", attachment.getSysId());
		String token = generateSnowToken(userId, customerId);
		if (StringUtils.isEmpty(token)) {
			throw new ServiceException(500, "Invalid token");
		}

		Map<String, String> queryParams = new HashMap<>();
		queryParams.put(USER_EMAIL_ID, userId);
		queryParams.put(LEGAL_ORG_ID, customerId);
		queryParams.put(CAPABILITY, attachment.getCapability());
		queryParams.put(BUSINESS_SERVICE, attachment.getBusinessService());
		queryParams.put(TICKET_ID, attachment.getTicketId());
		queryParams.put(ATTACHMENT_ID, attachment.getSysId());

		Map<String, String> headers = new HashMap<>();
		headers.put(TOKEN, token);

		String response = snowCallProcessor.processGetRequest(DELETE_FILE_URL, headers, queryParams);
		LOGGER.debug("Delete Attachment response {}", response);

		Attachment deleteAttachmentResponse = new Attachment();
		if (StringUtils.isNotBlank(response)) {
			JsonNode rootNode = coveResponseParser.getCoveMapper().readTree(response);
			deleteAttachmentResponse.setStatus(rootNode.path(RESULT).path(OPERATION).asText());
		} else {
			throw new ServiceException(500, "Invalid response");
		}
		return deleteAttachmentResponse;
	}

}
