package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ruleName", "applicableFields", "message" })
public class Rule {

	@JsonProperty("ruleName")
	private String ruleName;
	@JsonProperty("applicableFields")
	private List<String> applicableFields = null;
	@JsonProperty("message")
	private String message;

	@JsonProperty("ruleName")
	public String getRuleName() {
		return ruleName;
	}

	@JsonProperty("ruleName")
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	@JsonProperty("applicableFields")
	public List<String> getApplicableFields() {
		return applicableFields;
	}

	@JsonProperty("applicableFields")
	public void setApplicableFields(List<String> applicableFields) {
		this.applicableFields = applicableFields;
	}

	@JsonProperty("message")
	public String getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("ruleName", ruleName).append("applicableFields", applicableFields)
				.append("message", message).toString();
	}

}
