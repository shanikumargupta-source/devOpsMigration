<@compress single_line=true>
{
	<#if token?has_content>		
		"token": "${token}",	
	</#if>
	<#if user_email_id?has_content>		
		"user_email_id": "${user_email_id}",	
	</#if>
	<#if legal_org_id?has_content>		
		"legal_org_id": "${legal_org_id}",
	</#if>
	<#if capability?has_content>		
		"capability": "${capability}",	
	</#if>
	<#if business_service?has_content>		
		"business_service": "${business_service}",	
	</#if>
	<#if ticket_id?has_content>		
		"ticket_id": "${ticket_id}",	
	</#if>
	<#if variable_id?has_content>		
		"u_variable_id": "${variable_id}",	
	</#if>
	<#if attachment_content?has_content>		
		"attachment_content": "${attachment_content}",	
	</#if>
	<#if attachment_file_name?has_content>		
		"attachment_file_name": "${attachment_file_name}",	
	</#if>
	"reported_source":"COVE"
	
}
</@compress>
