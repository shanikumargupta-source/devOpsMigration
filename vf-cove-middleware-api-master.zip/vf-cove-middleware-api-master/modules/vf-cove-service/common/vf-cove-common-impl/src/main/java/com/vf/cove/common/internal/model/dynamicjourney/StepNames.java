package com.vf.cove.common.internal.model.dynamicjourney;

public class StepNames {

	private NextAndPreviousStepNames stepName;
	private NextAndPreviousStepNames footerName;

	public NextAndPreviousStepNames getStepName() {
		return stepName;
	}

	public void setStepName(NextAndPreviousStepNames stepName) {
		this.stepName = stepName;
	}

	public NextAndPreviousStepNames getFooterName() {
		return footerName;
	}

	public void setFooterName(NextAndPreviousStepNames footerName) {
		this.footerName = footerName;
	}
}
