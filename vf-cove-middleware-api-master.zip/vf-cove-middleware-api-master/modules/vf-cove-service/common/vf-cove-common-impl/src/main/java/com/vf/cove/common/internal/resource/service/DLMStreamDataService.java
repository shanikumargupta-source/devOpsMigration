package com.vf.cove.common.internal.resource.service;

import static com.vf.cove.common.internal.model.CommonConstants.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.vf.cove.common.dto.v1_0.ContractDate;
import com.vf.cove.common.dto.v1_0.DLMStreamDataRequest;
import com.vf.cove.common.dto.v1_0.DLMStreamDataResponse;
import com.vf.cove.common.dto.v1_0.Download;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.service.SNowCallProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;

@Component(service = DLMStreamDataService.class)
public class DLMStreamDataService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DLMStreamDataService.class);

    private static DateTimeFormatter fileDateFormat;
    private static Map<String, String> searchTypes;
    private static Map<String, List<String>> columnHeadersMap;
    private static Map<String, List<String>> dataKeysMap;
    private static final String FIELDLIST;

    private static final String ADDRESS_LINE_1 = "Address line 1";

    private static final String FIRST_NAME = "First name";

    private static final String ADDRESS_LINE_2 = "Address line 2";

    private static final String ADDRESS_LINE_3 = "Address line 3";

    private static final String LAST_NAME = "Last name";

    private static final String POSTCODE = "Postcode";

    private static final String MSISDN = "MSISDN";

    private static final String UNSUPPORTED = "Unsupported";

    private static final String CONTACT_NUMBER = "Contact number";

    private static final String EMAIL = "Email";

    private static final String SHIPPING_COUNTRY = "Shipping country";

    private static final String COST_CENTRE = "Cost centre";

    private static final String BUSINESS_UNIT = "Business unit";

    private static final String EQUIPMENT_TYPE = "Equipment type";

    private static final String EQUIPMENT_ID = "Equipment ID";

    private static final String ORDER_DATE = "Order date";

    private static final String BULK_ORDER_ID = "Bulk order ID";

    private static final String ORDER_ID = "Order ID";

    private static final String DEVICE_MAKE = "Device make";

    private static final String DEVICE_MODEL = "Device model";

    private static final String COUNTRY = "Country";

    private static final String END_USER_ID = "End user ID";

    private static final String CONTRACT_START_DATE = "Contract start date";

    private static final String CUSTOMER_REFERENCE = "Customer reference";

    private static final String TRANSACTION_TYPE = "Transaction type";

    private static final String SIM_NUMBER = "SIM number";

    private static final String CONTRACT_END_DATE = "Contract end date";

    private static final String WARRANTY_START_DATE = "Warranty start date";

    private static final String WARRANTY_END_DATE = "Warranty end date";

    private static final String DELIVERY_DATE = "Delivery date";

    private static final String DISPATCH_DATE = "Dispatch date";

    private static final String SIM_ACTIVATION_STATUS = "SIM activation status";

    private static final String SIM_ACTIVATION_DATE = "SIM activation date";

    private static final String COMMERCIAL_MODEL = "Commercial model";

    private static final String LEAVERS = "Leavers";

    private static final String SERIAL_NUMBER = "Serial number";

    private static final String ORGANISATION_NAME = "Organisation name";

    private static final String CUSTOMER_NOTES = "Customer notes";

    private static final String SKU_ID = "SKU ID";

    private static final String SIM_ICCID = "SIM ICCID";

    private static final String FIRSTNAME = "FirstName";

    private static final String ENDUSERADDRESS1 = "EndUserAddress1";

    private static final String ENDUSERADDRESS2 = "EndUserAddress2";

    private static final String ENDUSERADDRESS3 = "EndUserAddress3";

    private static final String USERLASTNAME = "Userlastname";

    private static final String BUSINESSUNIT = "BusinessUnit";

    private static final String STATE = "state";

    private static final String CONTACTNUMBER = "Contactnumber";

    private static final String SHIPPINGCOUNTRY = "ShippingCountry";

    private static final String DLMID = "DLMId";

    private static final String COSTCENTRE = "CostCentre";

    private static final String DEVICEMAKE = "DeviceMake";

    private static final String MODEL = "Model";

    private static final String COUNTRYNAME = "CountryName";

    private static final String EQUIPMENTTYPE = "Equipmenttype";

    private static final String ORDERDATE = "OrderDate";
    private static final String CUSTREF = "CustRef";

    private static final String ORDERID = "OrderID";

    private static final String ENDUSERID = "EndUserID";

    private static final String BULKORDERID = "bulkOrderId";

    private static final String TRANSACTIONTYPE = "TransactionType";

    private static final String CONTRACTENDDATE = "ContractEndDate";

    private static final String WARRANTYENDDATE = "WarrantyEndDate";

    private static final String WARRANTYSTARTDATE = "WarrantyStartDate";

    private static final String DELIVERYDATE = "DeliveryDate";

    private static final String CONTRACTSTARTDATE = "ContractStartDate";

    private static final String GSCATEGORY = "GSCategory";

    private static final String SIMNUMBER = "SIMNumber";

    private static final String DISPATCHEDDATE = "DispatchedDate";

    private static final String SIMACTIVATIONSTATUS = "simActivationStatus";

    private static final String SIMACTIVATIONDATE = "simActivationDate";

    private static final String ORGNAME = "OrgName";


    private static final String SKUID = "SKUId";

    private static final String ASSET_TAG = "AssetTag";

    private static final String CUSTOMERNOTE = "CustomerNote";

    private static final String SERIALNUMBER = "SerialNumber";

    private static final String SIMICCID = "SIMICCID";

    @Reference(unbind = "-")
    private SNowCallProcessor snowCallProcessor;

    @Reference(unbind = "-")
    private CoveResponseParser responseParser;

    public DLMStreamDataResponse postDownload(DLMStreamDataRequest request) throws Exception {
        LOGGER.info("DLM stream api request {}", request.toString());

        CompletableFuture<String> tokenAsync = CompletableFuture.supplyAsync(() -> {
            String token = null;
            try {
                token = generateSnowToken(request.getUserEmail(), request.getLegalOrgId());
                LOGGER.info("Token {}", token);
            } catch (Exception e) {
                LOGGER.error("Error while generating token");
            }
            return token;
        });

        CompletableFuture<String> queryParamsAsync = CompletableFuture.supplyAsync(() -> {
            String snowResponse = null;
            try {
                snowResponse = generateSnowRequestParam(request);
                LOGGER.info("SNOW query params generated");
            } catch (UnsupportedEncodingException e) {
                LOGGER.error("UnsupportedEncodingException for generating the token - {}", e.getMessage());
            }
            return snowResponse;
        });

        CompletableFuture<JsonNode> jsonNodeAsync = tokenAsync.thenCombineAsync(queryParamsAsync,
            (token, queryParam) -> {
                if (StringUtils.isNotEmpty(token) && StringUtils.isNotEmpty(queryParam)) {
                    JsonNode responseNode = null;
                    try {
                        responseNode = getInventoryData(request.getUserEmail(), request.getLegalOrgId(), token,
                            (String) queryParam);
                        LOGGER.debug("responseNode - {} " + responseNode);
                    } catch (Exception e) {
                        LOGGER.error("Exception for fetch inventory data - {}", e.getMessage());
                    }
                    return responseNode;
                } else {
                    throw new ServiceException(CommonConstants.ERROR_CODE_500,
                        CommonConstants.INTERNAL_SERVER_ERROR);
                }
            });

        return jsonNodeAsync.thenApplyAsync(responseNode -> {
            if (null != responseNode) {
                DLMStreamDataResponse dlmDataresponse = new DLMStreamDataResponse();
                Download download = new Download();
                String fileName = String.format(DLM_INVENTORY_S, getFileFormatDate());
                File excelFile = null;
                try {
                    excelFile = File.createTempFile(fileName, EXCEL_XLSX_EXTENSION);
                    LOGGER.info("excel file {} " + excelFile.getAbsolutePath());
                } catch (IOException e) {
                    LOGGER.error("IOException for creating file with name - {}", fileName);
                }
                if (null != excelFile) {
                    try (OutputStream outputStream = new FileOutputStream(excelFile.getAbsolutePath());
                         XSSFWorkbook workbook = new XSSFWorkbook();) {
                        XSSFSheet sheet = workbook.createSheet(DLM_INVENTORY);

                        String contentType = DEFAULT;
                        if (request.getStreamApiDLMUS()) {
                            contentType = STREAM_API_DLMUS;
                        }
                        if (request.getEorReport()) {
                            contentType = EOR_REPORT;
                        }

                        XSSFRow headerRow = sheet.createRow(0);
                        addStringCells(headerRow, columnHeadersMap.get(contentType), getHeaderStyle(workbook));

                        List<String> keys = dataKeysMap.get(contentType);
                        int rowNum = 0;
                        for (JsonNode node : responseNode) {
                            LOGGER.debug("Keys" + keys);
                            LOGGER.info("node {}", node);
                            XSSFRow row = sheet.createRow(rowNum + 1);
                            for (int i = 0; i < keys.size(); i++) {
                                String key = keys.get(i);
                                XSSFCell stringCell = row.createCell(i, CellType.STRING);
                                try {
                                    String value = StringUtils.EMPTY;
                                    if (key.toLowerCase().contains(DATE)) {
                                        value = formatDate(getValue(node.get(key).toString()));
                                    } else if (key.toLowerCase().contains("inheriteddlmid")
                                        || key.toLowerCase().contains(UNSUPPORTED)) {
                                        value = formatInheritDLMId(getValue(node.get(key).toString()));
                                    } else {
                                        value = getValue(node.get(key).toString());
                                    }
                                    stringCell.setCellValue(value);
                                } catch (Exception exception) {
                                    LOGGER.error("Exception {} ", exception);
                                }
                            }
                            rowNum++;
                        }
                        workbook.write(outputStream);
                        LOGGER.info("data write complete in workbook");

                        String base64Content = convertFiletoBase64String(excelFile);
                        if (StringUtils.isNotEmpty(base64Content)) {
                            LOGGER.info("DLM Inventory file generated {} for user {} ", fileName,
                                request.getUserEmail());
                            download.setFileContent(base64Content);
                            download.setFileName(fileName);
                        }
                        dlmDataresponse.setDownload(download);
                        terminateSnowToken(request.getUserEmail(), request.getLegalOrgId(), tokenAsync.get());

                    } catch (Exception exception) {
                        LOGGER.error("Exception in temp excel file creation {} ", exception);
                        throw new ServiceException(CommonConstants.ERROR_CODE_500,
                            CommonConstants.INTERNAL_SERVER_ERROR);
                    } finally {
                        if (excelFile != null) {
                            boolean isRemoved = excelFile.delete();
                            LOGGER.trace("Excel file removed - {}", isRemoved);
                        }
                    }
                }
                LOGGER.info("Successfully returned the xlsx response");
                return dlmDataresponse;
            } else {
                LOGGER.error("Exception while generating node data");
                throw new ServiceException(CommonConstants.ERROR_CODE_500, CommonConstants.INTERNAL_SERVER_ERROR);
            }

        }).join();
    }

    private JsonNode getInventoryData(String userEmail, String legalOrgId, String token, String queryParam)
        throws Exception {
        LOGGER.info("Invoking getInventoryData method");
        JsonNode result = null;
        if (StringUtils.isEmpty(userEmail) || StringUtils.isEmpty(legalOrgId) || StringUtils.isEmpty(queryParam)) {
            LOGGER.error("Inventorydata api - missing mandatory attributes");
            return result;
        }
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put(TABLE_ID, MOBILE_DEVICE);
        queryParams.put(USER_EMAIL_ID, userEmail);
        queryParams.put(LEGAL_ORG_ID, legalOrgId);
        queryParams.put(TOKEN, token);
        queryParams.put(QUERY_PARAMS, queryParam);
        queryParams.put(U_FIELD_LIST, FIELDLIST);

        String responseJson = snowCallProcessor.processGetRequest(INVENTORY_DATA, null, queryParams);
        LOGGER.info("Response received from inventory data API {}...." , responseJson);

        if (StringUtils.isNotEmpty(responseJson)) {
            result = responseParser.getCoveMapper().readTree(responseJson).get(RESPONSE);
        }
        return result;
    }

    private String generateSnowToken(String email, String legalOrgId) throws Exception {
        return getDLMToken(email, legalOrgId, INITIATE, StringUtils.EMPTY);
    }

    private String terminateSnowToken(String email, String legalOrgId, String token) throws Exception {
        return getDLMToken(email, legalOrgId, TERMINATE, token);
    }

    private String getDLMToken(String userEmail, String legalOrgId, String requestType, String oldToken)
        throws Exception {
        LOGGER.info("Invoking getDLMToken method");
        String token = StringUtils.EMPTY;

        if (StringUtils.isEmpty(userEmail) || StringUtils.isEmpty(legalOrgId) || StringUtils.isEmpty(requestType)) {
            LOGGER.error("DLM token api - missing mandatory attributes");
            return token;
        }

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put(TABLE_ID, MOBILE_DEVICE);
        queryParams.put(USER_EMAIL_ID, userEmail);
        queryParams.put(LEGAL_ORG_ID, legalOrgId);
        queryParams.put(U_REQUEST_TYPE, requestType);
        if (requestType.equalsIgnoreCase(TERMINATE)) {
            queryParams.put(TOKEN, oldToken);
        }

        String responseJson = snowCallProcessor.processGetRequest(DLM_TOKEN, null, queryParams);
        LOGGER.info("Response received from dlm token API {}", responseJson);

        if (StringUtils.isNotEmpty(responseJson)) {
            JsonNode results = responseParser.getCoveMapper().readTree(responseJson).get(RESULTS);
            if (results != null) {
                JsonNode result = results.get(0);
                String operation = getValue(result.get(OPERATION).toString());
                if (ObjectUtils.isNotEmpty(result) && StringUtils.isNotEmpty(operation)
                    && operation.equalsIgnoreCase(SUCCESS) && requestType.equalsIgnoreCase(INITIATE)) {
                    token = getValue(result.get(TOKEN).toString());
                }
            }
        }
        return token;
    }

    private String generateSnowRequestParam(DLMStreamDataRequest request) throws UnsupportedEncodingException {
        List<String> queryStrings = new ArrayList<>();

        if (StringUtils.isNotEmpty(request.getLegalOrgId())) {
            queryStrings.add(String.format(LEGAL_ORG_ID_QUERY, request.getLegalOrgId()));
        }
        if (StringUtils.isNotEmpty(request.getSearchType()) && StringUtils.isNotEmpty(request.getSearchValue())
            && StringUtils.isNotEmpty(searchTypes.get(request.getSearchType()))) {
            queryStrings.add(String.format(LIKE_S, searchTypes.get(request.getSearchType()),
                URLEncoder.encode(request.getSearchValue(), StandardCharsets.UTF_8.toString())));
        }
        if (ArrayUtils.isNotEmpty(request.getBusinessUnit())) {
            queryStrings.add(
                String.format(IN_S, searchTypes.get(BUSINESS_UNIT), String.join(COMMA, request.getBusinessUnit())));
        }
        if (ArrayUtils.isNotEmpty(request.getEquipmenttype())) {
            queryStrings.add(String.format(IN_S, searchTypes.get(EQUIPMENT_TYPE),
                String.join(COMMA, request.getEquipmenttype())));
        }
        if (ArrayUtils.isNotEmpty(request.getCountryCode())) {
            queryStrings.add(
                String.format(IN_S, searchTypes.get(COUNTRY_CODE), String.join(COMMA, request.getCountryCode())));
        }
        if (Objects.nonNull(request.getContractStartDate())) {
            queryStrings.add(getSnowFilterFormat(request.getContractStartDate(), searchTypes.get(CONTRACT_START_DATE)));
        }
        if (Objects.nonNull(request.getContractEndDate())) {
            queryStrings.add(getSnowFilterFormat(request.getContractEndDate(), searchTypes.get(CONTRACT_END_DATE)));
        }
        return String.join(CARET, queryStrings);
    }

    private String getSnowFilterFormat(ContractDate request, String searchType) {
        String snowDate = StringUtils.EMPTY;
        String date = StringUtils.EMPTY;

        if (StringUtils.isNotEmpty(request.getOperator()) && StringUtils.isNotEmpty(request.getValue())
            && !request.getOperator().equalsIgnoreCase(BETWEEN)) {
            date = request.getValue();
        }
        if (StringUtils.isNotEmpty(request.getOperator()) && StringUtils.isNotEmpty(searchType)) {

            switch (request.getOperator()) {
                case LESS_THAN:
                    snowDate = String.format(LESS_THAN_DATE_QUERY, searchType, date);
                    break;
                case GREATER_THAN:
                    snowDate = String.format(GREATER_THAN_DATE_QUERY, searchType, date);
                    break;
                case LESS_THAN_EQUALS:
                    snowDate = String.format(LESS_THAN_EQUALS_DATE_QUERY, searchType, date);
                    break;
                case GREATER_THAN_EQUALS:
                    snowDate = String.format(GRETAER_THAN_EQUALS_DATE_QUERY, searchType, date);
                    break;
                case EQLS:
                    snowDate = String.format(EQUALS_DATE_QUERY, searchType, date, date, date);
                    break;
                default:
                    String fromDate = request.getFromDate();
                    String toDate = request.getToDate();
                    if (StringUtils.isNotEmpty(fromDate) && StringUtils.isNotEmpty(toDate)) {
                        snowDate = String.format(BETWEEN_DATE_QUERY, searchType, fromDate, toDate);
                    }
            }
        }
        return snowDate;
    }

    private void addStringCells(XSSFRow row, List<String> strings, XSSFCellStyle style) {
        for (int i = 0; i < strings.size(); i++) {
            XSSFCell cell = row.createCell(i, CellType.STRING);
            cell.setCellValue(strings.get(i));
            cell.setCellStyle(style);
        }
    }

    private String getValue(String value) {
        String response = StringUtils.EMPTY;
        if (StringUtils.isNotEmpty(value)) {
            try {
                response = responseParser.getCoveMapper().readValue(value, String.class);
            } catch (IOException e) {
                LOGGER.error("Value not found", e);
            }
        }
        return response;
    }

    private String convertFiletoBase64String(File file) {
        String base64String = StringUtils.EMPTY;
        try {
            byte[] pdf = FileUtils.readFileToByteArray(file);
            base64String = Base64.getEncoder().encodeToString(pdf);
        } catch (Exception ex) {
            LOGGER.error("Exception in base64 file conversion ", ex);
        }
        return base64String;
    }

    private String getFileFormatDate() {
        LocalDate date = LocalDate.now();
        return date.format(fileDateFormat);
    }

    private String formatDate(String inputDate) {
        String formattedDate = StringUtils.EMPTY;
        try {
            if (StringUtils.isNotEmpty(inputDate)) {
                SimpleDateFormat inputDateFormat = new SimpleDateFormat(SNOW_DLM_DATE_FORMAT);
                SimpleDateFormat outputDateFormat = new SimpleDateFormat(COVE_DLM_DATE_FORMAT);
                Date date = inputDateFormat.parse(inputDate);
                formattedDate = outputDateFormat.format(date);
            }
        } catch (ParseException exception) {
            LOGGER.error("Error during date formatting.", exception);
        }
        return formattedDate;
    }

    private String formatInheritDLMId(String inputDate) {
        String formattedValue = StringUtils.EMPTY;
        if (StringUtils.isNotEmpty(inputDate)) {
            if(inputDate.equalsIgnoreCase("false")){
                formattedValue = "No";
            }else{
                formattedValue = "Yes";
            }
        }
        return formattedValue;
    }


    private XSSFCellStyle getHeaderStyle(XSSFWorkbook workbook) {
        XSSFCellStyle headerStyle = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.RED.index);
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return headerStyle;
    }

    static {
        searchTypes = new HashMap<>();
        searchTypes.put(MSISDN, U_MSISDN);
        searchTypes.put(EQUIPMENT_ID, U_DEVICE_ID);
        searchTypes.put(EMAIL, U_EMAIL_ADDRESS);
        searchTypes.put(IMEI, U_IMEI);
        searchTypes.put(EQUIPMENT_TYPE, U_EQUIPMENT_TYPE);
        searchTypes.put(COUNTRY_CODE, U_COUNTRY_CODE);
        searchTypes.put(BUSINESS_UNIT, U_BUSINESS_UNIT);
        searchTypes.put(CONTRACT_START_DATE, U_LEASE_START_DATE);
        searchTypes.put(CONTRACT_END_DATE, U_LEASE_END_DATE);

        fileDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd");

        columnHeadersMap = new HashMap<>();
        columnHeadersMap.put(EOR_REPORT,
            Arrays.asList(FIRST_NAME, LAST_NAME, ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3,
                "City/state", POSTCODE, SHIPPING_COUNTRY, EMAIL, MSISDN, "Inherit device", UNSUPPORTED, CONTACT_NUMBER,
                BUSINESS_UNIT, COST_CENTRE, EQUIPMENT_ID, "IMEI/Serial number", "EID", EQUIPMENT_TYPE,
                DEVICE_MAKE, DEVICE_MODEL, COUNTRY, BULK_ORDER_ID, ORDER_ID, ORDER_DATE, "BAN",
                CUSTOMER_REFERENCE, TRANSACTION_TYPE, END_USER_ID, CONTRACT_START_DATE,
                CONTRACT_END_DATE, DELIVERY_DATE, WARRANTY_START_DATE, WARRANTY_END_DATE, SIM_NUMBER,
                SIM_ACTIVATION_DATE, SIM_ACTIVATION_STATUS, DISPATCH_DATE, COMMERCIAL_MODEL,
                SIM_ICCID, SERIAL_NUMBER, CUSTOMER_NOTES, ORGANISATION_NAME, SKU_ID, LEAVERS,"Service Substatus", ASSET_TAG));
        columnHeadersMap.put(STREAM_API_DLMUS,
            Arrays.asList(EQUIPMENT_ID, MSISDN, EMAIL, EQUIPMENT_TYPE, DEVICE_MAKE, DEVICE_MODEL,
                COUNTRY, "IMEI", "EID", BULK_ORDER_ID, ORDER_ID, ORDER_DATE, "BAN", CUSTOMER_REFERENCE,
                TRANSACTION_TYPE, END_USER_ID, FIRST_NAME, LAST_NAME, BUSINESS_UNIT, CONTACT_NUMBER,
                COST_CENTRE, ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3, "Address line 4", "City",
                STATE, POSTCODE, SHIPPING_COUNTRY, CONTRACT_START_DATE, CONTRACT_END_DATE,
                DELIVERY_DATE, WARRANTY_START_DATE, WARRANTY_END_DATE, SIM_NUMBER,
                SIM_ACTIVATION_DATE, SIM_ACTIVATION_STATUS, DISPATCH_DATE, COMMERCIAL_MODEL,
                SIM_ICCID, SERIAL_NUMBER, CUSTOMER_NOTES, ORGANISATION_NAME, SKU_ID, LEAVERS));
        columnHeadersMap.put(DEFAULT,
            Arrays.asList(EQUIPMENT_ID, MSISDN, "Inherit device", UNSUPPORTED, EMAIL, EQUIPMENT_TYPE, DEVICE_MAKE, DEVICE_MODEL,
                COUNTRY, "IMEI", "EID", BULK_ORDER_ID, ORDER_ID, ORDER_DATE, "BAN", CUSTOMER_REFERENCE,
                TRANSACTION_TYPE, END_USER_ID, FIRST_NAME, LAST_NAME, BUSINESS_UNIT, CONTACT_NUMBER,
                COST_CENTRE, ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3, "Address line 4",
                "City/state", POSTCODE, SHIPPING_COUNTRY, CONTRACT_START_DATE, CONTRACT_END_DATE,
                DELIVERY_DATE, WARRANTY_START_DATE, WARRANTY_END_DATE, SIM_NUMBER,
                SIM_ACTIVATION_DATE, SIM_ACTIVATION_STATUS, DISPATCH_DATE, COMMERCIAL_MODEL,
                SIM_ICCID, SERIAL_NUMBER, CUSTOMER_NOTES, ORGANISATION_NAME, SKU_ID, LEAVERS,"Service Substatus", ASSET_TAG));

        dataKeysMap = new HashMap<>();
        dataKeysMap.put(EOR_REPORT,
            Arrays.asList(FIRSTNAME, USERLASTNAME, ENDUSERADDRESS1, ENDUSERADDRESS2, ENDUSERADDRESS3,
                STATE, POSTCODE, SHIPPINGCOUNTRY, EMAIL, MSISDN, "InheritedDLMId", UNSUPPORTED, CONTACTNUMBER, BUSINESSUNIT,
                COSTCENTRE, DLMID, "IMEI", "EID", EQUIPMENTTYPE, DEVICEMAKE, MODEL, COUNTRYNAME,
                BULKORDERID, ORDERID, ORDERDATE, "BAN", CUSTREF, TRANSACTIONTYPE, ENDUSERID,
                CONTRACTSTARTDATE, CONTRACTENDDATE, DELIVERYDATE, WARRANTYSTARTDATE, WARRANTYENDDATE,
                SIMNUMBER, SIMACTIVATIONDATE, SIMACTIVATIONSTATUS, DISPATCHEDDATE, GSCATEGORY,
                SIMICCID, SERIALNUMBER, CUSTOMERNOTE, ORGNAME, SKUID, LEAVERS,"ServiceSubstatus", ASSET_TAG));
        dataKeysMap.put(STREAM_API_DLMUS,
            Arrays.asList(DLMID, MSISDN, EMAIL, EQUIPMENTTYPE, DEVICEMAKE, MODEL, COUNTRYNAME, "IMEI", "EID", BULKORDERID, ORDERID, ORDERDATE, "BAN", CUSTREF, TRANSACTIONTYPE, ENDUSERID,
                FIRSTNAME, USERLASTNAME, BUSINESSUNIT, CONTACTNUMBER, COSTCENTRE, ENDUSERADDRESS1,
                ENDUSERADDRESS2, ENDUSERADDRESS3, "EndUserAddress4", "City", STATE, POSTCODE,
                SHIPPINGCOUNTRY, CONTRACTSTARTDATE, CONTRACTENDDATE, DELIVERYDATE, WARRANTYSTARTDATE,
                WARRANTYENDDATE, SIMNUMBER, SIMACTIVATIONDATE, SIMACTIVATIONSTATUS, DISPATCHEDDATE,
                GSCATEGORY, SIMICCID, SERIALNUMBER, CUSTOMERNOTE, ORGNAME, SKUID, LEAVERS));
        dataKeysMap.put(DEFAULT,
            Arrays.asList(DLMID, MSISDN, "InheritedDLMId", UNSUPPORTED, EMAIL, EQUIPMENTTYPE, DEVICEMAKE, MODEL, COUNTRYNAME, "IMEI", "EID", BULKORDERID, ORDERID, ORDERDATE, "BAN", CUSTREF, TRANSACTIONTYPE, ENDUSERID,
                FIRSTNAME, USERLASTNAME, BUSINESSUNIT, CONTACTNUMBER, COSTCENTRE, ENDUSERADDRESS1,
                ENDUSERADDRESS2, ENDUSERADDRESS3, "EndUserAddress4", STATE, POSTCODE, SHIPPINGCOUNTRY,
                CONTRACTSTARTDATE, CONTRACTENDDATE, DELIVERYDATE, WARRANTYSTARTDATE, WARRANTYENDDATE,
                SIMNUMBER, SIMACTIVATIONDATE, SIMACTIVATIONSTATUS, DISPATCHEDDATE, GSCATEGORY,
                SIMICCID, SERIALNUMBER, CUSTOMERNOTE, ORGNAME, SKUID, LEAVERS,"ServiceSubstatus", ASSET_TAG));

        FIELDLIST = "u_device_id,u_msisdn,u_inherited_dlmid,u_unsupported_device,u_asset_entity_type,u_email_address,model_number,u_make,u_imei,u_eid,u_user_first_name,u_user_last_name,u_contact_tel_number,u_sku_id,u_business_service.location.country.name,u_business_service.location.country.iso3166_2,u_business_service.name,u_gscategory,u_reverse_exchange_type,u_lease_start_date,u_lease_end_date,sys_id,u_bulk_order_id,u_order_date,u_ban,u_custref,u_transaction_type,u_user_id,u_business_unit,u_cost_centre,u_cost_centre_2,u_cost_centre_3,u_cost_centre_4,u_user_address_1,u_user_address_2,u_user_address_3,u_user_address_4,u_user_state,u_user_post_code,u_user_country,u_delivery_date,u_sim_number,u_dispatched_date,u_sim_iccid,u_device_serial_number,u_leavers,u_customer_notes,u_warranty_start_date,u_warranty_end_date,name,u_inventory_id,u_business_service.company.name,u_user_city,u_county,u_sim_activation_status,u_sim_activation_date,u_business_unit,u_lease_start_date,u_lease_end_date,u_service_substatus,asset_tag";
    }

}
