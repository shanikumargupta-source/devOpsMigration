package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "contentData" })
public class Content {

	@JsonProperty("type")
	private String type;
	@JsonProperty("contentData")
	private List<Object> contentData = null;

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("contentData")
	public List<Object> getContentData() {
		return contentData;
	}

	@JsonProperty("contentData")
	public void setContentData(List<Object> contentData) {
		this.contentData = contentData;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("type", type).append("contentData", contentData).toString();
	}

}
