package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "htmlFor", "type", "labelname", "apiData", "displayAccordion", "name", "alwaysExpanded",
		"header", "content" })
public class Data {

	@JsonProperty("id")
	private String id;
	@JsonProperty("htmlFor")
	private String htmlFor;
	@JsonProperty("type")
	private String type;
	@JsonProperty("labelname")
	private String labelname;
	@JsonProperty("apiData")
	private String apiData;
	@JsonProperty("displayAccordion")
	private boolean displayAccordion;
	@JsonProperty("name")
	private String name;
	@JsonProperty("alwaysExpanded")
	private boolean alwaysExpanded;
	@JsonProperty("header")
	private Header header;
	@JsonProperty("content")
	private Content content;

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("htmlFor")
	public String getHtmlFor() {
		return htmlFor;
	}

	@JsonProperty("htmlFor")
	public void setHtmlFor(String htmlFor) {
		this.htmlFor = htmlFor;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("labelname")
	public String getLabelname() {
		return labelname;
	}

	@JsonProperty("labelname")
	public void setLabelname(String labelname) {
		this.labelname = labelname;
	}

	@JsonProperty("apiData")
	public String getApiData() {
		return apiData;
	}

	@JsonProperty("apiData")
	public void setApiData(String apiData) {
		this.apiData = apiData;
	}

	@JsonProperty("displayAccordion")
	public boolean isDisplayAccordion() {
		return displayAccordion;
	}

	@JsonProperty("displayAccordion")
	public void setDisplayAccordion(boolean displayAccordion) {
		this.displayAccordion = displayAccordion;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("alwaysExpanded")
	public boolean isAlwaysExpanded() {
		return alwaysExpanded;
	}

	@JsonProperty("alwaysExpanded")
	public void setAlwaysExpanded(boolean alwaysExpanded) {
		this.alwaysExpanded = alwaysExpanded;
	}

	@JsonProperty("header")
	public Header getHeader() {
		return header;
	}

	@JsonProperty("header")
	public void setHeader(Header header) {
		this.header = header;
	}

	@JsonProperty("content")
	public Content getContent() {
		return content;
	}

	@JsonProperty("content")
	public void setContent(Content content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("id", id).append("htmlFor", htmlFor).append("type", type)
				.append("labelname", labelname).append("apiData", apiData).append("displayAccordion", displayAccordion)
				.append("name", name).append("alwaysExpanded", alwaysExpanded).append("header", header)
				.append("content", content).toString();
	}

}
