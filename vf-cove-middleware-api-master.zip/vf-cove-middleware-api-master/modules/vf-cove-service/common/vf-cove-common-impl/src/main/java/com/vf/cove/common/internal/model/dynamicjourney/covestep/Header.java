package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "headerData" })
public class Header {

	@JsonProperty("type")
	private String type;
	@JsonProperty("headerData")
	private HeaderData headerData;

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("headerData")
	public HeaderData getHeaderData() {
		return headerData;
	}

	@JsonProperty("headerData")
	public void setHeaderData(HeaderData headerData) {
		this.headerData = headerData;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("type", type).append("headerData", headerData).toString();
	}

}
