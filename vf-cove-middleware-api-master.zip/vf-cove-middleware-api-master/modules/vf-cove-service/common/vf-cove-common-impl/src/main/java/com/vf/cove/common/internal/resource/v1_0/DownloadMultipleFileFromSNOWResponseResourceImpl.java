package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.DownloadMultipleFileFromSNOWRequest;
import com.vf.cove.common.dto.v1_0.DownloadMultipleFileFromSNOWResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.SnowMultipleFileDownloadService;
import com.vf.cove.common.resource.v1_0.DownloadMultipleFileFromSNOWResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author GhousPasha
 */
@Component(
    properties = "OSGI-INF/liferay/rest/v1_0/download-multiple-file-from-snow-response.properties",
    scope = ServiceScope.PROTOTYPE,
    service = DownloadMultipleFileFromSNOWResponseResource.class
)
public class DownloadMultipleFileFromSNOWResponseResourceImpl
    extends BaseDownloadMultipleFileFromSNOWResponseResourceImpl {

    @Reference(unbind = "-")
    private SnowMultipleFileDownloadService snowMultipleFileDownloadService;

    @Override
    public DownloadMultipleFileFromSNOWResponse postDownloadMultipleFileFromSNOW(
        DownloadMultipleFileFromSNOWRequest downloadMultipleFileFromSNOWRequest) throws Exception {
        requiredFieldValidation(downloadMultipleFileFromSNOWRequest);
        downloadMultipleFileFromSNOWRequest.setUserEmail(contextUser.getEmailAddress());
        downloadMultipleFileFromSNOWRequest.setLegalOrgId(String.valueOf(
            contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
        return snowMultipleFileDownloadService.postDownloadMultipleFileFromSNow(downloadMultipleFileFromSNOWRequest);
    }

    private void requiredFieldValidation(DownloadMultipleFileFromSNOWRequest request) throws Exception {
        if (StringUtils.isEmpty(request.getCapability()) || isNullOrContainsNull(request.getFileSysIDs())) {
            throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
        }
    }

    private boolean isNullOrContainsNull(Object[] array) {
        if (null == array) {
            return true;
        }
        for (Object o : array) {
            if (null == o) {
                return true;
            }
        }
        return false;
    }
}
