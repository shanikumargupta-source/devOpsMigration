package com.vf.cove.common.dj.configuration.helper;

import com.vf.cove.common.dj.configuration.DJServiceConfiguration;

public interface DJServiceConfigurationHelper {

	DJServiceConfiguration getDJServiceConfiguration();
}
