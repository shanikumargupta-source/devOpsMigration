package com.vf.cove.common.internal.model.dynamicjourney;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "model", "selectIpLabel", "maxLength", "isRequired", "selectFieldValues", "selectFieldsCount",
		"type", "inputLabel", "docURL" })
public class ListOfField {

	@JsonProperty("model")
	private String model;
	@JsonProperty("selectIpLabel")
	private String selectIpLabel;
	@JsonProperty("maxLength")
	private String maxLength;
	@JsonProperty("isRequired")
	private String isRequired;
	@JsonProperty("selectFieldValues")
	private List<SelectFieldValue> selectFieldValues = null;
	@JsonProperty("selectFieldsCount")
	private String selectFieldsCount;
	@JsonProperty("type")
	private String type;
	@JsonProperty("inputLabel")
	private String inputLabel;

	@JsonProperty("helpText")
	private String helpText;

	@JsonProperty("readOnly")
	private String readOnly;

	@JsonProperty("validationCode")
	private String validationCode;

	@JsonProperty("validationCode")
	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public String getReadOnly() {
		return readOnly;
	}

	public void setReadOnly(String readOnly) {
		this.readOnly = readOnly;
	}

	@JsonProperty("helpText")
	public String getHelpText() {
		return helpText;
	}

	@JsonProperty("helpText")
	public void setHelpText(String helpText) {
		this.helpText = helpText;
	}

	@JsonProperty("name")
	private String name;

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("model")
	public String getModel() {
		return model;
	}

	@JsonProperty("model")
	public void setModel(String model) {
		this.model = model;
	}

	@JsonProperty("selectIpLabel")
	public String getSelectIpLabel() {
		return selectIpLabel;
	}

	@JsonProperty("selectIpLabel")
	public void setSelectIpLabel(String selectIpLabel) {
		this.selectIpLabel = selectIpLabel;
	}

	@JsonProperty("maxLength")
	public String getMaxLength() {
		return maxLength;
	}

	@JsonProperty("maxLength")
	public void setMaxLength(String maxLength) {
		this.maxLength = maxLength;
	}

	@JsonProperty("isRequired")
	public String getIsRequired() {
		return isRequired;
	}

	@JsonProperty("isRequired")
	public void setIsRequired(String isRequired) {
		this.isRequired = isRequired;
	}

	@JsonProperty("selectFieldValues")
	public List<SelectFieldValue> getSelectFieldValues() {
		return selectFieldValues;
	}

	@JsonProperty("selectFieldValues")
	public void setSelectFieldValues(List<SelectFieldValue> selectFieldValues) {
		this.selectFieldValues = selectFieldValues;
	}

	@JsonProperty("selectFieldsCount")
	public String getSelectFieldsCount() {
		return selectFieldsCount;
	}

	@JsonProperty("selectFieldsCount")
	public void setSelectFieldsCount(String selectFieldsCount) {
		this.selectFieldsCount = selectFieldsCount;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("inputLabel")
	public String getInputLabel() {
		return inputLabel;
	}

	@JsonProperty("inputLabel")
	public void setInputLabel(String inputLabel) {
		this.inputLabel = inputLabel;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("model", model).append("selectIpLabel", selectIpLabel)
				.append("maxLength", maxLength).append("isRequired", isRequired)
				.append("selectFieldValues", selectFieldValues).append("selectFieldsCount", selectFieldsCount)
				.append("type", type).append("inputLabel", inputLabel).append("name", name).append("helpText", helpText)
				.append("validationCode", validationCode).toString();
	}

}
