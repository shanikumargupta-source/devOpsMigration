package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.DynamicJourneyRequest;
import com.vf.cove.common.dto.v1_0.DynamicJourneyResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.DynamicJourneyService;
import com.vf.cove.common.resource.v1_0.DynamicJourneyResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/dynamic-journey-response.properties", scope = ServiceScope.PROTOTYPE, service = DynamicJourneyResponseResource.class)
public class DynamicJourneyResponseResourceImpl extends BaseDynamicJourneyResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(DynamicJourneyResponseResourceImpl.class);

	@Reference(unbind = "-")
	private DynamicJourneyService dynamicJourneyService;

	public DynamicJourneyResponse postGetDynamicJourneyMetadata(DynamicJourneyRequest dynamicJourneyRequest)
			throws Exception {
		String messageId = RequestUtils.getUUID();
		LOGGER.info("Invoking getDynamicJourneyMetadata API for messageId {} ", messageId);
		requiredFieldValidation(dynamicJourneyRequest);
		if (ObjectUtils.isNotEmpty(dynamicJourneyRequest) && ObjectUtils.isNotEmpty(contextUser)) {
			dynamicJourneyRequest.setUserId(contextUser.getEmailAddress());
			dynamicJourneyRequest.setCustomerId(String.valueOf(
					contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
			dynamicJourneyRequest.setCurrentDate(RequestUtils.getUTCDate());
			dynamicJourneyRequest.setMessageId(messageId);

			return dynamicJourneyService.getDynamicJourneyMetadata(dynamicJourneyRequest, messageId);
		}
		return new DynamicJourneyResponse();
	}

	private void requiredFieldValidation(DynamicJourneyRequest request) throws Exception {
		LOGGER.debug("Inside getDynamicJourneyMetadata - requiredFieldValidation()");
		if (StringUtils.isEmpty(request.getCatalogueItemSysID()) || StringUtils.isEmpty(request.getGroupID())
				|| StringUtils.isEmpty(request.getJourneyName()) || StringUtils.isEmpty(request.getType())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
	}
}
