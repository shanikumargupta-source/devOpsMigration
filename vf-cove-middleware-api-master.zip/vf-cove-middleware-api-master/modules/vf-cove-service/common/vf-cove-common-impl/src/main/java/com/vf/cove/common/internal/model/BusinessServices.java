package com.vf.cove.common.internal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "BusinessServices")
public class BusinessServices {
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String characteristicName;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String value;

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String description;

	public String getCharacteristicName() {
		return characteristicName;
	}

	public void setCharacteristicName(String characteristicName) {
		this.characteristicName = characteristicName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
