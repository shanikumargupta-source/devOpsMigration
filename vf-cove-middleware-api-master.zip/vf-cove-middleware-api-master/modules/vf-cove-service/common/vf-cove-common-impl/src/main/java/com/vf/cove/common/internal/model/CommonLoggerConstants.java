package com.vf.cove.common.internal.model;


public class CommonLoggerConstants {
    private CommonLoggerConstants() {
        throw new IllegalStateException("Utility class");
    }
	public static final String EVENT_TYPE = "Common Logger Audit";
	public static final String JOURNEY_NAME = "JourneyName";
	public static final String CURRENT_TIME = "CurrentTime";
	public static final String USER_EMAIL = "EmailAddress";

}
