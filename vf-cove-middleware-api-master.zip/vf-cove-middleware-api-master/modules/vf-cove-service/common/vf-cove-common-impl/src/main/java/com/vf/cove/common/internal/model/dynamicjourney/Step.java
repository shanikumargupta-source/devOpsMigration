package com.vf.cove.common.internal.model.dynamicjourney;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "listOfFieldsCount", "isPrevStep", "nextStepName", "listOfFields", "prevStepName",
		"currentStepName", "isNextStep" })
public class Step {

	@JsonProperty("listOfFieldsCount")
	private String listOfFieldsCount;
	@JsonProperty("isPrevStep")
	private String isPrevStep;
	@JsonProperty("nextStepName")
	private String nextStepName;
	@JsonProperty("listOfFields")
	private List<ListOfField> listOfFields = null;
	@JsonProperty("prevStepName")
	private String prevStepName;
	@JsonProperty("currentStepName")
	private String currentStepName;
	@JsonProperty("isNextStep")
	private String isNextStep;
	@JsonProperty("stepSequenceNum")
	private String stepSequenceNum;

	@JsonProperty("listOfFieldsCount")
	public String getListOfFieldsCount() {
		return listOfFieldsCount;
	}

	@JsonProperty("listOfFieldsCount")
	public void setListOfFieldsCount(String listOfFieldsCount) {
		this.listOfFieldsCount = listOfFieldsCount;
	}

	@JsonProperty("isPrevStep")
	public String getIsPrevStep() {
		return isPrevStep;
	}

	@JsonProperty("isPrevStep")
	public void setIsPrevStep(String isPrevStep) {
		this.isPrevStep = isPrevStep;
	}

	@JsonProperty("nextStepName")
	public String getNextStepName() {
		return nextStepName;
	}

	@JsonProperty("nextStepName")
	public void setNextStepName(String nextStepName) {
		this.nextStepName = nextStepName;
	}

	@JsonProperty("listOfFields")
	public List<ListOfField> getListOfFields() {
		return listOfFields;
	}

	@JsonProperty("listOfFields")
	public void setListOfFields(List<ListOfField> listOfFields) {
		this.listOfFields = listOfFields;
	}

	@JsonProperty("prevStepName")
	public String getPrevStepName() {
		return prevStepName;
	}

	@JsonProperty("prevStepName")
	public void setPrevStepName(String prevStepName) {
		this.prevStepName = prevStepName;
	}

	@JsonProperty("currentStepName")
	public String getCurrentStepName() {
		return currentStepName;
	}

	@JsonProperty("currentStepName")
	public void setCurrentStepName(String currentStepName) {
		this.currentStepName = currentStepName;
	}

	@JsonProperty("isNextStep")
	public String getIsNextStep() {
		return isNextStep;
	}

	@JsonProperty("isNextStep")
	public void setIsNextStep(String isNextStep) {
		this.isNextStep = isNextStep;
	}

	@JsonProperty("stepSequenceNum")
	public String getStepSequenceNum() {
		return stepSequenceNum;
	}

	@JsonProperty("stepSequenceNum")
	public void setStepSequenceNum(String stepSequenceNum) {
		this.stepSequenceNum = stepSequenceNum;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("listOfFieldsCount", listOfFieldsCount).append("isPrevStep", isPrevStep)
				.append("nextStepName", nextStepName).append("listOfFields", listOfFields)
				.append("prevStepName", prevStepName).append("currentStepName", currentStepName)
				.append("isNextStep", isNextStep).append("stepSequenceNum", stepSequenceNum).toString();
	}

}
