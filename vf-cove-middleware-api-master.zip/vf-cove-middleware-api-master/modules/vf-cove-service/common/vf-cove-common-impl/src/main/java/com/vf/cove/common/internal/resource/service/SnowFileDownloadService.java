package com.vf.cove.common.internal.resource.service;

import com.vf.cove.common.dto.v1_0.DownloadFileFromSNOW;
import com.vf.cove.common.dto.v1_0.SnowFileDownloadRequest;
import com.vf.cove.common.dto.v1_0.SnowFileDownloadResponse;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.service.SNowCallProcessor;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

import static com.vf.cove.common.internal.model.CommonConstants.*;

@Component(service = SnowFileDownloadService.class)
public class SnowFileDownloadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SnowFileDownloadService.class);

	@Reference(unbind = "-")
	private SNowCallProcessor snowCallProcessor;

	public SnowFileDownloadResponse postDownloadFileFromSNow(SnowFileDownloadRequest request)
			throws Exception {
		LOGGER.info("Download file from SNow request object {}", request.toString());
		String token = generateSnowToken(request);
		LOGGER.info("Token {}", token);

		if (StringUtils.isEmpty(token)) {
			throw new ServiceException(500, "Invalid token");
		}

		SnowFileDownloadResponse coveResponse = new SnowFileDownloadResponse();

		Map<String, String> headers = new HashMap<>();
		headers.put(CAPABILITY, request.getCapability());
		headers.put(TOKEN, token);

		Map<String, String> queryParams = populateQueryParams(request);

		String encodedString = snowCallProcessor.getAttachment(GET_ATTACHMENT, headers, queryParams);
		DownloadFileFromSNOW fileData = null;

		if (StringUtils.isNotEmpty(encodedString)) {
			fileData = new DownloadFileFromSNOW();
			fileData.setResponse(encodedString);
			coveResponse.setDownloadFileFromSNOW(fileData);
			if(StringUtils.isEmpty(encodedString)){
				LOGGER.info("Encoded response received is empty");
			}
		} else {
			throw new ServiceException(500, "Empty file content received from SNow");
		}
		return coveResponse;
	}

	private String generateSnowToken(SnowFileDownloadRequest request) throws Exception {
		return snowCallProcessor.getManageToken(request.getUserEmail(), request.getLegalOrgId());
	}

	private Map<String, String> populateQueryParams(SnowFileDownloadRequest request){
		Map<String, String> queryParams = new HashMap<>();
		if(StringUtils.isNotEmpty(request.getBusinessService())) {
			queryParams.put(BUSINESS_SERVICE, request.getBusinessService());
		}
		if(StringUtils.isNotEmpty(request.getTicketId())) {
			queryParams.put(TICKET_ID, request.getTicketId());
		}
		queryParams.put(ATTACHMENT_ID, request.getAttachmentId());
		queryParams.put(USER_EMAIL_ID, request.getUserEmail());
		queryParams.put(LEGAL_ORG_ID, request.getLegalOrgId());
		return queryParams;
	}
}
