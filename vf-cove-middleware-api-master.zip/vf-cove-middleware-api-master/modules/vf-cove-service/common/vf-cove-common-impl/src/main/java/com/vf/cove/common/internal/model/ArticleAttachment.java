package com.vf.cove.common.internal.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ArticleAttachment")
public class ArticleAttachment {

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String systemId;

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileType;

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fileSize;

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

}
