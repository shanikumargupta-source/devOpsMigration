package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.liferay.document.library.kernel.model.DLFolderConstants;
import com.liferay.document.library.kernel.service.DLAppService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.vf.configprovider.global.configuration.CatalogMessageConfiguration;
import com.vf.configprovider.global.configuration.helper.CatalogMessageConfigurationHelper;
import com.vf.cove.common.dj.configuration.DJServiceConfiguration;
import com.vf.cove.common.dj.configuration.helper.DJServiceConfigurationHelper;
import com.vf.cove.common.dto.v1_0.DynamicJourneyRequest;
import com.vf.cove.common.dto.v1_0.DynamicJourneyResponse;
import com.vf.cove.common.dto.v1_0.GetDynamicJourneyMetadata;
import com.vf.cove.common.internal.model.dynamicjourney.*;
import com.vf.cove.common.internal.model.dynamicjourney.covestep.CoveStep;
import com.vf.cove.common.internal.model.dynamicjourney.covestep.Rule;
import com.vf.cove.common.internal.util.CommonUtils;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import net.minidev.json.JSONObject;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.Map.Entry;

@Component(service = DynamicJourneyService.class)
public class DynamicJourneyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DynamicJourneyService.class);

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	@Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CatalogMessageConfigurationHelper catalogMessageConfigurationHelper;

	@Reference(unbind = "-")
	private DJServiceConfigurationHelper djServiceConfigurationHelper;

	@Reference
	private DLAppService dlAppService;
    @Reference
    private CommonUtils commonUtils;

    private static final String COMPONENTTYPE = "componentType";
    private static final String PROPS = "props";
    private static final String CONTENT = "content";
    private static final String MESSAGE = "message";
    private static final String LEFTOPERAND = "leftOperand";
    private static final String CONDITION = "condition";
    private static final String RIGHTOPERAND = "rightOperand";

	public DynamicJourneyResponse getDynamicJourneyMetadata(DynamicJourneyRequest djRequest, String messageId) {
		DynamicJourneyResponse coveResponse = new DynamicJourneyResponse();
		GetDynamicJourneyMetadata dynamicResponse = new GetDynamicJourneyMetadata();
		coveResponse.setGetDynamicJourneyMetadata(dynamicResponse);
		String voneConfiguration = djServiceConfigurationHelper.getDJServiceConfiguration().vonecSysId();
		try {
			String requestType = djRequest.getJourneyName();
			LOGGER.info("Metadata requested for {} ", requestType);

			JsonNode portalResponse = getTemplateFromPortalFolder(djRequest);
			LOGGER.debug("Portal response {} ", portalResponse);
			JsonNode updatedPortalResponse = filterResponse(portalResponse, DJConstants.PORTAL, djRequest);
			DJESBResponse esbResponse = getDynamicJourneyESBResponse(djRequest, messageId);

			if (updatedPortalResponse != null && esbResponse != null && !requestType.isEmpty()) {
				@SuppressWarnings("unchecked")
				DJResponseData esbResponseData = esbResponse.getResponseData();
				DJResponse response = esbResponseData.getResponse();
				ObjectNode coveObject = responseParser.getCoveMapper().createObjectNode();
				if (esbResponseData.getStatus().equalsIgnoreCase(Constants.ZERO)
						&& Integer.valueOf(esbResponseData.getResponse().getStepsCount()) > 0 ) {
					LOGGER.info("Processing request");
					List<Step> esbSteps = esbResponseData.getResponse().getSteps();
					CoveStep coveStep = null;
					Map<String, Map<String, JsonNode>> crieteriaMap = getConditions(response.getConditions());
					LOGGER.debug("crieteriaMap  {}", getTextValueFromNode(crieteriaMap));
					int stepSequenceNumber = 1;
					for (Step step : esbSteps) {
						step.setStepSequenceNum(String.valueOf(stepSequenceNumber));
						if (step.getListOfFields() != null) {
							if (step.getCurrentStepName().toLowerCase().contains(DJConstants.COVE_UNDERSCORE)) {
								LOGGER.info("Processing portal step..");
								JsonNode coveStepObj = populateCoveStep(step, updatedPortalResponse);
								if (coveStepObj != null) {
									if (stepSequenceNumber == 1) {
										if (StringUtils.isNotBlank(esbResponseData.getResponse().getDescription())) {
											coveStepObj = updateDefaultAlertMessage(coveStepObj,
													esbResponseData.getResponse().getDescription());
										}
										updateDefaultLoadMessage(coveStepObj, djRequest.getCatalogueItemSysID());
									}
									hideCategoryValues(coveStepObj, djRequest.getCatalogueItemSysID());
									coveObject.set(splitAndJoin(step.getCurrentStepName().substring(5)), coveStepObj);
								}
							} else {
								LOGGER.info("Processing snow step..");
								List<ListOfField> fields = step.getListOfFields();
								if (fields.size() > 0) {
									String snowStepTemplate = populateSnowStepTemplate(step, requestType,
											stepSequenceNumber);
									List<Object> esbFields = new ArrayList<>();
									List<String> mandatoryFields = new ArrayList<String>();
									Map<String, Rule> validationRuleMap = new HashMap<String, Rule>();
									Map<String, String> validationMessages = getValidationMessages(
											djServiceConfigurationHelper.getDJServiceConfiguration());
									for (ListOfField field : fields) {
										List<String> components = new ArrayList<String>();
										if (field.getIsRequired().equalsIgnoreCase(DJConstants.TRUE)) {
											mandatoryFields.add(splitAndJoin(field.getName()));
										}
										if (StringUtils.isNotBlank(field.getValidationCode())) {
											Rule rule = validationRuleMap.get(field.getValidationCode());
											if (rule == null) {
												rule = new Rule();
												rule.setRuleName(field.getValidationCode());
												rule.setApplicableFields(new ArrayList<String>());
												String message = validationMessages.get(field.getValidationCode());
												if (StringUtils.isNotBlank(message)) {
													rule.setMessage(message);
												} else {
													rule.setMessage(StringUtils.EMPTY);
												}
												validationRuleMap.put(field.getValidationCode(), rule);
											}
											List<String> applicableFieldList = rule.getApplicableFields();
											applicableFieldList.add(field.getName());
										}
										String componentType = field.getType().toLowerCase();
										String componentName = field.getName().toLowerCase();
										if (StringUtils.isNotBlank(field.getModel()) && ArrayUtils.contains(
												StringUtils.split(voneConfiguration, ","), field.getModel())) {
											LOGGER.info("VONE-C configuration..{}", voneConfiguration);
											String linkWrapper = populateComponentTemplate(field,
													DJConstants.LINKWRAPPER);
											components.add(linkWrapper);
											String fileUplad = populateComponentTemplate(field, DJConstants.FILEUPLOAD);
											components.add(fileUplad);
											if (mandatoryFields.contains(field.getName())) {
												mandatoryFields.remove(field.getName());
												mandatoryFields.add("fileUpl");
											}
										} else if (componentType.equalsIgnoreCase(DJConstants.RADIO)) {
											String radioLabel = populateComponentTemplate(field,
													DJConstants.RADIO_LABEL);
											components.add(radioLabel);
											String radioButton = populateComponentTemplate(field,
													DJConstants.RADIO_BUTTON);
											components.add(radioButton);

										} else {
											String component = getFieldTypeContent(field, componentType);
											components.add(component);
										}
										if (components.size() > 0) {
											for (String component : components) {
												if (StringUtils.isNotBlank(component)) {
													if (response.getConditions() != null
															&& !response.getConditions().isEmpty()) {
														component = updateHadlers(response.getConditions(),
																componentType, component, field.getModel(),
																voneConfiguration);
														component = updateComponentCriteria(component, crieteriaMap,
																componentName);
													}

													esbFields.add(responseParser.getCoveMapper().readValue(component,
															Object.class));
												}
											}
										}

									}
									coveStep = responseParser.getCoveMapper().readValue(snowStepTemplate,
											CoveStep.class);
									if (coveStep != null) {
										coveStep.getListOfFields().get(1).getProps().getData().getContent()
												.setContentData(esbFields);
										List<Rule> rules = coveStep.getValidationRules().getRules();
										rules.get(0).setApplicableFields(mandatoryFields);
										validationRuleMap.forEach((key, value) -> {
											rules.add(value);
										});
									}
								}
								String coveStepValue = getTextValueFromNode(coveStep);
								LOGGER.debug("Cove step formed: {} ", coveStepValue);
								coveObject.set(splitAndJoin(step.getCurrentStepName()),
										readStringToJsonNode(coveStepValue));
							}
						}
						stepSequenceNumber++;
					}
					if (coveObject.get(DJConstants.SUMMARY) != null && !requestType.equals(DJConstants.BILLING_QUERY)) {
						coveObject.set(DJConstants.SUMMARY,
								addContentToSummary(coveObject, esbSteps, djRequest.getCatalogueItemSysID()));
					}
					if (coveObject.has(DJConstants.YOUR_REFERENCE_STEP_ID)) {
						LOGGER.info("Add back button to your reference step");
						Map<String, Object> groupByObject = responseParser.getCoveMapper()
								.readValue(commonUtils.getDXLRequest(null,null, DJConstants.PREVIOUS_STEP_JSON_PATH), HashMap.class);
						addbackButton(coveObject, groupByObject);
					}
					Iterator<Entry<String, JsonNode>> fields = coveObject.fields();
					while (fields.hasNext()) {
						Entry<String, JsonNode> entry = fields.next();
						coveObject.set(entry.getKey(), removeEmptyFooter(entry.getValue()));
						break;
					}
					dynamicResponse.setResponse(coveObject);
					LOGGER.debug("Final response {} ", coveResponse);
					LOGGER.info("Response generated..");
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in generateDynamicJourneyMetadata", ex);
		}
		return coveResponse;
	}

	Map<String, String> getValidationMessages(DJServiceConfiguration djServiceConfiguration) {
		String messages = "";
		Map<String, String> messageMap = null;
		try {
            messages = djServiceConfiguration.validationMessages();
			messageMap = responseParser.getCoveMapper().readValue(messages, HashMap.class);
		} catch (JsonProcessingException e) {
			LOGGER.error("Exception in getValidationMessages {}", e);
		}
		return messageMap;
	}

	public void addbackButton(ObjectNode coveObject, Map<String, Object> groupByObject)
			throws JsonParseException, JsonMappingException, IOException {
		if (coveObject.has(DJConstants.CI_SELECTION)) {
			LOGGER.info("CI selection step is present");
			ObjectNode yourRefStep = (ObjectNode) coveObject.get(DJConstants.YOUR_REFERENCE_STEP_ID);
			ArrayNode footerFields = (ArrayNode) yourRefStep.get(DJConstants.FOOTER_FIELDS);
			footerFields.insertPOJO(1, groupByObject);
			yourRefStep.put("prevStepName", DJConstants.CI_SELECTION);
		}
	}

	private void hideCategoryValues(JsonNode coveStepObj, String catalogueItemSysID) {
		List<String> sysIDList = getSysIdsToHideCategoryAndSubCategory();
		if (sysIDList != null && sysIDList.contains(catalogueItemSysID)) {
			List<String> FieldsToHide = new ArrayList<>();
			FieldsToHide.add(DJConstants.CATEGORY_FIELD_NAME);
			FieldsToHide.add(DJConstants.SUBCATEGORY_FIELD_NAME);
			hideFields(coveStepObj, FieldsToHide);
		}
	}

	private void removeValidations(JsonNode coveStepObj, List<String> fieldsToHide) {
		JsonNode validationRules = coveStepObj.get("validationRules");
		if (validationRules != null && validationRules.get("rules") != null) {
			ArrayNode rules = (ArrayNode) validationRules.get("rules");
			rules.forEach(rule -> {
				if (rule.get("applicableFields") != null) {
					ArrayNode applicableFields = (ArrayNode) rule.get("applicableFields");
					List<Integer> indexList = new ArrayList<Integer>();
					for (int i = 0; i < applicableFields.size(); i++) {
						if (fieldsToHide.contains(applicableFields.get(i).asText())) {
							indexList.add(i);
						}
					}
					Collections.sort(indexList, Collections.reverseOrder());
					indexList.forEach(index -> {
						applicableFields.remove(index);
					});
				}

			});
		}
	}

	private void hideFields(JsonNode coveStepObj, List<String> fieldsToHide) {

		ArrayNode listOfFields = getFormListOfFields(coveStepObj);
		List<Integer> indexList = new ArrayList<Integer>();
		if (listOfFields != null) {
			for (int i = 0; i < listOfFields.size(); i++) {
				String name = getCoveComponentName(listOfFields.get(i));
				if (fieldsToHide.contains(name)) {
					indexList.add(i);
				}
			}
		}
		Collections.sort(indexList, Collections.reverseOrder());
		indexList.forEach(index -> {
			listOfFields.remove(index);
		});
		removeValidations(coveStepObj, fieldsToHide);
	}

	private ArrayNode getFormListOfFields(JsonNode coveStepObj) {
		ArrayNode[] listOfFields = new ArrayNode[1];
		ArrayNode parentListOfFields = (ArrayNode) coveStepObj.get("listOfFields");
		parentListOfFields.forEach(parentField -> {
			if (StringUtils.equalsIgnoreCase(parentField.get(COMPONENTTYPE).asText(), "Accordion")) {
				if (parentField.get(PROPS) != null && parentField.get(PROPS).get("data") != null
						&& parentField.get(PROPS).get("data").get(CONTENT) != null
						&& parentField.get(PROPS).get("data").get(CONTENT).get("contentData") != null)
					listOfFields[0] = (ArrayNode) parentField.get(PROPS).get("data").get(CONTENT)
							.get("contentData");
			}
		});
		return listOfFields[0];
	}

	private List<String> getSysIdsToHideCategoryAndSubCategory() {
		List<String> sysIDList = null;
		CatalogMessageConfiguration catalogMessageConfiguration = catalogMessageConfigurationHelper
				.getCatalogMessageConfiguration();
		String value = catalogMessageConfiguration.noCategorySysIDs();
		String[] sysIDs = value.split(",");
		if (sysIDs != null && sysIDs.length > 0) {
			sysIDList = Arrays.asList(sysIDs);
		}
		return sysIDList;
	}

	private void updateDefaultLoadMessage(JsonNode coveStepObj, String catalogueItemSysID) throws Exception{
		String message = getPopUpMessage(catalogueItemSysID);
		if (StringUtils.isNotBlank(message)) {
			updateLoadPopupMessage(coveStepObj, message);
		}
	}

	private void updateLoadPopupMessage(JsonNode coveStepObj, String message) throws Exception{
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(MESSAGE, message);
		String loadComponent = parseTemplate(params, DJConstants.LOAD_COMPONENT_NAME);
		((ObjectNode) coveStepObj).set("onLoadDialog", readStringToJsonNode(loadComponent));
	}

	private String getPopUpMessage(String catalogueItemSysID) {
		String message = StringUtils.EMPTY;
		CatalogMessageConfiguration catalogMessageConfiguration = catalogMessageConfigurationHelper
				.getCatalogMessageConfiguration();
		String content = catalogMessageConfiguration.defaultLoadMessageConfiguration();
		JsonNode defaultLoadMessageConfiguration = readStringToJsonNode(content);
		Iterator<Entry<String, JsonNode>> fieldEntries = defaultLoadMessageConfiguration.fields();
		while (fieldEntries.hasNext()) {
			Entry<String, JsonNode> entry = fieldEntries.next();
			if (StringUtils.equalsIgnoreCase(entry.getKey(), catalogueItemSysID)) {
				message = entry.getValue().asText();
			}
		}
		return message;
	}

	private String updateHadlers(List<Condition> conditions, String componentType, String component, String modelName,
			String voneConfiguration) throws IOException {

		if (componentType.equals(DJConstants.SELECT)) {
			if (StringUtils.isBlank(modelName)
					|| !ArrayUtils.contains(StringUtils.split(voneConfiguration, ","), modelName)) {
				component = updateJsonPath(component, DJConstants.CREATEHANDLER_PATH, DJConstants.DROPDOWN_HANDLER);
			}
		} else if (componentType.equalsIgnoreCase(DJConstants.IPADDRESS)) {
			component = updateJsonPath(component, DJConstants.CREATEHANDLER_PATH, DJConstants.IPADDRESS_HANDLER);
		}
		return component;
	}

	private String updateComponentCriteria(String component, Map<String, Map<String, JsonNode>> crieteriaMap,
			String componentName) throws IOException {
		ObjectNode componentNode = (ObjectNode) readStringToJsonNode(component);
		JsonNode uiCrieteria = crieteriaMap.get(DJConstants.RENDER).get(componentName);
		ObjectNode validationCrieteria = (ObjectNode) crieteriaMap.get(DJConstants.VALIDATION).get(componentName);
		if (uiCrieteria != null) {
			componentNode.set("criteria", uiCrieteria);
		}
		if (validationCrieteria != null && !StringUtils.equalsIgnoreCase(componentNode.get(COMPONENTTYPE).textValue(),
				DJConstants.LINKWRAPPER)) {
			componentNode.set("validationCriteria", getValidationCriteria(validationCrieteria));
		}
		return getTextValueFromNode(componentNode);
	}

	private String getCoveComponentName(JsonNode object) {
		String name = StringUtils.EMPTY;
		if (object != null && object.get(PROPS) != null && object.get(PROPS).get("data") != null
				&& object.get(PROPS).get("data").get("name") != null) {
			name = object.get(PROPS).get("data").get("name").asText();
		}
		return name;
	}

	private Map<String, Map<String, JsonNode>> getConditions(List<Condition> conditions) throws IOException {
		Map<String, Map<String, JsonNode>> crieteriaMap = new HashMap<String, Map<String, JsonNode>>();
		if (conditions != null && !conditions.isEmpty()) {
			InputStream in = DynamicJourneyService.class.getResourceAsStream(DJConstants.MAPPING_DEFINITION);
			JsonNode operatorMapping = responseParser.getCoveMapper().readTree(in);
			Map<String, JsonNode> uiConditions = new HashMap<String, JsonNode>();
			Map<String, JsonNode> validationConditions = new HashMap<String, JsonNode>();
			conditions.forEach(condition -> {
				String conditionValue = condition.getCondition();
				List<Action> actions = condition.getActions();
				if (actions != null) {
					ObjectNode criteria = constructCriteria(null, conditionValue, operatorMapping);
					actions.forEach(action -> {
						String variableName = action.getVariableName();
						String visible = action.getVisible();
						String mandatory = action.getMandatory();
						if (StringUtils.isNotBlank(visible) && !StringUtils.equalsIgnoreCase(visible, "ignore")) {
							if (StringUtils.equalsIgnoreCase(visible, "false")) {
								uiConditions.put(variableName, reverseCriteria(criteria));
							} else {
								uiConditions.put(variableName, criteria);
							}
						}
						if (StringUtils.isNotBlank(mandatory) && !StringUtils.equalsIgnoreCase(mandatory, "ignore")) {
							if (StringUtils.equalsIgnoreCase(mandatory, "false")) {
								validationConditions.put(variableName, reverseCriteria(criteria));
							} else {
								validationConditions.put(variableName, criteria);
							}
						}
					});
				}
			});
			crieteriaMap.put(DJConstants.RENDER, uiConditions);
			crieteriaMap.put(DJConstants.VALIDATION, validationConditions);

		}
		return crieteriaMap;
	}

	private JsonNode updateDefaultAlertMessage(JsonNode coveStepObj, String description) throws IOException {
		String coveStep = getTextValueFromNode(coveStepObj);
		String[] messageList = description.split(DJConstants.MULTILINE_MESSAGE_DELIMITER);
		if (ArrayUtils.isNotEmpty(messageList) && messageList.length > 1) {
			String messageTitle = messageList[0];
			messageList = ArrayUtils.remove(messageList, 0);
			ArrayNode messageNodeList = getMessageNodes(messageList);
			ArrayNode listOfFields = (ArrayNode) coveStepObj.get("listOfFields");
			ObjectNode[] alerMessage = new ObjectNode[1];
			listOfFields.forEach(field -> {
				if (StringUtils.equalsIgnoreCase(field.get(COMPONENTTYPE).asText(), "AlertMessage")) {
					JsonNode data = field.get(PROPS).get("data");
					if (data.get("id") != null
							&& StringUtils.equalsIgnoreCase(data.get("id").asText(), "OnLoadMessage")) {
						alerMessage[0] = (ObjectNode) field;
					}
				}
			});
			if (ArrayUtils.isNotEmpty(alerMessage) && alerMessage[0] != null) {
				((ObjectNode) alerMessage[0].get(PROPS).get("data")).set("messageBody", messageNodeList);
				((ObjectNode) alerMessage[0].get(PROPS).get("data")).put(DJConstants.MESSAGE_CSSCLASS_PATH,
						DJConstants.MESSAGE_CSSCLASS_NAME);
			}
			coveStep = getTextValueFromNode(coveStepObj);
			coveStep = updateJsonPath(coveStep, DJConstants.DEFAULT_MESSAGE_TITLE_PATH, messageTitle);
		} else {
			coveStep = updateJsonPath(coveStep, DJConstants.DEFAULT_MESSAGE_PATH, description);
			coveStep = updateJsonPath(coveStep, DJConstants.DEFAULT_MESSAGE_TITLE_PATH, StringUtils.EMPTY);
		}
		coveStep = updateJsonPath(coveStep, DJConstants.DEFAULT_MESSAGE_FOOTER, StringUtils.EMPTY);
		return readStringToJsonNode(coveStep);
	}

	private String updateJsonPath(String object, String path, Object value) {
		DocumentContext context = JsonPath.parse(object);
		return context.set(path, value).jsonString();
	}

	String replaceEsbStepContent(JsonNode updatedEsbResponse) throws IOException {
		String response = getTextValueFromNode(updatedEsbResponse);
		if (updatedEsbResponse != null) {
			response = response.replace("Cove_Upload files", DJConstants.COVE_ATTACH_FILES)
					.replace("Cove_UploadFiles", DJConstants.COVE_ATTACH_FILES)
					.replace("Your reference", DJConstants.YOUR_REFERENCE);
		}
		return response;
	}

	private String getTextValueFromNode(Object node) {
		String value = StringUtils.EMPTY;
		try {
			value = responseParser.getCoveMapper().writeValueAsString(node);
		} catch (JsonProcessingException e) {
			LOGGER.error("JsonProcessingException  {}", e);
		}
		return value;
	}

	private JsonNode replaceCoveStepContent(JsonNode temporaryStep, StepNames stepName, String seqNum)
			throws IOException {
		String response = getTextValueFromNode(temporaryStep);
		response = response.replaceAll(DJConstants.STEP_SEQ_NUM, seqNum)
				.replaceAll(DJConstants.NEXT_STEP_NAME, stepName.getStepName().getNextStepName())
				.replaceAll(DJConstants.PREV_STEP_NAME, stepName.getStepName().getPrevStepName())
				.replaceAll(DJConstants.FOOTER_NEXT, stepName.getFooterName().getNextStepName())
				.replaceAll(DJConstants.FOOTER_PREVIOUS, stepName.getFooterName().getPrevStepName());

		return readStringToJsonNode(response);
	}

	private String populateSnowStepTemplate(Step step, String requestType, int stepSequenceNumber) throws Exception{
		LOGGER.info("Inside populateSnowStepTemplate");
		String response = DJConstants.EMPTY;
		if (step != null) {
			StepNames stepName = getStepNames(step);
			if (step.getCurrentStepName().toLowerCase().contains(DJConstants.COVE_UNDERSCORE)) {
				step.setCurrentStepName(step.getCurrentStepName().substring(5));
			}
			Map<String, Object> params = new HashMap<>();
			params.put(DJConstants.SYSID, splitAndJoin(step.getCurrentStepName()));
			params.put(DJConstants.STEP_SEQUENCE, String.valueOf(stepSequenceNumber));
			params.put(DJConstants.CURRENT_STEP, step.getCurrentStepName());
			params.put(DJConstants.ID, splitAndJoin(step.getCurrentStepName()) + "_ID");
			params.put(DJConstants.NEXT_STEP, stepName.getStepName().getNextStepName());
			params.put(DJConstants.PREV_STEP, stepName.getStepName().getPrevStepName());
			params.put(DJConstants.FOOTER_NEXT_STEP, stepName.getFooterName().getNextStepName());
			params.put(DJConstants.FOOTER_PREV_STEP, stepName.getFooterName().getPrevStepName());
			if (step.getCurrentStepName() != null) {
				if (step.getCurrentStepName().equalsIgnoreCase(DJConstants.STEP_NAME_DESCRIPTION)) {
					if (StringUtils.equalsIgnoreCase(requestType, DJConstants.SERVICE_REQUEST)) {
						params.put(DJConstants.HEADER_DATA, DJConstants.SR_DESC);
					} else if (StringUtils.equalsIgnoreCase(requestType, DJConstants.BILLING_QUERY)) {
						params.put(DJConstants.HEADER_DATA, DJConstants.BQ_DESC);
					} else {
						params.put(DJConstants.HEADER_DATA, DJConstants.INC_DESC);
					}
				} else {
					params.put(DJConstants.HEADER_DATA, step.getCurrentStepName());
				}
			}
			response = commonUtils.getDXLRequest(null,params, DJConstants.SNOW_STEP_TEMPLATE);
			LOGGER.debug("Exiting populateSnowStepTemplate with response {} ", response);
		}
		return response;
	}

	private JsonNode populateCoveStep(Step step, JsonNode updatedPortalResponse) {
		JsonNode response = null;
		try {
			if (step != null) {
				StepNames stepName = getStepNames(step);
				String currentStepName = splitAndJoin(step.getCurrentStepName().substring(5));
				JsonNode temporaryStep = updatedPortalResponse.get(currentStepName);
				if (temporaryStep != null) {
					response = replaceCoveStepContent(temporaryStep, stepName, step.getStepSequenceNum());
					LOGGER.debug("Portal step formed {} ", currentStepName);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception occured in populateCoveStep {} ", ex);
		}
		return response;
	}

	private String populateComponentTemplate(ListOfField field, String templateName) throws Exception {
		String response = DJConstants.EMPTY;
		if (field != null) {
			Map<String, Object> params = getTemplateParams(field, templateName);
			response = parseTemplate(params, templateName);
		}
		LOGGER.debug("Component template formed: {}", response);
		return response;
	}

	private String parseTemplate(Map<String, Object> params, String templateName) throws Exception {
		String response = DJConstants.EMPTY;
		if (templateName.equalsIgnoreCase(DJConstants.MULTISELECT)) {
			templateName = DJConstants.SELECT;
		}
		String templatePath = getComponentTemplate(templateName);
		if (StringUtils.isNotBlank(templatePath)) {
			response = commonUtils.getDXLRequest(null,params, templatePath);
		}
		return response;
	}

	private final String generateDropDownData(ListOfField field) {
		String response = DJConstants.EMPTY;
		try {
			String dropdownTemplate = populateComponentTemplate(field, field.getType());
			List<SelectFieldValue> selectFieldValues = field.getSelectFieldValues();
			List<SelectDropDown> selectDropDownValues = new ArrayList<>();
			SelectDropDown dropDownValue = null;
			for (SelectFieldValue element : selectFieldValues) {
				dropDownValue = new SelectDropDown();
				dropDownValue.setLabel(element.getName());
				dropDownValue.setValue(element.getValue());
				selectDropDownValues.add(dropDownValue);
			}
			response = updateJsonPath(dropdownTemplate, DJConstants.DROP_DOWN_QUERY, selectDropDownValues);

			LOGGER.info("DropDown component template processed..");
		} catch (Exception ex) {
			LOGGER.error("Exception in dropdown component creation {} ", field.getName(), ex);
		}
		return response;
	}

	private Map<String, Object> getTemplateParams(ListOfField field, String templateName) {
		Map<String, Object> params = new HashMap<>();
		params.put(DJConstants.INPUT_LABEL, field.getInputLabel());
		params.put(DJConstants.FIELD_LIST, field.getSelectFieldValues());
		params.put(DJConstants.NAME, field.getName());
		params.put(DJConstants.HELP_TEXT, field.getHelpText());
		params.put(DJConstants.READ_ONLY, replaceSpecialChars(field.getReadOnly()));
		params.put(DJConstants.MODEL, replaceSpecialChars(field.getModel()));
		params.put(DJConstants.MAX_LENGTH, replaceSpecialChars(field.getMaxLength()));
		if (StringUtils.isNotEmpty(field.getIsRequired()) &&
            (field.getIsRequired().toLowerCase().equalsIgnoreCase(DJConstants.TRUE))) {
			params.put(DJConstants.IS_REQUIRED, replaceSpecialChars(field.getIsRequired()));
		}
		if (field.getType().equalsIgnoreCase(DJConstants.MULTISELECT)) {
			params.put(DJConstants.IS_MULTI, true);
		}
		if (field.getType().equalsIgnoreCase(DJConstants.DATETIME)) {
			if (StringUtils.isNotBlank(field.getValidationCode())
					&& StringUtils.equalsIgnoreCase(field.getValidationCode(), DJConstants.ENABLEPASTDATE)) {
				params.put(DJConstants.DISABLE_PAST_DATE, false);
			} else {
				params.put(DJConstants.DISABLE_PAST_DATE, true);
			}
		}
		params.put(DJConstants.SELECT_IP_LABEL, field.getSelectIpLabel());
		params.put(DJConstants.LABEL_NAME, field.getInputLabel());
		ArrayNode messagesNodeList = null;
		if (templateName.equalsIgnoreCase(DJConstants.LABEL_FIELD_NAME)) {
			String snowMessage = field.getHelpText();
			String[] messageList = snowMessage.split(DJConstants.MULTILINE_MESSAGE_DELIMITER);
			if (ArrayUtils.isNotEmpty(messageList)) {
				params.put(DJConstants.MESSAGE_TITLE, messageList[0]);
				messageList = ArrayUtils.remove(messageList, 0);
				if (ArrayUtils.isNotEmpty(messageList)) {

					messagesNodeList = getMessageNodes(messageList);
				}
			} else {
				params.put(DJConstants.MESSAGE_TITLE, StringUtils.EMPTY);
			}
			params.put(DJConstants.MESSAGES, messagesNodeList);
		}
		return params;
	}

	private ArrayNode getMessageNodes(String[] messageList) {
		ArrayNode messagesNodeList = responseParser.getCoveMapper().createArrayNode();

		for (int i = 0; i < messageList.length; i++) {
			ObjectNode messagesNode = responseParser.getCoveMapper().createObjectNode();
			if (StringUtils.contains(messageList[i], DJConstants.MULTILINE_SUB_MESSAGE_DELIMITER)) {
				String[] subMessages = messageList[i].split(DJConstants.MULTILINE_SUB_MESSAGE_DELIMITER);
				if (ArrayUtils.isNotEmpty(subMessages)) {
					messagesNode.put(MESSAGE, subMessages[0]);
					subMessages = ArrayUtils.remove(subMessages, 0);
					if (ArrayUtils.isNotEmpty(subMessages)) {
						ArrayNode subMessagesNodeList = responseParser.getCoveMapper().createArrayNode();
						for (int j = 0; j < subMessages.length; j++) {
							subMessagesNodeList.add(subMessages[j]);
						}
						messagesNode.set("subMessages", subMessagesNodeList);
					}
				}
			} else {
				messagesNode.put(MESSAGE, messageList[i]);
			}
			messagesNodeList.add(messagesNode);
		}
		return messagesNodeList;
	}

	private static String splitAndJoin(String value) {
		String response = DJConstants.EMPTY;
		LOGGER.debug("value in splitAndJoin  {}", value);
		if (StringUtils.isNotBlank(value)) {
			response = String.join(DJConstants.EMPTY, value.split(" "));
		}
		return response;
	}

	private static StepNames getStepNames(Step step) {
		StepNames stepName = new StepNames();
		String nextStepName = DJConstants.EMPTY, prevStepName = DJConstants.EMPTY;
		String nextFooterStepName = DJConstants.EMPTY, prevFooterStepName = DJConstants.EMPTY;
		if (StringUtils.isNotEmpty(step.getNextStepName())) {
			nextStepName = step.getNextStepName().toLowerCase().contains(DJConstants.COVE_UNDERSCORE)
					? splitAndJoin(step.getNextStepName().substring(5))
					: splitAndJoin(step.getNextStepName());

			nextFooterStepName = step.getNextStepName().toLowerCase().contains(DJConstants.COVE_UNDERSCORE)
					? step.getNextStepName().substring(5)
					: step.getNextStepName();
		}
		if (StringUtils.isNotEmpty(step.getPrevStepName())) {
			prevStepName = step.getPrevStepName().toLowerCase().contains(DJConstants.COVE_UNDERSCORE)
					? splitAndJoin(step.getPrevStepName().substring(5))
					: splitAndJoin(step.getPrevStepName());
			prevFooterStepName = step.getPrevStepName().toLowerCase().contains(DJConstants.COVE_UNDERSCORE)
					? step.getPrevStepName().substring(5)
					: step.getPrevStepName();
		}
		stepName.setStepName(new NextAndPreviousStepNames(nextStepName, prevStepName));
		stepName.setFooterName(new NextAndPreviousStepNames(nextFooterStepName, prevFooterStepName));
		return stepName;
	}

	private String getComponentTemplate(String type) {
		String templatePath = DJConstants.EMPTY;
		if (!type.isEmpty()) {
			templatePath = DJConstants.CUSTOM_COMPONENTS + type + DJConstants.VM;
		}
		return templatePath;
	}

	public JsonNode getTemplateFromPortalFolder(DynamicJourneyRequest request) throws IOException {
		JsonNode jsonObject = null;
		String jsonObjectString = StringUtils.EMPTY;
		try {
			if (request.getGroupID() != null && request.getJourneyName() != null) {
				long groupId = Long.parseLong(request.getGroupID());
				Folder folder = dlAppService.getFolder(groupId, DLFolderConstants.DEFAULT_PARENT_FOLDER_ID,
						DJConstants.PORTAL_METADATA_FOLDER_NAME);
				FileEntry fileEntry = dlAppService.getFileEntry(groupId, folder.getFolderId(),
						request.getJourneyName());

				try (java.util.Scanner scanner = new java.util.Scanner(fileEntry.getContentStream()).useDelimiter("\\A")) {
					jsonObjectString = scanner.hasNext() ? scanner.next() : "{}";
					jsonObject = readStringToJsonNode(jsonObjectString);
				} catch (Exception ex) {
					LOGGER.error("Exception while reading the content: {}", ex);
				}
			}
		} catch (PortalException ex) {
			LOGGER.error("Exception while retrieving template from portal: {}", ex);
		}
		return jsonObject;
	}

	private DJESBResponse getDynamicJourneyESBResponse(DynamicJourneyRequest djRequest, String messageId) {
		DJESBResponse esbResponseData = null;
		try {
			if (ObjectUtils.isNotEmpty(djRequest)) {
				if (djRequest.getJourneyName().equalsIgnoreCase(DJConstants.INCIDENT)) {
					djRequest.setJourneyName(DJConstants.INC_CREATE);
				} else if (djRequest.getJourneyName().equalsIgnoreCase(DJConstants.BILLING_QUERY)) {
					djRequest.setJourneyName(DJConstants.BQ_CREATE);
				} else {
					djRequest.setJourneyName(DJConstants.SR_CREATE);
				}

				final String request = djRequest.toString();
				RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
				restAPIRequest.setRelativeUrl(DJConstants.DYNAMIC_JOURNEY_URI);
		        restAPIRequest.setRequest(request);
		        restAPIRequest.setTransactionId(messageId);
				CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

				JsonNode updatedEsbResponse = filterResponse(readStringToJsonNode(dxlResponse.getData()), DJConstants.ESB,
						djRequest);
				String esbContent = replaceEsbStepContent(updatedEsbResponse);
				esbResponseData = responseParser.getCoveMapper().readValue(esbContent, DJESBResponse.class);
				LOGGER.info("ESB response received and mapped!");
			}

		} catch (Exception ex) {
			LOGGER.error("Exception occured in getDynamicJourneyESBResponse {}", ex);
		}
		return esbResponseData;
	}

	private JsonNode readStringToJsonNode(String content) {
		JsonNode node = null;
		try {
			node = responseParser.getCoveMapper().readTree(content);
		} catch (IOException e) {
			LOGGER.error("IOException in readStringToJsonNode: {}", e);
		}
		return node;
	}

	private String replaceSpecialChars(String request) {
		String response = DJConstants.EMPTY;
		if (StringUtils.isNotBlank(request)) {
			response = request.replaceAll("\\W+", StringUtils.EMPTY);
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public JsonNode addContentToSummary(ObjectNode coveObject, List<Step> esbSteps, String catalogueItemSysID) throws Exception{
		String response = getTextValueFromNode(coveObject);
		JsonNode responseObject = null;
		try {
			if (coveObject.size() > 0 && esbSteps.size() > 0) {
				LOGGER.info("Adding content to summary step!");
				JsonNode groupByObject = responseParser.getCoveMapper()
						.readTree(commonUtils.getDXLRequest(null,null, DJConstants.SUMMARY_JSON_PATH));

				List<String> stepList = new ArrayList<String>();
				Iterator<Entry<String, JsonNode>> it = coveObject.fields();
				while (it.hasNext()) {
					stepList.add(it.next().getKey());
				}
				String[] dynamicSteps = stepList.stream()
						.filter(e -> !e.equals(DJConstants.ATTACH_FILES) && !e.equals(DJConstants.SUMMARY))
						.toArray(String[]::new);
				if (dynamicSteps != null && dynamicSteps.length > 0) {
					response = updateJsonPath(response, DJConstants.SUMMARY_STEPS_QUERY, dynamicSteps);
				}

				List<Object> groupByList = new ArrayList<Object>();
				if (!stepList.contains(DJConstants.CI_SELECTION)
						&& stepList.contains(DJConstants.YOUR_REFERENCE_STEP_ID)) {
					ObjectNode yourRefStep = (ObjectNode) groupByObject.get(DJConstants.YOUR_REFERENCE_STEP_ID);
					if (yourRefStep != null && yourRefStep.get("listOfFieldIds") != null) {
						ArrayNode listOfFieldIds = (ArrayNode) yourRefStep.get("listOfFieldIds");
						listOfFieldIds.insert(0, "companyItem");
					}
				}
				for (String element : stepList) {
					if (groupByObject.has(element))
						groupByList.add(groupByObject.get(element));
				}
				groupByList.add(getDynamicJsonElement(esbSteps));
				String groupByListString = getTextValueFromNode(groupByList);
				LOGGER.debug("groupByListString: {}", groupByListString);

				response = updateJsonPath(response, DJConstants.GROUP_BY_QUERY,
						responseParser.getCoveMapper().readValue(groupByListString, Object.class));
				response = hideCategoryLabels(response, catalogueItemSysID);
				JsonNode updatedResponse = readStringToJsonNode(response);
				responseObject = updatedResponse.get(DJConstants.SUMMARY);
				LOGGER.info("Additional content added to summary step!");
			}
		} catch (IOException ex) {
			LOGGER.error("IOException in addContentToSummary {} ", ex);
		}
		return responseObject;
	}

	private String hideCategoryLabels(String response, String catalogueItemSysID) {
		List<String> sysIDList = getSysIdsToHideCategoryAndSubCategory();
		if (sysIDList != null && sysIDList.contains(catalogueItemSysID)) {
			response = deleteFromJson(response, DJConstants.CATEGORY_IN_SUMMARY);
			response = deleteFromJson(response, DJConstants.SUB_CATEGORY_IN_SUMMARY);
		}
		return response;
	}

	private String deleteFromJson(String response, String query) {
		DocumentContext context = JsonPath.parse(response);
		return context.delete(query).jsonString();
	}

	private JSONObject getDynamicJsonElement(List<Step> esbSteps) {
		JSONObject json = null;
		try {
			if (esbSteps.size() > 0) {
				Set<String> dynamicStepNames = new LinkedHashSet<>();
				for (Step element : esbSteps) {
					String currentStepName = element.getCurrentStepName();
					if (!currentStepName.toLowerCase().contains(DJConstants.COVE_UNDERSCORE)
							&& !currentStepName.contains(DJConstants.ATTACH_FILES)
							&& !currentStepName.contains(DJConstants.SUMMARY)) {
						dynamicStepNames.add(splitAndJoin(element.getCurrentStepName()));
					}
				}

				json = new JSONObject();
				json.put("dynamicSteps", dynamicStepNames.stream().toArray(String[]::new));
				json.put("labelname", StringUtils.EMPTY);

				LOGGER.info("Dynamic steps: {}", Arrays.toString(dynamicStepNames.stream().toArray(String[]::new)));
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in getDynamicJsonElement {}", ex);
		}
		return json;
	}

	private JsonNode filterResponse(JsonNode request, String type, DynamicJourneyRequest djRequest) throws IOException {
		String response = null;
		String requestText = getTextValueFromNode(request);
		try {
			if (request != null && type.equals(DJConstants.ESB)
					&& djRequest.getCatalogueItemSysID().equalsIgnoreCase(DJConstants.HIDE_REFERENCE)) {
				response = JsonPath.parse(requestText).delete(DJConstants.CUSTOMER_REF_QUERY).jsonString();
			} else if (request != null && type.equals(DJConstants.PORTAL)
					&& djRequest.getCatalogueItemSysID().equalsIgnoreCase(DJConstants.HIDE_REFERENCE)) {
				response = JsonPath.parse(requestText).delete(DJConstants.BUSINESS_SERVICE_QUERY).jsonString();
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in filterResponse {} ", ex);
		}
		if (StringUtils.isNotBlank(response)) {
			request = readStringToJsonNode(response);
		}
		return request;
	}

	private JsonNode removeEmptyFooter(JsonNode request) {
		JsonNode response = null;
		try {
			String responseString = JsonPath.parse(getTextValueFromNode(request)).delete(DJConstants.EMPTY_FOOTER)
					.jsonString();
			response = readStringToJsonNode(responseString);
		} catch (Exception ex) {
			LOGGER.error("Exception in removeEmptyFooter {} ", ex);
		}
		return response;
	}

	private String[] spiltConditions(String condition, String literal, int occuranceNumber) {
		String[] conditionArray = (literal.startsWith("^") || literal.startsWith("!") || literal.startsWith("=")
				|| literal.startsWith(">") || literal.startsWith("<")) ? condition.split("\\" + literal)
						: condition.split(literal);
		String leftCondition = StringUtils.EMPTY;
		if (conditionArray != null && conditionArray.length > 0) {
			leftCondition = conditionArray[0];
		}
		String rightCondition = StringUtils.EMPTY;
		if (occuranceNumber > 0 && conditionArray != null && occuranceNumber < conditionArray.length) {
			if (literal.equals("^") && StringUtils.isNotBlank(conditionArray[occuranceNumber])
					&& (conditionArray[occuranceNumber].startsWith("OR")
							|| conditionArray[occuranceNumber].startsWith("EQ"))) {
				String[] response = spiltConditions(condition, literal, occuranceNumber + 1);
				leftCondition = response[0];
				rightCondition = response[1];
			} else {
				for (int i = 1; i < occuranceNumber; i++) {
					leftCondition = leftCondition + literal + conditionArray[i];
				}
				for (int i = occuranceNumber; i < conditionArray.length; i++) {
					if (StringUtils.isNotBlank(rightCondition)) {
						rightCondition = rightCondition + literal + conditionArray[i];
					} else {
						rightCondition = rightCondition + conditionArray[i];
					}
				}
			}
		} else {
			leftCondition = condition;
		}
		return new String[] { leftCondition, rightCondition };
	}

	private ObjectNode reverseCriteria(ObjectNode uiCriteria) {
		ObjectNode reverseCriteria = responseParser.getCoveMapper().createObjectNode();
		reverseCriteria.set(LEFTOPERAND, uiCriteria);
		reverseCriteria.put(CONDITION, "EQUAL");
		reverseCriteria.put(RIGHTOPERAND, false);
		return reverseCriteria;
	}

	private ObjectNode getValidationCriteria(ObjectNode uiCriteria) {
		ObjectNode validationCriteria = responseParser.getCoveMapper().createObjectNode();
		validationCriteria.put("ruleName", "REQUIRED");
		validationCriteria.set("criteria", uiCriteria);
		return validationCriteria;
	}

	private ObjectNode constructCriteria(ObjectNode uiCriteria, String condition, JsonNode operatorMapping) {
		String str1 = StringUtils.EMPTY, str2 = StringUtils.EMPTY, operator = StringUtils.EMPTY;
		if (uiCriteria == null) {
			uiCriteria = responseParser.getCoveMapper().createObjectNode();
		}
		Iterator<Entry<String, JsonNode>> itr = operatorMapping.fields();
		while (itr.hasNext()) {
			Entry<String, JsonNode> element = itr.next();
			String key = element.getKey();
			if (condition.contains(key)) {
				boolean isSplitNeeded = false;
				if (key.equals("^")) {
					String[] conditionArray = condition.split("\\^");
					for (int i = 0; i < conditionArray.length; i++) {
						if (i > 0) {
							if (!(conditionArray[i].startsWith("OR") || conditionArray[i].startsWith("EQ")
									|| conditionArray[i].startsWith("NQ"))) {
								isSplitNeeded = true;
							}
						}
					}
					;
				} else {
					isSplitNeeded = true;
				}

				if (isSplitNeeded) {
					String[] response = spiltConditions(condition, key, 1);
					str1 = response[0];
					str2 = response[1];
					operator = key;
					break;
				}
			}
		}

		if (operator.equals("^NQ") || operator.equals("^") || operator.equals("^OR")) {
			if (StringUtils.isNotBlank(str1)) {
				uiCriteria.set(LEFTOPERAND,
						constructCriteria((ObjectNode) uiCriteria.get(LEFTOPERAND), str1, operatorMapping));
			}
			if (StringUtils.isNotBlank(str1) && StringUtils.isNotBlank(str2)) {
				uiCriteria.put(CONDITION, operatorMapping.get(operator).asText());
			}
			if (StringUtils.isNotBlank(str2)) {
				uiCriteria.set(RIGHTOPERAND,
						constructCriteria((ObjectNode) uiCriteria.get(RIGHTOPERAND), str2, operatorMapping));
			}
		} else if (operator.equals("^EQ")) {
			StringBuffer sb = new StringBuffer(str1);
			if (str1.endsWith("^EQ")) {
				sb.replace(str1.lastIndexOf("^EQ"), str1.lastIndexOf("^EQ") + 3, StringUtils.EMPTY);
			}

			constructCriteria(uiCriteria, sb.toString(), operatorMapping);
		} else if (operator.equals("!=") || operator.equals("=") || operator.equals(">") || operator.equals("<")
				|| operator.equals("NOTLIKE") || operator.equals("LIKE") || operator.equals("ISNOTEMPTY")
				|| operator.equals("ISEMPTY") || operator.equals("NOT IN") || operator.equals("IN")) {
			if (StringUtils.equalsIgnoreCase(str1, DJConstants.SNOW_CATEGORY_FIELD_NAME)) {
				str1 = DJConstants.CATEGORY_FIELD_NAME;
			}
			if (StringUtils.equalsIgnoreCase(str1, DJConstants.SNOW_SUBCATEGORY_FIELD_NAME)) {
				str1 = DJConstants.SUBCATEGORY_FIELD_NAME;
			}
			uiCriteria.put(LEFTOPERAND, str1);
			uiCriteria.put(CONDITION, operatorMapping.get(operator).asText());
			uiCriteria.put(RIGHTOPERAND, str2);
		}
		return uiCriteria;
	}

	public String getFieldTypeContent(ListOfField field, String componentType) throws Exception{

		String component;
		if (componentType.equals(DJConstants.SELECT) || componentType.equals(DJConstants.MULTISELECT)) {
			component = generateDropDownData(field);
		} else {
			component = populateComponentTemplate(field, field.getType());
		}
		return component;

	}
}
