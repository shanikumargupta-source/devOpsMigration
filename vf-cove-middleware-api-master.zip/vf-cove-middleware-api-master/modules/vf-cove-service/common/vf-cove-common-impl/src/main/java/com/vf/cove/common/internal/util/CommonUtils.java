package com.vf.cove.common.internal.util;

import com.vf.cove.common.internal.model.dynamicjourney.DJConstants;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.ftlutils.utils.StreamToStringUtil;
import com.vf.cove.core.restutils.constants.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Map;

@Component(immediate = true, service = { CommonUtils.class })
public class CommonUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);

    @Reference(unbind = "-")
    private FtlTemplateService ftlTemplateService;

    public String getDXLRequest(Object request, Map<String, Object> params, String templateName) {
        String template = DJConstants.EMPTY;
        try {
            if (request != null) {
                params.put(Constants.REQUEST_PARAM_NAME, request);
            }
            final InputStream resourceAsStream = this.getClass().getResourceAsStream(templateName);
            String templateStr = StreamToStringUtil.getString(resourceAsStream);
            template = ftlTemplateService.renderTemplate(templateName, templateStr, params);
        } catch (Exception e) {
            LOGGER.warn("Exception in creating template {}", e.getMessage());
        }
        return template;
    }
}
