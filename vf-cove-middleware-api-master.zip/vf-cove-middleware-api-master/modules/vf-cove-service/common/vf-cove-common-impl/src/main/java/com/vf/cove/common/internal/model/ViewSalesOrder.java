package com.vf.cove.common.internal.model;

import com.fasterxml.jackson.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Virtusa
 */
@XmlRootElement(name = "ViewSalesOrder")
public class ViewSalesOrder {

	@Schema
	@JsonGetter("Email")
	public String getEmail() {
		return Email;
	}

	@JsonSetter("Email")
	@JsonIgnoreProperties
	public void setEmail(String Email) {
		this.Email = Email;
	}

	@JsonProperty("Email")
	protected String Email;

	@JsonProperty("customer")
	protected String customer;

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	@Schema
	@JsonGetter("EoLDLM_ID")
	public String getEoLDLM_ID() {
		return EoLDLM_ID;
	}

	@JsonSetter("EoLDLM_ID")
	@JsonIgnoreProperties
	public void setEoLDLM_ID(String EoLDLM_ID) {
		this.EoLDLM_ID = EoLDLM_ID;
	}

	@JsonProperty("EoLDLM_ID")
	protected String EoLDLM_ID;

	@Schema
	@JsonGetter("EoLDeviceGrade")
	public String getEoLDeviceGrade() {
		return EoLDeviceGrade;
	}

	@JsonSetter("EoLDeviceGrade")
	@JsonIgnoreProperties
	public void setEoLDeviceGrade(String EoLDeviceGrade) {
		this.EoLDeviceGrade = EoLDeviceGrade;
	}

	@JsonProperty("EoLDeviceGrade")
	protected String EoLDeviceGrade;

    @Schema
    @JsonGetter("EoLDeviceGradeReason")
    public String getEoLDeviceGradeReason() {
        return EoLDeviceGradeReason;
    }

    @JsonSetter("EoLDeviceGradeReason")
    @JsonIgnoreProperties
    public void setEoLDeviceGradeReason(String EoLDeviceGradeReason) {
        this.EoLDeviceGradeReason = EoLDeviceGradeReason;
    }

    @JsonProperty("EoLDeviceGradeReason")
    protected String EoLDeviceGradeReason;

	@Schema
	@JsonGetter("EoLIMEI")
	public String getEoLIMEI() {
		return EoLIMEI;
	}

	@JsonSetter("EoLIMEI")
	@JsonIgnoreProperties
	public void setEoLIMEI(String EoLIMEI) {
		this.EoLIMEI = EoLIMEI;
	}

	@JsonProperty("EoLIMEI")
	protected String EoLIMEI;

	@Schema
	@JsonGetter("EoLStatus")
	public String getEoLStatus() {
		return EoLStatus;
	}

	@JsonSetter("EoLStatus")
	@JsonIgnoreProperties
	public void setEoLStatus(String EoLStatus) {
		this.EoLStatus = EoLStatus;
	}

	@JsonProperty("EoLStatus")
	protected String EoLStatus;

	@Schema
	@JsonGetter("IMEI")
	public String getIMEI() {
		return IMEI;
	}

	@JsonSetter("IMEI")
	@JsonIgnoreProperties
	public void setIMEI(String IMEI) {
		this.IMEI = IMEI;
	}

	@JsonProperty("IMEI")
	protected String IMEI;

	@Schema
	@JsonGetter("Pod")
	public String getPod() {
		return Pod;
	}

	@JsonSetter("Pod")
	@JsonIgnoreProperties
	public void setPod(String Pod) {
		this.Pod = Pod;
	}

	@JsonProperty("Pod")
	protected String Pod;

	@Schema
	@JsonGetter("ShippingContactEmail")
	public String getShippingContactEmail() {
		return ShippingContactEmail;
	}

	@JsonSetter("ShippingContactEmail")
	@JsonIgnoreProperties
	public void setShippingContactEmail(String ShippingContactEmail) {
		this.ShippingContactEmail = ShippingContactEmail;
	}

	@JsonProperty("ShippingContactEmail")
	protected String ShippingContactEmail;

	@Schema
	public String getTotalCount() {
		return TotalCount;
	}

	public void setTotalCount(String TotalCount) {
		this.TotalCount = TotalCount;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String TotalCount;

	@Schema
	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String addressLine1;

	@Schema
	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String addressLine2;

	@Schema
	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String addressLine3;

	@Schema
	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ban;

	@Schema
	public String getBulkOrderId() {
		return bulkOrderId;
	}

	public void setBulkOrderId(String bulkOrderId) {
		this.bulkOrderId = bulkOrderId;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String bulkOrderId;

	@Schema
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String city;

	@Schema
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String country;

	@Schema
	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String county;

	@Schema
	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String courierName;

	@Schema
	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerRef;

	@Schema
	public String getDispatchedDate() {
		return dispatchedDate;
	}

	public void setDispatchedDate(String dispatchedDate) {
		this.dispatchedDate = dispatchedDate;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String dispatchedDate;

	@Schema
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String firstName;

	@Schema
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String lastName;

	@Schema
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String msisdn;

	@Schema
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String orderId;

	@Schema
	@Valid
	public List<OrderItem> getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(List<OrderItem> orderItem) {
		this.orderItem = orderItem;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	@JsonInclude(JsonInclude.Include.ALWAYS)
	protected List<OrderItem> orderItem = new ArrayList<>();

	@Schema
	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String postCode;

	@Schema
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String state;

	@Schema
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String status;

	@Schema
	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String trackingId;

	@Schema
	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String transactionType;
}
