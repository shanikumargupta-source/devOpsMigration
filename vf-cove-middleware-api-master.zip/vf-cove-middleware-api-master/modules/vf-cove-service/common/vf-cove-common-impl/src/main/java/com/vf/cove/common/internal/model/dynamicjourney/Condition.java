package com.vf.cove.common.internal.model.dynamicjourney;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "onLoad", "appliesCatalog", "order", "condition", "name",
		"appliesReqItem", "reverseIf", "appliesSCTask" , "actions"})
public class Condition {

	@JsonProperty("on_load")
	private String onLoad;

	@JsonProperty("applies_catalog")
	private String appliesCatalog;

	@JsonProperty("order")
	private String order;

	@JsonProperty("condition")
	private String condition;

	@JsonProperty("name")
	private String name;

	public String getOnLoad() {
		return onLoad;
	}

	public void setOnLoad(String onLoad) {
		this.onLoad = onLoad;
	}

	public String getAppliesCatalog() {
		return appliesCatalog;
	}

	public void setAppliesCatalog(String appliesCatalog) {
		this.appliesCatalog = appliesCatalog;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAppliesReqItem() {
		return appliesReqItem;
	}

	public void setAppliesReqItem(String appliesReqItem) {
		this.appliesReqItem = appliesReqItem;
	}

	public String getReverseIf() {
		return reverseIf;
	}

	public void setReverseIf(String reverseIf) {
		this.reverseIf = reverseIf;
	}

	public String getAppliesSCTask() {
		return appliesSCTask;
	}

	public void setAppliesSCTask(String appliesSCTask) {
		this.appliesSCTask = appliesSCTask;
	}

	public List<Action> getActions() {
		return actions;
	}

	public void setActions(List<Action> actions) {
		this.actions = actions;
	}

	@JsonProperty("applies_req_item")
	private String appliesReqItem;

	@JsonProperty("reverse_if")
	private String reverseIf;

	@JsonProperty("applies_sc_task")
	private String appliesSCTask;

	@JsonProperty("actions")
	private List<Action> actions;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
