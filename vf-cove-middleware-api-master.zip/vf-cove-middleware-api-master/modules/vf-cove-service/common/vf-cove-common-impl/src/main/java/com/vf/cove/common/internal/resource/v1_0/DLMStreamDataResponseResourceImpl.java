package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.DLMStreamDataRequest;
import com.vf.cove.common.dto.v1_0.DLMStreamDataResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.DLMStreamDataService;
import com.vf.cove.common.resource.v1_0.DLMStreamDataResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author GhousPasha
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/dlm-stream-data-response.properties",
	scope = ServiceScope.PROTOTYPE,
	service = DLMStreamDataResponseResource.class
)
public class DLMStreamDataResponseResourceImpl extends BaseDLMStreamDataResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(DLMStreamDataResponseResourceImpl.class);

	@Reference(unbind = "-")
	private DLMStreamDataService dlmStreamDataService;

	public DLMStreamDataResponse postDownload(DLMStreamDataRequest dlmStreamDataRequest) throws Exception {
		requiredFieldValidation(dlmStreamDataRequest);
		dlmStreamDataRequest.setUserEmail(contextUser.getEmailAddress());
		dlmStreamDataRequest.setLegalOrgId(String.valueOf(
				contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));

		return dlmStreamDataService.postDownload(dlmStreamDataRequest);
	}

	private void requiredFieldValidation(DLMStreamDataRequest request) throws Exception {
		LOGGER.debug("Inside dlmStreamData - requiredFieldValidation()");
		if (request.getStreamApiDLMUS() == null || request.getEorReport() == null) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
	}
}
