package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vf.cove.common.dto.v1_0.BusinessService;
import com.vf.cove.common.dto.v1_0.BusinessServicesRequest;
import com.vf.cove.common.dto.v1_0.BusinessServicesResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * @author GhousPasha
 */
@Component(service = BusinessServices.class)
public class BusinessServices {

	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessService.class);

	private static final String BUSINESS_SERVICES_URI = "/cove/customerServiceInventoryItem/getCustomerServiceInventoryItem";

	@Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	public BusinessServicesResponse postBusinessService(BusinessServicesRequest businessServicesRequest,
			String messageId) throws Exception {
		LOGGER.info(" Business services service {}", BUSINESS_SERVICES_URI);
		BusinessServicesResponse coveResponse = new BusinessServicesResponse();

		final String request = businessServicesRequest.toString();
        String relativeUrl = BUSINESS_SERVICES_URI ;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);

        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            restAPIRequest.addHeader(CommonConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
        LOGGER.info("Request Headers.. {}", restAPIRequest.getHeaders());

        CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);


		if (StringUtils.isEmpty(dxlResponse.getData())) {
			throw new ServiceException(CommonConstants.ERROR_CODE_500, CommonConstants.INTERNAL_SERVER_ERROR);
		} else {
			try {
				InputStream in = BusinessServices.class
						.getResourceAsStream(CommonConstants.BUSINESS_SERVICE_RESPONSE_DEFINITION);

				JsonNode transformedJsonNode = responseParser.parse(in, dxlResponse.getData());
				LOGGER.debug("Transformed Response {}", transformedJsonNode.toString());
				List<BusinessService> businessServicesList = new ArrayList<>();
				transformedJsonNode.forEach(node -> {
					BusinessService businessService = null;
					try {
						businessService = responseParser.getCoveMapper().readValue(node.toString(), BusinessService.class);
					} catch (Exception e) {
						LOGGER.error("Exception {} ", e);
					}
					if (businessService != null) {
						businessServicesList.add(businessService);
					}
				});
				coveResponse.setBusinessServices(
						businessServicesList.toArray(new BusinessService[businessServicesList.size()]));
			} catch (Exception ex) {
				LOGGER.error("Exception {} ", ex);
			}
		}
		return coveResponse;
	}

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }
}
