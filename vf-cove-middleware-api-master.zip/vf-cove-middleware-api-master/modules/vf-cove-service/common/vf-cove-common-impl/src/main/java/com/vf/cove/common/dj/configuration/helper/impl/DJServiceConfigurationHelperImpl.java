package com.vf.cove.common.dj.configuration.helper.impl;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.vf.cove.common.dj.configuration.DJServiceConfiguration;
import com.vf.cove.common.dj.configuration.helper.DJServiceConfigurationHelper;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;

import java.util.Map;

@Component(
        configurationPid = DJServiceConfiguration.PID,
        configurationPolicy = ConfigurationPolicy.OPTIONAL,
        immediate = true,
        service = DJServiceConfigurationHelper.class
)
public class DJServiceConfigurationHelperImpl implements DJServiceConfigurationHelper {

    private DJServiceConfiguration djServiceConfiguration;

	@Override
	public DJServiceConfiguration getDJServiceConfiguration() {
		return djServiceConfiguration;
	}

    @Activate
    @Modified
    protected void activate(Map<Object, Object> properties) {
    	djServiceConfiguration = ConfigurableUtil.createConfigurable(
    			DJServiceConfiguration.class, properties);
    }

}

