package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.common.dto.v1_0.CatalogueItemsRequest;
import com.vf.cove.common.dto.v1_0.CatalogueItemsResponse;
import com.vf.cove.common.dto.v1_0.CatalogueService;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Component(service = CatalogueItemsService.class)
public class CatalogueItemsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CatalogueItemsService.class);

	private static final String CATALOGUE_ITEMS = "/cove/customerServiceInventoryItem/getCustomerServiceInventoryItem";

	@Reference(target="(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	public CatalogueItemsResponse postCatalogueItem(CatalogueItemsRequest catalogueItemsRequest, String messageId)
			throws Exception {
		CatalogueItemsResponse coveResponse = new CatalogueItemsResponse();
		final String request = catalogueItemsRequest.toString();
        String relativeUrl = CATALOGUE_ITEMS ;
        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);

        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            restAPIRequest.addHeader(CommonConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
        LOGGER.info("Request Headers.. {}", restAPIRequest.getHeaders());

		CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);


		if (StringUtils.isEmpty(dxlResponse.getData())) {
			throw new ServiceException(CommonConstants.ERROR_CODE_500, CommonConstants.INTERNAL_SERVER_ERROR);
		} else {
			try {
				InputStream in = BusinessServices.class
						.getResourceAsStream(CommonConstants.CATALOGUE_ITEMS_RESPONSE_DEFINITION);
				JsonNode transformedJsonNode = responseParser.parse(in, dxlResponse.getData());
				LOGGER.info("Transformed Response {} ", transformedJsonNode.toString());
				List<CatalogueService> catalogueItemsList = new ArrayList<>();
				transformedJsonNode.forEach(node -> {
					CatalogueService catalogueItem = null;
					try {
						catalogueItem = responseParser.getCoveMapper().readValue(node.toString(), CatalogueService.class);
					} catch (Exception e) {
						LOGGER.error("Exception {}", e);
					}
					if (catalogueItem != null) {
						catalogueItemsList.add(catalogueItem);
					}
				});
				coveResponse.setCatalogueServices(
						catalogueItemsList.toArray(new CatalogueService[catalogueItemsList.size()]));
			} catch (Exception ex) {
				LOGGER.error("Exception {}", ex);
			}
		}
		return coveResponse;
	}

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }


}
