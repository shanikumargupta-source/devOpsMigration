package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "buttonType", "isIcon", "name", "location", "id", "type", "CreateHandler" })
public class Data_ {

	@JsonProperty("buttonType")
	private String buttonType;
	@JsonProperty("isIcon")
	private boolean isIcon;
	@JsonProperty("name")
	private String name;
	@JsonProperty("location")
	private String location;
	@JsonProperty("id")
	private String id;
	@JsonProperty("type")
	private String type;
	@JsonProperty("CreateHandler")
	private String createHandler;

	@JsonProperty("buttonType")
	public String getButtonType() {
		return buttonType;
	}

	@JsonProperty("buttonType")
	public void setButtonType(String buttonType) {
		this.buttonType = buttonType;
	}

	@JsonProperty("isIcon")
	public boolean isIsIcon() {
		return isIcon;
	}

	@JsonProperty("isIcon")
	public void setIsIcon(boolean isIcon) {
		this.isIcon = isIcon;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("location")
	public String getLocation() {
		return location;
	}

	@JsonProperty("location")
	public void setLocation(String location) {
		this.location = location;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("CreateHandler")
	public String getCreateHandler() {
		return createHandler;
	}

	@JsonProperty("CreateHandler")
	public void setCreateHandler(String createHandler) {
		this.createHandler = createHandler;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("buttonType", buttonType).append("isIcon", isIcon).append("name", name)
				.append("location", location).append("id", id).append("type", type)
				.append("createHandler", createHandler).toString();
	}

}
