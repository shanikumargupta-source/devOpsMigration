package com.vf.cove.common.internal.resource.v1_0;

import com.vf.cove.common.dto.v1_0.CodeListRequest;
import com.vf.cove.common.dto.v1_0.CodeListResponse;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.resource.service.CodeListService;
import com.vf.cove.common.resource.v1_0.CodeListResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/code-list-response.properties", scope = ServiceScope.PROTOTYPE, service = CodeListResponseResource.class)
public class CodeListResponseResourceImpl extends BaseCodeListResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CodeListResponseResourceImpl.class);

	@Reference(unbind = "-")
	private CodeListService codeListService;

	public CodeListResponse postCodeList(CodeListRequest codeListRequest) throws Exception {
		String messageId = RequestUtils.getUUID();
		requiredFieldValidations(codeListRequest);
		LOGGER.info("Invoking codeList API for messageId {} " + messageId);
		if (ObjectUtils.isNotEmpty(codeListRequest) && ObjectUtils.isNotEmpty(contextUser)) {
			codeListRequest.setUserId(contextUser.getEmailAddress());
			codeListRequest.setCurrentDate(RequestUtils.getUTCDate());
			codeListRequest.setMessageId(messageId);
			codeListRequest.setCustomerId(String.valueOf(
					contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));

			return codeListService.postCodeList(codeListRequest, messageId);
		}
		return new CodeListResponse();
	}

	private void requiredFieldValidations(CodeListRequest codeListRequest) throws Exception {
		LOGGER.debug("Inside codeList - requiredFieldValidations()");
		if (StringUtils.isEmpty(codeListRequest.getBusinessService())
				|| StringUtils.isEmpty(codeListRequest.getType())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
	}
}
