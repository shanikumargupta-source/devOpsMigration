package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sectionSysId", "stepSequenceNum", "currentStepName", "id", "nextStepName", "prevStepName",
		"containerClass", "listOfFields", "footerFields", "validationRules" })
public class CoveStep {

	@JsonProperty("sectionSysId")
	private String sectionSysId;
	@JsonProperty("stepSequenceNum")
	private String stepSequenceNum;
	@JsonProperty("currentStepName")
	private String currentStepName;
	@JsonProperty("id")
	private String id;
	@JsonProperty("nextStepName")
	private String nextStepName;
	@JsonProperty("prevStepName")
	private String prevStepName;
	@JsonProperty("containerClass")
	private String containerClass;
	@JsonProperty("listOfFields")
	private List<ListOfField> listOfFields = null;
	@JsonProperty("footerFields")
	private List<FooterField> footerFields = null;
	@JsonProperty("validationRules")
	private ValidationRules validationRules;

	@JsonProperty("sectionSysId")
	public String getSectionSysId() {
		return sectionSysId;
	}

	@JsonProperty("sectionSysId")
	public void setSectionSysId(String sectionSysId) {
		this.sectionSysId = sectionSysId;
	}

	@JsonProperty("stepSequenceNum")
	public String getStepSequenceNum() {
		return stepSequenceNum;
	}

	@JsonProperty("stepSequenceNum")
	public void setStepSequenceNum(String stepSequenceNum) {
		this.stepSequenceNum = stepSequenceNum;
	}

	@JsonProperty("currentStepName")
	public String getCurrentStepName() {
		return currentStepName;
	}

	@JsonProperty("currentStepName")
	public void setCurrentStepName(String currentStepName) {
		this.currentStepName = currentStepName;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("nextStepName")
	public String getNextStepName() {
		return nextStepName;
	}

	@JsonProperty("nextStepName")
	public void setNextStepName(String nextStepName) {
		this.nextStepName = nextStepName;
	}

	@JsonProperty("prevStepName")
	public String getPrevStepName() {
		return prevStepName;
	}

	@JsonProperty("prevStepName")
	public void setPrevStepName(String prevStepName) {
		this.prevStepName = prevStepName;
	}

	@JsonProperty("containerClass")
	public String getContainerClass() {
		return containerClass;
	}

	@JsonProperty("containerClass")
	public void setContainerClass(String containerClass) {
		this.containerClass = containerClass;
	}

	@JsonProperty("listOfFields")
	public List<ListOfField> getListOfFields() {
		return listOfFields;
	}

	@JsonProperty("listOfFields")
	public void setListOfFields(List<ListOfField> listOfFields) {
		this.listOfFields = listOfFields;
	}

	@JsonProperty("footerFields")
	public List<FooterField> getFooterFields() {
		return footerFields;
	}

	@JsonProperty("footerFields")
	public void setFooterFields(List<FooterField> footerFields) {
		this.footerFields = footerFields;
	}

	@JsonProperty("validationRules")
	public ValidationRules getValidationRules() {
		return validationRules;
	}

	@JsonProperty("validationRules")
	public void setValidationRules(ValidationRules validationRules) {
		this.validationRules = validationRules;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("sectionSysId", sectionSysId).append("stepSequenceNum", stepSequenceNum)
				.append("currentStepName", currentStepName).append("id", id).append("nextStepName", nextStepName)
				.append("prevStepName", prevStepName).append("containerClass", containerClass)
				.append("listOfFields", listOfFields).append("footerFields", footerFields)
				.append("validationRules", validationRules).toString();
	}

}
