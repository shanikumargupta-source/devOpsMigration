<@compress single_line=true>
{
  "CISelection": {
    "listOfFieldIds": ["configurationItem"]
  },
  "YourReference": {
    "listOfFieldIds": [ "companyItem", "sla","yourReference", "summary", "date_time_picker" ]
  },
  "Configurationitem": {
    "listOfFieldIds": [ "configurationItemId" ]
  },
  "Impact": {
    "listOfFieldIds": [ "impactRangeSlider", "urgencyRangeSlider" ]
  },
  "Attachfiles": {
    "listOfFieldIds": [ "fileNames" ]
  }
}
</@compress>
