package com.vf.cove.common.internal.resource.v1_0;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.common.dto.v1_0.ExportPDFRequest;
import com.vf.cove.common.dto.v1_0.ExportPDFResponse;
import com.vf.cove.common.internal.model.BusinessServices;
import com.vf.cove.common.internal.model.CommonConstants;
import com.vf.cove.common.internal.model.GetArticleDetails;
import com.vf.cove.common.internal.model.ViewSalesOrder;
import com.vf.cove.common.internal.resource.service.ExportPDFService;
import com.vf.cove.common.resource.v1_0.ExportPDFResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author GhousPasha
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/export-pdf-response.properties", scope = ServiceScope.PROTOTYPE, service = ExportPDFResponseResource.class)
public class ExportPDFResponseResourceImpl extends BaseExportPDFResponseResourceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExportPDFResponseResourceImpl.class);

	@Reference(unbind = "-")
	private ExportPDFService exportPDFService;

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	@SuppressWarnings("unchecked")
	public ExportPDFResponse postExportPDF(ExportPDFRequest exportPDFRequest) throws Exception {
		ExportPDFResponse response = new ExportPDFResponse();
		LOGGER.info("Invoking exportPDF API ");
		requiredFieldValidation(exportPDFRequest);
		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> inputParams = null;
			String input = formatRequest(exportPDFRequest.getRequestBody());
			LOGGER.info("RequestBody String:: " + input);
			if (exportPDFRequest.getRequestType().equalsIgnoreCase(FileType.order.toString())
					&& StringUtils.isNotEmpty(input)) {
				ViewSalesOrder orderInput = responseParser.getCoveMapper().readValue(exportPDFRequest.getRequestBody(),
						ViewSalesOrder.class);
				if (orderInput != null) {
					orderInput.setCustomer(String.valueOf(contextUser.getOrganizations().get(0).getExpandoBridge()
							.getAttribute(Constants.VGECO_ORG_NAME)));
				}
				inputParams = mapper.convertValue(orderInput, Map.class);
			} else if (exportPDFRequest.getRequestType().equalsIgnoreCase(FileType.knowledgeCenter.toString())
					&& StringUtils.isNotEmpty(input)) {
				GetArticleDetails articleDetails = responseParser.getCoveMapper()
						.readValue(exportPDFRequest.getRequestBody(), GetArticleDetails.class);
				if (articleDetails.getBusinessService() != null) {
					List<BusinessServices> businessServicesList = new ArrayList<>();
					Set<String> uniqueValues = new HashSet<>();
					for (BusinessServices businessServices : articleDetails.getBusinessService()) {
						String bsName = businessServices.getDescription();
						if (!uniqueValues.contains(bsName)) {
							businessServicesList.add(businessServices);
							uniqueValues.add(bsName);
						}
					}
					for (BusinessServices bs : businessServicesList) {
						LOGGER.info("bs name  " + bs.getDescription());
					}
					articleDetails.setBusinessService(businessServicesList);
				}
				String rating = StringUtils.EMPTY;
				if (articleDetails.getArticleRating() != null) {
					double ratingPercentage = (Double.parseDouble(articleDetails.getArticleRating()) * 100) / 5;
					LOGGER.info("ratingPercentage  " + ratingPercentage);
					if (ratingPercentage > 1) {
						rating = "style=\"width: ${ratingPercentage}%\"";
					} else {
						rating = "style=\"width: 0%\"";
					}
				} else {
					rating = "style=\"width: 0%\"";
				}
				articleDetails.setArticleRating(rating);
				inputParams = mapper.convertValue(articleDetails, Map.class);
			} else {
				inputParams = responseParser.getCoveMapper().readValue(input, HashMap.class);
                LOGGER.debug("response pdf input params: {}", inputParams);
                if (inputParams != null && inputParams.containsKey("variables")){
                    inputParams = wrapEmptyQuestions(inputParams);
                    LOGGER.info("wrap questions pdf params: {}", inputParams);
                }
			}
			response = exportPDFService.exportPDF(inputParams, exportPDFRequest);
		} catch (Exception ex) {
			LOGGER.error("Error in exportPDF :" + ex);
		}
		return response;
	}

	private void requiredFieldValidation(ExportPDFRequest request) throws Exception {
		LOGGER.debug("Inside exportPDF - requiredFieldValidation()");
		if (StringUtils.isEmpty(request.getReferenceNumber()) || StringUtils.isEmpty(request.getRequestBody())
				|| StringUtils.isEmpty(request.getRequestType())) {
			throw new ValidationException(CommonConstants.ERROR_CODE_400, CommonConstants.MISSING_REQUIRED_ATTRIBUTES);
		}
	}

    private String formatRequest(String request) {
        return StringUtils.isNotEmpty(request) ? request.replace("\\\"null\\\"", "\\\"\\\"")
            .replace("null", "\" \"").replace("\\\"slaDueIn\\\":\\\"-\\\",", "\\\"slaDueIn\\\":\\\"0\\\",")
            : StringUtils.EMPTY;
    }

    public static Map<String, Object> wrapEmptyQuestions(Map<String, Object> pdfParams) {
        Object variablesObj = pdfParams.get("variables");

        List<?> variablesList = (List<?>) variablesObj;
        List<Map<String, Object>> cleanedList = new ArrayList<>();

        for (Object item : variablesList) {
            if (item instanceof Map) {
                Map<?, ?> variable = (Map<?, ?>) item;
                Object value = variable.get("value");

                if (value != null && !value.toString().trim().isEmpty()) {
                    cleanedList.add((Map<String, Object>) variable);
                }
            }
        }

        pdfParams.replace("variables", cleanedList);

        return pdfParams;
    }

}

enum FileType {
	incident, servicerequest, problem, billingQuery, order, knowledgeCenter;
}


