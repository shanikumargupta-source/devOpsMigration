package com.vf.cove.common.internal.model.dynamicjourney.covestep;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "name", "id", "lightBackground", "arrowRequired", "messageTitle", "messageBody" })
public class MessageProps {

	@JsonProperty("type")
	private String type;
	@JsonProperty("name")
	private String name;
	@JsonProperty("id")
	private String id;
	@JsonProperty("lightBackground")
	private boolean lightBackground;
	@JsonProperty("arrowRequired")
	private boolean arrowRequired;
	@JsonProperty("messageTitle")
	private String messageTitle;
	@JsonProperty("messageBody")
	private String messageBody;

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("lightBackground")
	public boolean isLightBackground() {
		return lightBackground;
	}

	@JsonProperty("lightBackground")
	public void setLightBackground(boolean lightBackground) {
		this.lightBackground = lightBackground;
	}

	@JsonProperty("arrowRequired")
	public boolean isArrowRequired() {
		return arrowRequired;
	}

	@JsonProperty("arrowRequired")
	public void setArrowRequired(boolean arrowRequired) {
		this.arrowRequired = arrowRequired;
	}

	@JsonProperty("messageTitle")
	public String getMessageTitle() {
		return messageTitle;
	}

	@JsonProperty("messageTitle")
	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	@JsonProperty("messageBody")
	public String getMessageBody() {
		return messageBody;
	}

	@JsonProperty("messageBody")
	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("type", type).append("name", name).append("id", id)
				.append("lightBackground", lightBackground).append("arrowRequired", arrowRequired)
				.append("messageTitle", messageTitle).append("messageBody", messageBody).toString();
	}

}
