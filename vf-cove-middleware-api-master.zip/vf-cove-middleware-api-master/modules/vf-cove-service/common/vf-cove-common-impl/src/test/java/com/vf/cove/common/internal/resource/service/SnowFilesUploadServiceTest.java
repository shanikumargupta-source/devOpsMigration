package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.common.dto.v1_0.Attachment;
import com.vf.cove.common.internal.util.CommonUtils;
import com.vf.cove.core.restutils.model.ServiceContext;
import com.vf.cove.core.restutils.service.SNowCallProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.HashMap;

import static com.vf.cove.common.internal.model.CommonConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class SnowFilesUploadServiceTest {

    @Mock
    private SNowCallProcessor snowCallProcessor;
    @Mock
    private CoveResponseParser coveResponseParser;
    @Mock
    private CommonUtils commonUtils;
	@InjectMocks
	private SnowFilesUploadService snowFilesUploadService;


	Attachment attachment;

	InputStream testFileToUpload;

	String customerId = "123456";

	String userId = "test@liferay.com";

	String deleteResponse;

	String uploadResponse;

	JsonNode uploadResponseNode;

	@Mock
	ObjectMapper mockmapper;

	ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	void setUp() throws Exception {
		attachment = new Attachment();
		attachment.setTicketId("ticket1");
		attachment.setCapability("RCS");

		deleteResponse = TestUtils.inputStreamToString("src/test/resources/deleteResponse.json");
		testFileToUpload = Files.newInputStream(new File("src/test/resources/uploadResponse.json").toPath());
		uploadResponse = TestUtils.inputStreamToString("src/test/resources/uploadResponse.json");
		uploadResponseNode = mapper.readTree(uploadResponse);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testDeleteAttachment() throws Exception {
		attachment.setSysId("642387ry2lhrflawefhlw7347823");
        when(coveResponseParser.getCoveMapper()).thenReturn(mapper);
		when(snowCallProcessor.getManageToken(eq(userId), eq(customerId))).thenReturn("1234");
		when(snowCallProcessor.processGetRequest(eq(DELETE_FILE_URL), any(HashMap.class), any(HashMap.class)))
				.thenReturn(deleteResponse);
		Attachment response = snowFilesUploadService.deleteAttachment(attachment, userId, customerId);
		assertEquals("success", response.getStatus());
	}

	@Test
	void testUploadFile() throws Exception {
		attachment.setVariableSysId("testvariableSysID");
		attachment.setBusinessService("RCS");
		attachment.setName("uploadResponse.json");
		when(snowCallProcessor.getManageToken(eq(userId), eq(customerId))).thenReturn("1234");
		when(snowCallProcessor.processPostRequest(eq(UPLOAD_FILE_URL), anyString(), any(ServiceContext.class)))
				.thenReturn(uploadResponse);
        when(coveResponseParser.getCoveMapper()).thenReturn(mapper);
        when(commonUtils.getDXLRequest(any(),any(),eq(FILE_UPLOAD_REQUEST_DEFINITION))).thenReturn("{}");
		Attachment response = snowFilesUploadService.uploadFile(attachment, testFileToUpload, userId, customerId);
		assertEquals("r2387rywiafhawliefhwelihfwifhwi3", response.getSysId());
	}

}
