package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import static org.junit.jupiter.api.Assertions.assertThrows;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.liferay.document.library.kernel.model.DLFileVersion;
import com.liferay.document.library.kernel.service.DLAppService;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.vf.configprovider.global.configuration.CatalogMessageConfiguration;
import com.vf.configprovider.global.configuration.helper.CatalogMessageConfigurationHelper;
import com.vf.cove.common.dj.configuration.DJServiceConfiguration;
import com.vf.cove.common.dj.configuration.helper.DJServiceConfigurationHelper;
import com.vf.cove.common.dto.v1_0.CodeListRequest;
import com.vf.cove.common.dto.v1_0.DynamicJourneyRequest;
import com.vf.cove.common.dto.v1_0.DynamicJourneyResponse;
import com.vf.cove.common.internal.model.dynamicjourney.DJConstants;
import com.vf.cove.common.internal.model.dynamicjourney.ListOfField;
import com.vf.cove.common.internal.util.CommonUtils;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class DynamicJourneyServiceTest {

    @Mock
    private CoveResponseParser responseParser;

    @Mock
    private RestAPIProcessor restAPIProcessor;

    @Mock
    DynamicJourneyRequest djRequest;

    @InjectMocks
    DynamicJourneyService dynamicJourneyService;

    @Mock
    DJServiceConfigurationHelper djServiceConfigurationHelper;

    @Mock
    DJServiceConfiguration djServiceConfiguration;

    @Mock
    private DLAppService dlAppService;

    @Mock
    CatalogMessageConfiguration catalogMessageConfiguration;

    @Mock
    CatalogMessageConfigurationHelper catalogMessageConfigurationHelper;

    @Mock
    FileEntry fileEntry;

    @Mock
    DLFileVersion fileVersion;

    @Mock
    Folder folder;

    InputStream inputStream;

    private long folderId = 12356;
    private String SuccessINCResponse;
    private String SuccessSRResponse;
    private String FailureResponse;
    private static final String MESSAGE_ID = "101df58d-6f7f-4cb0-bf2f-a609ca045943";

    private CoveResponse esbResponse;
    private CodeListRequest codeListRequest;
    private JsonNode jsonNode;
    private static ObjectMapper mapper = new ObjectMapper();

    private static final String defaultMessage = "{\n\"48b99244dbd84c50abb83a7f7c96194d\":\"Please note that there may be a charge associated with your request. If there is, your Account Manager will be in touch.\",\n\"eb396a04db1c4c50abb83a7f7c96192a\":\"Please note that there may be a charge associated with your request. If there is, your Account Manager will be in touch.\"\n}";
    private static final String categorySysId = "8f31b78bdb408850abb83a7f7c961912,15f3a0dadb08c4502cb5325c7c9619dd,48b99244dbd84c50abb83a7f7c96194d,2f89dddedb33b7805273325c7c961962,eb396a04db1c4c50abb83a7f7c96192a,ab87dfa0dbb34b0078fd3a7f7c9619d3,a2ac13e4dbf34f001b75325c7c961959,d43c5b64dbf34f001b75325c7c9619aa,297c1fa4dbb34b0078fd3a7f7c96193f,0293432cdb3f0f001b75325c7c9619ad,25bd17e5db781b00f5177d5a8c961931,56b96865db1e5f4060fc5259dc9619f4,21ecdba4dbb34b0078fd3a7f7c96198b,ff5ddbe4dbb34b0078fd3a7f7c96198d,60ec65a9db73cf0078fd3a7f7c9619c5";
    private String vonceSysId = "ca6e58a8dbf254d0ee055259dc96192c,406004f0db7e54d068e57d5a8c961945,b97201b0dbfa94d068e57d5a8c9619c0,d2296754db7690d068e57d5a8c961990,a4730ca8db7e14d0ee055259dc96193d,ce80053cdbba94d068e57d5a8c9619a3";
    private String validationMessage = "{\n  \"NUMERIC\": \"Characters must be numeric\",\n  \"ALPHANUMERIC\": \"The value you entered is invalid\",\n  \"ALPHABETIC\": \"The value you entered is invalid\",\n  \"EMAIL\": \"The email ID you entered is invalid\",\n  \"TELEPHONENUMBER\": \"The telephone number you entered is invalid\",\n  \"MOBILENUMBER\": \"The mobile number you entered is invalid\",\n  \"POSTCODE\": \"The postcode you entered is invalid\"\n}";

    @Mock
    private CommonUtils commonUtils;

    @BeforeEach
    public void setUp() throws Exception {
        when(djServiceConfiguration.validationMessages()).thenReturn(validationMessage);
        when(djServiceConfiguration.vonecSysId()).thenReturn(vonceSysId);
        when(djServiceConfigurationHelper.getDJServiceConfiguration()).thenReturn(djServiceConfiguration);
        SuccessINCResponse = TestUtils.inputStreamToString("src/test/resources/GetDynamicJourneyINCResp.json");
        SuccessSRResponse = TestUtils.inputStreamToString("src/test/resources/GetDynamicJourneySRResp.json");
        FailureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");

        inputStream = new FileInputStream("src/test/resources/PortalStep.json");

        esbResponse = new CoveResponse();
        codeListRequest = new CodeListRequest();

        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());

        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("HEADER", "COVE");
        esbResponse.setHeaders(responseHeaders);
        esbResponse.setHeaders(responseHeaders);

        jsonNode = mapper.readTree(SuccessSRResponse);
        when(responseParser.parse(any(InputStream.class), eq(esbResponse.getData()))).thenReturn(jsonNode);

    }

    @Test
    public void getDynamicJourneyMetadataINCSuccessResponse() throws Exception {
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
        DynamicJourneyResponse djResponse = dynamicJourneyService.getDynamicJourneyMetadata(djRequest, MESSAGE_ID);
        Assertions.assertThat(djResponse).isNotNull();

    }

    @Test
    public void getDynamicJourneyMetadataSRSuccessResponse() throws Exception {
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
        DynamicJourneyResponse djResponse = dynamicJourneyService.getDynamicJourneyMetadata(djRequest, MESSAGE_ID);
        Assertions.assertThat(djResponse).isNotNull();

    }

    @Test
    public void getDynamicJourneyMetadataFailureResponse() throws Exception {
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
        DynamicJourneyResponse djResponse = dynamicJourneyService.getDynamicJourneyMetadata(djRequest, MESSAGE_ID);
        Assertions.assertThat(djResponse).isNotNull();

    }

    @Test
    public void testAddbackButton() throws IOException {
        when(responseParser.getCoveMapper()).thenReturn(mapper);
        JsonNode coveObject = mapper.readTree(TestUtils.inputStreamToString("src/test/resources/COVEResponse.json"));

        Map<String, Object> groupByObject = mapper
            .readValue(TestUtils.inputStreamToString("src/test/resources/BackButton.json"), HashMap.class);
        ;

        dynamicJourneyService.addbackButton((ObjectNode) coveObject, groupByObject);
        Assertions.assertThat(coveObject.get(DJConstants.YOUR_REFERENCE_STEP_ID).get(DJConstants.FOOTER_FIELDS).size()).isGreaterThan(2);
    }


    //@Test
    public void getDJMetadataINCSuccessResponse() throws Exception {
        Mockito.when(catalogMessageConfiguration.defaultLoadMessageConfiguration()).thenReturn(defaultMessage);
        Mockito.when(catalogMessageConfiguration.noCategorySysIDs()).thenReturn(categorySysId);
        Mockito.when(catalogMessageConfigurationHelper.getCatalogMessageConfiguration()).thenReturn(catalogMessageConfiguration);
        Mockito.when(dlAppService.getFolder(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(folder);
        Mockito.when(folder.getFolderId()).thenReturn(folderId);
        Mockito.when(dlAppService.getFileEntry(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString()))
            .thenReturn(fileEntry);
        Mockito.when(fileEntry.getContentStream()).thenReturn(inputStream);
        when(responseParser.getCoveMapper()).thenReturn(mapper);
        esbResponse.setData(SuccessSRResponse);
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);

        DynamicJourneyResponse djResponse = dynamicJourneyService.getDynamicJourneyMetadata(getDJRequest(), MESSAGE_ID);
        Assertions.assertThat(djResponse).isNotNull();
        String respo = djResponse.getGetDynamicJourneyMetadata().getResponse().toString();
        Assertions.assertThat(respo).contains("CISelection");

    }

    @Test
    public void testGetFieldTypeContent() throws Exception {
        when(commonUtils.getDXLRequest(any(), anyMap(), anyString())).thenReturn("{\"name\":\"IncidentDateTime\"}");
        ListOfField listOfField = getListOfField();
        String result = dynamicJourneyService.getFieldTypeContent(listOfField, DJConstants.DATETIME);
        Assertions.assertThat(result).isNotNull();
        Assertions.assertThat(result).contains("IncidentDateTime");
    }

    private DynamicJourneyRequest getDJRequest() {
        DynamicJourneyRequest dynamicJourneyRequest = new DynamicJourneyRequest();
        dynamicJourneyRequest.setGroupID("42314");
        dynamicJourneyRequest.setJourneyName(DJConstants.SERVICE_REQUEST);
        dynamicJourneyRequest.setCatalogueItemSysID("48b99244dbd84c50abb83a7f7c96194d");
        return dynamicJourneyRequest;
    }

    private ListOfField getListOfField() {
        ListOfField listOfField = new ListOfField();
        listOfField.setModel("VOne");
        listOfField.setReadOnly("false");
        listOfField.setIsRequired("true");
        listOfField.setName("IncidentDateTime");
        listOfField.setHelpText("(UTC) Coordinated Universal Time");
        listOfField.setInputLabel("When did this incident first occur");
        listOfField.setSelectIpLabel("test");
        listOfField.setType(DJConstants.DATETIME);

        return listOfField;
    }

    @Test
    public void testGetValidationMessagesException() {
        when(responseParser.getCoveMapper()).thenReturn(mapper);
        DJServiceConfiguration mockDjServiceConfiguration = Mockito.mock(DJServiceConfiguration.class);
        when(mockDjServiceConfiguration.validationMessages()).thenReturn(null);


        assertThrows(IllegalArgumentException.class, () -> {
            dynamicJourneyService.getValidationMessages(mockDjServiceConfiguration);
        });

    }

}
