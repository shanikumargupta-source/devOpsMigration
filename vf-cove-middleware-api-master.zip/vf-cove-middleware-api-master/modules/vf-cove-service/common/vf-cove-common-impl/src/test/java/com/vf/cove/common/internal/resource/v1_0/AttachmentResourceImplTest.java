package com.vf.cove.common.internal.resource.v1_0;

import com.liferay.expando.kernel.model.ExpandoBridge;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.vulcan.multipart.BinaryFile;
import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.vf.cove.common.dto.v1_0.Attachment;
import com.vf.cove.common.internal.resource.service.SnowFilesUploadService;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AttachmentResourceImplTest {

	@InjectMocks
	AttachmentResourceImpl attachmentResourceImpl;

	@Mock
	SnowFilesUploadService filesUploadService;

	@Mock
	MultipartBody multipartBody;

	@Mock
	BinaryFile binaryFile;

	@Mock
	InputStream inputStream;

	@Mock
	Attachment mockAttachment;

	@Mock
	User contextUser;

	List<Organization> organisationList = new ArrayList<Organization>();

	@Mock
	Organization organization;

	@Mock
	ExpandoBridge expandoBridge;

	String customerId = "123456";

	String userId = "test@liferay.com";

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testPostAttachment() throws Exception {
		mockContextUser();
		when(multipartBody.getBinaryFile(eq("file"))).thenReturn(binaryFile);
		when(binaryFile.getFileName()).thenReturn("testFile.doc");
		when(binaryFile.getInputStream()).thenReturn(inputStream);

		when(multipartBody.getValueAsInstance(eq("attachment"), eq(Attachment.class))).thenReturn(mockAttachment);
		when(mockAttachment.getTicketId()).thenReturn("ticket1");
		when(mockAttachment.getCapability()).thenReturn("RCS");
		Attachment serviceResponse = new Attachment();
		String sysid = "ufyweufwedfwe873485347";
		serviceResponse.setSysId(sysid);
		when(filesUploadService.uploadFile(eq(mockAttachment), eq(inputStream), eq(userId), eq(customerId)))
				.thenReturn(serviceResponse);
		Attachment attachment = attachmentResourceImpl.postAttachment(multipartBody);
		assertEquals(sysid, attachment.getSysId());
	}

	@Test
	void testPostAttachmentValidationIssue() throws Exception {
		Attachment serviceResponse = new Attachment();
		String sysid = "ufyweufwedfwe873485347";
		serviceResponse.setSysId(sysid);
		Assertions.assertThatThrownBy(() -> attachmentResourceImpl.postAttachment(multipartBody))
				.isInstanceOf(ValidationException.class);
	}

	@Test
	void testPostAttachmentDelete() throws Exception {
		mockContextUser();
		when(mockAttachment.getTicketId()).thenReturn("ticket1");
		when(mockAttachment.getSysId()).thenReturn("642387ry2lhrflawefhlw7347823");
		when(mockAttachment.getCapability()).thenReturn("RCS");
		Attachment serviceResponse = new Attachment();
		serviceResponse.setStatus("Success");
		when(filesUploadService.deleteAttachment(eq(mockAttachment), eq(userId), eq(customerId)))
				.thenReturn(serviceResponse);
		Attachment attachment = attachmentResourceImpl.postAttachmentDelete(mockAttachment);
		assertEquals("Success", attachment.getStatus());
	}

	@Test
	void testPostAttachmentDeleteValidationIssue() throws Exception {
		Attachment serviceResponse = new Attachment();
		serviceResponse.setStatus("Success");
		Assertions.assertThatThrownBy(() -> attachmentResourceImpl.postAttachmentDelete(mockAttachment))
				.isInstanceOf(ValidationException.class);
	}

	void mockContextUser() throws PortalException {
		organisationList.add(organization);
		when(contextUser.getEmailAddress()).thenReturn(userId);
		when(contextUser.getOrganizations()).thenReturn(organisationList);
		when(organization.getExpandoBridge()).thenReturn(expandoBridge);
		when(expandoBridge.getAttribute(eq(Constants.LEGAL_ORG_ID))).thenReturn(customerId);
	}

}
