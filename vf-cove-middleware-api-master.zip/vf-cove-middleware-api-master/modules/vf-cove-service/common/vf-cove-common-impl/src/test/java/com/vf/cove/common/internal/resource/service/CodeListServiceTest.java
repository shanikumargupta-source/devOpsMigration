package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.common.dto.v1_0.CodeListRequest;
import com.vf.cove.common.dto.v1_0.CodeListResponse;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class CodeListServiceTest {

	@Mock
	private CoveResponseParser responseParser;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	@InjectMocks
	CodeListService codeListService;

	private String successResponse;
	private String failureResponse;
	private static final String MESSAGE_ID = "testMessageId";

	  private CoveResponse esbResponse;
	  private CodeListRequest codeListRequest;
	  private JsonNode jsonNode;
	  private static ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	public void setUp() throws Exception {
		successResponse = TestUtils.inputStreamToString("src/test/resources/CodeListSuccessResp.json");
		failureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");
		esbResponse = new CoveResponse();
		codeListRequest = new CodeListRequest();

        when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());

        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("HEADER", "COVE");
        esbResponse.setHeaders(responseHeaders);

        jsonNode = mapper.readTree(successResponse);
        when(responseParser.parse(any(InputStream.class),eq(esbResponse.getData()))).thenReturn(jsonNode);

        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setAttribute("contentLength","123");
        ServiceContextThreadLocal.pushServiceContext(serviceContext);

	}

	@Test
	public void codeListSuccessResponse() throws Exception {
		esbResponse.setData(successResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		CodeListResponse coResponse = codeListService.postCodeList(codeListRequest, MESSAGE_ID);
		Assertions.assertThat(coResponse).isNotNull();

	}

	@Test
	public void codeListFailureResponse() throws Exception {
		esbResponse.setData(failureResponse);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		CodeListResponse coResponse = codeListService.postCodeList(codeListRequest, MESSAGE_ID);
		Assertions.assertThat(coResponse).isNotNull();

	}

}

