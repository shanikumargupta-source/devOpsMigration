package com.vf.cove.common.internal.resource.service;

import com.vf.cove.common.dto.v1_0.ExportPDFRequest;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ExportPDFServiceTest {

	@Mock
	ExportPDFRequest exportPDFRequest;

	@InjectMocks
	ExportPDFService exportPDFService;

	Map<String, Object> inputParams;

	@BeforeEach
	public void setUp() throws Exception {

	}

	@Test
	public void testExportPDF() throws Exception {
		Assertions.assertThatThrownBy(() -> exportPDFService.exportPDF(inputParams, exportPDFRequest))
				.isInstanceOf(NullPointerException.class);
	}

	@Test
	public void testGetTemplatePath() throws NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Method method = ExportPDFService.class.getDeclaredMethod("getTemplatePath", String.class);
		method.setAccessible(true);
		String res = (String) method.invoke(exportPDFService, "test1");
		assertEquals("/templates/test1.html", res);
	}

	//@Test
	public void testCreatePDFFile() throws NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {

		Method method = ExportPDFService.class.getDeclaredMethod("createPDFFile", String.class, String.class);
		method.setAccessible(true);
		File file = (File) method.invoke(exportPDFService, "test1", "test2");
		Assertions.assertThat(file).isNotNull();

	}

}
