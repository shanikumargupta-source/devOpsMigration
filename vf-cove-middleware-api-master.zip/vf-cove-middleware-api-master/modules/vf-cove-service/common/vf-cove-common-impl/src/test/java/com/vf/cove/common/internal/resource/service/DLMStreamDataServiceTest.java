package com.vf.cove.common.internal.resource.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.common.dto.v1_0.DLMStreamDataRequest;
import com.vf.cove.common.dto.v1_0.DLMStreamDataResponse;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.service.SNowCallProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static com.vf.cove.common.internal.model.CommonConstants.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DLMStreamDataServiceTest {

	@InjectMocks
	DLMStreamDataService dlmStreamDataService;

	@Mock
	private SNowCallProcessor snowCallProcessor;

	@Mock
	private CoveResponseParser responseParser;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	private String successResponse;
	private String tokenSuccessResponse;

	private CoveResponse esbResponse;
	private JsonNode tokenJsonNode;
	Map<String, String> queryParams;
	private static final String fieldList = "u_device_id,u_msisdn,u_inherited_dlmid,u_unsupported_device,u_asset_entity_type,u_email_address,model_number,u_make,u_imei,u_eid,u_user_first_name,u_user_last_name,u_contact_tel_number,u_sku_id,u_business_service.location.country.name,u_business_service.location.country.iso3166_2,u_business_service.name,u_gscategory,u_reverse_exchange_type,u_lease_start_date,u_lease_end_date,sys_id,u_bulk_order_id,u_order_date,u_ban,u_custref,u_transaction_type,u_user_id,u_business_unit,u_cost_centre,u_cost_centre_2,u_cost_centre_3,u_cost_centre_4,u_user_address_1,u_user_address_2,u_user_address_3,u_user_address_4,u_user_state,u_user_post_code,u_user_country,u_delivery_date,u_sim_number,u_dispatched_date,u_sim_iccid,u_device_serial_number,u_leavers,u_customer_notes,u_warranty_start_date,u_warranty_end_date,name,u_inventory_id,u_business_service.company.name,u_user_city,u_county,u_sim_activation_status,u_sim_activation_date,u_business_unit,u_lease_start_date,u_lease_end_date,u_service_substatus,asset_tag";
	private static ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	public void setUp() throws Exception {
		successResponse = TestUtils.inputStreamToString("src/test/resources/DownloadSuccessResponse.json");
		tokenSuccessResponse = TestUtils.inputStreamToString("src/test/resources/tokenSuccess.json");
		esbResponse = new CoveResponse();

		queryParams = new HashMap<>();
		queryParams.put(TABLE_ID, MOBILE_DEVICE);
		queryParams.put(USER_EMAIL_ID, "test@vodafone.com");
		queryParams.put(LEGAL_ORG_ID, "VGECO");
		queryParams.put(U_REQUEST_TYPE, "initiate");

		when(responseParser.getCoveMapper()).thenReturn(mapper);

        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("HEADER", "COVE");
        esbResponse.setHeaders(responseHeaders);

        tokenJsonNode = mapper.readTree(tokenSuccessResponse);
        when(snowCallProcessor.processGetRequest(DLM_TOKEN, null, queryParams)).thenReturn(tokenSuccessResponse);
	}

	@Test
	void postDownloadSuccessResponse() throws Exception {
		esbResponse.setData(successResponse);
		DLMStreamDataRequest req = new DLMStreamDataRequest();
		req.setUserEmail("test@vodafone.com");
		req.setLegalOrgId("VGECO");
		req.setStreamApiDLMUS(Boolean.FALSE);
		req.setEorReport(Boolean.FALSE);
		String[] countryCode = {"GB"};
		req.setCountryCode(countryCode);

		Map<String, String> newQueryParams = new HashMap<>();
		newQueryParams.put(TABLE_ID, MOBILE_DEVICE);
		newQueryParams.put(USER_EMAIL_ID, "test@vodafone.com");
		newQueryParams.put(LEGAL_ORG_ID, "VGECO");
		newQueryParams.put(TOKEN, "462336410926419");
		newQueryParams.put(QUERY_PARAMS, "u_business_service.company.u_customer_id=VGECO^u_business_service.location.country.iso3166_2INGB");
		newQueryParams.put(U_FIELD_LIST, fieldList);

		when(snowCallProcessor.processGetRequest(INVENTORY_DATA, null, newQueryParams)).thenReturn(successResponse);

		DLMStreamDataResponse res = dlmStreamDataService.postDownload(req);
		assertNotNull(res);
		assertTrue(res.getDownload().getFileName().contains("DLMInventory"));
	}

}
