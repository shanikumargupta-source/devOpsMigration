package com.vf.cove.billingqueries.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("GetBillingServicesRequest")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetBillingServicesRequest")
public class GetBillingServicesRequest implements Serializable {

	public static GetBillingServicesRequest toDTO(String json) {
		return ObjectMapperUtil.readValue(
			GetBillingServicesRequest.class, json);
	}

	public static GetBillingServicesRequest unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			GetBillingServicesRequest.class, json);
	}

	@Schema
	public String getAccountName() {
		if (_accountNameSupplier != null) {
			accountName = _accountNameSupplier.get();

			_accountNameSupplier = null;
		}

		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;

		_accountNameSupplier = null;
	}

	@JsonIgnore
	public void setAccountName(
		UnsafeSupplier<String, Exception> accountNameUnsafeSupplier) {

		_accountNameSupplier = () -> {
			try {
				return accountNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String accountName;

	@JsonIgnore
	private Supplier<String> _accountNameSupplier;

	@Schema
	public String getBan() {
		if (_banSupplier != null) {
			ban = _banSupplier.get();

			_banSupplier = null;
		}

		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;

		_banSupplier = null;
	}

	@JsonIgnore
	public void setBan(UnsafeSupplier<String, Exception> banUnsafeSupplier) {
		_banSupplier = () -> {
			try {
				return banUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ban;

	@JsonIgnore
	private Supplier<String> _banSupplier;

	@Schema(example = "2019-07-03T06:52:31.289Z")
	public String getCountry() {
		if (_countrySupplier != null) {
			country = _countrySupplier.get();

			_countrySupplier = null;
		}

		return country;
	}

	public void setCountry(String country) {
		this.country = country;

		_countrySupplier = null;
	}

	@JsonIgnore
	public void setCountry(
		UnsafeSupplier<String, Exception> countryUnsafeSupplier) {

		_countrySupplier = () -> {
			try {
				return countryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String country;

	@JsonIgnore
	private Supplier<String> _countrySupplier;

	@Schema(example = "2019-07-03T06:52:31.289Z")
	public String getCurrentDate() {
		if (_currentDateSupplier != null) {
			currentDate = _currentDateSupplier.get();

			_currentDateSupplier = null;
		}

		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;

		_currentDateSupplier = null;
	}

	@JsonIgnore
	public void setCurrentDate(
		UnsafeSupplier<String, Exception> currentDateUnsafeSupplier) {

		_currentDateSupplier = () -> {
			try {
				return currentDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String currentDate;

	@JsonIgnore
	private Supplier<String> _currentDateSupplier;

	@Schema(example = "42487")
	public String getCustomerId() {
		if (_customerIdSupplier != null) {
			customerId = _customerIdSupplier.get();

			_customerIdSupplier = null;
		}

		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;

		_customerIdSupplier = null;
	}

	@JsonIgnore
	public void setCustomerId(
		UnsafeSupplier<String, Exception> customerIdUnsafeSupplier) {

		_customerIdSupplier = () -> {
			try {
				return customerIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String customerId;

	@JsonIgnore
	private Supplier<String> _customerIdSupplier;

	@Schema(example = "2019-06-03T06:52:32.184Z")
	public String getFromDate() {
		if (_fromDateSupplier != null) {
			fromDate = _fromDateSupplier.get();

			_fromDateSupplier = null;
		}

		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;

		_fromDateSupplier = null;
	}

	@JsonIgnore
	public void setFromDate(
		UnsafeSupplier<String, Exception> fromDateUnsafeSupplier) {

		_fromDateSupplier = () -> {
			try {
				return fromDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String fromDate;

	@JsonIgnore
	private Supplier<String> _fromDateSupplier;

	@Schema
	public Boolean getIsCompanySearch() {
		if (_isCompanySearchSupplier != null) {
			isCompanySearch = _isCompanySearchSupplier.get();

			_isCompanySearchSupplier = null;
		}

		return isCompanySearch;
	}

	public void setIsCompanySearch(Boolean isCompanySearch) {
		this.isCompanySearch = isCompanySearch;

		_isCompanySearchSupplier = null;
	}

	@JsonIgnore
	public void setIsCompanySearch(
		UnsafeSupplier<Boolean, Exception> isCompanySearchUnsafeSupplier) {

		_isCompanySearchSupplier = () -> {
			try {
				return isCompanySearchUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean isCompanySearch;

	@JsonIgnore
	private Supplier<Boolean> _isCompanySearchSupplier;

	@Schema(example = "3b0d49b8-6c31-4f8c-98e1-baf1c9a039afb")
	public String getMessageId() {
		if (_messageIdSupplier != null) {
			messageId = _messageIdSupplier.get();

			_messageIdSupplier = null;
		}

		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;

		_messageIdSupplier = null;
	}

	@JsonIgnore
	public void setMessageId(
		UnsafeSupplier<String, Exception> messageIdUnsafeSupplier) {

		_messageIdSupplier = () -> {
			try {
				return messageIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String messageId;

	@JsonIgnore
	private Supplier<String> _messageIdSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getOamuserId() {
		if (_oamuserIdSupplier != null) {
			oamuserId = _oamuserIdSupplier.get();

			_oamuserIdSupplier = null;
		}

		return oamuserId;
	}

	public void setOamuserId(String oamuserId) {
		this.oamuserId = oamuserId;

		_oamuserIdSupplier = null;
	}

	@JsonIgnore
	public void setOamuserId(
		UnsafeSupplier<String, Exception> oamuserIdUnsafeSupplier) {

		_oamuserIdSupplier = () -> {
			try {
				return oamuserIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String oamuserId;

	@JsonIgnore
	private Supplier<String> _oamuserIdSupplier;

	@Schema
	public String getOrganizationId() {
		if (_organizationIdSupplier != null) {
			organizationId = _organizationIdSupplier.get();

			_organizationIdSupplier = null;
		}

		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;

		_organizationIdSupplier = null;
	}

	@JsonIgnore
	public void setOrganizationId(
		UnsafeSupplier<String, Exception> organizationIdUnsafeSupplier) {

		_organizationIdSupplier = () -> {
			try {
				return organizationIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String organizationId;

	@JsonIgnore
	private Supplier<String> _organizationIdSupplier;

	@Schema(example = "0")
	public Integer getPageIndex() {
		if (_pageIndexSupplier != null) {
			pageIndex = _pageIndexSupplier.get();

			_pageIndexSupplier = null;
		}

		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;

		_pageIndexSupplier = null;
	}

	@JsonIgnore
	public void setPageIndex(
		UnsafeSupplier<Integer, Exception> pageIndexUnsafeSupplier) {

		_pageIndexSupplier = () -> {
			try {
				return pageIndexUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer pageIndex;

	@JsonIgnore
	private Supplier<Integer> _pageIndexSupplier;

	@Schema
	public String getParentAccountName() {
		if (_parentAccountNameSupplier != null) {
			parentAccountName = _parentAccountNameSupplier.get();

			_parentAccountNameSupplier = null;
		}

		return parentAccountName;
	}

	public void setParentAccountName(String parentAccountName) {
		this.parentAccountName = parentAccountName;

		_parentAccountNameSupplier = null;
	}

	@JsonIgnore
	public void setParentAccountName(
		UnsafeSupplier<String, Exception> parentAccountNameUnsafeSupplier) {

		_parentAccountNameSupplier = () -> {
			try {
				return parentAccountNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String parentAccountName;

	@JsonIgnore
	private Supplier<String> _parentAccountNameSupplier;

	@Schema
	public String getProduct() {
		if (_productSupplier != null) {
			product = _productSupplier.get();

			_productSupplier = null;
		}

		return product;
	}

	public void setProduct(String product) {
		this.product = product;

		_productSupplier = null;
	}

	@JsonIgnore
	public void setProduct(
		UnsafeSupplier<String, Exception> productUnsafeSupplier) {

		_productSupplier = () -> {
			try {
				return productUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String product;

	@JsonIgnore
	private Supplier<String> _productSupplier;

	@Schema(example = "20")
	public Integer getRecordsPerPage() {
		if (_recordsPerPageSupplier != null) {
			recordsPerPage = _recordsPerPageSupplier.get();

			_recordsPerPageSupplier = null;
		}

		return recordsPerPage;
	}

	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;

		_recordsPerPageSupplier = null;
	}

	@JsonIgnore
	public void setRecordsPerPage(
		UnsafeSupplier<Integer, Exception> recordsPerPageUnsafeSupplier) {

		_recordsPerPageSupplier = () -> {
			try {
				return recordsPerPageUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer recordsPerPage;

	@JsonIgnore
	private Supplier<Integer> _recordsPerPageSupplier;

	@Schema
	@Valid
	public SortOrder[] getSortOrder() {
		if (_sortOrderSupplier != null) {
			sortOrder = _sortOrderSupplier.get();

			_sortOrderSupplier = null;
		}

		return sortOrder;
	}

	public void setSortOrder(SortOrder[] sortOrder) {
		this.sortOrder = sortOrder;

		_sortOrderSupplier = null;
	}

	@JsonIgnore
	public void setSortOrder(
		UnsafeSupplier<SortOrder[], Exception> sortOrderUnsafeSupplier) {

		_sortOrderSupplier = () -> {
			try {
				return sortOrderUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected SortOrder[] sortOrder;

	@JsonIgnore
	private Supplier<SortOrder[]> _sortOrderSupplier;

	@Schema(example = "2019-07-03T06:52:32.184Z")
	public String getToDate() {
		if (_toDateSupplier != null) {
			toDate = _toDateSupplier.get();

			_toDateSupplier = null;
		}

		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;

		_toDateSupplier = null;
	}

	@JsonIgnore
	public void setToDate(
		UnsafeSupplier<String, Exception> toDateUnsafeSupplier) {

		_toDateSupplier = () -> {
			try {
				return toDateUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String toDate;

	@JsonIgnore
	private Supplier<String> _toDateSupplier;

	@Schema(example = "SBASRA@VIRTUSA.COM")
	public String getUserId() {
		if (_userIdSupplier != null) {
			userId = _userIdSupplier.get();

			_userIdSupplier = null;
		}

		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;

		_userIdSupplier = null;
	}

	@JsonIgnore
	public void setUserId(
		UnsafeSupplier<String, Exception> userIdUnsafeSupplier) {

		_userIdSupplier = () -> {
			try {
				return userIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String userId;

	@JsonIgnore
	private Supplier<String> _userIdSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetBillingServicesRequest)) {
			return false;
		}

		GetBillingServicesRequest getBillingServicesRequest =
			(GetBillingServicesRequest)object;

		return Objects.equals(toString(), getBillingServicesRequest.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String accountName = getAccountName();

		if (accountName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"accountName\": ");

			sb.append("\"");

			sb.append(_escape(accountName));

			sb.append("\"");
		}

		String ban = getBan();

		if (ban != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ban\": ");

			sb.append("\"");

			sb.append(_escape(ban));

			sb.append("\"");
		}

		String country = getCountry();

		if (country != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"country\": ");

			sb.append("\"");

			sb.append(_escape(country));

			sb.append("\"");
		}

		String currentDate = getCurrentDate();

		if (currentDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"currentDate\": ");

			sb.append("\"");

			sb.append(_escape(currentDate));

			sb.append("\"");
		}

		String customerId = getCustomerId();

		if (customerId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"customerId\": ");

			sb.append("\"");

			sb.append(_escape(customerId));

			sb.append("\"");
		}

		String fromDate = getFromDate();

		if (fromDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"fromDate\": ");

			sb.append("\"");

			sb.append(_escape(fromDate));

			sb.append("\"");
		}

		Boolean isCompanySearch = getIsCompanySearch();

		if (isCompanySearch != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"isCompanySearch\": ");

			sb.append(isCompanySearch);
		}

		String messageId = getMessageId();

		if (messageId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"messageId\": ");

			sb.append("\"");

			sb.append(_escape(messageId));

			sb.append("\"");
		}

		String oamuserId = getOamuserId();

		if (oamuserId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"oamuserId\": ");

			sb.append("\"");

			sb.append(_escape(oamuserId));

			sb.append("\"");
		}

		String organizationId = getOrganizationId();

		if (organizationId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"organizationId\": ");

			sb.append("\"");

			sb.append(_escape(organizationId));

			sb.append("\"");
		}

		Integer pageIndex = getPageIndex();

		if (pageIndex != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"pageIndex\": ");

			sb.append(pageIndex);
		}

		String parentAccountName = getParentAccountName();

		if (parentAccountName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"parentAccountName\": ");

			sb.append("\"");

			sb.append(_escape(parentAccountName));

			sb.append("\"");
		}

		String product = getProduct();

		if (product != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"product\": ");

			sb.append("\"");

			sb.append(_escape(product));

			sb.append("\"");
		}

		Integer recordsPerPage = getRecordsPerPage();

		if (recordsPerPage != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"recordsPerPage\": ");

			sb.append(recordsPerPage);
		}

		SortOrder[] sortOrder = getSortOrder();

		if (sortOrder != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"sortOrder\": ");

			sb.append("[");

			for (int i = 0; i < sortOrder.length; i++) {
				sb.append(String.valueOf(sortOrder[i]));

				if ((i + 1) < sortOrder.length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		String toDate = getToDate();

		if (toDate != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"toDate\": ");

			sb.append("\"");

			sb.append(_escape(toDate));

			sb.append("\"");
		}

		String userId = getUserId();

		if (userId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"userId\": ");

			sb.append("\"");

			sb.append(_escape(userId));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.billingqueries.dto.v1_0.GetBillingServicesRequest",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}