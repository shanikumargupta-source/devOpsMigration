package com.vf.cove.billingqueries.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("GetLatestBillingQuery")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetLatestBillingQuery")
public class GetLatestBillingQuery implements Serializable {

	public static GetLatestBillingQuery toDTO(String json) {
		return ObjectMapperUtil.readValue(GetLatestBillingQuery.class, json);
	}

	public static GetLatestBillingQuery unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(
			GetLatestBillingQuery.class, json);
	}

	@Schema
	public String getReference() {
		if (_ReferenceSupplier != null) {
			Reference = _ReferenceSupplier.get();

			_ReferenceSupplier = null;
		}

		return Reference;
	}

	public void setReference(String Reference) {
		this.Reference = Reference;

		_ReferenceSupplier = null;
	}

	@JsonIgnore
	public void setReference(
		UnsafeSupplier<String, Exception> ReferenceUnsafeSupplier) {

		_ReferenceSupplier = () -> {
			try {
				return ReferenceUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String Reference;

	@JsonIgnore
	private Supplier<String> _ReferenceSupplier;

	@Schema
	public String getStatus() {
		if (_StatusSupplier != null) {
			Status = _StatusSupplier.get();

			_StatusSupplier = null;
		}

		return Status;
	}

	public void setStatus(String Status) {
		this.Status = Status;

		_StatusSupplier = null;
	}

	@JsonIgnore
	public void setStatus(
		UnsafeSupplier<String, Exception> StatusUnsafeSupplier) {

		_StatusSupplier = () -> {
			try {
				return StatusUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String Status;

	@JsonIgnore
	private Supplier<String> _StatusSupplier;

	@Schema
	public String getStatusLabel() {
		if (_StatusLabelSupplier != null) {
			StatusLabel = _StatusLabelSupplier.get();

			_StatusLabelSupplier = null;
		}

		return StatusLabel;
	}

	public void setStatusLabel(String StatusLabel) {
		this.StatusLabel = StatusLabel;

		_StatusLabelSupplier = null;
	}

	@JsonIgnore
	public void setStatusLabel(
		UnsafeSupplier<String, Exception> StatusLabelUnsafeSupplier) {

		_StatusLabelSupplier = () -> {
			try {
				return StatusLabelUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String StatusLabel;

	@JsonIgnore
	private Supplier<String> _StatusLabelSupplier;

	@Schema
	public String getSummary() {
		if (_SummarySupplier != null) {
			Summary = _SummarySupplier.get();

			_SummarySupplier = null;
		}

		return Summary;
	}

	public void setSummary(String Summary) {
		this.Summary = Summary;

		_SummarySupplier = null;
	}

	@JsonIgnore
	public void setSummary(
		UnsafeSupplier<String, Exception> SummaryUnsafeSupplier) {

		_SummarySupplier = () -> {
			try {
				return SummaryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String Summary;

	@JsonIgnore
	private Supplier<String> _SummarySupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetLatestBillingQuery)) {
			return false;
		}

		GetLatestBillingQuery getLatestBillingQuery =
			(GetLatestBillingQuery)object;

		return Objects.equals(toString(), getLatestBillingQuery.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String Reference = getReference();

		if (Reference != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Reference\": ");

			sb.append("\"");

			sb.append(_escape(Reference));

			sb.append("\"");
		}

		String Status = getStatus();

		if (Status != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Status\": ");

			sb.append("\"");

			sb.append(_escape(Status));

			sb.append("\"");
		}

		String StatusLabel = getStatusLabel();

		if (StatusLabel != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"StatusLabel\": ");

			sb.append("\"");

			sb.append(_escape(StatusLabel));

			sb.append("\"");
		}

		String Summary = getSummary();

		if (Summary != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"Summary\": ");

			sb.append("\"");

			sb.append(_escape(Summary));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.billingqueries.dto.v1_0.GetLatestBillingQuery",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}