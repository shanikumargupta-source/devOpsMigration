package com.vf.cove.billingqueries.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Virtusa
 * @generated
 */
@Generated("")
@GraphQLName("GetBillingService")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "GetBillingService")
public class GetBillingService implements Serializable {

	public static GetBillingService toDTO(String json) {
		return ObjectMapperUtil.readValue(GetBillingService.class, json);
	}

	public static GetBillingService unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(GetBillingService.class, json);
	}

	@Schema
	public String getAccountName() {
		if (_accountNameSupplier != null) {
			accountName = _accountNameSupplier.get();

			_accountNameSupplier = null;
		}

		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;

		_accountNameSupplier = null;
	}

	@JsonIgnore
	public void setAccountName(
		UnsafeSupplier<String, Exception> accountNameUnsafeSupplier) {

		_accountNameSupplier = () -> {
			try {
				return accountNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String accountName;

	@JsonIgnore
	private Supplier<String> _accountNameSupplier;

	@Schema
	public String getBan() {
		if (_banSupplier != null) {
			ban = _banSupplier.get();

			_banSupplier = null;
		}

		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;

		_banSupplier = null;
	}

	@JsonIgnore
	public void setBan(UnsafeSupplier<String, Exception> banUnsafeSupplier) {
		_banSupplier = () -> {
			try {
				return banUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String ban;

	@JsonIgnore
	private Supplier<String> _banSupplier;

	@Schema
	public String getBanSystemId() {
		if (_banSystemIdSupplier != null) {
			banSystemId = _banSystemIdSupplier.get();

			_banSystemIdSupplier = null;
		}

		return banSystemId;
	}

	public void setBanSystemId(String banSystemId) {
		this.banSystemId = banSystemId;

		_banSystemIdSupplier = null;
	}

	@JsonIgnore
	public void setBanSystemId(
		UnsafeSupplier<String, Exception> banSystemIdUnsafeSupplier) {

		_banSystemIdSupplier = () -> {
			try {
				return banSystemIdUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String banSystemId;

	@JsonIgnore
	private Supplier<String> _banSystemIdSupplier;

	@Schema
	public String getCountry() {
		if (_countrySupplier != null) {
			country = _countrySupplier.get();

			_countrySupplier = null;
		}

		return country;
	}

	public void setCountry(String country) {
		this.country = country;

		_countrySupplier = null;
	}

	@JsonIgnore
	public void setCountry(
		UnsafeSupplier<String, Exception> countryUnsafeSupplier) {

		_countrySupplier = () -> {
			try {
				return countryUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String country;

	@JsonIgnore
	private Supplier<String> _countrySupplier;

	@Schema
	public String getParentAccountName() {
		if (_parentAccountNameSupplier != null) {
			parentAccountName = _parentAccountNameSupplier.get();

			_parentAccountNameSupplier = null;
		}

		return parentAccountName;
	}

	public void setParentAccountName(String parentAccountName) {
		this.parentAccountName = parentAccountName;

		_parentAccountNameSupplier = null;
	}

	@JsonIgnore
	public void setParentAccountName(
		UnsafeSupplier<String, Exception> parentAccountNameUnsafeSupplier) {

		_parentAccountNameSupplier = () -> {
			try {
				return parentAccountNameUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String parentAccountName;

	@JsonIgnore
	private Supplier<String> _parentAccountNameSupplier;

	@Schema
	public String getProduct() {
		if (_productSupplier != null) {
			product = _productSupplier.get();

			_productSupplier = null;
		}

		return product;
	}

	public void setProduct(String product) {
		this.product = product;

		_productSupplier = null;
	}

	@JsonIgnore
	public void setProduct(
		UnsafeSupplier<String, Exception> productUnsafeSupplier) {

		_productSupplier = () -> {
			try {
				return productUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String product;

	@JsonIgnore
	private Supplier<String> _productSupplier;

	@Schema
	public String getRegisteredSite() {
		if (_registeredSiteSupplier != null) {
			registeredSite = _registeredSiteSupplier.get();

			_registeredSiteSupplier = null;
		}

		return registeredSite;
	}

	public void setRegisteredSite(String registeredSite) {
		this.registeredSite = registeredSite;

		_registeredSiteSupplier = null;
	}

	@JsonIgnore
	public void setRegisteredSite(
		UnsafeSupplier<String, Exception> registeredSiteUnsafeSupplier) {

		_registeredSiteSupplier = () -> {
			try {
				return registeredSiteUnsafeSupplier.get();
			}
			catch (RuntimeException runtimeException) {
				throw runtimeException;
			}
			catch (Exception exception) {
				throw new RuntimeException(exception);
			}
		};
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String registeredSite;

	@JsonIgnore
	private Supplier<String> _registeredSiteSupplier;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof GetBillingService)) {
			return false;
		}

		GetBillingService getBillingService = (GetBillingService)object;

		return Objects.equals(toString(), getBillingService.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		String accountName = getAccountName();

		if (accountName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"accountName\": ");

			sb.append("\"");

			sb.append(_escape(accountName));

			sb.append("\"");
		}

		String ban = getBan();

		if (ban != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"ban\": ");

			sb.append("\"");

			sb.append(_escape(ban));

			sb.append("\"");
		}

		String banSystemId = getBanSystemId();

		if (banSystemId != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"banSystemId\": ");

			sb.append("\"");

			sb.append(_escape(banSystemId));

			sb.append("\"");
		}

		String country = getCountry();

		if (country != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"country\": ");

			sb.append("\"");

			sb.append(_escape(country));

			sb.append("\"");
		}

		String parentAccountName = getParentAccountName();

		if (parentAccountName != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"parentAccountName\": ");

			sb.append("\"");

			sb.append(_escape(parentAccountName));

			sb.append("\"");
		}

		String product = getProduct();

		if (product != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"product\": ");

			sb.append("\"");

			sb.append(_escape(product));

			sb.append("\"");
		}

		String registeredSite = getRegisteredSite();

		if (registeredSite != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"registeredSite\": ");

			sb.append("\"");

			sb.append(_escape(registeredSite));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.vf.cove.billingqueries.dto.v1_0.GetBillingService",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}