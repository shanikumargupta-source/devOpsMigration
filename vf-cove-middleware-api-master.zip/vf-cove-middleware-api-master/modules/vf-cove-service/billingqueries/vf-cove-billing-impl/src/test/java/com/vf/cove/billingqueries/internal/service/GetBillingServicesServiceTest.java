package com.vf.cove.billingqueries.internal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vf.cove.billingqueries.dto.v1_0.GetBillingServicesRequest;
import com.vf.cove.billingqueries.dto.v1_0.GetBillingServicesResponse;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class GetBillingServicesServiceTest {
	@Mock
	private CoveRequestParser coveRequestParser;

	@Mock
	GetBillingServicesRequest getBillingServicesRequest;

	@Mock
    private CoveResponseParser coveResponseParser;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	@InjectMocks
	GetBillingServicesService getBillingServicesService;

	private static final String MESSAGE_ID = "testMessageId";

	private CoveResponse esbResponse;
    private JsonNode jsonNode;
    private static ObjectMapper mapper = new ObjectMapper();


	@BeforeEach
	public void setUp() throws Exception {
		mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true);

		esbResponse = new CoveResponse();
		when(coveRequestParser.parseRequestToJson(getBillingServicesRequest)).thenReturn("REQUEST");
		when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
		Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("HEADER", "COVE");
        esbResponse.setHeaders(responseHeaders);
        jsonNode = mapper.readTree("{\r\n"
        		+ "		\"root\": \"roor\",\r\n"
        		+ "		\"ban\": \"123\",\r\n"
        		+ "  		\"banSystemId\": \"123\",\r\n"
        		+ "  		\"accountName\": \"Vodafone\",\r\n"
        		+ "  		\"parentAccountName\": \"Vodafone\",\r\n"
        		+ "  		\"product\": \"product\",\r\n"
        		+ "  		\"country\": \"UK\",\r\n"
        		+ "  		\"registeredSite\": \"test.com\"\r\n"
        		+ "	}");
        when(coveResponseParser.parse(any(InputStream.class),eq(esbResponse.getData()))).thenReturn(jsonNode);

	}

	@Test
	public void getBillingServicesSuccessResponse() throws Exception {
		when(coveResponseParser.getCoveMapper()).thenReturn(mapper);
		when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		GetBillingServicesResponse bResponse = getBillingServicesService.postGetBillingService("getBillingServicesRequest",
				MESSAGE_ID);
		Assertions.assertThat(bResponse).isNotNull();
	}
}
