package com.vf.cove.billingqueries.internal.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.billingqueries.dto.v1_0.GetPriorityBQRequest;
import com.vf.cove.billingqueries.dto.v1_0.GetPriorityBQResponse;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.DXLAPIRequest;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.test.common.util.TestUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class GetPriorityBQServiceTest {


	@Mock
	private CoveRequestParser coveRequestParser;

	@Mock
	GetPriorityBQRequest getPriorityBQRequest;

	@Mock
	private RestAPIProcessor restAPIProcessor;

	@Mock
    private CoveResponseParser coveResponseParser;

	@InjectMocks
	GetPriorityBQService getPriorityBQService;

	private String SuccessResponse;
	private String FailureResponse;
	private static final String MESSAGE_ID = "testMessageId";
	private CoveResponse esbResponse;
	private JsonNode jsonNode;
    private static ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	public void setUp() throws Exception {
		mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        mapper.configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true);
		SuccessResponse = TestUtils.inputStreamToString("src/test/resources/PriorityBQSuccessResp.json");
		FailureResponse = TestUtils.inputStreamToString("src/test/resources/ErrorResponse.json");
		esbResponse = new CoveResponse();
		when(coveRequestParser.parseRequestToJson(getPriorityBQRequest)).thenReturn("REQUEST");
		when(restAPIProcessor.createDefaultRequest(anyString())).thenReturn(new DXLAPIRequest());
		Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put("HEADER", "COVE");
        esbResponse.setHeaders(responseHeaders);
        jsonNode = mapper.readTree(SuccessResponse);
        when(coveResponseParser.parse(any(InputStream.class),eq(esbResponse.getData()))).thenReturn(jsonNode);

        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setAttribute("sourceSystemHeader","sourceSystemHeader");
        ServiceContextThreadLocal.pushServiceContext(serviceContext);


    }

	@Test
	public void getLatestBillingQueriesSuccessResponse() throws Exception {
		when(coveResponseParser.getCoveMapper()).thenReturn(mapper);
		esbResponse.setData(SuccessResponse);
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		GetPriorityBQResponse pBQResponse = getPriorityBQService.postGetLatestBillingQuery(getPriorityBQRequest,
				MESSAGE_ID);
		Assertions.assertThat(pBQResponse).isNotNull();
	}

	@Test
	public void getLatestBillingQueriesFailureResponse() throws Exception {
		when(coveResponseParser.getCoveMapper()).thenReturn(mapper);
		esbResponse.setData(FailureResponse);
        when(restAPIProcessor.post(any(RestAPIRequest.class))).thenReturn(esbResponse);
		Assertions
				.assertThatThrownBy(
						() -> getPriorityBQService.postGetLatestBillingQuery(getPriorityBQRequest, MESSAGE_ID))
				.isInstanceOf(DataNotFoundException.class);
	}
}
