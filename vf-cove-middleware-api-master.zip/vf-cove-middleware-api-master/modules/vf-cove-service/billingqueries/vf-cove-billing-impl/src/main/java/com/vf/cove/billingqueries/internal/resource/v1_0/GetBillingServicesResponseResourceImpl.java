package com.vf.cove.billingqueries.internal.resource.v1_0;

import com.liferay.portal.kernel.exception.PortalException;
import com.vf.cove.billingqueries.dto.v1_0.GetBillingServicesRequest;
import com.vf.cove.billingqueries.dto.v1_0.GetBillingServicesResponse;
import com.vf.cove.billingqueries.dto.v1_0.SortOrder;
import com.vf.cove.billingqueries.internal.constants.BillingConstants;
import com.vf.cove.billingqueries.internal.service.GetBillingServicesService;
import com.vf.cove.billingqueries.resource.v1_0.GetBillingServicesResponseResource;
import com.vf.cove.core.ftlutils.service.FtlTemplateService;
import com.vf.cove.core.ftlutils.utils.StreamToStringUtil;
import com.vf.cove.core.restutils.configuration.RestServicesCommonConfigurationHelper;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Virtusa
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/get-billing-services-response.properties", scope = ServiceScope.PROTOTYPE, service = GetBillingServicesResponseResource.class)
public class GetBillingServicesResponseResourceImpl extends BaseGetBillingServicesResponseResourceImpl {
	private static final Logger LOGGER = LoggerFactory.getLogger(GetBillingServicesResponseResourceImpl.class);

	@Reference(unbind = "-")
	private GetBillingServicesService getBillingServicesService;

	@Reference(unbind = "-")
	private RestServicesCommonConfigurationHelper configHelper;

	@Reference(unbind = "-")
	private CoveRequestParser coveRequestParser;
    @Reference(unbind = "-")
    private FtlTemplateService ftlTemplateService;

	@Override
	public GetBillingServicesResponse postGetBillingService(GetBillingServicesRequest getBillingServicesRequest)
			throws Exception {
		String messageId = RequestUtils.getUUID();
		LOGGER.info("Invoking postGetBillingService API for messageId {} ", messageId);
        if (getBillingServicesRequest.getRecordsPerPage() == null) {
            getBillingServicesRequest.setRecordsPerPage(configHelper.billingServicesDefaultCount());
        }
        if (getBillingServicesRequest.getPageIndex() == null) {
            getBillingServicesRequest.setPageIndex(0);
        }
        Map<String, Object> params = populateParams(getBillingServicesRequest);
        params.put(Constants.REQUEST_PARAM_NAME, getBillingServicesRequest);

        final InputStream resourceAsStream = this.getClass().getResourceAsStream(BillingConstants.GET_BILLING_SERVICES_API_REQUEST_DEFINITION);
        String templateStr = StreamToStringUtil.getString(resourceAsStream);
        String request = ftlTemplateService.renderTemplate(BillingConstants.GET_BILLING_SERVICES_API_REQUEST_DEFINITION, templateStr, params);
        return getBillingServicesService.postGetBillingService(request, messageId);

	}

	private Map<String, Object> populateParams(GetBillingServicesRequest getBillingServicesRequest)
			throws PortalException, IOException {

		Map<String, Object> additionalParams = new HashMap<>();
		if (ObjectUtils.isNotEmpty(contextUser)) {
			if (contextUser.getOrganizations() != null && !contextUser.getOrganizations().isEmpty()
					&& contextUser.getOrganizations().get(0) != null) {
				additionalParams.put(BillingConstants.ORGANIZATION_ID, String.valueOf(
						contextUser.getOrganizations().get(0).getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
			}
			additionalParams.put(BillingConstants.USER_ID, contextUser.getEmailAddress());
		}

		additionalParams.put(BillingConstants.BAN, getBillingServicesRequest.getBan());
		additionalParams.put(BillingConstants.ACCOUNT_NAME, getBillingServicesRequest.getAccountName());
		additionalParams.put(BillingConstants.PRODUCT, getBillingServicesRequest.getProduct());
		additionalParams.put(BillingConstants.COUNTRY, getBillingServicesRequest.getCountry());
		additionalParams.put(BillingConstants.PARENT_ACCOUNT_NAME, getBillingServicesRequest.getParentAccountName());
		additionalParams.put(BillingConstants.SORTING_PARAM, getSortOrder(getBillingServicesRequest.getSortOrder(),
				BillingConstants.GET_BILLING_SERVICES_API_RESPONSE_DEFINITION));

		return additionalParams;
	}

	private  String getSortOrder(@Valid SortOrder[] sortOrders, String responseParserFileName)
			throws IOException {
		if (sortOrders != null && sortOrders.length > 0) {
			StringBuilder stringBuilder = new StringBuilder();

			for (int i = 1; i <= sortOrders.length; i++) {
				if (StringUtils.equalsIgnoreCase(sortOrders[i - 1].getValue(), Constants.ASC)) {
					stringBuilder.append(Constants.PLUS);
				} else {
					stringBuilder.append(Constants.MINUS);
				}
				InputStream in = GetBillingServicesResponseResourceImpl.class
						.getResourceAsStream(responseParserFileName);
				stringBuilder.append(coveRequestParser.getESBSortParam(sortOrders[i - 1].getKey(), in));
				if (i != sortOrders.length) {
					stringBuilder.append(Constants.COMMA);
				}
			}
			return stringBuilder.toString();
		}
		return StringUtils.EMPTY;
	}
}
