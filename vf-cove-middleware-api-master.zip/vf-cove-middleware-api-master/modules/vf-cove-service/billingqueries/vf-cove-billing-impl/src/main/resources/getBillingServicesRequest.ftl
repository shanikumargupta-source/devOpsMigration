<@compress single_line=true>
{
	"queryOptions": {
		"pagination": {
            "count": ${request.pageIndex},
            "limit": ${request.recordsPerPage}
		}<#if sorting?has_content>,
		"sorting": "${sorting}"
		</#if>
	},
	"queries": [
		<#if organizationId?has_content>
		{
			"query": "$.customerAccount.id.value=${organizationId}"
		}</#if><#if userId?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.relatedParty[*].contactPerson.contactPoint[*].id.value=${userId}"
		}</#if><#if request.ban?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.id=${ban}"
		}</#if><#if request.accountName?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.name=${accountName}"
		}</#if><#if request.product?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.category[?(@.listName=='product')].value=${request.product}"
		}</#if><#if request.parentAccountName?has_content>,
		{
			"operator": "AND"
		},
		{
			"query": "$.relatedParty[*].id=${request.parentAccountName}"
		}</#if><#if request.isCompanySearch?has_content>
		,
		{
			"query": "$.characteristics[?(@.characteristicName=='companySearchFlag')].value=${request.isCompanySearch?c}"
		}
		</#if>
	]
}
</@compress>