package com.vf.cove.billingqueries.internal.resource.v1_0;

import com.vf.cove.billingqueries.dto.v1_0.GetPriorityBQRequest;
import com.vf.cove.billingqueries.dto.v1_0.GetPriorityBQResponse;
import com.vf.cove.billingqueries.internal.constants.BillingConstants;
import com.vf.cove.billingqueries.internal.service.GetPriorityBQService;
import com.vf.cove.billingqueries.resource.v1_0.GetPriorityBQResponseResource;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.ValidationException;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Virtusa
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/get-priority-bq-response.properties", scope = ServiceScope.PROTOTYPE, service = GetPriorityBQResponseResource.class)
public class GetPriorityBQResponseResourceImpl extends BaseGetPriorityBQResponseResourceImpl {
	private static final Logger LOGGER = LoggerFactory.getLogger(GetPriorityBQResponseResourceImpl.class);

	@Reference(unbind = "-")
	private GetPriorityBQService getPriorityBQService;

	@Override
	public GetPriorityBQResponse postGetLatestBillingQuery(GetPriorityBQRequest getPriorityBQRequest) throws Exception {
		String messageId = RequestUtils.getUUID();
		LOGGER.info("Invoking postGetLatestBillingQuery API for messageId {} " + messageId);
        requiredFieldValadation(getPriorityBQRequest);
        if (ObjectUtils.isNotEmpty(getPriorityBQRequest) && ObjectUtils.isNotEmpty(contextUser)) {
            getPriorityBQRequest.setUserId(contextUser.getEmailAddress());
            getPriorityBQRequest.setCurrentDate(RequestUtils.getUTCDate());
            getPriorityBQRequest.setOamuserId(contextUser.getEmailAddress());
            if (contextUser.getOrganizations().size() > 0) {
                getPriorityBQRequest.setCustomerId(String.valueOf(contextUser.getOrganizations().get(0)
                    .getExpandoBridge().getAttribute(Constants.LEGAL_ORG_ID)));
            }
            getPriorityBQRequest.setMessageId(messageId);
            return getPriorityBQService.postGetLatestBillingQuery(getPriorityBQRequest, messageId);
        }
		return new GetPriorityBQResponse();
	}
    private void requiredFieldValadation(GetPriorityBQRequest getPriorityBQRequest) throws Exception{
        LOGGER.debug("Inside GetPriorityBQRequest - requiredFieldValidations()");
        if(StringUtils.isEmpty(getPriorityBQRequest.getRequestType()) || ObjectUtils.isEmpty(getPriorityBQRequest.getPageIndex())
        || ObjectUtils.isEmpty(getPriorityBQRequest.getRecordsPerPage()) || getPriorityBQRequest.getStatus() == null
        || getPriorityBQRequest.getStatus().length == 0) {
            throw new ValidationException(BillingConstants.ERROR_CODE_400,
            BillingConstants.MISSING_REQUIRED_ATTRIBUTES);
        }
    }
}
