package com.vf.cove.billingqueries.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vf.cove.billingqueries.dto.v1_0.GetBillingService;
import com.vf.cove.billingqueries.dto.v1_0.GetBillingServicesResponse;
import com.vf.cove.billingqueries.internal.constants.BillingConstants;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import com.vf.cove.core.restutils.utils.RequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Virtusa
 */
@Component(service = GetBillingServicesService.class)
public class GetBillingServicesService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GetBillingServicesService.class);

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	@Reference(target = "(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	public GetBillingServicesResponse postGetBillingService(String request,
			String messageId) throws Exception {
		GetBillingServicesResponse coveResponse = new GetBillingServicesResponse();

        String relativeUrl = BillingConstants.GET_BILLING_SERVICES_API_URL;

        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);
        restAPIRequest.addHeaders(populateHeaders(messageId));
		CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);
		String esbResponseBody = dxlResponse.getData();
		if (StringUtils.isNotEmpty(esbResponseBody)) {
			LOGGER.debug("ESB Raw Response {}", esbResponseBody);
			if (StringUtils.isNotEmpty(esbResponseBody)) {
				InputStream in = GetBillingServicesService.class
						.getResourceAsStream(BillingConstants.GET_BILLING_SERVICES_API_RESPONSE_DEFINITION);
				JsonNode transformedJsonNode = responseParser.parse(in, esbResponseBody);
				LOGGER.debug("Transformed Response {}", transformedJsonNode);
				List<GetBillingService> getBillingServiceList = new ArrayList<>();
				transformedJsonNode.forEach(node -> {
                    GetBillingService addressLookup = null;
					try {
						addressLookup = responseParser.getCoveMapper().readValue(node.toString(), GetBillingService.class);
					} catch (Exception e) {
						LOGGER.error("Exception :", e);
					}
					if (addressLookup != null) {
						getBillingServiceList.add(addressLookup);
					}
				});

				coveResponse.setGetBillingServices(
						getBillingServiceList.toArray(new GetBillingService[getBillingServiceList.size()]));
				Map<String, String> header = dxlResponse.getHeaders();
				String totalCount = header.get(Constants.TOTAL_COUNT_HEADER);

				coveResponse.setTotalcount(responseParser.getCoveMapper().readValue(totalCount, String.class));

			}
		}
		return coveResponse;
	}

    private Map<String, String> populateHeaders(String messageId) {
        String sysDate = RequestUtils.getUTCDate();
		String correlationId = RequestUtils.getUUID();
        Map<String, String> headers = new HashMap<>();
        headers.put(Constants.CORRELATION_ID_HEADER, correlationId);
        headers.put(Constants.COUNTRY_CODE, Constants.UK_CODE);
        headers.put(Constants.SOURCE_OPERATOR, Constants.VODAFONE);
        headers.put(Constants.SOURCE_TIMESTAMP, sysDate.substring(0, sysDate.length() - 5));
        headers.put(Constants.MESSAGE_ID, messageId);
        return headers;
    }

}
