package com.vf.cove.billingqueries.internal.constants;

public class BillingConstants {
    private BillingConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String INTERNAL_SERVER_ERROR = "Internal server error";

	public static final String MISSING_REQUIRED_ATTRIBUTES = "Missing required attributes as part of the request";

	public static final String NO_DATA_FOUND = "No data found";

	public static final String STATUS_CODE = "1";

	public static final String RESPONSE_DATA = "responseData";

	public static final String RESPONSE = "response";

	public static final String STATUS = "status";

	public static final String CARDS_DATA = "CardsData";

	public static final String TOTAL_COUNT = "TotalCount";

	public static final int ERROR_CODE_500 = 500;

	public static final int ERROR_CODE_400 = 400;

	public static final int ERROR_CODE_491 = 491;

	public static final String PRIORITY_BQS = "/cove/customerRequest/getLatestCustomerRequest";

	public static final String SORTING_PARAM = "sorting";
	public static final String ASC = "ASC";
	public static final String PLUS = "+";
	public static final String MINUS = "-";
	public static final String SORT_PREFIX = "$.";
	public static final String TYPE_PARAM = "type";
	public static final String ESB_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String COVE_DATE_FORMAT = "dd MMM yyyy HH:mm";
	public static final String NO_DATA = "No data found";
	public static final String ZERO_COUNT = "0";
	public static final String BAN = "ban";
	public static final String ACCOUNT_NAME = "accountName";
	public static final String PRODUCT = "product";
	public static final String ORGANIZATION_ID = "organizationId";
	public static final String USER_ID = "userId";
	public static final String PARENT_ACCOUNT_NAME = "parentAccountName";
	public static final String COUNTRY = "country";

	public static final String GET_BILLING_SERVICES_API_URL = "/auth/billingAccountAPI/v1/billingAccount/search";
	public static final String GET_BILLING_SERVICES_API_RESPONSE_DEFINITION = "/getBillingServicesResponse.json";
	public static final String GET_BILLING_SERVICES_API_REQUEST_DEFINITION = "/getBillingServicesRequest.ftl";
	public static final String CORRELATION_ID_HEADER = "X-Correlation-ConversationID";

    public static final String SOURCE_SYSTEM_HEADER = "X-Source-System";
}
