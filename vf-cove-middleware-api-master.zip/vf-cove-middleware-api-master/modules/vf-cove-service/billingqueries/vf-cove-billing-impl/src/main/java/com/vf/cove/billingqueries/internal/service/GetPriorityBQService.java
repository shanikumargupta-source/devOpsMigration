package com.vf.cove.billingqueries.internal.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.vf.cove.billingqueries.dto.v1_0.GetLatestBillingQuery;
import com.vf.cove.billingqueries.dto.v1_0.GetPriorityBQRequest;
import com.vf.cove.billingqueries.dto.v1_0.GetPriorityBQResponse;
import com.vf.cove.billingqueries.internal.constants.BillingConstants;
import com.vf.cove.core.restutils.constants.Constants;
import com.vf.cove.core.restutils.exception.DataNotFoundException;
import com.vf.cove.core.restutils.exception.ServiceException;
import com.vf.cove.core.restutils.model.CoveResponse;
import com.vf.cove.core.restutils.model.RestAPIRequest;
import com.vf.cove.core.restutils.service.RestAPIProcessor;
import com.vf.cove.core.restutils.utils.CoveRequestParser;
import com.vf.cove.core.restutils.utils.CoveResponseParser;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Virtusa
 */
@Component(service = GetPriorityBQService.class)
public class GetPriorityBQService {
	private static final Logger LOGGER = LoggerFactory.getLogger(GetPriorityBQService.class);

	@Reference(unbind = "-")
	private CoveResponseParser responseParser;

	@Reference(unbind = "-")
	private CoveRequestParser coveRequestParser;

	@Reference(target = "(backend=DXL)")
	private RestAPIProcessor restAPIProcessor;

	public GetPriorityBQResponse postGetLatestBillingQuery(GetPriorityBQRequest getPriorityBQRequest, String messageId)
			throws Exception {
		GetPriorityBQResponse coveResponse = new GetPriorityBQResponse();
		final String request = getPriorityBQRequest.toString();
        String relativeUrl = BillingConstants.PRIORITY_BQS;

        RestAPIRequest restAPIRequest = restAPIProcessor.createDefaultRequest(Constants.DESTINATION_SYSTEM_SNOW);
		restAPIRequest.setRelativeUrl(relativeUrl);
        restAPIRequest.setRequest(request);
        restAPIRequest.setTransactionId(messageId);
        String sourceSystem = getSourceSystemHeader();
        if(StringUtils.isNotEmpty(sourceSystem)){
            restAPIRequest.addHeader(BillingConstants.SOURCE_SYSTEM_HEADER,sourceSystem);
        }
		CoveResponse dxlResponse = restAPIProcessor.post(restAPIRequest);

		if (StringUtils.isEmpty(dxlResponse.getData())) {
			throw new ServiceException(BillingConstants.ERROR_CODE_500, BillingConstants.INTERNAL_SERVER_ERROR);
		}
		JsonNode rootNode = responseParser.getCoveMapper().readTree(dxlResponse.getData());
		JsonNode responseData = rootNode.get(BillingConstants.RESPONSE_DATA);

		JsonNode responseStatus = responseData.get(BillingConstants.STATUS);
		String status = responseParser.getCoveMapper().readValue(responseStatus.toString(), String.class);
		if (status.equalsIgnoreCase(BillingConstants.STATUS_CODE)) {
			throw new DataNotFoundException(BillingConstants.ERROR_CODE_491, BillingConstants.NO_DATA_FOUND);
		}

		JsonNode response = responseData.get(BillingConstants.RESPONSE);
		List<GetLatestBillingQuery> getLatestBillingQueryList = new ArrayList<>();
		ArrayNode arrayNode = (ArrayNode) response.get(BillingConstants.CARDS_DATA);
		arrayNode.forEach(node -> {
			try {
				LOGGER.debug(" node {} " + node);
				getLatestBillingQueryList
						.add(responseParser.getCoveMapper().readValue(node.toString(), GetLatestBillingQuery.class));
			} catch (IOException e) {
				LOGGER.error("Exception {} ", e);
			}
		});

		coveResponse.setGetLatestBillingQueries(
				getLatestBillingQueryList.toArray(new GetLatestBillingQuery[getLatestBillingQueryList.size()]));
		return coveResponse;
	}

    private String getSourceSystemHeader(){
        ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
        String sourceSystemHeader = (String)serviceContext.getAttribute("sourceSystemHeader");
        LOGGER.info("sourceSystemHeader  ..." +sourceSystemHeader);
        return sourceSystemHeader;
    }

}
